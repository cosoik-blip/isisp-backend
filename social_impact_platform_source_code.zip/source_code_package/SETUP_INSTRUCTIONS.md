# Social Impact Project Management Platform - Setup Instructions

## Overview
This is the complete source code for the Social Impact Project Management Platform with role-based access control for Administrators, Investors, and Social Actors.

## Tech Stack
- **Backend:** FastAPI (Python)
- **Frontend:** React.js
- **Database:** MongoDB
- **Styling:** Tailwind CSS with Shadcn UI components

## Prerequisites
- Python 3.8+
- Node.js 16+
- MongoDB
- Yarn package manager

## Setup Instructions

### 1. Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set environment variables
# Edit .env file and update MONGO_URL to your MongoDB connection string

# Run the backend server
python server.py
```

The backend will run on `http://localhost:8001`

### 2. Frontend Setup

```bash
cd frontend

# Install dependencies
yarn install

# Set environment variables
# Edit .env file and update REACT_APP_BACKEND_URL to your backend URL
# For local development: REACT_APP_BACKEND_URL=http://localhost:8001

# Start the development server
yarn start
```

The frontend will run on `http://localhost:3000`

### 3. Database Setup

1. Install and start MongoDB
2. The application will automatically create the database and collections
3. Use the "Initialize Sample Data" button on the login page to create test users and projects

### 4. Default Test Users

After initializing sample data, you can login with:

- **Administrator:** username: `admin`, password: `admin123`
- **Investor:** username: `investor_demo`, password: `investor123`
- **Social Actor:** username: `social_demo`, password: `social123`

## Key Features

### Administrator Features
- Complete platform oversight
- User management (create, edit, delete users)
- Platform reports and analytics with PDF export
- Electronic library management (add, edit, delete instruments)
- Platform settings configuration
- Source code documentation download

### Investor Features
- Investment project tracking
- Portfolio analytics
- Document access and reviews
- Project progress monitoring

### Social Actor Features
- Project implementation tracking
- Beneficiary management
- Field reporting and evidence collection
- Compliance monitoring

## API Documentation

The backend includes comprehensive API endpoints:

- **Authentication:** `/api/auth/login`, `/api/auth/register`
- **Projects:** `/api/projects/*` 
- **Template Library:** `/api/template-library/*`
- **User Management:** `/api/admin/users/*` (Admin only)
- **Reports:** `/api/admin/reports/*` (Admin only)
- **Platform Settings:** `/api/admin/settings/*` (Admin only)

## File Structure

```
├── backend/
│   ├── server.py          # Main FastAPI application
│   ├── requirements.txt   # Python dependencies
│   └── .env              # Environment variables
├── frontend/
│   ├── src/
│   │   ├── components/   # React components
│   │   ├── hooks/       # Custom React hooks
│   │   └── lib/         # Utility functions
│   ├── package.json     # Node.js dependencies
│   └── .env            # Frontend environment variables
└── documentation/       # User guides and documentation
```

## Deployment Considerations

1. **Environment Variables:** Update `.env` files for production URLs
2. **Database:** Configure MongoDB for production use
3. **Security:** Change default passwords and JWT secret
4. **CORS:** Update CORS settings in server.py for production domains
5. **File Storage:** Configure appropriate file storage for uploaded documents

## Support

For technical issues or questions about the platform functionality, refer to the included user guides:
- `USER_GUIDE_ADMINISTRATOR.md`
- `USER_GUIDE_INVESTOR.md` 
- `USER_GUIDE_SOCIAL_ACTOR.md`
- `COMPLETE_SOURCE_CODE_DOCUMENTATION.md`

## License

This software is proprietary. All rights reserved.