import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Progress } from './ui/progress';
import { Checkbox } from './ui/checkbox';
import { toast } from 'sonner';
import { 
  CheckSquare, 
  Plus, 
  Edit3, 
  Trash2, 
  FileText, 
  MessageSquare, 
  Calendar,
  User,
  BarChart3,
  Target,
  Clock,
  CheckCircle2
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const DigitalChecklists = ({ projectId, user }) => {
  const [checklists, setChecklists] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [selectedChecklist, setSelectedChecklist] = useState(null);
  const [loading, setLoading] = useState(true);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [newChecklistForm, setNewChecklistForm] = useState({
    title: '',
    description: '',
    template_type: 'custom',
    deliverable_id: '',
    items: []
  });

  useEffect(() => {
    fetchChecklists();
    fetchTemplates();
  }, [projectId]);

  const fetchChecklists = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/projects/${projectId}/digital-checklists`);
      setChecklists(response.data);
      if (response.data.length > 0 && !selectedChecklist) {
        setSelectedChecklist(response.data[0]);
      }
    } catch (error) {
      console.error('Error fetching checklists:', error);
      toast.error('Failed to load checklists');
    } finally {
      setLoading(false);
    }
  };

  const fetchTemplates = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/projects/${projectId}/checklist-templates`);
      setTemplates(response.data);
    } catch (error) {
      console.error('Error fetching templates:', error);
    }
  };

  const handleCreateChecklist = async () => {
    try {
      const response = await axios.post(
        `${BACKEND_URL}/api/projects/${projectId}/digital-checklists`,
        newChecklistForm
      );
      setChecklists([...checklists, response.data]);
      setCreateDialogOpen(false);
      setNewChecklistForm({
        title: '',
        description: '',
        template_type: 'custom',
        deliverable_id: '',
        items: []
      });
      toast.success('Digital checklist created successfully');
    } catch (error) {
      console.error('Error creating checklist:', error);
      toast.error('Failed to create checklist');
    }
  };

  const handleTemplateSelect = (templateId) => {
    const template = templates.find(t => t.id === templateId);
    if (template) {
      setNewChecklistForm(prev => ({
        ...prev,
        template_type: templateId,
        title: template.name,
        description: template.description,
        items: template.items.map(item => ({
          id: Math.random().toString(36).substr(2, 9),
          text: item.text,
          required: item.required,
          completed: false,
          comments: ''
        }))
      }));
    }
  };

  const handleUpdateChecklistItem = async (checklistId, itemId, updates) => {
    try {
      const checklist = checklists.find(c => c.id === checklistId);
      const updatedItems = checklist.items.map(item => 
        item.id === itemId 
          ? { ...item, ...updates, updated_at: new Date().toISOString() }
          : item
      );

      const response = await axios.patch(
        `${BACKEND_URL}/api/projects/${projectId}/digital-checklists/${checklistId}`,
        { items: updatedItems }
      );

      setChecklists(checklists.map(c => 
        c.id === checklistId ? response.data : c
      ));

      if (selectedChecklist && selectedChecklist.id === checklistId) {
        setSelectedChecklist(response.data);
      }

      toast.success('Checklist updated successfully');
    } catch (error) {
      console.error('Error updating checklist:', error);
      toast.error('Failed to update checklist');
    }
  };

  const handleDeleteChecklist = async (checklistId) => {
    try {
      await axios.delete(`${BACKEND_URL}/api/projects/${projectId}/digital-checklists/${checklistId}`);
      setChecklists(checklists.filter(c => c.id !== checklistId));
      if (selectedChecklist && selectedChecklist.id === checklistId) {
        setSelectedChecklist(checklists[0] || null);
      }
      toast.success('Checklist deleted successfully');
    } catch (error) {
      console.error('Error deleting checklist:', error);
      toast.error('Failed to delete checklist');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in_progress': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Digital Checklists</h2>
          <p className="text-gray-600">Manage deliverable checklists and track progress</p>
        </div>
        {user.role !== 'investor' && (
          <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center space-x-2">
                <Plus className="h-4 w-4" />
                <span>Create Checklist</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create Digital Checklist</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={newChecklistForm.title}
                    onChange={(e) => setNewChecklistForm(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Enter checklist title"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newChecklistForm.description}
                    onChange={(e) => setNewChecklistForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Enter checklist description"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="template">Template</Label>
                  <Select onValueChange={handleTemplateSelect}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a template (optional)" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="custom">Custom Checklist</SelectItem>
                      {templates.map(template => (
                        <SelectItem key={template.id} value={template.id}>
                          {template.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateChecklist} disabled={!newChecklistForm.title}>
                    Create Checklist
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckSquare className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Total Checklists</p>
                <p className="text-2xl font-bold text-gray-900">{checklists.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Completed</p>
                <p className="text-2xl font-bold text-gray-900">
                  {checklists.filter(c => c.completion_percentage === 100).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">In Progress</p>
                <p className="text-2xl font-bold text-gray-900">
                  {checklists.filter(c => c.completion_percentage > 0 && c.completion_percentage < 100).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-5 w-5 text-purple-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Progress</p>
                <p className="text-2xl font-bold text-gray-900">
                  {checklists.length > 0 
                    ? Math.round(checklists.reduce((sum, c) => sum + c.completion_percentage, 0) / checklists.length)
                    : 0}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Checklists List */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="h-5 w-5" />
                <span>Checklists</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-2 p-4">
                {checklists.map(checklist => (
                  <div
                    key={checklist.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      selectedChecklist?.id === checklist.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setSelectedChecklist(checklist)}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <h4 className="font-medium text-gray-900 truncate">{checklist.title}</h4>
                      <Badge className={getStatusColor(checklist.status)}>
                        {checklist.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-2 line-clamp-2">{checklist.description}</p>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-gray-500">Progress</span>
                        <span className="text-xs font-medium text-gray-700">
                          {checklist.completion_percentage}%
                        </span>
                      </div>
                      <Progress value={checklist.completion_percentage} className="h-2" />
                    </div>

                    <div className="flex justify-between items-center mt-2">
                      <span className="text-xs text-gray-500">
                        {checklist.items?.length || 0} items
                      </span>
                      {user.role !== 'investor' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteChecklist(checklist.id);
                          }}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
                {checklists.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <CheckSquare className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <p>No checklists created yet</p>
                    <p className="text-sm">Create your first checklist to get started</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Checklist Details */}
        <div className="lg:col-span-2">
          {selectedChecklist ? (
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center space-x-2">
                      <Target className="h-5 w-5" />
                      <span>{selectedChecklist.title}</span>
                    </CardTitle>
                    <p className="text-gray-600 mt-1">{selectedChecklist.description}</p>
                  </div>
                  <Badge className={getStatusColor(selectedChecklist.status)}>
                    {selectedChecklist.completion_percentage}% Complete
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-gray-700">Overall Progress</span>
                      <span className="text-sm text-gray-600">
                        {selectedChecklist.items?.filter(item => item.completed).length || 0} of {selectedChecklist.items?.length || 0} completed
                      </span>
                    </div>
                    <Progress value={selectedChecklist.completion_percentage} className="h-3" />
                  </div>

                  {/* Checklist Items */}
                  <div className="space-y-3">
                    {selectedChecklist.items?.map(item => (
                      <div key={item.id} className="border rounded-lg p-4 space-y-3">
                        <div className="flex items-start space-x-3">
                          <Checkbox
                            checked={item.completed}
                            onCheckedChange={(checked) => {
                              if (user.role !== 'investor') {
                                handleUpdateChecklistItem(selectedChecklist.id, item.id, {
                                  completed: checked,
                                  completed_by: checked ? user.id : null,
                                  completed_at: checked ? new Date().toISOString() : null
                                });
                              }
                            }}
                            disabled={user.role === 'investor'}
                            className="mt-1"
                          />
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center space-x-2">
                              <p className={`font-medium ${item.completed ? 'line-through text-gray-500' : 'text-gray-900'}`}>
                                {item.text}
                              </p>
                              {item.required && (
                                <Badge variant="outline" className="text-xs">Required</Badge>
                              )}
                            </div>
                            
                            {item.comments && (
                              <div className="bg-gray-50 p-2 rounded text-sm text-gray-700">
                                <MessageSquare className="h-3 w-3 inline mr-1" />
                                {item.comments}
                              </div>
                            )}

                            {item.completed && item.completed_at && (
                              <div className="flex items-center space-x-4 text-xs text-gray-500">
                                <div className="flex items-center space-x-1">
                                  <Calendar className="h-3 w-3" />
                                  <span>{new Date(item.completed_at).toLocaleDateString()}</span>
                                </div>
                                {item.completed_by && (
                                  <div className="flex items-center space-x-1">
                                    <User className="h-3 w-3" />
                                    <span>Completed by user</span>
                                  </div>
                                )}
                              </div>
                            )}

                            {user.role !== 'investor' && (
                              <div className="space-y-2">
                                <Textarea
                                  placeholder="Add comments..."
                                  value={item.comments || ''}
                                  onChange={(e) => {
                                    handleUpdateChecklistItem(selectedChecklist.id, item.id, {
                                      comments: e.target.value
                                    });
                                  }}
                                  className="text-sm"
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {(!selectedChecklist.items || selectedChecklist.items.length === 0) && (
                    <div className="text-center py-8 text-gray-500">
                      <CheckSquare className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>No checklist items yet</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-8 text-center text-gray-500">
                <CheckSquare className="h-16 w-16 mx-auto mb-4 text-gray-300" />
                <p className="text-lg font-medium">Select a checklist to view details</p>
                <p>Choose a checklist from the left panel to see its items and progress</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default DigitalChecklists;