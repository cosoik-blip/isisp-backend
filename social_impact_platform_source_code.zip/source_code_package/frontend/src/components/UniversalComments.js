import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Separator } from './ui/separator';
import { toast } from 'sonner';
import { 
  MessageCircle, 
  Plus, 
  Send,
  Reply,
  Edit3,
  Trash2,
  Clock,
  CheckCircle2,
  AlertCircle,
  User,
  Tag,
  Paperclip,
  AtSign,
  Eye,
  EyeOff,
  ThumbsUp,
  Flag,
  MoreHorizontal
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const UniversalComments = ({ 
  projectId, 
  user, 
  itemType = "general", 
  itemId = null,
  title = "Comments"
}) => {
  const [comments, setComments] = useState([]);
  const [pendingComments, setPendingComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCommentDialog, setShowCommentDialog] = useState(false);
  const [replyingTo, setReplyingTo] = useState(null);
  const [editingComment, setEditingComment] = useState(null);
  const [newComment, setNewComment] = useState({
    content: '',
    priority: 'normal',
    tags: '',
    mentions: '',
    attachments: []
  });

  useEffect(() => {
    fetchComments();
    if (user.role === 'administrator') {
      fetchPendingComments();
    }
  }, [projectId, itemType, itemId]);

  const fetchComments = async () => {
    try {
      const params = { item_type: itemType };
      if (itemId) params.item_id = itemId;
      
      const response = await axios.get(`${BACKEND_URL}/api/projects/${projectId}/comments`, { params });
      setComments(response.data);
    } catch (error) {
      console.error('Error fetching comments:', error);
      toast.error('Failed to load comments');
    } finally {
      setLoading(false);
    }
  };

  const fetchPendingComments = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/projects/${projectId}/comments/pending-approval`);
      setPendingComments(response.data);
    } catch (error) {
      console.error('Error fetching pending comments:', error);
    }
  };

  const handleCreateComment = async () => {
    try {
      const tags = newComment.tags ? newComment.tags.split(',').map(tag => tag.trim()) : [];
      const mentions = newComment.mentions ? newComment.mentions.split(',').map(mention => mention.trim()) : [];
      
      const commentData = {
        content: newComment.content,
        item_type: itemType,
        item_id: itemId,
        parent_comment_id: replyingTo?.id || null,
        priority: newComment.priority,
        tags: tags,
        mentions: mentions,
        attachments: newComment.attachments
      };

      const response = await axios.post(`${BACKEND_URL}/api/projects/${projectId}/comments`, commentData);
      
      if (user.role === 'investor') {
        toast.success('Comment submitted for approval');
      } else {
        setComments([...comments, response.data]);
        toast.success('Comment added successfully');
      }
      
      setShowCommentDialog(false);
      setReplyingTo(null);
      setNewComment({
        content: '',
        priority: 'normal',
        tags: '',
        mentions: '',
        attachments: []
      });
      
      // Refresh comments and pending if admin
      fetchComments();
      if (user.role === 'administrator') {
        fetchPendingComments();
      }
    } catch (error) {
      console.error('Error creating comment:', error);
      toast.error('Failed to add comment');
    }
  };

  const handleApproveComment = async (commentId, approve = true) => {
    try {
      await axios.patch(`${BACKEND_URL}/api/projects/${projectId}/comments/${commentId}`, {
        approval_status: approve ? 'approved' : 'rejected'
      });
      
      toast.success(approve ? 'Comment approved' : 'Comment rejected');
      fetchComments();
      fetchPendingComments();
    } catch (error) {
      console.error('Error updating comment approval:', error);
      toast.error('Failed to update comment status');
    }
  };

  const handleEditComment = async (commentId, newContent) => {
    try {
      await axios.patch(`${BACKEND_URL}/api/projects/${projectId}/comments/${commentId}`, {
        content: newContent
      });
      
      toast.success('Comment updated successfully');
      setEditingComment(null);
      fetchComments();
    } catch (error) {
      console.error('Error updating comment:', error);
      toast.error('Failed to update comment');
    }
  };

  const handleDeleteComment = async (commentId) => {
    try {
      await axios.delete(`${BACKEND_URL}/api/projects/${projectId}/comments/${commentId}`);
      setComments(comments.filter(c => c.id !== commentId));
      toast.success('Comment deleted successfully');
    } catch (error) {
      console.error('Error deleting comment:', error);
      toast.error('Failed to delete comment');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'pending_approval': return 'bg-yellow-100 text-yellow-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'auto_approved': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'normal': return 'bg-blue-100 text-blue-800';
      case 'low': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const CommentCard = ({ comment, isReply = false }) => (
    <Card key={comment.id} className={`${isReply ? 'ml-8 mt-2' : 'mt-4'}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-3">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="text-xs">
                {comment.created_by_name?.charAt(0)?.toUpperCase() || 'U'}
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center space-x-2">
                <p className="font-medium text-sm">{comment.created_by_name}</p>
                <Badge variant="outline" className="text-xs">
                  {comment.created_by_role}
                </Badge>
                {comment.priority !== 'normal' && (
                  <Badge className={getPriorityColor(comment.priority)} variant="outline">
                    {comment.priority}
                  </Badge>
                )}
              </div>
              <p className="text-xs text-gray-500">
                {new Date(comment.created_at).toLocaleString()}
                {comment.is_edited && <span className="ml-2">(edited)</span>}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Badge className={getStatusColor(comment.approval_status)}>
              {comment.approval_status.replace('_', ' ')}
            </Badge>
            
            {user.role === 'administrator' && comment.approval_status === 'pending_approval' && (
              <div className="flex space-x-1">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleApproveComment(comment.id, true)}
                  className="text-green-600 hover:text-green-800"
                >
                  <CheckCircle2 className="h-3 w-3" />
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleApproveComment(comment.id, false)}
                  className="text-red-600 hover:text-red-800"
                >
                  <AlertCircle className="h-3 w-3" />
                </Button>
              </div>
            )}
          </div>
        </div>

        <div className="mb-3">
          {editingComment === comment.id ? (
            <div className="space-y-2">
              <Textarea
                defaultValue={comment.content}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && e.ctrlKey) {
                    handleEditComment(comment.id, e.target.value);
                  }
                }}
                className="min-h-[80px]"
              />
              <div className="flex space-x-2">
                <Button
                  size="sm"
                  onClick={(e) => {
                    const content = e.target.parentElement.previousElementSibling.value;
                    handleEditComment(comment.id, content);
                  }}
                >
                  Save
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setEditingComment(null)}
                >
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <p className="text-gray-900 whitespace-pre-wrap">{comment.content}</p>
          )}
        </div>

        {comment.tags && comment.tags.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {comment.tags.map((tag, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                <Tag className="h-2 w-2 mr-1" />
                {tag}
              </Badge>
            ))}
          </div>
        )}

        {comment.attachments && comment.attachments.length > 0 && (
          <div className="flex items-center space-x-2 mb-3 text-sm text-gray-600">
            <Paperclip className="h-3 w-3" />
            <span>{comment.attachments.length} attachment(s)</span>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            {!isReply && (
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  setReplyingTo(comment);
                  setShowCommentDialog(true);
                }}
                className="text-blue-600 hover:text-blue-800"
              >
                <Reply className="h-3 w-3 mr-1" />
                Reply
              </Button>
            )}
          </div>
          
          <div className="flex items-center space-x-1">
            {(comment.created_by === user.id || user.role === 'administrator') && (
              <>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setEditingComment(comment.id)}
                  className="text-gray-600 hover:text-gray-800"
                >
                  <Edit3 className="h-3 w-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleDeleteComment(comment.id)}
                  className="text-red-600 hover:text-red-800"
                >
                  <Trash2 className="h-3 w-3" />
                </Button>
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center p-4">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <MessageCircle className="h-5 w-5 text-blue-600" />
          <h3 className="text-lg font-semibold">{title}</h3>
          <Badge variant="outline" className="text-xs">
            {comments.length} comments
          </Badge>
        </div>
        
        <Dialog open={showCommentDialog} onOpenChange={setShowCommentDialog}>
          <DialogTrigger asChild>
            <Button size="sm" className="flex items-center space-x-2">
              <Plus className="h-4 w-4" />
              <span>{replyingTo ? 'Reply' : 'Add Comment'}</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {replyingTo ? `Reply to ${replyingTo.created_by_name}` : 'Add Comment'}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              {replyingTo && (
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Replying to:</p>
                  <p className="text-sm">{replyingTo.content}</p>
                </div>
              )}
              
              <div className="space-y-2">
                <Label htmlFor="content">Comment *</Label>
                <Textarea
                  id="content"
                  value={newComment.content}
                  onChange={(e) => setNewComment(prev => ({ ...prev, content: e.target.value }))}
                  placeholder="Enter your comment..."
                  className="min-h-[120px]"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="priority">Priority</Label>
                  <Select value={newComment.priority} onValueChange={(value) => setNewComment(prev => ({ ...prev, priority: value }))}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="tags">Tags (comma-separated)</Label>
                  <Input
                    id="tags"
                    value={newComment.tags}
                    onChange={(e) => setNewComment(prev => ({ ...prev, tags: e.target.value }))}
                    placeholder="e.g., budget, timeline, quality"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="mentions">Mentions (comma-separated user IDs)</Label>
                <Input
                  id="mentions"
                  value={newComment.mentions}
                  onChange={(e) => setNewComment(prev => ({ ...prev, mentions: e.target.value }))}
                  placeholder="Mention team members"
                />
              </div>
              
              {user.role === 'investor' && (
                <div className="bg-yellow-50 p-3 rounded-lg">
                  <p className="text-sm text-yellow-800">
                    <AlertCircle className="h-4 w-4 inline mr-1" />
                    Your comment will be sent for administrator approval before being visible to the team.
                  </p>
                </div>
              )}
              
              <div className="flex justify-end space-x-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowCommentDialog(false);
                    setReplyingTo(null);
                  }}
                >
                  Cancel
                </Button>
                <Button onClick={handleCreateComment} disabled={!newComment.content.trim()}>
                  <Send className="h-4 w-4 mr-2" />
                  {user.role === 'investor' ? 'Submit for Approval' : 'Add Comment'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Pending Comments (Admin Only) */}
      {user.role === 'administrator' && pendingComments.length > 0 && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center space-x-2">
              <Clock className="h-4 w-4 text-yellow-600" />
              <span>Pending Approval ({pendingComments.length})</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {pendingComments.map(comment => (
              <CommentCard key={comment.id} comment={comment} />
            ))}
          </CardContent>
        </Card>
      )}

      {/* Comments List */}
      <div className="space-y-2">
        {comments.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <MessageCircle className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p className="text-gray-500">No comments yet</p>
              <p className="text-sm text-gray-400">Be the first to add a comment</p>
            </CardContent>
          </Card>
        ) : (
          comments
            .filter(comment => !comment.parent_comment_id) // Only show top-level comments
            .map(comment => (
              <div key={comment.id}>
                <CommentCard comment={comment} />
                {/* Show replies */}
                {comments
                  .filter(reply => reply.parent_comment_id === comment.id)
                  .map(reply => (
                    <CommentCard key={reply.id} comment={reply} isReply={true} />
                  ))}
              </div>
            ))
        )}
      </div>
    </div>
  );
};

export default UniversalComments;