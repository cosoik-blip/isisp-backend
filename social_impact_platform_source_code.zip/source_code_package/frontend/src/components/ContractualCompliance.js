import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  FileText, 
  Plus, 
  Calendar, 
  DollarSign,
  AlertTriangle,
  CheckCircle2,
  Clock,
  TrendingUp,
  Target,
  ShieldCheck,
  AlertCircle,
  FileCheck,
  Gavel,
  Scale,
  Eye,
  Edit3,
  Trash2,
  Download,
  Upload,
  User,
  Activity,
  Flag,
  BarChart3,
  Award
} from 'lucide-react';
import UniversalComments from './UniversalComments';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const ContractualCompliance = ({ projectId, user }) => {
  const [milestones, setMilestones] = useState([]);
  const [complianceItems, setComplianceItems] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [reportingSchedule, setReportingSchedule] = useState([]);
  const [budgetCompliance, setBudgetCompliance] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedTab, setSelectedTab] = useState('milestones');
  
  const [showMilestoneDialog, setShowMilestoneDialog] = useState(false);
  const [showComplianceDialog, setShowComplianceDialog] = useState(false);
  const [showContractDialog, setShowContractDialog] = useState(false);
  const [showReportDialog, setShowReportDialog] = useState(false);
  
  const [editingMilestone, setEditingMilestone] = useState(null);
  const [editingCompliance, setEditingCompliance] = useState(null);
  const [editingContract, setEditingContract] = useState(null);
  
  const [milestoneForm, setMilestoneForm] = useState({
    title: '',
    description: '',
    due_date: '',
    budget_allocation: '',
    success_criteria: '',
    deliverables: '',
    status: 'not_started'
  });
  
  const [complianceForm, setComplianceForm] = useState({
    requirement_type: '',
    description: '',
    compliance_status: 'pending',
    due_date: '',
    responsible_party: '',
    evidence_required: '',
    priority: 'medium'
  });
  
  const [contractForm, setContractForm] = useState({
    contract_name: '',
    contractor: '',
    contract_type: 'service_agreement',
    start_date: '',
    end_date: '',
    contract_value: '',
    payment_terms: '',
    key_deliverables: '',
    compliance_requirements: ''
  });

  useEffect(() => {
    fetchComplianceData();
  }, [projectId]);

  const fetchComplianceData = async () => {
    try {
      const [milestonesRes, complianceRes, contractsRes, budgetRes] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/projects/${projectId}/milestones`),
        axios.get(`${BACKEND_URL}/api/projects/${projectId}/compliance-items`),
        axios.get(`${BACKEND_URL}/api/projects/${projectId}/contracts`),
        axios.get(`${BACKEND_URL}/api/projects/${projectId}/budget-compliance`)
      ]);
      
      setMilestones(milestonesRes.data);
      setComplianceItems(complianceRes.data);
      setContracts(contractsRes.data);
      setBudgetCompliance(budgetRes.data);
    } catch (error) {
      console.error('Error fetching compliance data:', error);
      toast.error('Failed to load compliance data');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateMilestone = async (e) => {
    e.preventDefault();
    try {
      const isEditing = editingMilestone !== null;
      
      if (isEditing) {
        await axios.put(`${BACKEND_URL}/api/projects/${projectId}/milestones/${editingMilestone}`, milestoneForm);
        toast.success('Milestone updated successfully!');
      } else {
        await axios.post(`${BACKEND_URL}/api/projects/${projectId}/milestones`, milestoneForm);
        toast.success('Milestone created successfully!');
      }
      
      setShowMilestoneDialog(false);
      resetMilestoneForm();
      fetchComplianceData();
    } catch (error) {
      console.error('Error with milestone:', error);
      toast.error(`Failed to ${editingMilestone ? 'update' : 'create'} milestone`);
    }
  };

  const handleCreateCompliance = async (e) => {
    e.preventDefault();
    try {
      const isEditing = editingCompliance !== null;
      
      if (isEditing) {
        await axios.put(`${BACKEND_URL}/api/projects/${projectId}/compliance-items/${editingCompliance}`, complianceForm);
        toast.success('Compliance item updated successfully!');
      } else {
        await axios.post(`${BACKEND_URL}/api/projects/${projectId}/compliance-items`, complianceForm);
        toast.success('Compliance item created successfully!');
      }
      
      setShowComplianceDialog(false);
      resetComplianceForm();
      fetchComplianceData();
    } catch (error) {
      console.error('Error with compliance item:', error);
      toast.error(`Failed to ${editingCompliance ? 'update' : 'create'} compliance item`);
    }
  };

  const handleCreateContract = async (e) => {
    e.preventDefault();
    try {
      const isEditing = editingContract !== null;
      
      if (isEditing) {
        await axios.put(`${BACKEND_URL}/api/projects/${projectId}/contracts/${editingContract}`, contractForm);
        toast.success('Contract updated successfully!');
      } else {
        await axios.post(`${BACKEND_URL}/api/projects/${projectId}/contracts`, contractForm);
        toast.success('Contract created successfully!');
      }
      
      setShowContractDialog(false);
      resetContractForm();
      fetchComplianceData();
    } catch (error) {
      console.error('Error with contract:', error);
      toast.error(`Failed to ${editingContract ? 'update' : 'create'} contract`);
    }
  };

  const handleDeleteMilestone = async (milestoneId) => {
    if (!window.confirm('Are you sure you want to delete this milestone?')) return;
    
    try {
      await axios.delete(`${BACKEND_URL}/api/projects/${projectId}/milestones/${milestoneId}`);
      toast.success('Milestone deleted successfully!');
      fetchComplianceData();
    } catch (error) {
      console.error('Error deleting milestone:', error);
      toast.error('Failed to delete milestone');
    }
  };

  const resetMilestoneForm = () => {
    setMilestoneForm({
      title: '',
      description: '',
      due_date: '',
      budget_allocation: '',
      success_criteria: '',
      deliverables: '',
      status: 'not_started'
    });
    setEditingMilestone(null);
  };

  const resetComplianceForm = () => {
    setComplianceForm({
      requirement_type: '',
      description: '',
      compliance_status: 'pending',
      due_date: '',
      responsible_party: '',
      evidence_required: '',
      priority: 'medium'
    });
    setEditingCompliance(null);
  };

  const resetContractForm = () => {
    setContractForm({
      contract_name: '',
      contractor: '',
      contract_type: 'service_agreement',
      start_date: '',
      end_date: '',
      contract_value: '',
      payment_terms: '',
      key_deliverables: '',
      compliance_requirements: ''
    });
    setEditingContract(null);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in_progress': return 'bg-blue-100 text-blue-800';
      case 'at_risk': return 'bg-yellow-100 text-yellow-800';
      case 'overdue': return 'bg-red-100 text-red-800';
      case 'compliant': return 'bg-green-100 text-green-800';
      case 'non_compliant': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical': return 'bg-red-100 text-red-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'medium': return 'bg-blue-100 text-blue-800';
      case 'low': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const calculateComplianceScore = () => {
    if (complianceItems.length === 0) return 0;
    const compliantItems = complianceItems.filter(item => item.compliance_status === 'compliant').length;
    return Math.round((compliantItems / complianceItems.length) * 100);
  };

  const getMilestoneProgress = () => {
    if (milestones.length === 0) return 0;
    const completedMilestones = milestones.filter(m => m.status === 'completed').length;
    return Math.round((completedMilestones / milestones.length) * 100);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Contractual Compliance & Accountability</h2>
          <p className="text-gray-600">Track milestones, compliance requirements, and contractual obligations</p>
        </div>
      </div>

      {/* Overview Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Target className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Milestone Progress</p>
                <p className="text-2xl font-bold text-gray-900">{getMilestoneProgress()}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <ShieldCheck className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Compliance Score</p>
                <p className="text-2xl font-bold text-gray-900">{calculateComplianceScore()}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Gavel className="h-5 w-5 text-purple-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Active Contracts</p>
                <p className="text-2xl font-bold text-gray-900">{contracts.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">At Risk Items</p>
                <p className="text-2xl font-bold text-gray-900">
                  {milestones.filter(m => m.status === 'at_risk').length + 
                   complianceItems.filter(c => c.compliance_status === 'non_compliant').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="milestones">Milestones</TabsTrigger>
          <TabsTrigger value="compliance">Compliance</TabsTrigger>
          <TabsTrigger value="contracts">Contracts</TabsTrigger>
          <TabsTrigger value="reporting">Reporting</TabsTrigger>
        </TabsList>

        {/* Milestones Tab */}
        <TabsContent value="milestones" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Project Milestones</h3>
            {user.role !== 'investor' && (
              <Dialog open={showMilestoneDialog} onOpenChange={setShowMilestoneDialog}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Milestone
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader>
                    <DialogTitle>{editingMilestone ? 'Edit Milestone' : 'Add New Milestone'}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleCreateMilestone} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="title">Milestone Title</Label>
                        <Input
                          id="title"
                          value={milestoneForm.title}
                          onChange={(e) => setMilestoneForm(prev => ({ ...prev, title: e.target.value }))}
                          placeholder="Enter milestone title"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="due_date">Due Date</Label>
                        <Input
                          id="due_date"
                          type="date"
                          value={milestoneForm.due_date}
                          onChange={(e) => setMilestoneForm(prev => ({ ...prev, due_date: e.target.value }))}
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={milestoneForm.description}
                        onChange={(e) => setMilestoneForm(prev => ({ ...prev, description: e.target.value }))}
                        placeholder="Describe the milestone requirements"
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="budget_allocation">Budget Allocation</Label>
                        <Input
                          id="budget_allocation"
                          type="number"
                          value={milestoneForm.budget_allocation}
                          onChange={(e) => setMilestoneForm(prev => ({ ...prev, budget_allocation: e.target.value }))}
                          placeholder="Enter budget amount"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="status">Status</Label>
                        <Select value={milestoneForm.status} onValueChange={(value) => setMilestoneForm(prev => ({ ...prev, status: value }))}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="not_started">Not Started</SelectItem>
                            <SelectItem value="in_progress">In Progress</SelectItem>
                            <SelectItem value="completed">Completed</SelectItem>
                            <SelectItem value="at_risk">At Risk</SelectItem>
                            <SelectItem value="overdue">Overdue</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <div className="flex justify-end space-x-2">
                      <Button type="button" variant="outline" onClick={() => {
                        setShowMilestoneDialog(false);
                        resetMilestoneForm();
                      }}>
                        Cancel
                      </Button>
                      <Button type="submit">{editingMilestone ? 'Update' : 'Create'} Milestone</Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            )}
          </div>

          <div className="space-y-4">
            {milestones.map((milestone) => (
              <Card key={milestone.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h4 className="font-semibold text-lg">{milestone.title}</h4>
                        <Badge className={getStatusColor(milestone.status)}>
                          {milestone.status.replace('_', ' ')}
                        </Badge>
                      </div>
                      <p className="text-gray-600 mb-3">{milestone.description}</p>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="font-medium text-gray-700">Due Date:</p>
                          <p className="text-gray-600">{new Date(milestone.due_date).toLocaleDateString()}</p>
                        </div>
                        <div>
                          <p className="font-medium text-gray-700">Budget Allocation:</p>
                          <p className="text-gray-600">${milestone.budget_allocation?.toLocaleString() || 'N/A'}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="ml-4 flex items-center space-x-2">
                      {milestone.status === 'completed' ? (
                        <CheckCircle2 className="h-6 w-6 text-green-500" />
                      ) : milestone.status === 'at_risk' || milestone.status === 'overdue' ? (
                        <AlertTriangle className="h-6 w-6 text-red-500" />
                      ) : (
                        <Clock className="h-6 w-6 text-blue-500" />
                      )}
                      
                      {user.role !== 'investor' && (
                        <div className="flex items-center space-x-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              setMilestoneForm({
                                title: milestone.title,
                                description: milestone.description,
                                due_date: milestone.due_date.split('T')[0],
                                budget_allocation: milestone.budget_allocation?.toString() || '',
                                success_criteria: milestone.success_criteria || '',
                                deliverables: milestone.deliverables || '',
                                status: milestone.status
                              });
                              setEditingMilestone(milestone.id);
                              setShowMilestoneDialog(true);
                            }}
                            className="text-blue-600 hover:text-blue-800"
                          >
                            <Edit3 className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteMilestone(milestone.id)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Comments for individual milestone */}
                  <div className="mt-4 pt-4 border-t">
                    <UniversalComments 
                      projectId={projectId} 
                      user={user} 
                      itemType="milestone" 
                      itemId={milestone.id}
                      title={`Comments for ${milestone.title}`} 
                    />
                  </div>
                </CardContent>
              </Card>
            ))}
            
            {milestones.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Target className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No milestones defined yet</p>
                <p className="text-sm">Add milestones to track project progress</p>
              </div>
            )}
          </div>
          
          {/* Universal Comments for Milestones */}
          <UniversalComments 
            projectId={projectId} 
            user={user} 
            itemType="milestones" 
            title="Milestone Management Comments" 
          />
        </TabsContent>

        {/* Additional tabs would be implemented similarly... */}
        <TabsContent value="compliance" className="space-y-4">
          <div className="text-center py-8 text-gray-500">
            <ShieldCheck className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>Compliance management features coming soon</p>
          </div>
        </TabsContent>

        <TabsContent value="contracts" className="space-y-4">
          <div className="text-center py-8 text-gray-500">
            <Gavel className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>Contract management features coming soon</p>
          </div>
        </TabsContent>

        <TabsContent value="reporting" className="space-y-4">
          <div className="text-center py-8 text-gray-500">
            <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>Reporting features coming soon</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ContractualCompliance;