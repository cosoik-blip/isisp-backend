import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardContent 
} from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Textarea } from '../components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from '../components/ui/dialog';
import {
  Settings,
  ArrowLeft,
  Shield,
  Globe,
  Database,
  Mail,
  Key,
  Palette,
  Save,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  Info,
  Server,
  Lock
} from 'lucide-react';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const PlatformSettings = () => {
  const [settings, setSettings] = useState({
    platform_name: 'Social Impact Investment Platform',
    platform_description: 'Comprehensive platform for social impact project management and investment tracking',
    admin_email: 'admin@platform.com',
    max_users: 1000,
    max_projects: 500,
    max_file_size_mb: 50,
    allowed_file_types: ['pdf', 'doc', 'docx', 'xlsx', 'ppt', 'pptx', 'jpg', 'png'],
    enable_notifications: true,
    enable_analytics: true,
    enable_user_registration: false,
    maintenance_mode: false,
    theme_color: '#2563eb',
    logo_url: '',
    backup_frequency: 'daily',
    session_timeout_hours: 24
  });
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [confirmAction, setConfirmAction] = useState(null);

  useEffect(() => {
    fetchPlatformSettings();
  }, []);

  const fetchPlatformSettings = async () => {
    try {
      // For now, we'll use default settings since we don't have a backend endpoint yet
      // In a real implementation, you would fetch from /api/admin/platform-settings
      setLoading(false);
    } catch (error) {
      console.error('Error fetching settings:', error);
      toast.error('Failed to load platform settings');
      setLoading(false);
    }
  };

  const savePlatformSettings = async () => {
    try {
      setSaving(true);
      
      // Simulate saving settings (in real implementation, would call /api/admin/platform-settings)
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast.success('Platform settings saved successfully!');
    } catch (error) {
      console.error('Error saving settings:', error);
      toast.error('Failed to save platform settings');
    } finally {
      setSaving(false);
    }
  };

  const handleSettingChange = (key, value) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleArraySettingChange = (key, value) => {
    const arrayValue = value.split(',').map(item => item.trim()).filter(item => item);
    setSettings(prev => ({
      ...prev,
      [key]: arrayValue
    }));
  };

  const confirmCriticalAction = (action, message) => {
    setConfirmAction({ action, message });
    setShowConfirmDialog(true);
  };

  const executeConfirmedAction = () => {
    if (confirmAction) {
      confirmAction.action();
      setShowConfirmDialog(false);
      setConfirmAction(null);
    }
  };

  const restartPlatform = () => {
    confirmCriticalAction(
      () => {
        toast.success('Platform restart initiated (simulated)');
      },
      'This will restart all platform services and briefly interrupt user access. Continue?'
    );
  };

  const enableMaintenanceMode = () => {
    confirmCriticalAction(
      () => {
        handleSettingChange('maintenance_mode', true);
        toast.warning('Maintenance mode enabled - users will see maintenance page');
      },
      'This will put the platform in maintenance mode and prevent user access. Continue?'
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link 
            to="/dashboard" 
            className="flex items-center space-x-2 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Back to Dashboard</span>
          </Link>
          <div className="border-l border-gray-300 h-8"></div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <Settings className="h-7 w-7 text-blue-600" />
              <span>Platform Settings</span>
            </h2>
            <p className="text-gray-600 mt-1">
              Configure platform-wide settings and preferences
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            onClick={restartPlatform}
            className="text-orange-600 border-orange-300 hover:bg-orange-50"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Restart Platform
          </Button>
          <Button onClick={savePlatformSettings} disabled={saving}>
            <Save className="h-4 w-4 mr-2" />
            {saving ? 'Saving...' : 'Save Settings'}
          </Button>
        </div>
      </div>

      {/* Maintenance Mode Alert */}
      {settings.maintenance_mode && (
        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              <div>
                <h4 className="font-medium text-orange-900">Maintenance Mode Active</h4>
                <p className="text-sm text-orange-700">
                  The platform is currently in maintenance mode. Users cannot access the system.
                </p>
              </div>
              <Button
                size="sm"
                onClick={() => handleSettingChange('maintenance_mode', false)}
                className="ml-auto"
              >
                Disable Maintenance
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* General Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Globe className="h-5 w-5 text-blue-600" />
              <span>General Settings</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Platform Name</Label>
              <Input
                value={settings.platform_name}
                onChange={(e) => handleSettingChange('platform_name', e.target.value)}
                placeholder="Platform name"
              />
            </div>
            
            <div>
              <Label>Platform Description</Label>
              <Textarea
                value={settings.platform_description}
                onChange={(e) => handleSettingChange('platform_description', e.target.value)}
                placeholder="Brief description of the platform"
                className="min-h-[80px]"
              />
            </div>
            
            <div>
              <Label>Administrator Email</Label>
              <Input
                type="email"
                value={settings.admin_email}
                onChange={(e) => handleSettingChange('admin_email', e.target.value)}
                placeholder="admin@example.com"
              />
            </div>
            
            <div>
              <Label>Theme Color</Label>
              <div className="flex items-center space-x-2">
                <Input
                  type="color"
                  value={settings.theme_color}
                  onChange={(e) => handleSettingChange('theme_color', e.target.value)}
                  className="w-16 h-10"
                />
                <Input
                  value={settings.theme_color}
                  onChange={(e) => handleSettingChange('theme_color', e.target.value)}
                  placeholder="#2563eb"
                  className="flex-1"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* System Limits */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Database className="h-5 w-5 text-green-600" />
              <span>System Limits</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Maximum Users</Label>
              <Input
                type="number"
                value={settings.max_users}
                onChange={(e) => handleSettingChange('max_users', parseInt(e.target.value))}
                min="1"
              />
            </div>
            
            <div>
              <Label>Maximum Projects</Label>
              <Input
                type="number"
                value={settings.max_projects}
                onChange={(e) => handleSettingChange('max_projects', parseInt(e.target.value))}
                min="1"
              />
            </div>
            
            <div>
              <Label>Maximum File Size (MB)</Label>
              <Input
                type="number"
                value={settings.max_file_size_mb}
                onChange={(e) => handleSettingChange('max_file_size_mb', parseInt(e.target.value))}
                min="1"
              />
            </div>
            
            <div>
              <Label>Session Timeout (Hours)</Label>
              <Input
                type="number"
                value={settings.session_timeout_hours}
                onChange={(e) => handleSettingChange('session_timeout_hours', parseInt(e.target.value))}
                min="1"
                max="168"
              />
            </div>
          </CardContent>
        </Card>

        {/* File Management */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Server className="h-5 w-5 text-purple-600" />
              <span>File Management</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Allowed File Types</Label>
              <Input
                value={settings.allowed_file_types.join(', ')}
                onChange={(e) => handleArraySettingChange('allowed_file_types', e.target.value)}
                placeholder="pdf, doc, docx, xlsx, jpg, png"
              />
              <p className="text-xs text-gray-500 mt-1">Separate with commas</p>
            </div>
            
            <div>
              <Label>Backup Frequency</Label>
              <Select 
                value={settings.backup_frequency} 
                onValueChange={(value) => handleSettingChange('backup_frequency', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hourly">Hourly</SelectItem>
                  <SelectItem value="daily">Daily</SelectItem>
                  <SelectItem value="weekly">Weekly</SelectItem>
                  <SelectItem value="monthly">Monthly</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>Logo URL</Label>
              <Input
                value={settings.logo_url}
                onChange={(e) => handleSettingChange('logo_url', e.target.value)}
                placeholder="https://example.com/logo.png"
              />
            </div>
          </CardContent>
        </Card>

        {/* Security & Access */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Lock className="h-5 w-5 text-red-600" />
              <span>Security & Access</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Enable User Registration</Label>
                <p className="text-sm text-gray-500">Allow new users to register themselves</p>
              </div>
              <input
                type="checkbox"
                checked={settings.enable_user_registration}
                onChange={(e) => handleSettingChange('enable_user_registration', e.target.checked)}
                className="h-4 w-4"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label>Enable Notifications</Label>
                <p className="text-sm text-gray-500">Send system notifications to users</p>
              </div>
              <input
                type="checkbox"
                checked={settings.enable_notifications}
                onChange={(e) => handleSettingChange('enable_notifications', e.target.checked)}
                className="h-4 w-4"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label>Enable Analytics</Label>
                <p className="text-sm text-gray-500">Track platform usage and performance</p>
              </div>
              <input
                type="checkbox"
                checked={settings.enable_analytics}
                onChange={(e) => handleSettingChange('enable_analytics', e.target.checked)}
                className="h-4 w-4"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label>Maintenance Mode</Label>
                <p className="text-sm text-gray-500">Temporarily disable user access</p>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={enableMaintenanceMode}
                className="text-orange-600 border-orange-300"
              >
                Enable Maintenance
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* System Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5 text-blue-600" />
            <span>System Status</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 border rounded-lg">
              <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <h4 className="font-medium">Database</h4>
              <p className="text-sm text-gray-500">Connected</p>
            </div>
            
            <div className="text-center p-4 border rounded-lg">
              <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <h4 className="font-medium">Backend API</h4>
              <p className="text-sm text-gray-500">Running</p>
            </div>
            
            <div className="text-center p-4 border rounded-lg">
              <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <h4 className="font-medium">File Storage</h4>
              <p className="text-sm text-gray-500">Available</p>
            </div>
            
            <div className="text-center p-4 border rounded-lg">
              <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <h4 className="font-medium">Email Service</h4>
              <p className="text-sm text-gray-500">Configured</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Confirmation Dialog */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              <span>Confirm Action</span>
            </DialogTitle>
            <DialogDescription>
              {confirmAction?.message}
            </DialogDescription>
          </DialogHeader>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowConfirmDialog(false)}>
              Cancel
            </Button>
            <Button onClick={executeConfirmedAction} className="bg-orange-600 hover:bg-orange-700">
              Confirm
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default PlatformSettings;