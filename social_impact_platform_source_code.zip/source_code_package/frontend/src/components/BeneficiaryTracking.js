import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  Users, 
  Plus, 
  TrendingUp, 
  User, 
  Heart,
  MapPin, 
  Calendar,
  Target,
  Award,
  BarChart3,
  PieChart,
  Activity,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileText,
  Download,
  Filter,
  Search,
  Edit3,
  Eye,
  Phone,
  Mail,
  Home,
  GraduationCap
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const BeneficiaryTracking = ({ projectId, user }) => {
  const [beneficiaries, setBeneficiaries] = useState([]);
  const [outcomes, setOutcomes] = useState([]);
  const [demographics, setDemographics] = useState({});
  const [impactMetrics, setImpactMetrics] = useState({});
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBeneficiary, setSelectedBeneficiary] = useState(null);
  const [showBeneficiaryDialog, setShowBeneficiaryDialog] = useState(false);
  const [showOutcomeDialog, setShowOutcomeDialog] = useState(false);
  const [viewMode, setViewMode] = useState('grid'); // grid, list, analytics

  const [beneficiaryFormData, setBeneficiaryFormData] = useState({
    first_name: '',
    last_name: '',
    email: '',
    phone: '',
    age: '',
    gender: '',
    location: '',
    education_level: '',
    employment_status: '',
    household_size: '',
    income_level: '',
    special_needs: ''
  });

  const [outcomeFormData, setOutcomeFormData] = useState({
    beneficiary_id: '',
    outcome_type: '',
    description: '',
    measurement_value: '',
    measurement_unit: '',
    date_recorded: '',
    impact_level: 'medium'
  });

  useEffect(() => {
    fetchBeneficiaryData();
  }, [projectId]);

  const fetchBeneficiaryData = async () => {
    try {
      const [beneficiariesRes, outcomesRes] = await Promise.all([
        axios.get(`${API}/projects/${projectId}/beneficiaries`),
        axios.get(`${API}/projects/${projectId}/beneficiary-outcomes`)
      ]);
      
      setBeneficiaries(beneficiariesRes.data);
      setOutcomes(outcomesRes.data);
      
      // Calculate demographics
      const demo = calculateDemographics(beneficiariesRes.data);
      setDemographics(demo);
      
      // Calculate impact metrics
      const impact = calculateImpactMetrics(beneficiariesRes.data, outcomesRes.data);
      setImpactMetrics(impact);
      
    } catch (error) {
      toast.error('Failed to load beneficiary data');
      console.error('Beneficiary data fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateDemographics = (beneficiaries) => {
    const total = beneficiaries.length;
    if (total === 0) return {};

    const genderCounts = beneficiaries.reduce((acc, b) => {
      acc[b.gender] = (acc[b.gender] || 0) + 1;
      return acc;
    }, {});

    const ageCounts = beneficiaries.reduce((acc, b) => {
      const ageGroup = getAgeGroup(b.age);
      acc[ageGroup] = (acc[ageGroup] || 0) + 1;
      return acc;
    }, {});

    const educationCounts = beneficiaries.reduce((acc, b) => {
      acc[b.education_level] = (acc[b.education_level] || 0) + 1;
      return acc;
    }, {});

    const locationCounts = beneficiaries.reduce((acc, b) => {
      acc[b.location] = (acc[b.location] || 0) + 1;
      return acc;
    }, {});

    return {
      total,
      gender: Object.entries(genderCounts).map(([key, value]) => ({ 
        category: key, 
        count: value, 
        percentage: ((value / total) * 100).toFixed(1) 
      })),
      ageGroups: Object.entries(ageCounts).map(([key, value]) => ({ 
        category: key, 
        count: value, 
        percentage: ((value / total) * 100).toFixed(1) 
      })),
      education: Object.entries(educationCounts).map(([key, value]) => ({ 
        category: key, 
        count: value, 
        percentage: ((value / total) * 100).toFixed(1) 
      })),
      locations: Object.entries(locationCounts).map(([key, value]) => ({ 
        category: key, 
        count: value, 
        percentage: ((value / total) * 100).toFixed(1) 
      }))
    };
  };

  const calculateImpactMetrics = (beneficiaries, outcomes) => {
    const totalBeneficiaries = beneficiaries.length;
    const totalOutcomes = outcomes.length;
    const avgOutcomesPerBeneficiary = totalBeneficiaries > 0 ? 
      (totalOutcomes / totalBeneficiaries).toFixed(1) : 0;

    const impactLevels = outcomes.reduce((acc, outcome) => {
      acc[outcome.impact_level] = (acc[outcome.impact_level] || 0) + 1;
      return acc;
    }, {});

    const outcomeTypes = outcomes.reduce((acc, outcome) => {
      acc[outcome.outcome_type] = (acc[outcome.outcome_type] || 0) + 1;
      return acc;
    }, {});

    const recentOutcomes = outcomes.filter(outcome => {
      const outcomeDate = new Date(outcome.date_recorded);
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      return outcomeDate >= thirtyDaysAgo;
    }).length;

    return {
      totalBeneficiaries,
      totalOutcomes,
      avgOutcomesPerBeneficiary,
      recentOutcomes,
      impactDistribution: Object.entries(impactLevels).map(([level, count]) => ({
        level,
        count,
        percentage: ((count / totalOutcomes) * 100).toFixed(1)
      })),
      outcomeTypes: Object.entries(outcomeTypes).map(([type, count]) => ({
        type,
        count,
        percentage: ((count / totalOutcomes) * 100).toFixed(1)
      }))
    };
  };

  const getAgeGroup = (age) => {
    if (age < 18) return 'Under 18';
    if (age < 25) return '18-24';
    if (age < 35) return '25-34';
    if (age < 50) return '35-49';
    if (age < 65) return '50-64';
    return '65+';
  };

  const handleCreateBeneficiary = async (e) => {
    e.preventDefault();
    try {
      const beneficiaryData = {
        ...beneficiaryFormData,
        age: parseInt(beneficiaryFormData.age),
        household_size: parseInt(beneficiaryFormData.household_size)
      };

      await axios.post(`${API}/projects/${projectId}/beneficiaries`, beneficiaryData);
      toast.success('Beneficiary registered successfully!');
      setShowBeneficiaryDialog(false);
      setBeneficiaryFormData({
        first_name: '',
        last_name: '',
        email: '',
        phone: '',
        age: '',
        gender: '',
        location: '',
        education_level: '',
        employment_status: '',
        household_size: '',
        income_level: '',
        special_needs: ''
      });
      fetchBeneficiaryData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to register beneficiary');
    }
  };

  const handleCreateOutcome = async (e) => {
    e.preventDefault();
    try {
      const outcomeData = {
        ...outcomeFormData,
        measurement_value: parseFloat(outcomeFormData.measurement_value) || 0,
        date_recorded: new Date(outcomeFormData.date_recorded).toISOString()
      };

      await axios.post(`${API}/projects/${projectId}/beneficiary-outcomes`, outcomeData);
      toast.success('Outcome recorded successfully!');
      setShowOutcomeDialog(false);
      setOutcomeFormData({
        beneficiary_id: '',
        outcome_type: '',
        description: '',
        measurement_value: '',
        measurement_unit: '',
        date_recorded: '',
        impact_level: 'medium'
      });
      fetchBeneficiaryData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to record outcome');
    }
  };

  const getImpactLevelColor = (level) => {
    switch (level) {
      case 'high': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const filteredBeneficiaries = beneficiaries.filter(beneficiary =>
    `${beneficiary.first_name} ${beneficiary.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
    beneficiary.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    beneficiary.location.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const MetricCard = ({ title, value, subtitle, icon: Icon, color = 'blue' }) => (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className={`text-2xl font-bold text-${color}-600`}>{value}</p>
            {subtitle && <p className="text-xs text-gray-500">{subtitle}</p>}
          </div>
          <div className={`p-3 rounded-full bg-${color}-100`}>
            <Icon className={`h-5 w-5 text-${color}-600`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold flex items-center space-x-2">
            <Users className="h-5 w-5 text-blue-600" />
            <span>Beneficiary Tracking Module</span>
          </h3>
          <p className="text-sm text-gray-600">Track beneficiaries, measure impact, and analyze demographics</p>
        </div>
        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search beneficiaries..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
              data-testid="search-beneficiaries"
            />
          </div>
          <Select value={viewMode} onValueChange={setViewMode}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="grid">Grid</SelectItem>
              <SelectItem value="list">List</SelectItem>
              <SelectItem value="analytics">Analytics</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Overview Metrics */}
      {impactMetrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            title="Total Beneficiaries"
            value={impactMetrics.totalBeneficiaries}
            subtitle="Registered participants"
            icon={Users}
            color="blue"
          />
          <MetricCard
            title="Recorded Outcomes"
            value={impactMetrics.totalOutcomes}
            subtitle={`${impactMetrics.avgOutcomesPerBeneficiary} avg per person`}
            icon={Target}
            color="green"
          />
          <MetricCard
            title="Recent Activity"
            value={impactMetrics.recentOutcomes}
            subtitle="Outcomes in last 30 days"
            icon={Activity}
            color="purple"
          />
          <MetricCard
            title="Impact Coverage"
            value={`${((impactMetrics.totalOutcomes / Math.max(1, impactMetrics.totalBeneficiaries)) * 100).toFixed(0)}%`}
            subtitle="Beneficiaries with outcomes"
            icon={Award}
            color="orange"
          />
        </div>
      )}

      {/* Main Content */}
      <Tabs defaultValue="beneficiaries" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="beneficiaries">Beneficiaries</TabsTrigger>
          <TabsTrigger value="outcomes">Outcomes</TabsTrigger>
          <TabsTrigger value="demographics">Demographics</TabsTrigger>
          <TabsTrigger value="impact">Impact Analysis</TabsTrigger>
        </TabsList>

        {/* Beneficiaries Tab */}
        <TabsContent value="beneficiaries" className="space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-semibold">Beneficiary Registry</h4>
            <Dialog open={showBeneficiaryDialog} onOpenChange={setShowBeneficiaryDialog}>
              <DialogTrigger asChild>
                <Button data-testid="add-beneficiary-button">
                  <Plus className="h-4 w-4 mr-2" />
                  Register Beneficiary
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Register New Beneficiary</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateBeneficiary} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="first-name">First Name</Label>
                      <Input
                        id="first-name"
                        value={beneficiaryFormData.first_name}
                        onChange={(e) => setBeneficiaryFormData({...beneficiaryFormData, first_name: e.target.value})}
                        placeholder="e.g., John"
                        required
                        data-testid="beneficiary-first-name-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="last-name">Last Name</Label>
                      <Input
                        id="last-name"
                        value={beneficiaryFormData.last_name}
                        onChange={(e) => setBeneficiaryFormData({...beneficiaryFormData, last_name: e.target.value})}
                        placeholder="e.g., Doe"
                        required
                        data-testid="beneficiary-last-name-input"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={beneficiaryFormData.email}
                        onChange={(e) => setBeneficiaryFormData({...beneficiaryFormData, email: e.target.value})}
                        placeholder="john.doe@email.com"
                        data-testid="beneficiary-email-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        value={beneficiaryFormData.phone}
                        onChange={(e) => setBeneficiaryFormData({...beneficiaryFormData, phone: e.target.value})}
                        placeholder="+1-555-123-4567"
                        data-testid="beneficiary-phone-input"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="age">Age</Label>
                      <Input
                        id="age"
                        type="number"
                        value={beneficiaryFormData.age}
                        onChange={(e) => setBeneficiaryFormData({...beneficiaryFormData, age: e.target.value})}
                        placeholder="25"
                        required
                        data-testid="beneficiary-age-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="gender">Gender</Label>
                      <Select value={beneficiaryFormData.gender} onValueChange={(value) => 
                        setBeneficiaryFormData({...beneficiaryFormData, gender: value})
                      }>
                        <SelectTrigger data-testid="beneficiary-gender-select">
                          <SelectValue placeholder="Select gender" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="male">Male</SelectItem>
                          <SelectItem value="female">Female</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                          <SelectItem value="prefer_not_to_say">Prefer not to say</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        value={beneficiaryFormData.location}
                        onChange={(e) => setBeneficiaryFormData({...beneficiaryFormData, location: e.target.value})}
                        placeholder="City, State"
                        required
                        data-testid="beneficiary-location-input"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="education">Education Level</Label>
                      <Select value={beneficiaryFormData.education_level} onValueChange={(value) => 
                        setBeneficiaryFormData({...beneficiaryFormData, education_level: value})
                      }>
                        <SelectTrigger>
                          <SelectValue placeholder="Select education level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="no_formal_education">No Formal Education</SelectItem>
                          <SelectItem value="primary">Primary School</SelectItem>
                          <SelectItem value="secondary">Secondary School</SelectItem>
                          <SelectItem value="high_school">High School</SelectItem>
                          <SelectItem value="college">College</SelectItem>
                          <SelectItem value="university">University</SelectItem>
                          <SelectItem value="postgraduate">Postgraduate</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="employment">Employment Status</Label>
                      <Select value={beneficiaryFormData.employment_status} onValueChange={(value) => 
                        setBeneficiaryFormData({...beneficiaryFormData, employment_status: value})
                      }>
                        <SelectTrigger>
                          <SelectValue placeholder="Select employment status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="employed">Employed</SelectItem>
                          <SelectItem value="unemployed">Unemployed</SelectItem>
                          <SelectItem value="self_employed">Self-employed</SelectItem>
                          <SelectItem value="student">Student</SelectItem>
                          <SelectItem value="retired">Retired</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="household-size">Household Size</Label>
                      <Input
                        id="household-size"
                        type="number"
                        value={beneficiaryFormData.household_size}
                        onChange={(e) => setBeneficiaryFormData({...beneficiaryFormData, household_size: e.target.value})}
                        placeholder="4"
                        data-testid="beneficiary-household-size-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="income">Income Level</Label>
                      <Select value={beneficiaryFormData.income_level} onValueChange={(value) => 
                        setBeneficiaryFormData({...beneficiaryFormData, income_level: value})
                      }>
                        <SelectTrigger>
                          <SelectValue placeholder="Select income level" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="very_low">Very Low (&lt; $20k)</SelectItem>
                          <SelectItem value="low">Low ($20k - $40k)</SelectItem>
                          <SelectItem value="moderate">Moderate ($40k - $60k)</SelectItem>
                          <SelectItem value="high">High ($60k+)</SelectItem>
                          <SelectItem value="prefer_not_to_say">Prefer not to say</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="special-needs">Special Needs/Notes</Label>
                    <Textarea
                      id="special-needs"
                      value={beneficiaryFormData.special_needs}
                      onChange={(e) => setBeneficiaryFormData({...beneficiaryFormData, special_needs: e.target.value})}
                      placeholder="Any special accommodations or additional information..."
                      rows={3}
                      data-testid="beneficiary-special-needs-input"
                    />
                  </div>
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setShowBeneficiaryDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" data-testid="create-beneficiary-submit">Register Beneficiary</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          {/* Beneficiaries Grid/List */}
          <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4' : 'space-y-4'}>
            {filteredBeneficiaries.map((beneficiary) => {
              const beneficiaryOutcomes = outcomes.filter(o => o.beneficiary_id === beneficiary.id);
              
              return (
                <Card key={beneficiary.id} className="hover:shadow-md transition-shadow" data-testid={`beneficiary-card-${beneficiary.id}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <User className="h-5 w-5 text-blue-600" />
                        </div>
                        <div>
                          <h4 className="font-medium">{beneficiary.first_name} {beneficiary.last_name}</h4>
                          <p className="text-sm text-gray-500 capitalize">{beneficiary.age} • {beneficiary.gender}</p>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedBeneficiary(beneficiary)}
                        data-testid={`view-beneficiary-${beneficiary.id}`}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center space-x-2 text-gray-600">
                        <MapPin className="h-4 w-4" />
                        <span>{beneficiary.location}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-gray-600">
                        <GraduationCap className="h-4 w-4" />
                        <span className="capitalize">{beneficiary.education_level?.replace('_', ' ')}</span>
                      </div>
                      {beneficiary.email && (
                        <div className="flex items-center space-x-2 text-gray-600">
                          <Mail className="h-4 w-4" />
                          <span>{beneficiary.email}</span>
                        </div>
                      )}
                    </div>
                    <div className="mt-3 pt-3 border-t border-gray-200">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">Outcomes Recorded</span>
                        <Badge className="bg-blue-100 text-blue-800">
                          {beneficiaryOutcomes.length}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
            {filteredBeneficiaries.length === 0 && (
              <div className="col-span-full text-center py-8 text-gray-500">
                <Users className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No beneficiaries found</p>
                <p className="text-sm">Register beneficiaries to start tracking impact</p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Outcomes Tab */}
        <TabsContent value="outcomes" className="space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-semibold">Impact Outcomes</h4>
            <Dialog open={showOutcomeDialog} onOpenChange={setShowOutcomeDialog}>
              <DialogTrigger asChild>
                <Button data-testid="add-outcome-button">
                  <Plus className="h-4 w-4 mr-2" />
                  Record Outcome
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Record Impact Outcome</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateOutcome} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="outcome-beneficiary">Beneficiary</Label>
                    <Select value={outcomeFormData.beneficiary_id} onValueChange={(value) => 
                      setOutcomeFormData({...outcomeFormData, beneficiary_id: value})
                    }>
                      <SelectTrigger data-testid="outcome-beneficiary-select">
                        <SelectValue placeholder="Select beneficiary" />
                      </SelectTrigger>
                      <SelectContent>
                        {beneficiaries.map(beneficiary => (
                          <SelectItem key={beneficiary.id} value={beneficiary.id}>
                            {beneficiary.first_name} {beneficiary.last_name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="outcome-type">Outcome Type</Label>
                      <Select value={outcomeFormData.outcome_type} onValueChange={(value) => 
                        setOutcomeFormData({...outcomeFormData, outcome_type: value})
                      }>
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="skill_development">Skill Development</SelectItem>
                          <SelectItem value="employment">Employment</SelectItem>
                          <SelectItem value="income_increase">Income Increase</SelectItem>
                          <SelectItem value="education_completion">Education Completion</SelectItem>
                          <SelectItem value="health_improvement">Health Improvement</SelectItem>
                          <SelectItem value="social_connection">Social Connection</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="impact-level">Impact Level</Label>
                      <Select value={outcomeFormData.impact_level} onValueChange={(value) => 
                        setOutcomeFormData({...outcomeFormData, impact_level: value})
                      }>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="outcome-description">Description</Label>
                    <Textarea
                      id="outcome-description"
                      value={outcomeFormData.description}
                      onChange={(e) => setOutcomeFormData({...outcomeFormData, description: e.target.value})}
                      placeholder="Describe the outcome achieved..."
                      rows={3}
                      required
                      data-testid="outcome-description-input"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="measurement-value">Measurement Value</Label>
                      <Input
                        id="measurement-value"
                        type="number"
                        step="0.01"
                        value={outcomeFormData.measurement_value}
                        onChange={(e) => setOutcomeFormData({...outcomeFormData, measurement_value: e.target.value})}
                        placeholder="100"
                        data-testid="outcome-measurement-value-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="measurement-unit">Unit</Label>
                      <Input
                        id="measurement-unit"
                        value={outcomeFormData.measurement_unit}
                        onChange={(e) => setOutcomeFormData({...outcomeFormData, measurement_unit: e.target.value})}
                        placeholder="e.g., hours, %, points"
                        data-testid="outcome-measurement-unit-input"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="outcome-date">Date Recorded</Label>
                    <Input
                      id="outcome-date"
                      type="date"
                      value={outcomeFormData.date_recorded}
                      onChange={(e) => setOutcomeFormData({...outcomeFormData, date_recorded: e.target.value})}
                      required
                      data-testid="outcome-date-input"
                    />
                  </div>
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setShowOutcomeDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" data-testid="create-outcome-submit">Record Outcome</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-4">
            {outcomes.map((outcome) => {
              const beneficiary = beneficiaries.find(b => b.id === outcome.beneficiary_id);
              
              return (
                <Card key={outcome.id} data-testid={`outcome-card-${outcome.id}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-4">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                          <Target className="h-5 w-5 text-green-600" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <h4 className="font-medium capitalize">{outcome.outcome_type.replace('_', ' ')}</h4>
                            <Badge className={getImpactLevelColor(outcome.impact_level)}>
                              {outcome.impact_level} impact
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{outcome.description}</p>
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <span>
                              <User className="h-4 w-4 inline mr-1" />
                              {beneficiary ? `${beneficiary.first_name} ${beneficiary.last_name}` : 'Unknown'}
                            </span>
                            <span>
                              <Calendar className="h-4 w-4 inline mr-1" />
                              {new Date(outcome.date_recorded).toLocaleDateString()}
                            </span>
                            {outcome.measurement_value && (
                              <span>
                                <BarChart3 className="h-4 w-4 inline mr-1" />
                                {outcome.measurement_value} {outcome.measurement_unit}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
            {outcomes.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Target className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No outcomes recorded yet</p>
                <p className="text-sm">Record outcomes to track beneficiary impact</p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Demographics Tab */}
        <TabsContent value="demographics" className="space-y-6">
          <h4 className="text-lg font-semibold">Demographic Analysis</h4>
          
          {demographics.total > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Gender Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="h-5 w-5 text-blue-600" />
                    <span>Gender Distribution</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {demographics.gender?.map((item, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm font-medium capitalize">{item.category}</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-20 bg-gray-200 rounded-full h-2">
                            <div 
                              className="h-2 bg-blue-500 rounded-full"
                              style={{ width: `${item.percentage}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-600">{item.count} ({item.percentage}%)</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Age Groups */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <PieChart className="h-5 w-5 text-green-600" />
                    <span>Age Groups</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {demographics.ageGroups?.map((item, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm font-medium">{item.category}</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-20 bg-gray-200 rounded-full h-2">
                            <div 
                              className="h-2 bg-green-500 rounded-full"
                              style={{ width: `${item.percentage}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-600">{item.count} ({item.percentage}%)</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Education Levels */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <GraduationCap className="h-5 w-5 text-purple-600" />
                    <span>Education Levels</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {demographics.education?.map((item, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm font-medium capitalize">{item.category?.replace('_', ' ')}</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-20 bg-gray-200 rounded-full h-2">
                            <div 
                              className="h-2 bg-purple-500 rounded-full"
                              style={{ width: `${item.percentage}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-600">{item.count} ({item.percentage}%)</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Geographic Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <MapPin className="h-5 w-5 text-orange-600" />
                    <span>Geographic Distribution</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {demographics.locations?.slice(0, 5).map((item, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm font-medium">{item.category}</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-20 bg-gray-200 rounded-full h-2">
                            <div 
                              className="h-2 bg-orange-500 rounded-full"
                              style={{ width: `${item.percentage}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-600">{item.count} ({item.percentage}%)</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <BarChart3 className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>No demographic data available</p>
              <p className="text-sm">Register beneficiaries to view demographic analysis</p>
            </div>
          )}
        </TabsContent>

        {/* Impact Analysis Tab */}
        <TabsContent value="impact" className="space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-semibold">Impact Analysis</h4>
            <Button variant="outline" data-testid="export-impact-report">
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
          </div>
          
          {impactMetrics.totalOutcomes > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Impact Level Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Award className="h-5 w-5 text-green-600" />
                    <span>Impact Level Distribution</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {impactMetrics.impactDistribution?.map((item, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium capitalize">{item.level} Impact</span>
                          <span className="text-sm text-gray-600">{item.count} ({item.percentage}%)</span>
                        </div>
                        <Progress value={parseFloat(item.percentage)} className="h-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Outcome Types */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Target className="h-5 w-5 text-blue-600" />
                    <span>Outcome Types</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {impactMetrics.outcomeTypes?.map((item, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm font-medium capitalize">{item.type.replace('_', ' ')}</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-20 bg-gray-200 rounded-full h-2">
                            <div 
                              className="h-2 bg-blue-500 rounded-full"
                              style={{ width: `${item.percentage}%` }}
                            ></div>
                          </div>
                          <span className="text-sm text-gray-600">{item.count}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Impact Summary */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5 text-purple-600" />
                    <span>Impact Summary</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-600">
                        {impactMetrics.totalBeneficiaries}
                      </div>
                      <p className="text-sm text-gray-600">Total Beneficiaries</p>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-600">
                        {impactMetrics.totalOutcomes}
                      </div>
                      <p className="text-sm text-gray-600">Total Outcomes</p>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-purple-600">
                        {impactMetrics.avgOutcomesPerBeneficiary}
                      </div>
                      <p className="text-sm text-gray-600">Avg Outcomes/Person</p>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-orange-600">
                        {impactMetrics.recentOutcomes}
                      </div>
                      <p className="text-sm text-gray-600">Recent Outcomes (30d)</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <Award className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>No impact data available</p>
              <p className="text-sm">Record outcomes to view impact analysis</p>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Selected Beneficiary Detail Modal */}
      {selectedBeneficiary && (
        <Dialog open={!!selectedBeneficiary} onOpenChange={() => setSelectedBeneficiary(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {selectedBeneficiary.first_name} {selectedBeneficiary.last_name}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-600">Contact Information</Label>
                  <div className="space-y-2 mt-2">
                    {selectedBeneficiary.email && (
                      <div className="flex items-center space-x-2 text-sm">
                        <Mail className="h-4 w-4 text-gray-400" />
                        <span>{selectedBeneficiary.email}</span>
                      </div>
                    )}
                    {selectedBeneficiary.phone && (
                      <div className="flex items-center space-x-2 text-sm">
                        <Phone className="h-4 w-4 text-gray-400" />
                        <span>{selectedBeneficiary.phone}</span>
                      </div>
                    )}
                    <div className="flex items-center space-x-2 text-sm">
                      <MapPin className="h-4 w-4 text-gray-400" />
                      <span>{selectedBeneficiary.location}</span>
                    </div>
                  </div>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-600">Demographics</Label>
                  <div className="space-y-2 mt-2 text-sm">
                    <div>Age: {selectedBeneficiary.age}</div>
                    <div className="capitalize">Gender: {selectedBeneficiary.gender}</div>
                    <div className="capitalize">Education: {selectedBeneficiary.education_level?.replace('_', ' ')}</div>
                    <div className="capitalize">Employment: {selectedBeneficiary.employment_status?.replace('_', ' ')}</div>
                  </div>
                </div>
              </div>
              {selectedBeneficiary.special_needs && (
                <div>
                  <Label className="text-sm font-medium text-gray-600">Special Needs/Notes</Label>
                  <p className="text-sm mt-1">{selectedBeneficiary.special_needs}</p>
                </div>
              )}
              <div>
                <Label className="text-sm font-medium text-gray-600">Recorded Outcomes</Label>
                <div className="mt-2 space-y-2">
                  {outcomes.filter(o => o.beneficiary_id === selectedBeneficiary.id).map(outcome => (
                    <div key={outcome.id} className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium text-sm capitalize">{outcome.outcome_type.replace('_', ' ')}</p>
                          <p className="text-xs text-gray-600">{outcome.description}</p>
                        </div>
                        <Badge className={getImpactLevelColor(outcome.impact_level)}>
                          {outcome.impact_level}
                        </Badge>
                      </div>
                    </div>
                  ))}
                  {outcomes.filter(o => o.beneficiary_id === selectedBeneficiary.id).length === 0 && (
                    <p className="text-sm text-gray-500">No outcomes recorded yet</p>
                  )}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
};

export default BeneficiaryTracking;