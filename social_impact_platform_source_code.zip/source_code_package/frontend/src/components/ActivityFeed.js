import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { toast } from 'sonner';
import { 
  Activity, 
  User, 
  Calendar, 
  Package, 
  AlertTriangle, 
  Bug, 
  Calculator, 
  CheckCircle2,
  Clock,
  DollarSign,
  Target,
  FileText,
  RefreshCw
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const ActivityFeed = ({ projectId, user }) => {
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchActivities();
    // Set up polling for real-time updates every 30 seconds
    const interval = setInterval(fetchActivities, 30000);
    return () => clearInterval(interval);
  }, [projectId]);

  const fetchActivities = async () => {
    try {
      // Fetch activities from multiple sources and combine them
      const [kpis, deliverables, risks, issues, sroi] = await Promise.all([
        axios.get(`${API}/projects/${projectId}/kpis`),
        axios.get(`${API}/projects/${projectId}/deliverables`),
        axios.get(`${API}/projects/${projectId}/risks`),
        axios.get(`${API}/projects/${projectId}/issues`),
        axios.get(`${API}/projects/${projectId}/sroi`)
      ]);

      // Combine and sort activities by creation date
      const allActivities = [
        ...kpis.data.map(item => ({
          ...item,
          type: 'kpi',
          activity: 'KPI Created',
          icon: Target,
          color: 'blue'
        })),
        ...deliverables.data.map(item => ({
          ...item,
          type: 'deliverable',
          activity: `Deliverable ${item.status === 'certified' ? 'Certified' : item.status === 'completed' ? 'Completed' : 'Created'}`,
          icon: Package,
          color: item.status === 'certified' ? 'purple' : item.status === 'completed' ? 'green' : 'gray'
        })),
        ...risks.data.map(item => ({
          ...item,
          type: 'risk',
          activity: 'Risk Identified',
          icon: AlertTriangle,
          color: item.level === 'critical' ? 'red' : item.level === 'high' ? 'orange' : 'yellow'
        })),
        ...issues.data.map(item => ({
          ...item,
          type: 'issue',
          activity: `Issue ${item.status === 'resolved' ? 'Resolved' : item.status === 'in_progress' ? 'In Progress' : 'Reported'}`,
          icon: Bug,
          color: item.status === 'resolved' ? 'green' : item.priority === 'urgent' ? 'red' : 'blue'
        })),
        ...sroi.data.map(item => ({
          ...item,
          type: 'sroi',
          activity: 'SROI Calculated',
          icon: Calculator,
          color: 'indigo'
        }))
      ].sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

      setActivities(allActivities);
    } catch (error) {
      console.error('Failed to load activities:', error);
    } finally {
      setLoading(false);
    }
  };

  const getActivityMessage = (activity) => {
    const roleMap = {
      'administrator': 'Administrator',
      'investor': 'Investor',
      'social_actor': 'Social Actor'
    };

    const actorRole = roleMap[user.role] || 'User';
    
    switch (activity.type) {
      case 'kpi':
        return `${actorRole} added KPI: "${activity.name}"`;
      case 'deliverable':
        return `${actorRole} ${activity.activity.toLowerCase()}: "${activity.name}"`;
      case 'risk':
        return `${actorRole} identified ${activity.level} risk: "${activity.title}"`;
      case 'issue':
        return `${actorRole} ${activity.activity.toLowerCase()}: "${activity.title}"`;
      case 'sroi':
        return `${actorRole} calculated SROI ratio: ${activity.sroi_ratio.toFixed(2)}:1`;
      default:
        return `${actorRole} performed an action`;
    }
  };

  const getColorClasses = (color) => {
    const colorMap = {
      blue: 'bg-blue-100 text-blue-800 border-blue-200',
      green: 'bg-green-100 text-green-800 border-green-200',
      red: 'bg-red-100 text-red-800 border-red-200',
      yellow: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      orange: 'bg-orange-100 text-orange-800 border-orange-200',
      purple: 'bg-purple-100 text-purple-800 border-purple-200',
      indigo: 'bg-indigo-100 text-indigo-800 border-indigo-200',
      gray: 'bg-gray-100 text-gray-800 border-gray-200'
    };
    return colorMap[color] || colorMap.gray;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <Card data-testid="activity-feed">
      <CardHeader className="flex flex-row items-center justify-between pb-4">
        <CardTitle className="flex items-center space-x-2">
          <Activity className="h-5 w-5 text-blue-600" />
          <span>Real-time Activity Feed</span>
        </CardTitle>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={fetchActivities}
          disabled={loading}
          data-testid="refresh-activities"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </CardHeader>
      <CardContent className="max-h-96 overflow-y-auto">
        {activities.length > 0 ? (
          <div className="space-y-4">
            {activities.slice(0, 10).map((activity) => {
              const IconComponent = activity.icon;
              return (
                <div 
                  key={`${activity.type}-${activity.id}`} 
                  className="flex items-start space-x-3 p-3 border rounded-lg hover:bg-gray-50 transition-colors"
                  data-testid={`activity-${activity.type}-${activity.id}`}
                >
                  <div className={`p-2 rounded-full ${getColorClasses(activity.color)}`}>
                    <IconComponent className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-medium text-gray-900">
                        {getActivityMessage(activity)}
                      </p>
                      <div className="flex items-center space-x-1 text-xs text-gray-500">
                        <Calendar className="h-3 w-3" />
                        <span>{new Date(activity.created_at).toLocaleDateString()}</span>
                      </div>
                    </div>
                    
                    {/* Show additional details based on activity type */}
                    {activity.type === 'deliverable' && activity.status === 'certified' && (
                      <div className="flex items-center space-x-1 mt-1">
                        <CheckCircle2 className="h-3 w-3 text-green-600" />
                        <span className="text-xs text-green-600">Administrator Certified</span>
                      </div>
                    )}
                    
                    {activity.type === 'risk' && activity.level === 'critical' && (
                      <div className="flex items-center space-x-1 mt-1">
                        <AlertTriangle className="h-3 w-3 text-red-600" />
                        <span className="text-xs text-red-600">Critical Risk - Immediate Action Required</span>
                      </div>
                    )}
                    
                    {activity.type === 'sroi' && activity.sroi_ratio >= 3 && (
                      <div className="flex items-center space-x-1 mt-1">
                        <Target className="h-3 w-3 text-green-600" />
                        <span className="text-xs text-green-600">Excellent Social Impact Achieved</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <Activity className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>No recent activities</p>
            <p className="text-sm">Activities will appear here as team members interact with the project</p>
          </div>
        )}
        
        {activities.length > 10 && (
          <div className="text-center mt-4">
            <Button variant="outline" size="sm">
              View All {activities.length} Activities
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ActivityFeed;