import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import RiskIssueManagement from './RiskIssueManagement';
import SROICalculator from './SROICalculator';
import ActivityFeed from './ActivityFeed';
import TeamManagement from './TeamManagement';
// import DocumentManagement from './DocumentManagement';
import PhaseGateManagement from './PhaseGateManagement';
import AdvancedReporting from './AdvancedReporting';
import GanttChart from './GanttChart';
import FinancialManagement from './FinancialManagement';
import BeneficiaryTracking from './BeneficiaryTracking';
import ComplianceAudit from './ComplianceAudit';
import VideoVerification from './VideoVerification';
import MobileFieldApp from './MobileFieldApp';
import NotificationCenter from './NotificationCenter';
import QualityAssuranceModule from './QualityAssuranceModule';
import AdvancedAnalyticsAI from './AdvancedAnalyticsAI';
import ProcurementManagement from './ProcurementManagement';
import DigitalChecklists from './DigitalChecklists';
import DocumentEvidenceManagement from './DocumentEvidenceManagement';
import UniversalComments from './UniversalComments';
import ContractualCompliance from './ContractualCompliance';
import TemplateLibrary from './TemplateLibrary';
import { toast } from 'sonner';
import { 
  ArrowLeft,
  Plus,
  Calendar,
  DollarSign,
  Target,
  CheckCircle2,
  Clock,
  AlertCircle,
  TrendingUp,
  BookOpen,
  Heart,
  Leaf,
  Activity,
  Users,
  LogOut,
  Menu,
  X,
  BarChart3,
  Package,
  Award,
  AlertTriangle,
  Bug,
  Calculator,
  Upload,
  FileText,
  X as XIcon,
  Edit3,
  Trash2
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const ProjectDetails = ({ user, onLogout }) => {
  const { id } = useParams();
  const [project, setProject] = useState(null);
  const [kpis, setKpis] = useState([]);
  const [deliverables, setDeliverables] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showKpiDialog, setShowKpiDialog] = useState(false);
  const [showDeliverableDialog, setShowDeliverableDialog] = useState(false);
  const [kpiFormData, setKpiFormData] = useState({
    name: '',
    type: '',
    baseline_value: '',
    target_value: '',
    unit: ''
  });
  const [editingKpi, setEditingKpi] = useState(null);
  const [deliverableFormData, setDeliverableFormData] = useState({
    name: '',
    description: '',
    due_date: '',
    files: []
  });
  const [editingDeliverable, setEditingDeliverable] = useState(null);

  useEffect(() => {
    fetchProjectDetails();
  }, [id]);

  const fetchProjectDetails = async () => {
    try {
      const [projectRes, kpisRes, deliverablesRes] = await Promise.all([
        axios.get(`${API}/projects/${id}`),
        axios.get(`${API}/projects/${id}/kpis`),
        axios.get(`${API}/projects/${id}/deliverables`)
      ]);
      
      setProject(projectRes.data);
      setKpis(kpisRes.data);
      setDeliverables(deliverablesRes.data);
    } catch (error) {
      toast.error('Failed to load project details');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateKpi = async (e) => {
    e.preventDefault();
    try {
      const kpiData = {
        ...kpiFormData,
        baseline_value: parseFloat(kpiFormData.baseline_value),
        target_value: parseFloat(kpiFormData.target_value)
      };

      const isEditing = editingKpi !== null;

      if (isEditing) {
        await axios.put(`${API}/projects/${id}/kpis/${editingKpi}`, kpiData, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        toast.success('KPI updated successfully!');
      } else {
        await axios.post(`${API}/projects/${id}/kpis`, kpiData, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        toast.success('KPI created successfully!');
      }
      
      setShowKpiDialog(false);
      setKpiFormData({
        name: '',
        description: '',
        baseline_value: '',
        target_value: '',
        unit: ''
      });
      setEditingKpi(null);
      fetchProjectDetails();
    } catch (error) {
      toast.error(error.response?.data?.detail || `Failed to ${editingKpi ? 'update' : 'create'} KPI`);
    }
  };

  const handleDeleteKpi = async (kpiId) => {
    if (!window.confirm('Are you sure you want to delete this KPI?')) {
      return;
    }

    try {
      await axios.delete(`${API}/projects/${id}/kpis/${kpiId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      toast.success('KPI deleted successfully!');
      fetchProjectDetails();
    } catch (error) {
      console.error('Failed to delete KPI:', error);
      toast.error('Failed to delete KPI');
    }
  };

  const handleCreateDeliverable = async (e) => {
    e.preventDefault();
    try {
      const deliverableData = {
        ...deliverableFormData,
        due_date: new Date(deliverableFormData.due_date).toISOString(),
        files: [] // Will be populated after file uploads
      };

      let deliverableId;
      let isEditing = editingDeliverable !== null;

      if (isEditing) {
        // Update existing deliverable
        await axios.put(`${API}/projects/${id}/deliverables/${editingDeliverable}`, deliverableData, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        deliverableId = editingDeliverable;
      } else {
        // Create new deliverable
        const response = await axios.post(`${API}/projects/${id}/deliverables`, deliverableData, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        deliverableId = response.data.id;
      }

      // Upload files if any
      if (deliverableFormData.files.length > 0) {
        const uploadPromises = deliverableFormData.files.map(async (file) => {
          const formData = new FormData();
          formData.append('file', file);
          formData.append('deliverable_id', deliverableId);
          
          return axios.post(`${API}/projects/${id}/deliverables/${deliverableId}/upload`, formData, {
            headers: { 
              Authorization: `Bearer ${localStorage.getItem('token')}`,
              'Content-Type': 'multipart/form-data'
            }
          });
        });

        await Promise.all(uploadPromises);
      }

      toast.success(`Deliverable ${isEditing ? 'updated' : 'created'} successfully! ${deliverableFormData.files.length > 0 ? `${deliverableFormData.files.length} file(s) uploaded.` : ''}`);
      setShowDeliverableDialog(false);
      setDeliverableFormData({
        name: '',
        description: '',
        due_date: '',
        files: []
      });
      setEditingDeliverable(null);
      fetchProjectDetails();
    } catch (error) {
      console.error(`Failed to ${editingDeliverable ? 'update' : 'create'} deliverable:`, error);
      toast.error(`Failed to ${editingDeliverable ? 'update' : 'create'} deliverable`);
    }
  };

  const handleDeleteDeliverable = async (deliverableId) => {
    if (!window.confirm('Are you sure you want to delete this deliverable?')) {
      return;
    }

    try {
      await axios.delete(`${API}/projects/${id}/deliverables/${deliverableId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      toast.success('Deliverable deleted successfully!');
      fetchProjectDetails();
    } catch (error) {
      console.error('Failed to delete deliverable:', error);
      toast.error('Failed to delete deliverable');
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'education': return <BookOpen className="h-5 w-5" />;
      case 'care': return <Heart className="h-5 w-5" />;
      case 'environment': return <Leaf className="h-5 w-5" />;
      default: return <Activity className="h-5 w-5" />;
    }
  };

  const getCategoryColor = (category) => {
    switch (category) {
      case 'education': return 'bg-blue-100 text-blue-800';
      case 'care': return 'bg-green-100 text-green-800';
      case 'environment': return 'bg-emerald-100 text-emerald-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'executing': return 'bg-green-100 text-green-800';
      case 'planning': return 'bg-yellow-100 text-yellow-800';
      case 'initiating': return 'bg-blue-100 text-blue-800';
      case 'closing': return 'bg-purple-100 text-purple-800';
      case 'on_hold': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getDeliverableStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'certified': return 'bg-purple-100 text-purple-800';
      case 'in_progress': return 'bg-blue-100 text-blue-800';
      case 'planned': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const calculateKpiProgress = (kpi) => {
    const range = kpi.target_value - kpi.baseline_value;
    const progress = kpi.actual_value - kpi.baseline_value;
    return Math.max(0, Math.min(100, (progress / range) * 100));
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Project Not Found</h2>
          <p className="text-gray-600 mb-4">The requested project could not be found.</p>
          <Link to="/projects">
            <Button>Back to Projects</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`fixed left-0 top-0 h-full w-64 bg-white shadow-xl transform transition-transform duration-300 ease-in-out z-50 lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-800">POTC Platform</h2>
            <button 
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <p className="text-sm text-gray-600 mt-1">Physical Object Tracking</p>
        </div>

        <nav className="mt-6 px-4">
          <div className="space-y-2">
            <Link 
              to="/dashboard" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-colors"
            >
              <BarChart3 className="h-5 w-5" />
              <span>Dashboard</span>
            </Link>
            <Link 
              to="/projects" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-colors"
            >
              <Activity className="h-5 w-5" />
              <span>Projects</span>
            </Link>
            <Link 
              to="/templates" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-colors"
            >
              <BookOpen className="h-5 w-5" />
              <span>Electronic Library of Financial Instruments & Supporting Material</span>
            </Link>
          </div>
        </nav>

        <div className="absolute bottom-6 left-4 right-4">
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Users className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">{user.username}</p>
                <p className="text-sm text-gray-500 capitalize">{user.role.replace('_', ' ')}</p>
              </div>
            </div>
            <Button 
              onClick={onLogout} 
              variant="outline" 
              size="sm" 
              className="w-full"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:ml-64">
        <header className="bg-white shadow-sm border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"
              >
                <Menu className="h-5 w-5" />
              </button>
              <Link 
                to="/projects" 
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900"
                data-testid="back-to-projects"
              >
                <ArrowLeft className="h-4 w-4" />
                <span>Back to Projects</span>
              </Link>
            </div>
          </div>
        </header>

        <main className="p-6">
          {/* Project Header */}
          <div className="mb-8">
            <div className="flex items-start justify-between mb-4">
              <div>
                <div className="flex items-center space-x-3 mb-2">
                  <div className="p-2 rounded-full bg-gray-100">
                    {getCategoryIcon(project.category)}
                  </div>
                  <Badge className={getCategoryColor(project.category)}>
                    {project.category}
                  </Badge>
                  <Badge className={getStatusColor(project.status)}>
                    {project.status.replace('_', ' ')}
                  </Badge>
                </div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2" data-testid="project-title">
                  {project.title}
                </h1>
                <p className="text-gray-600 max-w-3xl" data-testid="project-description">
                  {project.description}
                </p>
              </div>
            </div>

            {/* Project Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 rounded-full bg-blue-100">
                      <Target className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Progress</p>
                      <p className="text-2xl font-bold text-blue-600">{Math.round(project.progress)}%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 rounded-full bg-green-100">
                      <DollarSign className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Budget</p>
                      <p className="text-lg font-bold text-green-600">{formatCurrency(project.budget)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 rounded-full bg-orange-100">
                      <TrendingUp className="h-5 w-5 text-orange-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Spent</p>
                      <p className="text-lg font-bold text-orange-600">{formatCurrency(project.actual_cost)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 rounded-full bg-purple-100">
                      <Calendar className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">End Date</p>
                      <p className="text-sm font-bold text-purple-600">{new Date(project.end_date).toLocaleDateString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="kpis" className="space-y-6">
            <TabsList className="flex flex-wrap w-full bg-muted p-1 text-muted-foreground" style={{height: 'auto', flexDirection: 'row', justifyContent: 'flex-start'}}>
              {/* All tabs with specific width to force wrapping after 10 tabs */}
              <TabsTrigger value="kpis" data-testid="kpis-tab" className="text-xs" style={{width: '9.8%', margin: '1px'}}>KPIs</TabsTrigger>
              <TabsTrigger value="deliverables" data-testid="deliverables-tab" className="text-xs" style={{width: '9.8%', margin: '1px'}}>Deliverables</TabsTrigger>
              <TabsTrigger value="risks" data-testid="risks-tab" className="text-xs" style={{width: '9.8%', margin: '1px'}}>Risks & Issues</TabsTrigger>
              <TabsTrigger value="impact" data-testid="impact-tab" className="text-xs" style={{width: '9.8%', margin: '1px'}}>Impact & SROI</TabsTrigger>
              {/* Documents tab removed - functionality moved to deliverables */}
              <TabsTrigger value="phase-gates" data-testid="phase-gates-tab" className="text-xs" style={{width: '9.8%', margin: '1px'}}>Phase Gates</TabsTrigger>
              <TabsTrigger value="timeline" data-testid="timeline-tab" className="text-xs" style={{width: '9.8%', margin: '1px'}}>Timeline</TabsTrigger>
              <TabsTrigger value="financial" data-testid="financial-tab" className="text-xs" style={{width: '9.8%', margin: '1px'}}>Financial</TabsTrigger>
              <TabsTrigger value="beneficiaries" data-testid="beneficiaries-tab" className="text-xs" style={{width: '9.8%', margin: '1px'}}>Beneficiaries</TabsTrigger>
              <TabsTrigger value="compliance" data-testid="compliance-tab" className="text-xs" style={{width: '9.8%', margin: '1px'}}>Compliance</TabsTrigger>
              
              {/* Force line break and second row */}
              <div style={{flexBasis: '100%', height: '0'}}></div>
              
              <TabsTrigger value="videos" data-testid="videos-tab" className="text-xs" style={{width: '9.5%', margin: '1px'}}>Videos</TabsTrigger>
              <TabsTrigger value="mobile" data-testid="mobile-tab" className="text-xs" style={{width: '9.5%', margin: '1px'}}>Mobile Field</TabsTrigger>
              <TabsTrigger value="notifications" data-testid="notifications-tab" className="text-xs" style={{width: '9.5%', margin: '1px'}}>Notifications</TabsTrigger>
              <TabsTrigger value="quality" data-testid="quality-tab" className="text-xs" style={{width: '9.5%', margin: '1px'}}>Quality</TabsTrigger>
              <TabsTrigger value="analytics" data-testid="analytics-tab" className="text-xs" style={{width: '9.5%', margin: '1px'}}>Analytics & AI</TabsTrigger>
              <TabsTrigger value="procurement" data-testid="procurement-tab" className="text-xs" style={{width: '9.5%', margin: '1px'}}>Procurement</TabsTrigger>
              <TabsTrigger value="reports" data-testid="reports-tab" className="text-xs" style={{width: '9.5%', margin: '1px'}}>Reports</TabsTrigger>
              <TabsTrigger value="activity" data-testid="activity-tab" className="text-xs" style={{width: '9.5%', margin: '1px'}}>Activity</TabsTrigger>
              <TabsTrigger value="collaboration" data-testid="collaboration-tab" className="text-xs" style={{width: '9.5%', margin: '1px'}}>Team</TabsTrigger>
              <TabsTrigger value="checklists" data-testid="checklists-tab" className="text-xs" style={{width: '9.5%', margin: '1px'}}>Checklists</TabsTrigger>
              <TabsTrigger value="documents" data-testid="documents-tab" className="text-xs" style={{width: '9.5%', margin: '1px'}}>Evidence</TabsTrigger>
            </TabsList>

            {/* KPIs Tab */}
            <TabsContent value="kpis" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Key Performance Indicators</h2>
                <Dialog open={showKpiDialog} onOpenChange={setShowKpiDialog}>
                  <DialogTrigger asChild>
                    <Button data-testid="add-kpi-button">
                      <Plus className="h-4 w-4 mr-2" />
                      Add KPI
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>{editingKpi ? 'Edit KPI' : 'Add New KPI'}</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleCreateKpi} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="kpi-name">KPI Name</Label>
                        <Input
                          id="kpi-name"
                          value={kpiFormData.name}
                          onChange={(e) => setKpiFormData({...kpiFormData, name: e.target.value})}
                          placeholder="e.g., Students Trained"
                          required
                          data-testid="kpi-name-input"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="kpi-type">Type</Label>
                          <Select value={kpiFormData.type} onValueChange={(value) => setKpiFormData({...kpiFormData, type: value})}>
                            <SelectTrigger data-testid="kpi-type-select" className="relative z-50">
                              <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                            <SelectContent className="z-50">
                              <SelectItem value="quantitative">Quantitative</SelectItem>
                              <SelectItem value="qualitative">Qualitative</SelectItem>
                              <SelectItem value="impact">Impact</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="kpi-unit">Unit</Label>
                          <Input
                            id="kpi-unit"
                            value={kpiFormData.unit}
                            onChange={(e) => setKpiFormData({...kpiFormData, unit: e.target.value})}
                            placeholder="e.g., people, %, score"
                            required
                            data-testid="kpi-unit-input"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="baseline">Baseline Value</Label>
                          <Input
                            id="baseline"
                            type="number"
                            value={kpiFormData.baseline_value}
                            onChange={(e) => setKpiFormData({...kpiFormData, baseline_value: e.target.value})}
                            placeholder="0"
                            required
                            data-testid="kpi-baseline-input"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="target">Target Value</Label>
                          <Input
                            id="target"
                            type="number"
                            value={kpiFormData.target_value}
                            onChange={(e) => setKpiFormData({...kpiFormData, target_value: e.target.value})}
                            placeholder="100"
                            required
                            data-testid="kpi-target-input"
                          />
                        </div>
                      </div>
                      <div className="flex justify-end space-x-2 pt-4">
                        <Button type="button" variant="outline" onClick={() => {
                          setShowKpiDialog(false);
                          setEditingKpi(null);
                          setKpiFormData({
                            name: '',
                            description: '',
                            baseline_value: '',
                            target_value: '',
                            unit: ''
                          });
                        }}>
                          Cancel
                        </Button>
                        <Button type="submit" data-testid="create-kpi-submit">{editingKpi ? 'Update KPI' : 'Create KPI'}</Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {kpis.map((kpi) => (
                  <Card key={kpi.id} data-testid={`kpi-card-${kpi.id}`}>
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{kpi.name}</CardTitle>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline" className="capitalize">
                            {kpi.type}
                          </Badge>
                          {/* Edit/Delete Actions for Admin and Social Actor */}
                          {user.role !== 'investor' && (
                            <div className="flex items-center space-x-1">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => {
                                  setKpiFormData({
                                    name: kpi.name,
                                    description: kpi.description,
                                    baseline_value: kpi.baseline_value.toString(),
                                    target_value: kpi.target_value.toString(),
                                    unit: kpi.unit
                                  });
                                  setEditingKpi(kpi.id);
                                  setShowKpiDialog(true);
                                }}
                                className="text-blue-600 hover:text-blue-800"
                              >
                                <Edit3 className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleDeleteKpi(kpi.id)}
                                className="text-red-600 hover:text-red-800"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="grid grid-cols-3 gap-4 text-sm">
                          <div>
                            <p className="text-gray-500">Baseline</p>
                            <p className="font-semibold">{kpi.baseline_value} {kpi.unit}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Target</p>
                            <p className="font-semibold">{kpi.target_value} {kpi.unit}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Actual</p>
                            <p className="font-semibold">{kpi.actual_value} {kpi.unit}</p>
                          </div>
                        </div>
                        <div>
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-sm font-medium">Progress</span>
                            <span className="text-sm text-gray-600">
                              {Math.round(calculateKpiProgress(kpi))}%
                            </span>
                          </div>
                          <Progress value={calculateKpiProgress(kpi)} />
                        </div>
                        
                        {/* Comments for individual KPI */}
                        <div className="mt-4 pt-4 border-t">
                          <UniversalComments 
                            projectId={id} 
                            user={user} 
                            itemType="kpi" 
                            itemId={kpi.id}
                            title={`Comments for ${kpi.name}`} 
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {kpis.length === 0 && (
                  <div className="col-span-full text-center py-8 text-gray-500">
                    <Target className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No KPIs defined yet</p>
                    <p className="text-sm">Add KPIs to track your project's success metrics</p>
                  </div>
                )}
              </div>
              
              {/* Universal Comments for KPIs */}
              <UniversalComments 
                projectId={id} 
                user={user} 
                itemType="kpis" 
                title="KPIs Comments & Feedback" 
              />
            </TabsContent>

            {/* Deliverables Tab */}
            <TabsContent value="deliverables" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Project Deliverables</h2>
                <Dialog open={showDeliverableDialog} onOpenChange={setShowDeliverableDialog}>
                  <DialogTrigger asChild>
                    <Button data-testid="add-deliverable-button">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Deliverable
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>{editingDeliverable ? 'Edit Deliverable' : 'Add New Deliverable'}</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleCreateDeliverable} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="deliverable-name">Deliverable Name</Label>
                        <Input
                          id="deliverable-name"
                          value={deliverableFormData.name}
                          onChange={(e) => setDeliverableFormData({...deliverableFormData, name: e.target.value})}
                          placeholder="e.g., Training Materials"
                          required
                          data-testid="deliverable-name-input"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="deliverable-description">Description</Label>
                        <Textarea
                          id="deliverable-description"
                          value={deliverableFormData.description}
                          onChange={(e) => setDeliverableFormData({...deliverableFormData, description: e.target.value})}
                          placeholder="Describe the deliverable..."
                          rows={3}
                          required
                          data-testid="deliverable-description-input"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="due-date">Due Date</Label>
                        <Input
                          id="due-date"
                          type="date"
                          value={deliverableFormData.due_date}
                          onChange={(e) => setDeliverableFormData({...deliverableFormData, due_date: e.target.value})}
                          required
                          data-testid="deliverable-due-date-input"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="deliverable-files">Files (Optional)</Label>
                        <Input
                          id="deliverable-files"
                          type="file"
                          multiple
                          onChange={(e) => setDeliverableFormData({...deliverableFormData, files: Array.from(e.target.files)})}
                          data-testid="deliverable-files-input"
                          className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                        />
                        {deliverableFormData.files.length > 0 && (
                          <div className="mt-2">
                            <p className="text-sm text-gray-600 mb-2">Selected files:</p>
                            <div className="space-y-1">
                              {deliverableFormData.files.map((file, index) => (
                                <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded text-sm">
                                  <div className="flex items-center space-x-2">
                                    <FileText className="h-4 w-4 text-gray-500" />
                                    <span>{file.name}</span>
                                    <span className="text-gray-500">({(file.size / 1024 / 1024).toFixed(2)} MB)</span>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newFiles = deliverableFormData.files.filter((_, i) => i !== index);
                                      setDeliverableFormData({...deliverableFormData, files: newFiles});
                                    }}
                                    className="text-red-500 hover:text-red-700"
                                  >
                                    <XIcon className="h-4 w-4" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="deliverable-files">Files (Optional)</Label>
                        <Input
                          id="deliverable-files"
                          type="file"
                          multiple
                          onChange={(e) => setDeliverableFormData({...deliverableFormData, files: Array.from(e.target.files)})}
                          data-testid="deliverable-files-input"
                          className="file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                        />
                        {deliverableFormData.files.length > 0 && (
                          <div className="mt-2">
                            <p className="text-sm text-gray-600 mb-2">Selected files:</p>
                            <div className="space-y-1">
                              {deliverableFormData.files.map((file, index) => (
                                <div key={index} className="flex items-center justify-between bg-gray-50 p-2 rounded text-sm">
                                  <div className="flex items-center space-x-2">
                                    <FileText className="h-4 w-4 text-gray-500" />
                                    <span>{file.name}</span>
                                    <span className="text-gray-500">({(file.size / 1024 / 1024).toFixed(2)} MB)</span>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const newFiles = deliverableFormData.files.filter((_, i) => i !== index);
                                      setDeliverableFormData({...deliverableFormData, files: newFiles});
                                    }}
                                    className="text-red-500 hover:text-red-700"
                                  >
                                    <XIcon className="h-4 w-4" />
                                  </button>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="flex justify-end space-x-2 pt-4">
                        <Button type="button" variant="outline" onClick={() => {
                          setShowDeliverableDialog(false);
                          setEditingDeliverable(null);
                          setDeliverableFormData({
                            name: '',
                            description: '',
                            due_date: '',
                            files: []
                          });
                        }}>
                          Cancel
                        </Button>
                        <Button type="submit" data-testid="create-deliverable-submit">{editingDeliverable ? 'Update Deliverable' : 'Create Deliverable'}</Button>
                      </div>
                    </form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="space-y-4">
                {deliverables.map((deliverable) => (
                  <Card key={deliverable.id} data-testid={`deliverable-card-${deliverable.id}`}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <Package className="h-5 w-5 text-gray-600" />
                            <h3 className="font-semibold text-lg">{deliverable.name}</h3>
                            <Badge className={getDeliverableStatusColor(deliverable.status)}>
                              {deliverable.status.replace('_', ' ')}
                            </Badge>
                            {deliverable.certification_status && (
                              <Badge className="bg-purple-100 text-purple-800">
                                <Award className="h-3 w-3 mr-1" />
                                Certified
                              </Badge>
                            )}
                          </div>
                          <p className="text-gray-600 mb-3">{deliverable.description}</p>
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <div className="flex items-center space-x-1">
                              <Calendar className="h-4 w-4" />
                              <span>Due: {new Date(deliverable.due_date).toLocaleDateString()}</span>
                            </div>
                            {new Date(deliverable.due_date) < new Date() && deliverable.status !== 'completed' && deliverable.status !== 'certified' && (
                              <Badge className="bg-red-100 text-red-800">
                                <AlertCircle className="h-3 w-3 mr-1" />
                                Overdue
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="ml-4 flex items-center space-x-2">
                          {deliverable.status === 'completed' ? (
                            <CheckCircle2 className="h-8 w-8 text-green-500" />
                          ) : deliverable.status === 'certified' ? (
                            <Award className="h-8 w-8 text-purple-500" />
                          ) : deliverable.status === 'in_progress' ? (
                            <Clock className="h-8 w-8 text-blue-500" />
                          ) : (
                            <AlertCircle className="h-8 w-8 text-gray-400" />
                          )}
                          
                          {/* Edit/Delete Actions for Admin and Social Actor */}
                          {user.role !== 'investor' && (
                            <div className="flex items-center space-x-1 ml-2">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => {
                                  setDeliverableFormData({
                                    name: deliverable.name,
                                    description: deliverable.description,
                                    due_date: deliverable.due_date.split('T')[0],
                                    priority: deliverable.priority || 'medium',
                                    files: []
                                  });
                                  setEditingDeliverable(deliverable.id);
                                  setShowDeliverableDialog(true);
                                }}
                                className="text-blue-600 hover:text-blue-800"
                              >
                                <Edit3 className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleDeleteDeliverable(deliverable.id)}
                                className="text-red-600 hover:text-red-800"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {/* Comments for individual deliverable */}
                      <div className="mt-4 pt-4 border-t">
                        <UniversalComments 
                          projectId={id} 
                          user={user} 
                          itemType="deliverable" 
                          itemId={deliverable.id}
                          title={`Comments for ${deliverable.name}`} 
                        />
                      </div>
                    </CardContent>
                  </Card>
                ))}
                {deliverables.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Package className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No deliverables defined yet</p>
                    <p className="text-sm">Add deliverables to track project outputs</p>
                  </div>
                )}
              </div>
              
              {/* Universal Comments for Deliverables */}
              <UniversalComments 
                projectId={id} 
                user={user} 
                itemType="deliverables" 
                title="Deliverables Comments & Feedback" 
              />
            </TabsContent>

            {/* Risks & Issues Tab */}
            <TabsContent value="risks" className="space-y-6">
              <RiskIssueManagement projectId={id} user={user} />
            </TabsContent>

            {/* Impact & SROI Tab */}
            <TabsContent value="impact" className="space-y-6">
              <SROICalculator projectId={id} user={user} />
            </TabsContent>

            {/* Document Management Tab removed - file uploads moved to deliverables */}

            {/* Phase Gate Management Tab */}
            <TabsContent value="phase-gates" className="space-y-6">
              <PhaseGateManagement projectId={id} user={user} />
            </TabsContent>

            {/* Gantt Chart & Timeline Management Tab */}
            <TabsContent value="timeline" className="space-y-6">
              <GanttChart projectId={id} user={user} />
              
              {/* Contractual Compliance & Accountability Section */}
              <div className="mt-8">
                <ContractualCompliance projectId={id} user={user} />
              </div>
            </TabsContent>

            {/* Financial Management Suite Tab */}
            <TabsContent value="financial" className="space-y-6">
              <FinancialManagement projectId={id} user={user} />
            </TabsContent>

            {/* Beneficiary Tracking Module Tab */}
            <TabsContent value="beneficiaries" className="space-y-6">
              <BeneficiaryTracking projectId={id} user={user} />
            </TabsContent>

            {/* Compliance & Audit Module Tab */}
            <TabsContent value="compliance" className="space-y-6">
              <ComplianceAudit projectId={id} user={user} />
            </TabsContent>

            {/* Video Verification System Tab */}
            <TabsContent value="videos" className="space-y-6">
              <VideoVerification projectId={id} user={user} />
            </TabsContent>

            {/* Mobile Field Application Tab */}
            <TabsContent value="mobile" className="space-y-6">
              <MobileFieldApp projectId={id} user={user} />
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications" className="space-y-6">
              <NotificationCenter user={user} />
            </TabsContent>

            {/* Quality Assurance Module Tab */}
            <TabsContent value="quality" className="space-y-6">
              <QualityAssuranceModule projectId={id} user={user} />
            </TabsContent>

            {/* Advanced Analytics & AI Tab */}
            <TabsContent value="analytics" className="space-y-6">
              <AdvancedAnalyticsAI projectId={id} user={user} />
            </TabsContent>

            {/* Procurement Management Tab */}
            <TabsContent value="procurement" className="space-y-6">
              <ProcurementManagement projectId={id} user={user} />
            </TabsContent>

            {/* Advanced Reporting Engine Tab */}
            <TabsContent value="reports" className="space-y-6">
              <AdvancedReporting projectId={id} user={user} />
            </TabsContent>

            {/* Activity Feed Tab */}
            <TabsContent value="activity" className="space-y-6">
              <ActivityFeed projectId={id} user={user} />
            </TabsContent>

            {/* Team Management Tab */}
            <TabsContent value="collaboration" className="space-y-6">
              <TeamManagement projectId={id} user={user} />
            </TabsContent>

            {/* Digital Checklists Tab */}
            <TabsContent value="checklists" className="space-y-6">
              <DigitalChecklists projectId={id} user={user} />
            </TabsContent>

            {/* Document Evidence Management Tab */}
            <TabsContent value="documents" className="space-y-6">
              <DocumentEvidenceManagement projectId={id} user={user} />
            </TabsContent>
          </Tabs>

          {/* Electronic Library of Financial Instruments & Supporting Material Section */}
          <div className="mt-8">
            <TemplateLibrary user={user} />
          </div>
        </main>
      </div>
    </div>
  );
};

export default ProjectDetails;