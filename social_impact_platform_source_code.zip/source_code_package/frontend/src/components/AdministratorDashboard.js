import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  Users, 
  TrendingUp, 
  DollarSign, 
  Activity, 
  BookOpen, 
  Heart, 
  Leaf, 
  BarChart3, 
  Clock,
  Target,
  AlertCircle,
  CheckCircle2,
  Shield,
  Settings,
  UserCheck,
  Building,
  Download
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const AdministratorDashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await axios.get(`${API}/dashboard`);
      setDashboardData(response.data);
    } catch (error) {
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'education': return <BookOpen className="h-5 w-5" />;
      case 'care': return <Heart className="h-5 w-5" />;
      case 'environment': return <Leaf className="h-5 w-5" />;
      default: return <Activity className="h-5 w-5" />;
    }
  };

  const getCategoryColor = (category) => {
    switch (category) {
      case 'education': return 'bg-blue-100 text-blue-800';
      case 'care': return 'bg-green-100 text-green-800';
      case 'environment': return 'bg-emerald-100 text-emerald-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'executing': return 'bg-green-100 text-green-800';
      case 'planning': return 'bg-yellow-100 text-yellow-800';
      case 'initiating': return 'bg-blue-100 text-blue-800';
      case 'closing': return 'bg-purple-100 text-purple-800';
      case 'on_hold': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const downloadSourceCode = async (format = 'html') => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`${API}/admin/source-code-documentation/download`, {
        params: { format },
        headers: {
          'Authorization': `Bearer ${token}`
        },
        responseType: 'blob'
      });
      
      // Create download link
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `Complete_Source_Code_Documentation.${format === 'html' ? 'html' : 'md'}`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      
      toast.success(`Source code documentation downloaded as ${format.toUpperCase()}`);
    } catch (error) {
      console.error('Download failed:', error);
      toast.error('Failed to download source code documentation');
    }
  };

  const StatCard = ({ title, value, icon: Icon, subtitle, color = "blue" }) => (
    <Card className="hover-lift transition-all duration-300" data-testid={`admin-stat-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className={`text-2xl font-bold text-${color}-600`}>{value}</p>
            {subtitle && (
              <p className="text-xs text-gray-500">{subtitle}</p>
            )}
          </div>
          <div className={`p-3 rounded-full bg-${color}-100`}>
            <Icon className={`h-6 w-6 text-${color}-600`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center space-x-3">
            <Shield className="h-8 w-8 text-blue-600" />
            <span>Administrator Dashboard</span>
          </h1>
          <p className="text-gray-600 mt-1">ISISP Platform Management & Oversight</p>
        </div>
        <Link to="/admin/settings">
          <Button className="bg-gradient-to-r from-blue-600 to-indigo-600">
            <Settings className="h-4 w-4 mr-2" />
            Platform Settings
          </Button>
        </Link>
      </div>

      {/* Platform Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Projects"
          value={dashboardData?.total_projects || 0}
          icon={Activity}
          subtitle="Platform-wide"
          color="blue"
        />
        <StatCard
          title="Active Projects"
          value={dashboardData?.active_projects || 0}
          icon={TrendingUp}
          subtitle="Currently executing"
          color="green"
        />
        <StatCard
          title="Total Users"
          value={dashboardData?.total_users || 0}
          icon={Users}
          subtitle="All platform users"
          color="purple"
        />
        <StatCard
          title="Platform Budget"
          value={formatCurrency(dashboardData?.total_budget || 0)}
          icon={DollarSign}
          subtitle="Total managed funds"
          color="orange"
        />
      </div>

      {/* User Distribution */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <UserCheck className="h-5 w-5 text-green-600" />
              <span>User Distribution</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                  <span className="text-sm text-gray-600">Investors</span>
                </div>
                <span className="font-semibold">{dashboardData?.total_investors || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <span className="text-sm text-gray-600">Social Actors</span>
                </div>
                <span className="font-semibold">{dashboardData?.total_social_actors || 0}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full bg-purple-500"></div>
                  <span className="text-sm text-gray-600">Administrators</span>
                </div>
                <span className="font-semibold">
                  {(dashboardData?.total_users || 0) - (dashboardData?.total_investors || 0) - (dashboardData?.total_social_actors || 0)}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Building className="h-5 w-5 text-indigo-600" />
              <span>Platform Health</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Budget Utilization</span>
                <span className="font-semibold">
                  {dashboardData?.total_budget ? 
                    Math.round((dashboardData.total_spent / dashboardData.total_budget) * 100) : 0}%
                </span>
              </div>
              <Progress 
                value={dashboardData?.total_budget ? 
                  (dashboardData.total_spent / dashboardData.total_budget) * 100 : 0} 
              />
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">Spent: {formatCurrency(dashboardData?.total_spent || 0)}</span>
                <span className="text-gray-500">Budget: {formatCurrency(dashboardData?.total_budget || 0)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Projects */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-blue-600" />
            <span>Recent Projects</span>
          </CardTitle>
          <Link to="/projects">
            <Button variant="outline" size="sm" data-testid="admin-view-all-projects">
              Manage All Projects
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {dashboardData?.recent_projects?.map((project) => (
              <div key={project.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center space-x-4">
                  <div className="p-2 rounded-full bg-gray-100">
                    {getCategoryIcon(project.category)}
                  </div>
                  <div>
                    <Link 
                      to={`/projects/${project.id}`}
                      className="font-medium text-gray-900 hover:text-blue-600 transition-colors"
                      data-testid={`admin-project-link-${project.id}`}
                    >
                      {project.title}
                    </Link>
                    <div className="flex items-center space-x-2 mt-1">
                      <Badge className={getCategoryColor(project.category)}>
                        {project.category}
                      </Badge>
                      <Badge className={getStatusColor(project.status)}>
                        {project.status.replace('_', ' ')}
                      </Badge>
                      <span className="text-xs text-gray-500">
                        Budget: {formatCurrency(project.budget)}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-sm font-medium">{Math.round(project.progress)}%</span>
                    {project.progress >= 75 ? (
                      <CheckCircle2 className="h-4 w-4 text-green-500" />
                    ) : project.progress >= 25 ? (
                      <Clock className="h-4 w-4 text-yellow-500" />
                    ) : (
                      <AlertCircle className="h-4 w-4 text-red-500" />
                    )}
                  </div>
                  <Progress value={project.progress} className="w-24" />
                </div>
              </div>
            ))}
            {(!dashboardData?.recent_projects || dashboardData.recent_projects.length === 0) && (
              <div className="text-center py-8 text-gray-500">
                <Activity className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No projects found on the platform.</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card data-testid="admin-quick-actions">
        <CardHeader>
          <CardTitle>Platform Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link to="/projects">
              <Button className="w-full justify-start h-auto p-4" variant="outline">
                <Activity className="h-5 w-5 mr-3" />
                <div className="text-left">
                  <p className="font-medium">Manage Projects</p>
                  <p className="text-sm text-gray-500">Oversee all platform projects</p>
                </div>
              </Button>
            </Link>
            <Link to="/admin/users">
              <Button className="w-full justify-start h-auto p-4" variant="outline">
                <Users className="h-5 w-5 mr-3" />
                <div className="text-left">
                  <p className="font-medium">User Management</p>
                  <p className="text-sm text-gray-500">Manage platform users, roles, and permissions</p>
                </div>
              </Button>
            </Link>
            <Link to="/admin/reports">
              <Button className="w-full justify-start h-auto p-4" variant="outline">
                <BarChart3 className="h-5 w-5 mr-3" />
                <div className="text-left">
                  <p className="font-medium">Platform Reports</p>
                  <p className="text-sm text-gray-500">View comprehensive analytics and insights</p>
                </div>
              </Button>
            </Link>
            <Button 
              className="w-full justify-start h-auto p-4" 
              variant="outline"
              onClick={() => downloadSourceCode('html')}
              data-testid="download-source-code-btn"
            >
              <Download className="h-5 w-5 mr-3" />
              <div className="text-left">
                <p className="font-medium">Download Source Code</p>
                <p className="text-sm text-gray-500">Get complete platform source code</p>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdministratorDashboard;