import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  DollarSign, 
  Plus, 
  TrendingUp, 
  TrendingDown,
  CreditCard, 
  Receipt, 
  PieChart,
  BarChart3,
  Calculator,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileText,
  Download,
  Filter,
  Calendar,
  Wallet,
  Target,
  Activity,
  Edit3,
  Trash2
} from 'lucide-react';
import UniversalComments from './UniversalComments';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const FinancialManagement = ({ projectId, user }) => {
  const [budget, setBudget] = useState(null);
  const [expenses, setExpenses] = useState([]);
  const [payments, setPayments] = useState([]);
  const [budgetCategories, setBudgetCategories] = useState([]);
  const [financialReports, setFinancialReports] = useState({});
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState('current_month');
  const [showExpenseDialog, setShowExpenseDialog] = useState(false);
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showBudgetDialog, setShowBudgetDialog] = useState(false);

  const [expenseFormData, setExpenseFormData] = useState({
    category: '',
    description: '',
    amount: '',
    expense_type: 'operational',
    receipt_url: '',
    approval_status: 'pending'
  });

  const [paymentFormData, setPaymentFormData] = useState({
    recipient: '',
    amount: '',
    description: '',
    payment_method: 'bank_transfer',
    due_date: '',
    status: 'pending'
  });

  const [budgetFormData, setBudgetFormData] = useState({
    category: '',
    allocated_amount: '',
    period: 'monthly',
    description: ''
  });
  const [editingExpense, setEditingExpense] = useState(null);
  const [editingPayment, setEditingPayment] = useState(null);

  useEffect(() => {
    fetchFinancialData();
  }, [projectId, selectedPeriod]);

  const fetchFinancialData = async () => {
    try {
      const [budgetRes, expensesRes, paymentsRes, categoriesRes] = await Promise.all([
        axios.get(`${API}/projects/${projectId}/budget`),
        axios.get(`${API}/projects/${projectId}/expenses?period=${selectedPeriod}`),
        axios.get(`${API}/projects/${projectId}/payments?period=${selectedPeriod}`),
        axios.get(`${API}/projects/${projectId}/budget-categories`)
      ]);
      
      setBudget(budgetRes.data);
      setExpenses(expensesRes.data);
      setPayments(paymentsRes.data);
      setBudgetCategories(categoriesRes.data);
      
      // Calculate financial reports
      const totalExpenses = expensesRes.data.reduce((sum, exp) => sum + exp.amount, 0);
      const totalPayments = paymentsRes.data.reduce((sum, pay) => sum + pay.amount, 0);
      const budgetUtilization = budgetRes.data.total_budget > 0 ? 
        ((totalExpenses / budgetRes.data.total_budget) * 100).toFixed(1) : 0;
      
      setFinancialReports({
        totalExpenses,
        totalPayments,
        budgetUtilization,
        remainingBudget: budgetRes.data.total_budget - totalExpenses,
        expensesByCategory: groupExpensesByCategory(expensesRes.data),
        monthlyTrend: calculateMonthlyTrend(expensesRes.data)
      });
      
    } catch (error) {
      toast.error('Failed to load financial data');
      console.error('Financial data fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  const groupExpensesByCategory = (expenses) => {
    const grouped = expenses.reduce((acc, expense) => {
      acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
      return acc;
    }, {});
    
    return Object.entries(grouped).map(([category, amount]) => ({ category, amount }));
  };

  const calculateMonthlyTrend = (expenses) => {
    const monthlyData = {};
    expenses.forEach(expense => {
      const month = new Date(expense.date).toISOString().slice(0, 7); // YYYY-MM
      monthlyData[month] = (monthlyData[month] || 0) + expense.amount;
    });
    
    return Object.entries(monthlyData)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, amount]) => ({ month, amount }));
  };

  const handleCreateExpense = async (e) => {
    e.preventDefault();
    try {
      const expenseData = {
        ...expenseFormData,
        amount: parseFloat(expenseFormData.amount),
        date: new Date().toISOString()
      };

      await axios.post(`${API}/projects/${projectId}/expenses`, expenseData);
      toast.success('Expense recorded successfully!');
      setShowExpenseDialog(false);
      setExpenseFormData({
        category: '',
        description: '',
        amount: '',
        expense_type: 'operational',
        receipt_url: '',
        approval_status: 'pending'
      });
      fetchFinancialData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to record expense');
    }
  };

  const handleCreatePayment = async (e) => {
    e.preventDefault();
    try {
      const paymentData = {
        ...paymentFormData,
        amount: parseFloat(paymentFormData.amount),
        due_date: new Date(paymentFormData.due_date).toISOString()
      };

      await axios.post(`${API}/projects/${projectId}/payments`, paymentData);
      toast.success('Payment scheduled successfully!');
      setShowPaymentDialog(false);
      setPaymentFormData({
        recipient: '',
        amount: '',
        description: '',
        payment_method: 'bank_transfer',
        due_date: '',
        status: 'pending'
      });
      fetchFinancialData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to schedule payment');
    }
  };

  const handleCreateBudgetCategory = async (e) => {
    e.preventDefault();
    try {
      const budgetData = {
        ...budgetFormData,
        allocated_amount: parseFloat(budgetFormData.allocated_amount)
      };

      await axios.post(`${API}/projects/${projectId}/budget-categories`, budgetData);
      toast.success('Budget category created successfully!');
      setShowBudgetDialog(false);
      setBudgetFormData({
        category: '',
        allocated_amount: '',
        period: 'monthly',
        description: ''
      });
      fetchFinancialData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to create budget category');
    }
  };

  const approveExpense = async (expenseId) => {
    try {
      await axios.patch(`${API}/projects/${projectId}/expenses/${expenseId}`, {
        approval_status: 'approved'
      });
      toast.success('Expense approved successfully');
      fetchFinancialData();
    } catch (error) {
      toast.error('Failed to approve expense');
    }
  };

  const processPayment = async (paymentId) => {
    try {
      await axios.patch(`${API}/projects/${projectId}/payments/${paymentId}`, {
        status: 'completed'
      });
      toast.success('Payment processed successfully');
      fetchFinancialData();
    } catch (error) {
      toast.error('Failed to process payment');
    }
  };

  const getExpenseStatusColor = (status) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPaymentStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      case 'cancelled': return 'bg-gray-100 text-gray-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const MetricCard = ({ title, value, subtitle, icon: Icon, color = 'blue', trend = null }) => (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className={`text-2xl font-bold text-${color}-600`}>{value}</p>
            {subtitle && <p className="text-xs text-gray-500">{subtitle}</p>}
          </div>
          <div className={`p-3 rounded-full bg-${color}-100`}>
            <Icon className={`h-5 w-5 text-${color}-600`} />
          </div>
        </div>
        {trend && (
          <div className={`flex items-center mt-2 text-xs ${trend.positive ? 'text-green-600' : 'text-red-600'}`}>
            {trend.positive ? 
              <TrendingUp className="h-3 w-3 mr-1" /> : 
              <TrendingDown className="h-3 w-3 mr-1" />
            }
            <span>{trend.value}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold flex items-center space-x-2">
            <DollarSign className="h-5 w-5 text-green-600" />
            <span>Financial Management Suite</span>
          </h3>
          <p className="text-sm text-gray-600">Budget tracking, expense management, and financial reporting</p>
        </div>
        <div className="flex items-center space-x-2">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-40" data-testid="period-select">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current_month">Current Month</SelectItem>
              <SelectItem value="last_month">Last Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
              <SelectItem value="year">This Year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Financial Overview */}
      {budget && financialReports && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            title="Total Budget"
            value={formatCurrency(budget.total_budget)}
            subtitle="Project allocation"
            icon={Target}
            color="blue"
          />
          <MetricCard
            title="Total Expenses"
            value={formatCurrency(financialReports.totalExpenses)}
            subtitle={`${financialReports.budgetUtilization}% utilized`}
            icon={Receipt}
            color="orange"
            trend={{ 
              positive: financialReports.budgetUtilization < 80, 
              value: `${financialReports.budgetUtilization}% of budget`
            }}
          />
          <MetricCard
            title="Remaining Budget"
            value={formatCurrency(financialReports.remainingBudget)}
            subtitle="Available funds"
            icon={Wallet}
            color="green"
          />
          <MetricCard
            title="Pending Payments"
            value={formatCurrency(financialReports.totalPayments)}
            subtitle={`${payments.filter(p => p.status === 'pending').length} transactions`}
            icon={Clock}
            color="purple"
          />
        </div>
      )}

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="expenses">Expenses</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
          <TabsTrigger value="budget">Budget</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Budget Utilization */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <PieChart className="h-5 w-5 text-blue-600" />
                  <span>Budget Utilization</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Overall Progress</span>
                    <span className="text-sm text-gray-600">{financialReports.budgetUtilization}%</span>
                  </div>
                  <Progress value={parseFloat(financialReports.budgetUtilization)} className="h-3" />
                  <div className="text-center">
                    <p className="text-2xl font-bold text-blue-600">
                      {formatCurrency(financialReports.remainingBudget)}
                    </p>
                    <p className="text-sm text-gray-600">Remaining Budget</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Expense Categories */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5 text-green-600" />
                  <span>Expenses by Category</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {financialReports.expensesByCategory?.slice(0, 5).map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm font-medium capitalize">{item.category}</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-20 bg-gray-200 rounded-full h-2">
                          <div 
                            className="h-2 bg-green-500 rounded-full"
                            style={{ 
                              width: `${(item.amount / Math.max(...financialReports.expensesByCategory.map(c => c.amount))) * 100}%` 
                            }}
                          ></div>
                        </div>
                        <span className="text-sm text-gray-600">{formatCurrency(item.amount)}</span>
                      </div>
                    </div>
                  )) || (
                    <p className="text-gray-500 text-center py-4">No expense data available</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Transactions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Activity className="h-5 w-5 text-purple-600" />
                <span>Recent Financial Activity</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[...expenses.slice(0, 3), ...payments.slice(0, 2)]
                  .sort((a, b) => new Date(b.date || b.created_at) - new Date(a.date || a.created_at))
                  .slice(0, 5)
                  .map((transaction, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className={`p-2 rounded-full ${transaction.category ? 'bg-orange-100' : 'bg-blue-100'}`}>
                          {transaction.category ? 
                            <Receipt className="h-4 w-4 text-orange-600" /> : 
                            <CreditCard className="h-4 w-4 text-blue-600" />
                          }
                        </div>
                        <div>
                          <p className="font-medium text-sm">
                            {transaction.description || transaction.recipient}
                          </p>
                          <p className="text-xs text-gray-500">
                            {transaction.category ? 'Expense' : 'Payment'} • {
                              new Date(transaction.date || transaction.created_at).toLocaleDateString()
                            }
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{formatCurrency(transaction.amount)}</p>
                        <Badge className={transaction.category ? 
                          getExpenseStatusColor(transaction.approval_status) : 
                          getPaymentStatusColor(transaction.status)
                        }>
                          {transaction.approval_status || transaction.status}
                        </Badge>
                      </div>
                    </div>
                  ))
                }
                {expenses.length === 0 && payments.length === 0 && (
                  <p className="text-gray-500 text-center py-8">No recent financial activity</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Expenses Tab */}
        <TabsContent value="expenses" className="space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-semibold">Expense Management</h4>
            <Dialog open={showExpenseDialog} onOpenChange={setShowExpenseDialog}>
              <DialogTrigger asChild>
                <Button data-testid="add-expense-button">
                  <Plus className="h-4 w-4 mr-2" />
                  Record Expense
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Record New Expense</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateExpense} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="expense-category">Category</Label>
                      <Select value={expenseFormData.category} onValueChange={(value) => 
                        setExpenseFormData({...expenseFormData, category: value})
                      }>
                        <SelectTrigger data-testid="expense-category-select">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="personnel">Personnel</SelectItem>
                          <SelectItem value="equipment">Equipment</SelectItem>
                          <SelectItem value="materials">Materials</SelectItem>
                          <SelectItem value="travel">Travel</SelectItem>
                          <SelectItem value="utilities">Utilities</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="expense-amount">Amount</Label>
                      <Input
                        id="expense-amount"
                        type="number"
                        step="0.01"
                        value={expenseFormData.amount}
                        onChange={(e) => setExpenseFormData({...expenseFormData, amount: e.target.value})}
                        placeholder="0.00"
                        required
                        data-testid="expense-amount-input"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="expense-description">Description</Label>
                    <Textarea
                      id="expense-description"
                      value={expenseFormData.description}
                      onChange={(e) => setExpenseFormData({...expenseFormData, description: e.target.value})}
                      placeholder="Describe the expense..."
                      rows={3}
                      required
                      data-testid="expense-description-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="expense-type">Expense Type</Label>
                    <Select value={expenseFormData.expense_type} onValueChange={(value) => 
                      setExpenseFormData({...expenseFormData, expense_type: value})
                    }>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="operational">Operational</SelectItem>
                        <SelectItem value="capital">Capital</SelectItem>
                        <SelectItem value="administrative">Administrative</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setShowExpenseDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" data-testid="create-expense-submit">Record Expense</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-4">
            {expenses.map((expense) => (
              <Card key={expense.id} data-testid={`expense-card-${expense.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="p-2 rounded-full bg-orange-100">
                        <Receipt className="h-5 w-5 text-orange-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">{expense.description}</h4>
                        <p className="text-sm text-gray-500 capitalize">
                          {expense.category} • {expense.expense_type}
                        </p>
                        <p className="text-xs text-gray-400">
                          {new Date(expense.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold">{formatCurrency(expense.amount)}</p>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge className={getExpenseStatusColor(expense.approval_status)}>
                          {expense.approval_status}
                        </Badge>
                        {expense.approval_status === 'pending' && user.role === 'administrator' && (
                          <Button 
                            size="sm" 
                            onClick={() => approveExpense(expense.id)}
                            data-testid={`approve-expense-${expense.id}`}
                          >
                            Approve
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            {expenses.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Receipt className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No expenses recorded yet</p>
                <p className="text-sm">Record expenses to track project spending</p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Payments Tab */}
        <TabsContent value="payments" className="space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-semibold">Payment Management</h4>
            <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
              <DialogTrigger asChild>
                <Button data-testid="add-payment-button">
                  <Plus className="h-4 w-4 mr-2" />
                  Schedule Payment
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Schedule New Payment</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreatePayment} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="payment-recipient">Recipient</Label>
                      <Input
                        id="payment-recipient"
                        value={paymentFormData.recipient}
                        onChange={(e) => setPaymentFormData({...paymentFormData, recipient: e.target.value})}
                        placeholder="e.g., Vendor Name"
                        required
                        data-testid="payment-recipient-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="payment-amount">Amount</Label>
                      <Input
                        id="payment-amount"
                        type="number"
                        step="0.01"
                        value={paymentFormData.amount}
                        onChange={(e) => setPaymentFormData({...paymentFormData, amount: e.target.value})}
                        placeholder="0.00"
                        required
                        data-testid="payment-amount-input"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="payment-description">Description</Label>
                    <Textarea
                      id="payment-description"
                      value={paymentFormData.description}
                      onChange={(e) => setPaymentFormData({...paymentFormData, description: e.target.value})}
                      placeholder="Payment purpose..."
                      rows={3}
                      required
                      data-testid="payment-description-input"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="payment-method">Payment Method</Label>
                      <Select value={paymentFormData.payment_method} onValueChange={(value) => 
                        setPaymentFormData({...paymentFormData, payment_method: value})
                      }>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                          <SelectItem value="check">Check</SelectItem>
                          <SelectItem value="cash">Cash</SelectItem>
                          <SelectItem value="credit_card">Credit Card</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="payment-due-date">Due Date</Label>
                      <Input
                        id="payment-due-date"
                        type="date"
                        value={paymentFormData.due_date}
                        onChange={(e) => setPaymentFormData({...paymentFormData, due_date: e.target.value})}
                        required
                        data-testid="payment-due-date-input"
                      />
                    </div>
                  </div>
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setShowPaymentDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" data-testid="create-payment-submit">Schedule Payment</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-4">
            {payments.map((payment) => (
              <Card key={payment.id} data-testid={`payment-card-${payment.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="p-2 rounded-full bg-blue-100">
                        <CreditCard className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">{payment.recipient}</h4>
                        <p className="text-sm text-gray-500">{payment.description}</p>
                        <p className="text-xs text-gray-400 capitalize">
                          {payment.payment_method.replace('_', ' ')} • Due: {new Date(payment.due_date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold">{formatCurrency(payment.amount)}</p>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge className={getPaymentStatusColor(payment.status)}>
                          {payment.status}
                        </Badge>
                        {payment.status === 'pending' && user.role === 'administrator' && (
                          <Button 
                            size="sm" 
                            onClick={() => processPayment(payment.id)}
                            data-testid={`process-payment-${payment.id}`}
                          >
                            Process
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            {payments.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <CreditCard className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No payments scheduled yet</p>
                <p className="text-sm">Schedule payments to manage cash flow</p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Budget Tab */}
        <TabsContent value="budget" className="space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-semibold">Budget Management</h4>
            <Dialog open={showBudgetDialog} onOpenChange={setShowBudgetDialog}>
              <DialogTrigger asChild>
                <Button data-testid="add-budget-category-button">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Category
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Budget Category</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateBudgetCategory} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="budget-category">Category Name</Label>
                      <Input
                        id="budget-category"
                        value={budgetFormData.category}
                        onChange={(e) => setBudgetFormData({...budgetFormData, category: e.target.value})}
                        placeholder="e.g., Training Materials"
                        required
                        data-testid="budget-category-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="budget-amount">Allocated Amount</Label>
                      <Input
                        id="budget-amount"
                        type="number"
                        step="0.01"
                        value={budgetFormData.allocated_amount}
                        onChange={(e) => setBudgetFormData({...budgetFormData, allocated_amount: e.target.value})}
                        placeholder="0.00"
                        required
                        data-testid="budget-amount-input"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="budget-description">Description</Label>
                    <Textarea
                      id="budget-description"
                      value={budgetFormData.description}
                      onChange={(e) => setBudgetFormData({...budgetFormData, description: e.target.value})}
                      placeholder="Budget category description..."
                      rows={3}
                      data-testid="budget-description-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="budget-period">Period</Label>
                    <Select value={budgetFormData.period} onValueChange={(value) => 
                      setBudgetFormData({...budgetFormData, period: value})
                    }>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="monthly">Monthly</SelectItem>
                        <SelectItem value="quarterly">Quarterly</SelectItem>
                        <SelectItem value="annual">Annual</SelectItem>
                        <SelectItem value="project">Project Duration</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setShowBudgetDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" data-testid="create-budget-category-submit">Create Category</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {budgetCategories.map((category) => {
              const spent = financialReports.expensesByCategory?.find(
                exp => exp.category === category.category
              )?.amount || 0;
              const utilization = category.allocated_amount > 0 ? 
                ((spent / category.allocated_amount) * 100).toFixed(1) : 0;
              
              return (
                <Card key={category.id} data-testid={`budget-category-${category.id}`}>
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex justify-between items-start">
                        <h4 className="font-medium capitalize">{category.category}</h4>
                        <Badge className={utilization > 100 ? 'bg-red-100 text-red-800' : 
                          utilization > 80 ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'
                        }>
                          {utilization}%
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">{category.description}</p>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Allocated:</span>
                          <span className="font-medium">{formatCurrency(category.allocated_amount)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Spent:</span>
                          <span className="font-medium">{formatCurrency(spent)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Remaining:</span>
                          <span className={`font-medium ${category.allocated_amount - spent < 0 ? 'text-red-600' : 'text-green-600'}`}>
                            {formatCurrency(category.allocated_amount - spent)}
                          </span>
                        </div>
                        <Progress value={Math.min(utilization, 100)} className="h-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
            {budgetCategories.length === 0 && (
              <div className="col-span-full text-center py-8 text-gray-500">
                <Calculator className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No budget categories defined yet</p>
                <p className="text-sm">Create budget categories to track spending</p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Reports Tab */}
        <TabsContent value="reports" className="space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-semibold">Financial Reports</h4>
            <div className="flex items-center space-x-2">
              <Button variant="outline" data-testid="export-financial-report">
                <Download className="h-4 w-4 mr-2" />
                Export Report
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Monthly Spending Trend */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="h-5 w-5 text-blue-600" />
                  <span>Monthly Spending Trend</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center text-gray-500">
                  📈 Monthly spending visualization
                  <br />
                  <small>(Chart would show spending trends over time)</small>
                </div>
              </CardContent>
            </Card>

            {/* Cost Analysis */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <PieChart className="h-5 w-5 text-green-600" />
                  <span>Cost Analysis</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">
                      {formatCurrency(financialReports.totalExpenses)}
                    </p>
                    <p className="text-sm text-gray-600">Total Project Costs</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Average Monthly Spend:</span>
                      <span className="font-medium">
                        {formatCurrency(financialReports.totalExpenses / Math.max(1, financialReports.monthlyTrend?.length || 1))}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Projected Annual Cost:</span>
                      <span className="font-medium">
                        {formatCurrency(financialReports.totalExpenses * 12 / Math.max(1, financialReports.monthlyTrend?.length || 1))}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Financial Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <FileText className="h-5 w-5 text-purple-600" />
                <span>Financial Summary</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600">
                    {formatCurrency(budget?.total_budget || 0)}
                  </div>
                  <p className="text-sm text-gray-600">Total Budget</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-orange-600">
                    {formatCurrency(financialReports.totalExpenses)}
                  </div>
                  <p className="text-sm text-gray-600">Total Expenses</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">
                    {financialReports.budgetUtilization}%
                  </div>
                  <p className="text-sm text-gray-600">Budget Utilization</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FinancialManagement;