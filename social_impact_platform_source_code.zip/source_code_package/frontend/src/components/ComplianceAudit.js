import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  Shield, 
  Plus, 
  CheckCircle2, 
  AlertTriangle,
  Clock,
  FileText,
  Eye,
  Download,
  Search,
  Calendar,
  User,
  Activity,
  BarChart3,
  Target,
  Award,
  ExternalLink,
  AlertCircle,
  Bookmark,
  Flag,
  Settings
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const ComplianceAudit = ({ projectId, user }) => {
  const [complianceItems, setComplianceItems] = useState([]);
  const [auditTrail, setAuditTrail] = useState([]);
  const [certifications, setCertifications] = useState([]);
  const [complianceStats, setComplianceStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [showComplianceDialog, setShowComplianceDialog] = useState(false);
  const [showCertificationDialog, setShowCertificationDialog] = useState(false);

  const [complianceFormData, setComplianceFormData] = useState({
    requirement: '',
    description: '',
    regulatory_body: '',
    compliance_status: 'pending',
    due_date: '',
    priority: 'medium',
    evidence_required: '',
    assigned_to: ''
  });

  const [certificationFormData, setCertificationFormData] = useState({
    name: '',
    issuing_body: '',
    certification_type: 'quality',
    issue_date: '',
    expiry_date: '',
    status: 'active',
    certificate_url: ''
  });

  useEffect(() => {
    fetchComplianceData();
  }, [projectId]);

  const fetchComplianceData = async () => {
    try {
      const [complianceRes, auditRes, certRes] = await Promise.all([
        axios.get(`${API}/projects/${projectId}/compliance-items`),
        axios.get(`${API}/projects/${projectId}/audit-trail`),
        axios.get(`${API}/projects/${projectId}/certifications`)
      ]);
      
      setComplianceItems(complianceRes.data);
      setAuditTrail(auditRes.data);
      setCertifications(certRes.data);
      
      // Calculate compliance statistics
      const stats = calculateComplianceStats(complianceRes.data, certRes.data);
      setComplianceStats(stats);
      
    } catch (error) {
      toast.error('Failed to load compliance data');
      console.error('Compliance data fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateComplianceStats = (items, certs) => {
    const total = items.length;
    const compliant = items.filter(item => item.compliance_status === 'compliant').length;
    const pending = items.filter(item => item.compliance_status === 'pending').length;
    const nonCompliant = items.filter(item => item.compliance_status === 'non_compliant').length;
    const overdue = items.filter(item => 
      new Date(item.due_date) < new Date() && item.compliance_status !== 'compliant'
    ).length;

    const activeCerts = certs.filter(cert => cert.status === 'active').length;
    const expiringSoon = certs.filter(cert => {
      const expiryDate = new Date(cert.expiry_date);
      const thirtyDaysFromNow = new Date();
      thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
      return expiryDate <= thirtyDaysFromNow && cert.status === 'active';
    }).length;

    return {
      totalCompliance: total,
      compliantPercentage: total > 0 ? ((compliant / total) * 100).toFixed(1) : 0,
      pendingItems: pending,
      nonCompliantItems: nonCompliant,
      overdueItems: overdue,
      activeCertifications: activeCerts,
      expiringSoonCerts: expiringSoon,
      complianceScore: total > 0 ? Math.round((compliant / total) * 100) : 0
    };
  };

  const handleCreateCompliance = async (e) => {
    e.preventDefault();
    try {
      const complianceData = {
        ...complianceFormData,
        due_date: new Date(complianceFormData.due_date).toISOString()
      };

      await axios.post(`${API}/projects/${projectId}/compliance-items`, complianceData);
      toast.success('Compliance item created successfully!');
      setShowComplianceDialog(false);
      setComplianceFormData({
        requirement: '',
        description: '',
        regulatory_body: '',
        compliance_status: 'pending',
        due_date: '',
        priority: 'medium',
        evidence_required: '',
        assigned_to: ''
      });
      fetchComplianceData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to create compliance item');
    }
  };

  const handleCreateCertification = async (e) => {
    e.preventDefault();
    try {
      const certificationData = {
        ...certificationFormData,
        issue_date: new Date(certificationFormData.issue_date).toISOString(),
        expiry_date: new Date(certificationFormData.expiry_date).toISOString()
      };

      await axios.post(`${API}/projects/${projectId}/certifications`, certificationData);
      toast.success('Certification added successfully!');
      setShowCertificationDialog(false);
      setCertificationFormData({
        name: '',
        issuing_body: '',
        certification_type: 'quality',
        issue_date: '',
        expiry_date: '',
        status: 'active',
        certificate_url: ''
      });
      fetchComplianceData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to add certification');
    }
  };

  const updateComplianceStatus = async (itemId, status) => {
    try {
      await axios.patch(`${API}/projects/${projectId}/compliance-items/${itemId}`, {
        compliance_status: status
      });
      toast.success('Compliance status updated');
      fetchComplianceData();
    } catch (error) {
      toast.error('Failed to update compliance status');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'compliant': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'non_compliant': return 'bg-red-100 text-red-800';
      case 'under_review': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const MetricCard = ({ title, value, subtitle, icon: Icon, color = 'blue' }) => (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className={`text-2xl font-bold text-${color}-600`}>{value}</p>
            {subtitle && <p className="text-xs text-gray-500">{subtitle}</p>}
          </div>
          <div className={`p-3 rounded-full bg-${color}-100`}>
            <Icon className={`h-5 w-5 text-${color}-600`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const filteredItems = complianceItems.filter(item => 
    selectedFilter === 'all' || item.compliance_status === selectedFilter
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold flex items-center space-x-2">
            <Shield className="h-5 w-5 text-blue-600" />
            <span>Compliance & Audit Module</span>
          </h3>
          <p className="text-sm text-gray-600">Regulatory compliance tracking, audit trails, and certifications</p>
        </div>
        <div className="flex items-center space-x-2">
          <Select value={selectedFilter} onValueChange={setSelectedFilter}>
            <SelectTrigger className="w-40" data-testid="compliance-filter">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Items</SelectItem>
              <SelectItem value="compliant">Compliant</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="non_compliant">Non-Compliant</SelectItem>
              <SelectItem value="under_review">Under Review</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Compliance Overview */}
      {complianceStats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            title="Compliance Score"
            value={`${complianceStats.complianceScore}%`}
            subtitle={`${complianceStats.totalCompliance} total items`}
            icon={Target}
            color="blue"
          />
          <MetricCard
            title="Pending Items"
            value={complianceStats.pendingItems}
            subtitle="Require attention"
            icon={Clock}
            color="yellow"
          />
          <MetricCard
            title="Overdue Items"
            value={complianceStats.overdueItems}
            subtitle="Past due date"
            icon={AlertTriangle}
            color="red"
          />
          <MetricCard
            title="Active Certifications"
            value={complianceStats.activeCertifications}
            subtitle={`${complianceStats.expiringSoonCerts} expiring soon`}
            icon={Award}
            color="green"
          />
        </div>
      )}

      {/* Main Content */}
      <Tabs defaultValue="compliance" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="compliance">Compliance Items</TabsTrigger>
          <TabsTrigger value="certifications">Certifications</TabsTrigger>
          <TabsTrigger value="audit">Audit Trail</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        {/* Compliance Items Tab */}
        <TabsContent value="compliance" className="space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-semibold">Compliance Management</h4>
            <Dialog open={showComplianceDialog} onOpenChange={setShowComplianceDialog}>
              <DialogTrigger asChild>
                <Button data-testid="add-compliance-item-button">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Compliance Item
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Add Compliance Requirement</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateCompliance} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="requirement">Requirement</Label>
                      <Input
                        id="requirement"
                        value={complianceFormData.requirement}
                        onChange={(e) => setComplianceFormData({...complianceFormData, requirement: e.target.value})}
                        placeholder="e.g., Data Protection Compliance"
                        required
                        data-testid="compliance-requirement-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="regulatory-body">Regulatory Body</Label>
                      <Input
                        id="regulatory-body"
                        value={complianceFormData.regulatory_body}
                        onChange={(e) => setComplianceFormData({...complianceFormData, regulatory_body: e.target.value})}
                        placeholder="e.g., GDPR, SOX, ISO"
                        required
                        data-testid="compliance-regulatory-body-input"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="compliance-description">Description</Label>
                    <Textarea
                      id="compliance-description"
                      value={complianceFormData.description}
                      onChange={(e) => setComplianceFormData({...complianceFormData, description: e.target.value})}
                      placeholder="Detailed description of compliance requirement..."
                      rows={3}
                      required
                      data-testid="compliance-description-input"
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="due-date">Due Date</Label>
                      <Input
                        id="due-date"
                        type="date"
                        value={complianceFormData.due_date}
                        onChange={(e) => setComplianceFormData({...complianceFormData, due_date: e.target.value})}
                        required
                        data-testid="compliance-due-date-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="priority">Priority</Label>
                      <Select value={complianceFormData.priority} onValueChange={(value) => 
                        setComplianceFormData({...complianceFormData, priority: value})
                      }>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="critical">Critical</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="assigned-to">Assigned To</Label>
                      <Input
                        id="assigned-to"
                        value={complianceFormData.assigned_to}
                        onChange={(e) => setComplianceFormData({...complianceFormData, assigned_to: e.target.value})}
                        placeholder="Team member"
                        data-testid="compliance-assigned-to-input"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="evidence-required">Evidence Required</Label>
                    <Textarea
                      id="evidence-required"
                      value={complianceFormData.evidence_required}
                      onChange={(e) => setComplianceFormData({...complianceFormData, evidence_required: e.target.value})}
                      placeholder="Documentation and evidence needed for compliance..."
                      rows={2}
                      data-testid="compliance-evidence-input"
                    />
                  </div>
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setShowComplianceDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" data-testid="create-compliance-item-submit">Add Compliance Item</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-4">
            {filteredItems.map((item) => (
              <Card key={item.id} data-testid={`compliance-item-${item.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-4">
                      <div className={`w-3 h-3 rounded-full mt-2 ${getPriorityColor(item.priority)}`}></div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h4 className="font-medium">{item.requirement}</h4>
                          <Badge className={getStatusColor(item.compliance_status)}>
                            {item.compliance_status.replace('_', ' ')}
                          </Badge>
                          {new Date(item.due_date) < new Date() && item.compliance_status !== 'compliant' && (
                            <Badge className="bg-red-100 text-red-800">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              Overdue
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{item.description}</p>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>
                            <Shield className="h-4 w-4 inline mr-1" />
                            {item.regulatory_body}
                          </span>
                          <span>
                            <Calendar className="h-4 w-4 inline mr-1" />
                            Due: {new Date(item.due_date).toLocaleDateString()}
                          </span>
                          {item.assigned_to && (
                            <span>
                              <User className="h-4 w-4 inline mr-1" />
                              {item.assigned_to}
                            </span>
                          )}
                        </div>
                        {item.evidence_required && (
                          <div className="mt-2 p-2 bg-gray-50 rounded text-sm">
                            <strong>Evidence Required:</strong> {item.evidence_required}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {item.compliance_status === 'pending' && user.role === 'administrator' && (
                        <>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => updateComplianceStatus(item.id, 'under_review')}
                            data-testid={`review-compliance-${item.id}`}
                          >
                            Review
                          </Button>
                          <Button 
                            size="sm"
                            onClick={() => updateComplianceStatus(item.id, 'compliant')}
                            data-testid={`approve-compliance-${item.id}`}
                          >
                            Mark Compliant
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            {filteredItems.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Shield className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No compliance items found</p>
                <p className="text-sm">Add compliance requirements to track regulatory adherence</p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Certifications Tab */}
        <TabsContent value="certifications" className="space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-semibold">Certifications Management</h4>
            <Dialog open={showCertificationDialog} onOpenChange={setShowCertificationDialog}>
              <DialogTrigger asChild>
                <Button data-testid="add-certification-button">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Certification
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Certification</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateCertification} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="cert-name">Certification Name</Label>
                      <Input
                        id="cert-name"
                        value={certificationFormData.name}
                        onChange={(e) => setCertificationFormData({...certificationFormData, name: e.target.value})}
                        placeholder="e.g., ISO 9001"
                        required
                        data-testid="certification-name-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="issuing-body">Issuing Body</Label>
                      <Input
                        id="issuing-body"
                        value={certificationFormData.issuing_body}
                        onChange={(e) => setCertificationFormData({...certificationFormData, issuing_body: e.target.value})}
                        placeholder="e.g., ISO Organization"
                        required
                        data-testid="certification-issuing-body-input"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cert-type">Certification Type</Label>
                    <Select value={certificationFormData.certification_type} onValueChange={(value) => 
                      setCertificationFormData({...certificationFormData, certification_type: value})
                    }>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="quality">Quality Management</SelectItem>
                        <SelectItem value="environmental">Environmental</SelectItem>
                        <SelectItem value="safety">Safety & Health</SelectItem>
                        <SelectItem value="security">Information Security</SelectItem>
                        <SelectItem value="social">Social Responsibility</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="issue-date">Issue Date</Label>
                      <Input
                        id="issue-date"
                        type="date"
                        value={certificationFormData.issue_date}
                        onChange={(e) => setCertificationFormData({...certificationFormData, issue_date: e.target.value})}
                        required
                        data-testid="certification-issue-date-input"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="expiry-date">Expiry Date</Label>
                      <Input
                        id="expiry-date"
                        type="date"
                        value={certificationFormData.expiry_date}
                        onChange={(e) => setCertificationFormData({...certificationFormData, expiry_date: e.target.value})}
                        required
                        data-testid="certification-expiry-date-input"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="certificate-url">Certificate URL</Label>
                    <Input
                      id="certificate-url"
                      type="url"
                      value={certificationFormData.certificate_url}
                      onChange={(e) => setCertificationFormData({...certificationFormData, certificate_url: e.target.value})}
                      placeholder="https://..."
                      data-testid="certification-url-input"
                    />
                  </div>
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => setShowCertificationDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" data-testid="create-certification-submit">Add Certification</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {certifications.map((cert) => {
              const isExpiringSoon = new Date(cert.expiry_date) <= new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
              
              return (
                <Card key={cert.id} className={`${isExpiringSoon ? 'border-yellow-300' : ''}`} data-testid={`certification-card-${cert.id}`}>
                  <CardContent className="p-4">
                    <div className="space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-2">
                          <Award className="h-5 w-5 text-blue-600" />
                          <h4 className="font-medium">{cert.name}</h4>
                        </div>
                        <Badge className={cert.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                          {cert.status}
                        </Badge>
                      </div>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Issuing Body:</span>
                          <span className="font-medium">{cert.issuing_body}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Type:</span>
                          <span className="font-medium capitalize">{cert.certification_type.replace('_', ' ')}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Issue Date:</span>
                          <span className="font-medium">{new Date(cert.issue_date).toLocaleDateString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Expiry Date:</span>
                          <span className={`font-medium ${isExpiringSoon ? 'text-yellow-600' : ''}`}>
                            {new Date(cert.expiry_date).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      {isExpiringSoon && (
                        <div className="p-2 bg-yellow-50 border border-yellow-200 rounded text-sm">
                          <AlertTriangle className="h-4 w-4 inline text-yellow-600 mr-1" />
                          <span className="text-yellow-800">Expires within 30 days</span>
                        </div>
                      )}
                      <div className="flex justify-between items-center pt-2">
                        {cert.certificate_url && (
                          <Button size="sm" variant="outline" asChild>
                            <a href={cert.certificate_url} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="h-4 w-4 mr-1" />
                              View
                            </a>
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
            {certifications.length === 0 && (
              <div className="col-span-full text-center py-8 text-gray-500">
                <Award className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No certifications added yet</p>
                <p className="text-sm">Add certifications to track compliance credentials</p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Audit Trail Tab */}
        <TabsContent value="audit" className="space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-semibold">Audit Trail</h4>
            <Button variant="outline" data-testid="export-audit-trail">
              <Download className="h-4 w-4 mr-2" />
              Export Audit Log
            </Button>
          </div>

          <div className="space-y-3">
            {auditTrail.map((entry) => (
              <Card key={entry.id} data-testid={`audit-entry-${entry.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-start space-x-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <Activity className="h-5 w-5 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-medium">{entry.action}</h4>
                        <span className="text-sm text-gray-500">
                          {new Date(entry.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{entry.description}</p>
                      <div className="flex items-center space-x-4 text-xs text-gray-500">
                        <span>
                          <User className="h-3 w-3 inline mr-1" />
                          {entry.performed_by}
                        </span>
                        <span>
                          <FileText className="h-3 w-3 inline mr-1" />
                          {entry.resource_type}
                        </span>
                        {entry.ip_address && (
                          <span>IP: {entry.ip_address}</span>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
            {auditTrail.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Activity className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No audit entries found</p>
                <p className="text-sm">System activities will be logged here</p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Reports Tab */}
        <TabsContent value="reports" className="space-y-6">
          <div className="flex justify-between items-center">
            <h4 className="text-lg font-semibold">Compliance Reports</h4>
            <Button data-testid="generate-compliance-report">
              <FileText className="h-4 w-4 mr-2" />
              Generate Report
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Compliance Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5 text-blue-600" />
                  <span>Compliance Overview</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-blue-600">
                      {complianceStats.complianceScore}%
                    </div>
                    <p className="text-sm text-gray-600">Overall Compliance Score</p>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Compliant Items:</span>
                      <span className="font-medium text-green-600">
                        {complianceItems.filter(i => i.compliance_status === 'compliant').length}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Pending Items:</span>
                      <span className="font-medium text-yellow-600">{complianceStats.pendingItems}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Non-Compliant:</span>
                      <span className="font-medium text-red-600">{complianceStats.nonCompliantItems}</span>
                    </div>
                  </div>
                  <Progress value={complianceStats.complianceScore} className="h-3" />
                </div>
              </CardContent>
            </Card>

            {/* Certification Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Award className="h-5 w-5 text-green-600" />
                  <span>Certification Status</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-green-600">
                        {complianceStats.activeCertifications}
                      </div>
                      <p className="text-sm text-gray-600">Active Certifications</p>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-yellow-600">
                        {complianceStats.expiringSoonCerts}
                      </div>
                      <p className="text-sm text-gray-600">Expiring Soon</p>
                    </div>
                  </div>
                  {complianceStats.expiringSoonCerts > 0 && (
                    <div className="p-3 bg-yellow-50 border border-yellow-200 rounded">
                      <AlertTriangle className="h-4 w-4 inline text-yellow-600 mr-2" />
                      <span className="text-sm text-yellow-800">
                        {complianceStats.expiringSoonCerts} certification(s) expiring within 30 days
                      </span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Compliance Summary */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-purple-600" />
                <span>Compliance Summary</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600">
                    {complianceStats.totalCompliance}
                  </div>
                  <p className="text-sm text-gray-600">Total Requirements</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600">
                    {complianceItems.filter(i => i.compliance_status === 'compliant').length}
                  </div>
                  <p className="text-sm text-gray-600">Compliant</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-yellow-600">
                    {complianceStats.pendingItems}
                  </div>
                  <p className="text-sm text-gray-600">Pending Review</p>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-red-600">
                    {complianceStats.overdueItems}
                  </div>
                  <p className="text-sm text-gray-600">Overdue Items</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ComplianceAudit;