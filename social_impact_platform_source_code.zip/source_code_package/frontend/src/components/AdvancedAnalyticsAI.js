import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { toast } from 'sonner';
import { 
  TrendingUp, 
  Brain,
  BarChart3,
  LineChart,
  Activity,
  AlertTriangle,
  CheckCircle2,
  DollarSign,
  Target,
  Lightbulb,
  Sparkles,
  Zap,
  RefreshCw,
  ArrowUp,
  ArrowDown,
  Minus
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const AdvancedAnalyticsAI = ({ projectId, user }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  
  // Data states
  const [analyticsOverview, setAnalyticsOverview] = useState({});
  const [trends, setTrends] = useState({});
  const [aiInsights, setAiInsights] = useState([]);
  const [predictions, setPredictions] = useState([]);
  
  // Analysis request states
  const [analysisType, setAnalysisType] = useState('general');
  const [predictionType, setPredictionType] = useState('completion_timeline');

  useEffect(() => {
    fetchAnalyticsData();
  }, [projectId]);

  const fetchAnalyticsData = async () => {
    setLoading(true);
    try {
      const [overviewRes, trendsRes, insightsRes, predictionsRes] = await Promise.all([
        axios.get(`${API}/projects/${projectId}/analytics/overview`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/analytics/trends?days=30`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/analytics/ai-insights`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/analytics/predictions`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        })
      ]);
      
      setAnalyticsOverview(overviewRes.data);
      setTrends(trendsRes.data);
      setAiInsights(insightsRes.data);
      setPredictions(predictionsRes.data);
    } catch (error) {
      console.error('Failed to fetch analytics data:', error);
      toast.error('Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  const generateAIInsights = async () => {
    setGenerating(true);
    try {
      const response = await axios.post(`${API}/projects/${projectId}/analytics/ai-insights`, {
        type: analysisType
      }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      // Refresh insights list
      const insightsRes = await axios.get(`${API}/projects/${projectId}/analytics/ai-insights`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      setAiInsights(insightsRes.data);
      toast.success('AI insights generated successfully');
    } catch (error) {
      console.error('Failed to generate AI insights:', error);
      toast.error('Failed to generate AI insights');
    } finally {
      setGenerating(false);
    }
  };

  const generatePredictiveAnalysis = async () => {
    setGenerating(true);
    try {
      const response = await axios.post(`${API}/projects/${projectId}/analytics/predictive-model`, {
        type: predictionType
      }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      // Refresh predictions list
      const predictionsRes = await axios.get(`${API}/projects/${projectId}/analytics/predictions`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      setPredictions(predictionsRes.data);
      toast.success('Predictive analysis generated successfully');
    } catch (error) {
      console.error('Failed to generate predictive analysis:', error);
      toast.error('Failed to generate predictive analysis');
    } finally {
      setGenerating(false);
    }
  };

  const getStatusIcon = (value, threshold = 80) => {
    if (value >= threshold) return <CheckCircle2 className="h-4 w-4 text-green-600" />;
    if (value >= threshold * 0.7) return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
    return <AlertTriangle className="h-4 w-4 text-red-600" />;
  };

  const getStatusColor = (value, threshold = 80) => {
    if (value >= threshold) return 'text-green-600';
    if (value >= threshold * 0.7) return 'text-yellow-600';
    return 'text-red-600';
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  const formatInsight = (insight) => {
    return insight.split('\n').map((line, index) => (
      <div key={index} className={line.startsWith('**') || line.startsWith('#') ? 'font-semibold mt-3 mb-1' : 'mb-2'}>
        {line.replace(/\*\*/g, '').replace(/^#+ /, '')}
      </div>
    ));
  };

  // Overview Tab Component
  const OverviewTab = () => (
    <div className="space-y-6">
      {/* Key Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Deliverable Progress</p>
                <div className="flex items-center space-x-2">
                  <p className="text-2xl font-bold">{analyticsOverview.overview_metrics?.deliverable_completion_rate || 0}%</p>
                  {getStatusIcon(analyticsOverview.overview_metrics?.deliverable_completion_rate)}
                </div>
                <p className="text-xs text-gray-500">
                  {analyticsOverview.overview_metrics?.completed_deliverables || 0}/{analyticsOverview.overview_metrics?.total_deliverables || 0} completed
                </p>
              </div>
              <Target className="h-8 w-8 text-blue-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Task Completion</p>
                <div className="flex items-center space-x-2">
                  <p className="text-2xl font-bold">{analyticsOverview.overview_metrics?.task_completion_rate || 0}%</p>
                  {getStatusIcon(analyticsOverview.overview_metrics?.task_completion_rate)}
                </div>
                <p className="text-xs text-gray-500">
                  {analyticsOverview.overview_metrics?.completed_tasks || 0}/{analyticsOverview.overview_metrics?.total_tasks || 0} tasks
                </p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-green-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Budget Utilization</p>
                <div className="flex items-center space-x-2">
                  <p className="text-2xl font-bold">{analyticsOverview.overview_metrics?.budget_utilization || 0}%</p>
                  {getStatusIcon(analyticsOverview.overview_metrics?.budget_utilization, 90)}
                </div>
                <p className="text-xs text-gray-500">
                  Spending efficiency
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-yellow-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Quality Score</p>
                <div className="flex items-center space-x-2">
                  <p className="text-2xl font-bold">{analyticsOverview.overview_metrics?.qa_pass_rate || 0}%</p>
                  {getStatusIcon(analyticsOverview.overview_metrics?.qa_pass_rate, 85)}
                </div>
                <p className="text-xs text-gray-500">
                  QA pass rate
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-purple-600 opacity-20" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="h-5 w-5 text-blue-600" />
            <span>Performance Summary</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-3">
              <h4 className="font-medium text-green-700">Strengths</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <span>High quality standards maintained</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <span>Strong field data collection</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <span>Effective risk management</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium text-yellow-700">Areas for Improvement</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm">
                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                  <span>Budget utilization optimization</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                  <span>Task completion acceleration</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium text-blue-700">Recommendations</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm">
                  <Lightbulb className="h-4 w-4 text-blue-600" />
                  <span>Implement predictive analytics</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <Lightbulb className="h-4 w-4 text-blue-600" />
                  <span>Optimize resource allocation</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // AI Insights Tab Component
  const AIInsightsTab = () => (
    <div className="space-y-6">
      {/* Generate New Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="h-5 w-5 text-purple-600" />
            <span>AI-Powered Insights</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4 mb-4">
            <div className="flex-1">
              <Select value={analysisType} onValueChange={setAnalysisType}>
                <SelectTrigger data-testid="analysis-type-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">General Analysis</SelectItem>
                  <SelectItem value="risk_assessment">Risk Assessment</SelectItem>
                  <SelectItem value="performance_prediction">Performance Prediction</SelectItem>
                  <SelectItem value="optimization_suggestions">Optimization Suggestions</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button 
              onClick={generateAIInsights}
              disabled={generating}
              data-testid="generate-insights-button"
            >
              {generating ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Generate Insights
                </>
              )}
            </Button>
          </div>
          <p className="text-sm text-gray-600">
            Generate AI-powered insights based on your project data using advanced analytics and machine learning.
          </p>
        </CardContent>
      </Card>

      {/* Historical Insights */}
      <div className="space-y-4">
        {aiInsights.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Brain className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-600">No AI insights generated yet.</p>
              <p className="text-sm text-gray-500">Click "Generate Insights" to create your first analysis.</p>
            </CardContent>
          </Card>
        ) : (
          aiInsights.map((insight) => (
            <Card key={insight.id}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Brain className="h-5 w-5 text-purple-600" />
                    <span className="capitalize">{insight.analysis_type.replace('_', ' ')}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline">AI Generated</Badge>
                    <span className="text-sm text-gray-500">{formatDate(insight.created_at)}</span>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm max-w-none">
                  {formatInsight(insight.insights)}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );

  // Predictive Analytics Tab Component
  const PredictiveAnalyticsTab = () => (
    <div className="space-y-6">
      {/* Generate New Predictions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="h-5 w-5 text-blue-600" />
            <span>Predictive Analytics</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4 mb-4">
            <div className="flex-1">
              <Select value={predictionType} onValueChange={setPredictionType}>
                <SelectTrigger data-testid="prediction-type-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="completion_timeline">Completion Timeline</SelectItem>
                  <SelectItem value="budget_forecast">Budget Forecast</SelectItem>
                  <SelectItem value="risk_probability">Risk Probability</SelectItem>
                  <SelectItem value="success_probability">Success Probability</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button 
              onClick={generatePredictiveAnalysis}
              disabled={generating}
              data-testid="generate-prediction-button"
            >
              {generating ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  Predicting...
                </>
              ) : (
                <>
                  <Zap className="h-4 w-4 mr-2" />
                  Generate Prediction
                </>
              )}
            </Button>
          </div>
          <p className="text-sm text-gray-600">
            Generate predictive models and forecasts based on historical project data and trends.
          </p>
        </CardContent>
      </Card>

      {/* Historical Predictions */}
      <div className="space-y-4">
        {predictions.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <TrendingUp className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <p className="text-gray-600">No predictions generated yet.</p>
              <p className="text-sm text-gray-500">Click "Generate Prediction" to create your first forecast.</p>
            </CardContent>
          </Card>
        ) : (
          predictions.map((prediction) => (
            <Card key={prediction.id}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5 text-blue-600" />
                    <span className="capitalize">{prediction.prediction_type.replace('_', ' ')}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline" className="bg-blue-50">Predictive Model</Badge>
                    <span className="text-sm text-gray-500">{formatDate(prediction.created_at)}</span>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm max-w-none">
                  {formatInsight(prediction.predictions)}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );

  // Trends Tab Component
  const TrendsTab = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <LineChart className="h-5 w-5 text-green-600" />
            <span>Analytics Trends</span>
            <Badge variant="outline">Last 30 Days</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-3">
              <h4 className="font-medium">Field Data Trends</h4>
              <div className="space-y-2">
                <div className="text-sm">
                  <span className="text-gray-600">Total Entries:</span>
                  <span className="ml-2 font-medium">{trends.trends?.field_data?.length || 0}</span>
                </div>
                <div className="text-sm">
                  <span className="text-gray-600">Activity Level:</span>
                  <span className="ml-2 font-medium text-green-600">High</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium">Quality Trends</h4>
              <div className="space-y-2">
                <div className="text-sm">
                  <span className="text-gray-600">QA Inspections:</span>
                  <span className="ml-2 font-medium">{trends.trends?.quality_assurance?.length || 0}</span>
                </div>
                <div className="text-sm">
                  <span className="text-gray-600">Trend Direction:</span>
                  <span className="ml-2 font-medium text-green-600">Improving</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium">Financial Trends</h4>
              <div className="space-y-2">
                <div className="text-sm">
                  <span className="text-gray-600">Expense Entries:</span>
                  <span className="ml-2 font-medium">{trends.trends?.expenses?.length || 0}</span>
                </div>
                <div className="text-sm">
                  <span className="text-gray-600">Spending Pattern:</span>
                  <span className="ml-2 font-medium text-blue-600">Stable</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Trend Analysis Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
              <div className="flex items-center space-x-2">
                <ArrowUp className="h-4 w-4 text-green-600" />
                <span className="font-medium">Quality Improvements</span>
              </div>
              <Badge className="bg-green-100 text-green-800">+12% this month</Badge>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center space-x-2">
                <ArrowUp className="h-4 w-4 text-blue-600" />
                <span className="font-medium">Field Activity</span>
              </div>
              <Badge className="bg-blue-100 text-blue-800">+8% this month</Badge>
            </div>
            
            <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
              <div className="flex items-center space-x-2">
                <Minus className="h-4 w-4 text-yellow-600" />
                <span className="font-medium">Budget Utilization</span>
              </div>
              <Badge className="bg-yellow-100 text-yellow-800">Stable</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Brain className="h-6 w-6 text-purple-600" />
              <span>Advanced Analytics & AI</span>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                variant="outline"
                onClick={fetchAnalyticsData}
                data-testid="refresh-analytics-button"
              >
                <RefreshCw className="h-4 w-4 mr-1" />
                Refresh
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview" data-testid="overview-tab">
            <BarChart3 className="h-4 w-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="ai-insights" data-testid="ai-insights-tab">
            <Brain className="h-4 w-4 mr-2" />
            AI Insights
          </TabsTrigger>
          <TabsTrigger value="predictions" data-testid="predictions-tab">
            <TrendingUp className="h-4 w-4 mr-2" />
            Predictions
          </TabsTrigger>
          <TabsTrigger value="trends" data-testid="trends-tab">
            <LineChart className="h-4 w-4 mr-2" />
            Trends
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <OverviewTab />
        </TabsContent>

        <TabsContent value="ai-insights">
          <AIInsightsTab />
        </TabsContent>

        <TabsContent value="predictions">
          <PredictiveAnalyticsTab />
        </TabsContent>

        <TabsContent value="trends">
          <TrendsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdvancedAnalyticsAI;