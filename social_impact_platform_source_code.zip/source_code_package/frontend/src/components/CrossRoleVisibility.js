import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  Users, 
  Eye, 
  Shield, 
  Briefcase, 
  UserCheck,
  Calendar,
  DollarSign,
  Package,
  AlertTriangle,
  CheckCircle2
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const CrossRoleVisibility = ({ projectId, currentUser }) => {
  const [projectData, setProjectData] = useState(null);
  const [teamMembers, setTeamMembers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCrossRoleData();
  }, [projectId]);

  const fetchCrossRoleData = async () => {
    try {
      const [projectRes, deliverablesRes, risksRes, issuesRes] = await Promise.all([
        axios.get(`${API}/projects/${projectId}`),
        axios.get(`${API}/projects/${projectId}/deliverables`),
        axios.get(`${API}/projects/${projectId}/risks`),
        axios.get(`${API}/projects/${projectId}/issues`)
      ]);

      const project = projectRes.data;
      
      // Simulate team member data (in real implementation, this would come from user management)
      const members = [
        {
          id: project.owner_id,
          role: 'social_actor',
          name: 'Social Actor',
          organization: 'Community Development Solutions',
          lastActive: new Date(),
          permissions: ['create_deliverables', 'update_kpis', 'report_issues']
        },
        {
          id: project.investor_id,
          role: 'investor',
          name: 'Investor',
          organization: 'Impact Investment Fund',
          lastActive: new Date(),
          permissions: ['view_reports', 'review_progress', 'approve_milestones']
        },
        {
          id: 'admin_id',
          role: 'administrator',
          name: 'Administrator',
          organization: 'ISISP Platform',
          lastActive: new Date(),
          permissions: ['certify_deliverables', 'approve_changes', 'manage_risks']
        }
      ];

      setProjectData({
        ...project,
        deliverables: deliverablesRes.data,
        risks: risksRes.data,
        issues: issuesRes.data
      });
      setTeamMembers(members);
    } catch (error) {
      toast.error('Failed to load cross-role data');
    } finally {
      setLoading(false);
    }
  };

  const getRoleIcon = (role) => {
    switch (role) {
      case 'administrator': return <Shield className="h-4 w-4 text-blue-600" />;
      case 'investor': return <Briefcase className="h-4 w-4 text-green-600" />;
      case 'social_actor': return <UserCheck className="h-4 w-4 text-purple-600" />;
      default: return <Users className="h-4 w-4 text-gray-600" />;
    }
  };

  const getRoleColor = (role) => {
    switch (role) {
      case 'administrator': return 'bg-blue-100 text-blue-800';
      case 'investor': return 'bg-green-100 text-green-800';
      case 'social_actor': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const canUserSee = (permission, userRole) => {
    const rolePermissions = {
      administrator: ['view_all', 'certify_deliverables', 'approve_changes', 'manage_risks', 'view_reports'],
      investor: ['view_funded_projects', 'view_reports', 'review_progress', 'approve_milestones'],
      social_actor: ['view_owned_projects', 'create_deliverables', 'update_kpis', 'report_issues']
    };
    
    return rolePermissions[userRole]?.includes(permission) || rolePermissions[userRole]?.includes('view_all');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Project Team Overview */}
      <Card data-testid="team-overview">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Users className="h-5 w-5 text-blue-600" />
            <span>Project Team & Real-time Visibility</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {teamMembers.map((member) => (
              <div 
                key={member.id} 
                className={`p-4 border rounded-lg ${member.id === currentUser.id ? 'ring-2 ring-blue-200 bg-blue-50' : ''}`}
                data-testid={`team-member-${member.role}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    {getRoleIcon(member.role)}
                    <span className="font-medium">{member.name}</span>
                  </div>
                  <Badge className={getRoleColor(member.role)}>
                    {member.role.replace('_', ' ')}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 mb-2">{member.organization}</p>
                <div className="flex items-center space-x-1 text-xs text-gray-500">
                  <Calendar className="h-3 w-3" />
                  <span>Active now</span>
                </div>
                
                {member.id === currentUser.id && (
                  <div className="mt-2 p-2 bg-blue-100 rounded text-xs text-blue-800">
                    <strong>You</strong> - This is your current view
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Cross-Role Data Sharing */}
      <Card data-testid="data-sharing">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Eye className="h-5 w-5 text-green-600" />
            <span>Real-time Data Sharing Status</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            
            {/* Deliverables Visibility */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <Package className="h-5 w-5 text-blue-600" />
                  <span className="font-medium">Deliverables ({projectData?.deliverables?.length || 0})</span>
                </div>
                <div className="flex items-center space-x-2">
                  {teamMembers.map((member) => (
                    <div key={member.id} className="flex items-center space-x-1">
                      {getRoleIcon(member.role)}
                      {canUserSee('view_deliverables', member.role) ? (
                        <CheckCircle2 className="h-3 w-3 text-green-500" />
                      ) : (
                        <div className="h-3 w-3 rounded-full bg-gray-300"></div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
              <p className="text-sm text-gray-600">
                ✅ <strong>Real-time sharing active:</strong> When Social Actor creates/updates deliverables, 
                Administrator and Investor see changes immediately. Administrator can certify deliverables 
                and all roles see certification status instantly.
              </p>
            </div>

            {/* Risks Visibility */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-orange-600" />
                  <span className="font-medium">Risks & Issues ({(projectData?.risks?.length || 0) + (projectData?.issues?.length || 0)})</span>
                </div>
                <div className="flex items-center space-x-2">
                  {teamMembers.map((member) => (
                    <div key={member.id} className="flex items-center space-x-1">
                      {getRoleIcon(member.role)}
                      <CheckCircle2 className="h-3 w-3 text-green-500" />
                    </div>
                  ))}
                </div>
              </div>
              <p className="text-sm text-gray-600">
                ✅ <strong>Real-time sharing active:</strong> All roles can see risks and issues immediately. 
                Social Actor reports issues, Administrator can resolve them, and Investor monitors risk levels in real-time.
              </p>
            </div>

            {/* Budget & Progress Visibility */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  <DollarSign className="h-5 w-5 text-green-600" />
                  <span className="font-medium">Budget & Progress Tracking</span>
                </div>
                <div className="flex items-center space-x-2">
                  {teamMembers.map((member) => (
                    <div key={member.id} className="flex items-center space-x-1">
                      {getRoleIcon(member.role)}
                      <CheckCircle2 className="h-3 w-3 text-green-500" />
                    </div>
                  ))}
                </div>
              </div>
              <div className="mb-2">
                <div className="flex justify-between text-sm mb-1">
                  <span>Project Progress</span>
                  <span>{Math.round(projectData?.progress || 0)}%</span>
                </div>
                <Progress value={projectData?.progress || 0} />
              </div>
              <p className="text-sm text-gray-600">
                ✅ <strong>Real-time sharing active:</strong> Budget utilization, project progress, and KPI updates 
                are shared instantly across all roles. Each role sees the same data with different analytical perspectives.
              </p>
            </div>

          </div>
        </CardContent>
      </Card>

      {/* Role-Based Actions */}
      <Card data-testid="role-actions">
        <CardHeader>
          <CardTitle>What Each Role Can Do (Real-time Impact)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            <div className="border rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-3">
                <UserCheck className="h-5 w-5 text-purple-600" />
                <span className="font-medium">Social Actor</span>
              </div>
              <ul className="text-sm space-y-1">
                <li>• Creates deliverables → <strong>Others see instantly</strong></li>
                <li>• Updates KPIs → <strong>Real-time dashboard updates</strong></li>
                <li>• Reports risks/issues → <strong>Immediate notifications</strong></li>
                <li>• Uploads evidence → <strong>Available to all immediately</strong></li>
              </ul>
            </div>

            <div className="border rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-3">
                <Briefcase className="h-5 w-5 text-green-600" />
                <span className="font-medium">Investor</span>
              </div>
              <ul className="text-sm space-y-1">
                <li>• Monitors progress → <strong>Real-time data feed</strong></li>
                <li>• Reviews SROI → <strong>Live impact calculations</strong></li>
                <li>• Tracks budget → <strong>Instant utilization updates</strong></li>
                <li>• Views evidence → <strong>Same files as uploaded</strong></li>
              </ul>
            </div>

            <div className="border rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-3">
                <Shield className="h-5 w-5 text-blue-600" />
                <span className="font-medium">Administrator</span>
              </div>
              <ul className="text-sm space-y-1">
                <li>• Certifies deliverables → <strong>Status updates for all</strong></li>
                <li>• Manages platform → <strong>System-wide visibility</strong></li>
                <li>• Approves changes → <strong>Notifications to stakeholders</strong></li>
                <li>• Mediates issues → <strong>Real-time resolution tracking</strong></li>
              </ul>
            </div>

          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CrossRoleVisibility;