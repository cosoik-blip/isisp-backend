import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Checkbox } from './ui/checkbox';
import { toast } from 'sonner';
import { 
  BarChart3, 
  FileText, 
  Download, 
  Calendar, 
  Filter, 
  Settings,
  TrendingUp,
  DollarSign,
  Users,
  Target,
  Clock,
  PieChart,
  LineChart,
  Activity
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const AdvancedReporting = ({ projectId, user }) => {
  const [reportData, setReportData] = useState(null);
  const [availableReports, setAvailableReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedReport, setSelectedReport] = useState('executive_summary');
  const [reportFilters, setReportFilters] = useState({
    dateRange: 'last_30_days',
    includeFinancials: true,
    includeKPIs: true,
    includeRisks: true,
    includeDeliverables: true,
    format: 'dashboard'
  });
  const [customReportBuilder, setCustomReportBuilder] = useState({
    title: '',
    sections: [],
    charts: [],
    filters: {}
  });
  const [showCustomBuilder, setShowCustomBuilder] = useState(false);

  useEffect(() => {
    fetchReportData();
    initializeReportTemplates();
  }, [projectId, selectedReport, reportFilters]);

  const initializeReportTemplates = () => {
    const templates = [
      {
        id: 'executive_summary',
        name: 'Executive Summary',
        description: 'High-level overview for investors and executives',
        icon: BarChart3,
        sections: ['overview', 'financial', 'progress', 'risks', 'forecast']
      },
      {
        id: 'detailed_impact',
        name: 'Detailed Impact Report',
        description: 'Comprehensive social impact analysis',
        icon: TrendingUp,
        sections: ['beneficiaries', 'outcomes', 'sroi', 'sustainability', 'lessons']
      },
      {
        id: 'financial_analysis',
        name: 'Financial Analysis',
        description: 'Budget, expenditure, and financial performance',
        icon: DollarSign,
        sections: ['budget_vs_actual', 'cash_flow', 'cost_analysis', 'roi', 'projections']
      },
      {
        id: 'operational_dashboard',
        name: 'Operational Dashboard',
        description: 'Real-time operational metrics and KPIs',
        icon: Activity,
        sections: ['kpis', 'deliverables', 'timeline', 'resources', 'issues']
      },
      {
        id: 'compliance_report',
        name: 'Compliance Report',
        description: 'Regulatory compliance and audit trail',
        icon: FileText,
        sections: ['compliance_status', 'audit_trail', 'documentation', 'certifications']
      }
    ];
    setAvailableReports(templates);
  };

  const fetchReportData = async () => {
    try {
      // Simulate comprehensive report data fetching
      const [
        projectRes,
        kpisRes,
        deliverablesRes,
        risksRes,
        issuesRes,
        sroiRes,
        dashboardRes
      ] = await Promise.all([
        axios.get(`${API}/projects/${projectId}`),
        axios.get(`${API}/projects/${projectId}/kpis`),
        axios.get(`${API}/projects/${projectId}/deliverables`),
        axios.get(`${API}/projects/${projectId}/risks`),
        axios.get(`${API}/projects/${projectId}/issues`),
        axios.get(`${API}/projects/${projectId}/sroi`),
        axios.get(`${API}/dashboard`)
      ]);

      // Process and aggregate data for reporting
      const aggregatedData = {
        project: projectRes.data,
        kpis: kpisRes.data,
        deliverables: deliverablesRes.data,
        risks: risksRes.data,
        issues: issuesRes.data,
        sroi: sroiRes.data,
        dashboard: dashboardRes.data,
        
        // Calculated metrics
        metrics: {
          totalBudget: projectRes.data.budget,
          actualCost: projectRes.data.actual_cost,
          budgetUtilization: ((projectRes.data.actual_cost / projectRes.data.budget) * 100).toFixed(1),
          progressPercentage: projectRes.data.progress,
          kpiCompletion: calculateKPICompletion(kpisRes.data),
          deliverableCompletion: calculateDeliverableCompletion(deliverablesRes.data),
          riskLevel: calculateOverallRiskLevel(risksRes.data),
          issueResolutionRate: calculateIssueResolutionRate(issuesRes.data),
          avgSROI: sroiRes.data.length > 0 ? (sroiRes.data.reduce((acc, curr) => acc + curr.sroi_ratio, 0) / sroiRes.data.length).toFixed(2) : 0
        },
        
        // Charts data
        charts: {
          budgetTrend: generateBudgetTrendData(projectRes.data),
          progressTimeline: generateProgressTimelineData(projectRes.data),
          kpiPerformance: generateKPIPerformanceData(kpisRes.data),
          riskDistribution: generateRiskDistributionData(risksRes.data),
          deliverableStatus: generateDeliverableStatusData(deliverablesRes.data)
        }
      };

      setReportData(aggregatedData);
    } catch (error) {
      toast.error('Failed to load report data');
      console.error('Report data fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  // Helper functions for calculations
  const calculateKPICompletion = (kpis) => {
    if (kpis.length === 0) return 0;
    const completedKPIs = kpis.filter(kpi => 
      kpi.actual_value >= kpi.target_value * 0.9 // 90% of target considered complete
    ).length;
    return ((completedKPIs / kpis.length) * 100).toFixed(1);
  };

  const calculateDeliverableCompletion = (deliverables) => {
    if (deliverables.length === 0) return 0;
    const completedDeliverables = deliverables.filter(d => 
      d.status === 'completed' || d.status === 'certified'
    ).length;
    return ((completedDeliverables / deliverables.length) * 100).toFixed(1);
  };

  const calculateOverallRiskLevel = (risks) => {
    if (risks.length === 0) return 'Low';
    const avgRiskScore = risks.reduce((acc, curr) => acc + curr.risk_score, 0) / risks.length;
    if (avgRiskScore >= 15) return 'Critical';
    if (avgRiskScore >= 10) return 'High';
    if (avgRiskScore >= 5) return 'Medium';
    return 'Low';
  };

  const calculateIssueResolutionRate = (issues) => {
    if (issues.length === 0) return 100;
    const resolvedIssues = issues.filter(i => i.status === 'resolved' || i.status === 'closed').length;
    return ((resolvedIssues / issues.length) * 100).toFixed(1);
  };

  // Data generation functions for charts
  const generateBudgetTrendData = (project) => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
    return months.map((month, index) => ({
      month,
      budgeted: project.budget * (index + 1) / 6,
      actual: project.actual_cost * (index + 1) / 6,
      projected: project.budget * (index + 1) / 6 * 1.1 // 10% variance
    }));
  };

  const generateProgressTimelineData = (project) => {
    return [
      { phase: 'Initiating', planned: 10, actual: 12 },
      { phase: 'Planning', planned: 25, actual: 28 },
      { phase: 'Executing', planned: 80, actual: project.progress },
      { phase: 'Closing', planned: 100, actual: 0 }
    ];
  };

  const generateKPIPerformanceData = (kpis) => {
    return kpis.map(kpi => ({
      name: kpi.name,
      target: kpi.target_value,
      actual: kpi.actual_value,
      percentage: ((kpi.actual_value / kpi.target_value) * 100).toFixed(1)
    }));
  };

  const generateRiskDistributionData = (risks) => {
    const distribution = { Low: 0, Medium: 0, High: 0, Critical: 0 };
    risks.forEach(risk => {
      distribution[risk.level]++;
    });
    return Object.entries(distribution).map(([level, count]) => ({ level, count }));
  };

  const generateDeliverableStatusData = (deliverables) => {
    const statusCount = { planned: 0, in_progress: 0, completed: 0, certified: 0 };
    deliverables.forEach(d => {
      statusCount[d.status]++;
    });
    return Object.entries(statusCount).map(([status, count]) => ({ status, count }));
  };

  const exportReport = async (format) => {
    try {
      toast.success(`Exporting report in ${format.toUpperCase()} format...`);
      // In a real implementation, this would trigger a backend export
      setTimeout(() => {
        toast.success(`Report exported successfully in ${format.toUpperCase()} format!`);
      }, 2000);
    } catch (error) {
      toast.error('Failed to export report');
    }
  };

  const MetricCard = ({ title, value, subtitle, icon: Icon, color = 'blue', trend = null }) => (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className={`text-2xl font-bold text-${color}-600`}>{value}</p>
            {subtitle && <p className="text-xs text-gray-500">{subtitle}</p>}
          </div>
          <div className={`p-3 rounded-full bg-${color}-100`}>
            <Icon className={`h-5 w-5 text-${color}-600`} />
          </div>
        </div>
        {trend && (
          <div className={`flex items-center mt-2 text-xs ${trend.positive ? 'text-green-600' : 'text-red-600'}`}>
            <TrendingUp className={`h-3 w-3 mr-1 ${!trend.positive ? 'transform rotate-180' : ''}`} />
            <span>{trend.value}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const currentReportTemplate = availableReports.find(r => r.id === selectedReport);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold flex items-center space-x-2">
            <BarChart3 className="h-5 w-5 text-blue-600" />
            <span>Advanced Reporting Engine</span>
          </h3>
          <p className="text-sm text-gray-600">Comprehensive reporting and analytics dashboard</p>
        </div>
        <div className="flex items-center space-x-2">
          <Dialog open={showCustomBuilder} onOpenChange={setShowCustomBuilder}>
            <DialogTrigger asChild>
              <Button variant="outline" data-testid="custom-report-builder">
                <Settings className="h-4 w-4 mr-2" />
                Custom Report
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl">
              <DialogHeader>
                <DialogTitle>Custom Report Builder</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Report Title</Label>
                    <Input 
                      value={customReportBuilder.title}
                      onChange={(e) => setCustomReportBuilder({...customReportBuilder, title: e.target.value})}
                      placeholder="Enter report title"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Report Format</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select format" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="dashboard">Interactive Dashboard</SelectItem>
                        <SelectItem value="pdf">PDF Report</SelectItem>
                        <SelectItem value="excel">Excel Spreadsheet</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Include Sections</Label>
                  <div className="grid grid-cols-2 gap-2">
                    {['Financial Analysis', 'KPI Performance', 'Risk Assessment', 'Timeline Progress', 'Social Impact', 'Compliance Status'].map((section) => (
                      <div key={section} className="flex items-center space-x-2">
                        <Checkbox />
                        <label className="text-sm">{section}</label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          <Button onClick={() => exportReport('pdf')} data-testid="export-pdf">
            <Download className="h-4 w-4 mr-2" />
            Export PDF
          </Button>
          <Button onClick={() => exportReport('excel')} variant="outline" data-testid="export-excel">
            <Download className="h-4 w-4 mr-2" />
            Export Excel
          </Button>
        </div>
      </div>

      {/* Report Selection and Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="space-y-1">
                <Label className="text-xs">Report Type</Label>
                <Select value={selectedReport} onValueChange={setSelectedReport}>
                  <SelectTrigger className="w-64" data-testid="report-type-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {availableReports.map((report) => {
                      const IconComponent = report.icon;
                      return (
                        <SelectItem key={report.id} value={report.id}>
                          <div className="flex items-center space-x-2">
                            <IconComponent className="h-4 w-4" />
                            <span>{report.name}</span>
                          </div>
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Date Range</Label>
                <Select value={reportFilters.dateRange} onValueChange={(value) => 
                  setReportFilters({...reportFilters, dateRange: value})
                }>
                  <SelectTrigger className="w-40">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="last_7_days">Last 7 Days</SelectItem>
                    <SelectItem value="last_30_days">Last 30 Days</SelectItem>
                    <SelectItem value="last_quarter">Last Quarter</SelectItem>
                    <SelectItem value="last_year">Last Year</SelectItem>
                    <SelectItem value="project_lifetime">Project Lifetime</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button variant="outline" size="sm">
              <Filter className="h-4 w-4 mr-2" />
              More Filters
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Report Content */}
      <Tabs defaultValue="dashboard" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="dashboard">Interactive Dashboard</TabsTrigger>
          <TabsTrigger value="analytics">Advanced Analytics</TabsTrigger>
          <TabsTrigger value="export">Export & Schedule</TabsTrigger>
        </TabsList>

        {/* Dashboard View */}
        <TabsContent value="dashboard" className="space-y-6">
          {reportData && (
            <>
              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <MetricCard
                  title="Budget Utilization"
                  value={`${reportData.metrics.budgetUtilization}%`}
                  subtitle={`$${reportData.metrics.actualCost.toLocaleString()} of $${reportData.metrics.totalBudget.toLocaleString()}`}
                  icon={DollarSign}
                  color="green"
                  trend={{ positive: true, value: '+5.2% vs last month' }}
                />
                <MetricCard
                  title="Project Progress"
                  value={`${reportData.metrics.progressPercentage}%`}
                  subtitle="Overall completion"
                  icon={Target}
                  color="blue"
                  trend={{ positive: true, value: '+12% this month' }}
                />
                <MetricCard
                  title="KPI Achievement"
                  value={`${reportData.metrics.kpiCompletion}%`}
                  subtitle={`${reportData.kpis.length} KPIs tracked`}
                  icon={TrendingUp}
                  color="purple"
                />
                <MetricCard
                  title="Issue Resolution"
                  value={`${reportData.metrics.issueResolutionRate}%`}
                  subtitle={`${reportData.issues.length} total issues`}
                  icon={Activity}
                  color="orange"
                />
              </div>

              {/* Charts Section */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Budget Trend Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <LineChart className="h-5 w-5 text-green-600" />
                      <span>Budget vs Actual Trend</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-64 flex items-center justify-center text-gray-500">
                      📊 Interactive chart showing budget vs actual spending over time
                      <br />
                      <small>(Chart visualization would be implemented with a library like Chart.js or D3)</small>
                    </div>
                  </CardContent>
                </Card>

                {/* KPI Performance Chart */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <BarChart3 className="h-5 w-5 text-blue-600" />
                      <span>KPI Performance</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {reportData.charts.kpiPerformance.slice(0, 4).map((kpi, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>{kpi.name}</span>
                            <span className="font-medium">{kpi.percentage}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full ${
                                parseFloat(kpi.percentage) >= 90 ? 'bg-green-500' :
                                parseFloat(kpi.percentage) >= 70 ? 'bg-yellow-500' : 'bg-red-500'
                              }`}
                              style={{ width: `${Math.min(parseFloat(kpi.percentage), 100)}%` }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Deliverables Status */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <PieChart className="h-5 w-5 text-purple-600" />
                    <span>Deliverables Overview</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-4 gap-4">
                    {reportData.charts.deliverableStatus.map(({ status, count }) => (
                      <div key={status} className="text-center">
                        <div className={`w-16 h-16 rounded-full mx-auto mb-2 flex items-center justify-center text-white font-bold text-xl ${
                          status === 'certified' ? 'bg-green-500' :
                          status === 'completed' ? 'bg-blue-500' :
                          status === 'in_progress' ? 'bg-yellow-500' : 'bg-gray-400'
                        }`}>
                          {count}
                        </div>
                        <p className="text-sm capitalize font-medium">{status.replace('_', ' ')}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* SROI and Impact */}
              {reportData.sroi.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <TrendingUp className="h-5 w-5 text-indigo-600" />
                      <span>Social Return on Investment (SROI)</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="text-center">
                        <div className="text-4xl font-bold text-indigo-600">
                          {reportData.metrics.avgSROI}:1
                        </div>
                        <p className="text-sm text-gray-600">Average SROI Ratio</p>
                      </div>
                      <div className="text-center">
                        <div className="text-4xl font-bold text-green-600">
                          ${(reportData.metrics.totalBudget * parseFloat(reportData.metrics.avgSROI)).toLocaleString()}
                        </div>
                        <p className="text-sm text-gray-600">Estimated Social Value</p>
                      </div>
                      <div className="text-center">
                        <div className="text-4xl font-bold text-blue-600">
                          {reportData.sroi.length}
                        </div>
                        <p className="text-sm text-gray-600">SROI Calculations</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </TabsContent>

        {/* Advanced Analytics */}
        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Predictive Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium text-blue-900">Project Completion Forecast</h4>
                    <p className="text-sm text-blue-700 mt-1">
                      Based on current progress, project is estimated to complete on {
                        new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toLocaleDateString()
                      }
                    </p>
                  </div>
                  <div className="p-4 bg-green-50 rounded-lg">
                    <h4 className="font-medium text-green-900">Budget Forecast</h4>
                    <p className="text-sm text-green-700 mt-1">
                      Project is tracking {reportData?.metrics.budgetUtilization}% budget utilization. 
                      Projected final cost: ${(parseFloat(reportData?.metrics.totalBudget) * 1.05).toLocaleString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Risk Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Overall Risk Level</span>
                    <Badge className={`${
                      reportData?.metrics.riskLevel === 'Critical' ? 'bg-red-100 text-red-800' :
                      reportData?.metrics.riskLevel === 'High' ? 'bg-orange-100 text-orange-800' :
                      reportData?.metrics.riskLevel === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {reportData?.metrics.riskLevel}
                    </Badge>
                  </div>
                  {reportData?.charts.riskDistribution.map(({ level, count }) => (
                    <div key={level} className="flex justify-between items-center">
                      <span className="text-sm">{level} Risk</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-20 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${
                              level === 'Critical' ? 'bg-red-500' :
                              level === 'High' ? 'bg-orange-500' :
                              level === 'Medium' ? 'bg-yellow-500' : 'bg-green-500'
                            }`}
                            style={{ width: `${(count / Math.max(...reportData.charts.riskDistribution.map(r => r.count))) * 100}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium">{count}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Export and Schedule */}
        <TabsContent value="export" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Export Options</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <Button className="w-full justify-start" onClick={() => exportReport('pdf')}>
                    <FileText className="h-4 w-4 mr-2" />
                    Export as PDF Report
                  </Button>
                  <Button className="w-full justify-start" variant="outline" onClick={() => exportReport('excel')}>
                    <BarChart3 className="h-4 w-4 mr-2" />
                    Export as Excel Spreadsheet
                  </Button>
                  <Button className="w-full justify-start" variant="outline" onClick={() => exportReport('csv')}>
                    <Download className="h-4 w-4 mr-2" />
                    Export Raw Data (CSV)
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Schedule Reports</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <Label className="text-sm">Report Frequency</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select frequency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                        <SelectItem value="quarterly">Quarterly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-sm">Recipients</Label>
                    <Input placeholder="Enter email addresses" />
                  </div>
                  <Button className="w-full">
                    <Calendar className="h-4 w-4 mr-2" />
                    Schedule Report
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Report Template Info */}
      {currentReportTemplate && (
        <Card className="bg-gray-50">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2 text-gray-800">
              <currentReportTemplate.icon className="h-5 w-5" />
              <span>{currentReportTemplate.name}</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-600 mb-3">{currentReportTemplate.description}</p>
            <div className="flex flex-wrap gap-2">
              {currentReportTemplate.sections.map((section) => (
                <Badge key={section} variant="outline" className="text-xs">
                  {section.replace('_', ' ')}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default AdvancedReporting;