import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  Video, 
  Plus, 
  Upload, 
  Play,
  Pause,
  CheckCircle2, 
  XCircle,
  Clock,
  Eye,
  Download,
  Search,
  Filter,
  Calendar,
  User,
  MapPin,
  FileVideo,
  Camera,
  RotateCcw,
  FastForward,
  Volume2,
  VolumeX,
  Maximize,
  Edit3,
  Trash2,
  AlertTriangle,
  Shield,
  Award,
  Activity,
  BarChart3,
  Settings
} from 'lucide-react';
import UniversalComments from './UniversalComments';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const VideoVerification = ({ projectId, user }) => {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [videoForm, setVideoForm] = useState({
    title: '',
    description: '',
    verification_type: 'project_progress',
    priority: 'medium',
    location: '',
    tags: ''
  });

  useEffect(() => {
    fetchVideos();
  }, [projectId]);

  const fetchVideos = async () => {
    try {
      const response = await axios.get(`${API}/projects/${projectId}/videos`);
      setVideos(response.data);
    } catch (error) {
      console.error('Error fetching videos:', error);
      toast.error('Failed to load videos');
    } finally {
      setLoading(false);
    }
  };

  const handleUploadVideo = async (e) => {
    e.preventDefault();
    try {
      const videoData = {
        ...videoForm,
        tags: videoForm.tags.split(',').map(tag => tag.trim()).filter(tag => tag)
      };

      const response = await axios.post(`${API}/projects/${projectId}/videos`, videoData);
      setVideos([...videos, response.data]);
      setShowUploadDialog(false);
      resetVideoForm();
      toast.success('Video uploaded successfully!');
    } catch (error) {
      console.error('Error uploading video:', error);
      toast.error('Failed to upload video');
    }
  };

  const resetVideoForm = () => {
    setVideoForm({
      title: '',
      description: '',
      verification_type: 'project_progress',
      priority: 'medium',
      location: '',
      tags: ''
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'verified': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold flex items-center space-x-2">
            <Video className="h-5 w-5 text-purple-600" />
            <span>Video Verification System</span>
          </h3>
          <p className="text-sm text-gray-600">Upload, review, and manage verification videos for physical objects</p>
        </div>
        {user.role !== 'investor' && (
          <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
            <DialogTrigger asChild>
              <Button className="flex items-center space-x-2">
                <Upload className="h-4 w-4" />
                <span>Upload Video</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Upload Video for Verification</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleUploadVideo} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="video_title">Video Title *</Label>
                  <Input
                    id="video_title"
                    value={videoForm.title}
                    onChange={(e) => setVideoForm(prev => ({ ...prev, title: e.target.value }))}
                    placeholder="Enter video title"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="video_description">Description</Label>
                  <Textarea
                    id="video_description"
                    value={videoForm.description}
                    onChange={(e) => setVideoForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe what this video shows"
                    className="min-h-[100px]"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="verification_type">Verification Type</Label>
                    <Select value={videoForm.verification_type} onValueChange={(value) => setVideoForm(prev => ({ ...prev, verification_type: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="equipment_installation">Equipment Installation</SelectItem>
                        <SelectItem value="training_session">Training Session</SelectItem>
                        <SelectItem value="project_progress">Project Progress</SelectItem>
                        <SelectItem value="beneficiary_testimonial">Beneficiary Testimonial</SelectItem>
                        <SelectItem value="site_inspection">Site Inspection</SelectItem>
                        <SelectItem value="completion_verification">Completion Verification</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="priority">Priority Level</Label>
                    <Select value={videoForm.priority} onValueChange={(value) => setVideoForm(prev => ({ ...prev, priority: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="location">Location (Optional)</Label>
                  <Input
                    id="location"
                    value={videoForm.location}
                    onChange={(e) => setVideoForm(prev => ({ ...prev, location: e.target.value }))}
                    placeholder="Where was this video recorded?"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="tags">Tags (comma-separated)</Label>
                  <Input
                    id="tags"
                    value={videoForm.tags}
                    onChange={(e) => setVideoForm(prev => ({ ...prev, tags: e.target.value }))}
                    placeholder="e.g., equipment, training, progress"
                  />
                </div>
                
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <FileVideo className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600 mb-2">Drop your video here or click to browse</p>
                  <p className="text-xs text-gray-500">Supported formats: MP4, MOV, AVI (Max size: 500MB)</p>
                  <Button type="button" variant="outline" className="mt-3">
                    <Upload className="h-4 w-4 mr-2" />
                    Choose Video File
                  </Button>
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => {
                    setShowUploadDialog(false);
                    resetVideoForm();
                  }}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={!videoForm.title}>
                    Upload Video
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Video className="h-5 w-5 text-purple-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Total Videos</p>
                <p className="text-2xl font-bold text-gray-900">{videos.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle2 className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Verified</p>
                <p className="text-2xl font-bold text-gray-900">
                  {videos.filter(v => v.verification_status === 'verified').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-yellow-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Pending Review</p>
                <p className="text-2xl font-bold text-gray-900">
                  {videos.filter(v => v.verification_status === 'pending').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <BarChart3 className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-sm font-medium text-gray-600">Total Views</p>
                <p className="text-2xl font-bold text-gray-900">
                  {videos.reduce((sum, v) => sum + (v.view_count || 0), 0)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Video Gallery */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {videos.map((video) => (
          <Card key={video.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-base line-clamp-2">{video.title}</CardTitle>
                  <p className="text-xs text-gray-500 mt-1">
                    by {video.uploaded_by_name} • {new Date(video.created_at).toLocaleDateString()}
                  </p>
                </div>
                <Badge className={getStatusColor(video.verification_status)}>
                  {video.verification_status}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="pt-0">
              <div className="relative bg-gray-100 rounded-lg mb-3 aspect-video flex items-center justify-center">
                <Play className="h-12 w-12 text-gray-400" />
                <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
                  {video.duration || '0:00'}
                </div>
              </div>
              
              <p className="text-sm text-gray-600 mb-3 line-clamp-2">{video.description}</p>
              
              <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                <div className="flex items-center space-x-1">
                  <MapPin className="h-3 w-3" />
                  <span>{video.location || 'No location'}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Eye className="h-3 w-3" />
                  <span>{video.view_count || 0} views</span>
                </div>
              </div>

              {video.tags && video.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mb-3">
                  {video.tags.slice(0, 3).map((tag, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {video.tags.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{video.tags.length - 3}
                    </Badge>
                  )}
                </div>
              )}

              <div className="flex items-center justify-between">
                <Button size="sm" variant="outline">
                  <Play className="h-3 w-3 mr-1" />
                  Play
                </Button>
                
                {user.role !== 'investor' && (
                  <div className="flex items-center space-x-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-blue-600 hover:text-blue-800"
                    >
                      <Edit3 className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Empty State */}
      {videos.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Video className="h-16 w-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No videos uploaded yet</h3>
            <p className="text-gray-500 mb-4">
              Upload verification videos to document project progress and deliverables
            </p>
            {user.role !== 'investor' && (
              <Button onClick={() => setShowUploadDialog(true)}>
                <Upload className="h-4 w-4 mr-2" />
                Upload First Video
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Universal Comments for Video Verification */}
      <UniversalComments 
        projectId={projectId} 
        user={user} 
        itemType="video_verification" 
        title="Video Verification Comments & Feedback" 
      />
    </div>
  );
};

export default VideoVerification;