import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  TrendingUp, 
  DollarSign, 
  Activity, 
  BookOpen, 
  Heart, 
  Leaf, 
  BarChart3, 
  Clock,
  Target,
  AlertCircle,
  CheckCircle2,
  Package,
  Users,
  Zap,
  Calendar,
  Plus
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const SocialActorDashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await axios.get(`${API}/dashboard`);
      setDashboardData(response.data);
    } catch (error) {
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'education': return <BookOpen className="h-5 w-5" />;
      case 'care': return <Heart className="h-5 w-5" />;
      case 'environment': return <Leaf className="h-5 w-5" />;
      default: return <Activity className="h-5 w-5" />;
    }
  };

  const getCategoryColor = (category) => {
    switch (category) {
      case 'education': return 'bg-blue-100 text-blue-800';
      case 'care': return 'bg-green-100 text-green-800';
      case 'environment': return 'bg-emerald-100 text-emerald-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'executing': return 'bg-green-100 text-green-800';
      case 'planning': return 'bg-yellow-100 text-yellow-800';
      case 'initiating': return 'bg-blue-100 text-blue-800';
      case 'closing': return 'bg-purple-100 text-purple-800';
      case 'on_hold': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const StatCard = ({ title, value, icon: Icon, subtitle, color = "blue", urgent = false }) => (
    <Card className={`hover-lift transition-all duration-300 ${urgent ? 'ring-2 ring-orange-200' : ''}`} data-testid={`social-stat-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className={`text-2xl font-bold text-${color}-600`}>{value}</p>
            {subtitle && (
              <p className="text-xs text-gray-500">{subtitle}</p>
            )}
          </div>
          <div className={`p-3 rounded-full bg-${color}-100 ${urgent ? 'animate-pulse' : ''}`}>
            <Icon className={`h-6 w-6 text-${color}-600`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center space-x-3">
            <Users className="h-8 w-8 text-green-600" />
            <span>Project Management</span>
          </h1>
          <p className="text-gray-600 mt-1">Execute and deliver impactful social investment projects</p>
        </div>
        <Link to="/projects">
          <Button className="bg-gradient-to-r from-green-600 to-emerald-600">
            <Plus className="h-4 w-4 mr-2" />
            New Project
          </Button>
        </Link>
      </div>

      {/* Project Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="My Projects"
          value={dashboardData?.total_projects || 0}
          icon={Activity}
          subtitle="Total projects"
          color="blue"
        />
        <StatCard
          title="Active Projects"
          value={dashboardData?.active_projects || 0}
          icon={TrendingUp}
          subtitle="In progress"
          color="green"
        />
        <StatCard
          title="Project Budget"
          value={formatCurrency(dashboardData?.total_budget || 0)}
          icon={DollarSign}
          subtitle="Total funding"
          color="purple"
        />
        <StatCard
          title="Pending Deliverables"
          value={dashboardData?.pending_deliverables || 0}
          icon={Package}
          subtitle="Require attention"
          color="orange"
          urgent={dashboardData?.pending_deliverables > 0}
        />
      </div>

      {/* Progress Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="h-5 w-5 text-green-600" />
              <span>Budget Utilization</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Budget Spent</span>
                <span className="font-semibold">
                  {dashboardData?.total_budget ? 
                    Math.round((dashboardData.total_spent / dashboardData.total_budget) * 100) : 0}%
                </span>
              </div>
              <Progress 
                value={dashboardData?.total_budget ? 
                  (dashboardData.total_spent / dashboardData.total_budget) * 100 : 0} 
              />
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">Spent: {formatCurrency(dashboardData?.total_spent || 0)}</span>
                <span className="text-gray-500">Budget: {formatCurrency(dashboardData?.total_budget || 0)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Zap className="h-5 w-5 text-blue-600" />
              <span>Project Health</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <p className="text-2xl font-bold text-green-600">{dashboardData?.active_projects || 0}</p>
                  <p className="text-xs text-green-700">On Track</p>
                </div>
                <div className="text-center p-3 bg-orange-50 rounded-lg">
                  <p className="text-2xl font-bold text-orange-600">{dashboardData?.pending_deliverables || 0}</p>
                  <p className="text-xs text-orange-700">Need Attention</p>
                </div>
              </div>
              <div className="text-center">
                <p className="text-sm text-gray-600">
                  {dashboardData?.pending_deliverables > 0 
                    ? `${dashboardData.pending_deliverables} deliverable${dashboardData.pending_deliverables > 1 ? 's' : ''} pending` 
                    : 'All deliverables up to date'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* My Projects */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-blue-600" />
            <span>My Projects</span>
          </CardTitle>
          <Link to="/projects">
            <Button variant="outline" size="sm" data-testid="social-view-all-projects">
              Manage All Projects
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {dashboardData?.recent_projects?.map((project) => (
              <div key={project.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center space-x-4">
                  <div className="p-2 rounded-full bg-gray-100">
                    {getCategoryIcon(project.category)}
                  </div>
                  <div>
                    <Link 
                      to={`/projects/${project.id}`}
                      className="font-medium text-gray-900 hover:text-blue-600 transition-colors"
                      data-testid={`social-project-link-${project.id}`}
                    >
                      {project.title}
                    </Link>
                    <div className="flex items-center space-x-2 mt-1">
                      <Badge className={getCategoryColor(project.category)}>
                        {project.category}
                      </Badge>
                      <Badge className={getStatusColor(project.status)}>
                        {project.status.replace('_', ' ')}
                      </Badge>
                      <span className="text-xs text-gray-500">
                        Budget: {formatCurrency(project.budget)}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-sm font-medium">{Math.round(project.progress)}%</span>
                    {project.progress >= 75 ? (
                      <CheckCircle2 className="h-4 w-4 text-green-500" />
                    ) : project.progress >= 25 ? (
                      <Clock className="h-4 w-4 text-yellow-500" />
                    ) : (
                      <AlertCircle className="h-4 w-4 text-red-500" />
                    )}
                  </div>
                  <Progress value={project.progress} className="w-24" />
                  <p className="text-xs text-gray-500 mt-1">
                    Due: {new Date(project.end_date).toLocaleDateString()}
                  </p>
                </div>
              </div>
            ))}
            {(!dashboardData?.recent_projects || dashboardData.recent_projects.length === 0) && (
              <div className="text-center py-8 text-gray-500">
                <Activity className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No projects assigned yet. Contact your administrator to get started.</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card data-testid="social-quick-actions">
        <CardHeader>
          <CardTitle>Project Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link to="/projects">
              <Button className="w-full justify-start h-auto p-4" variant="outline">
                <Activity className="h-5 w-5 mr-3" />
                <div className="text-left">
                  <p className="font-medium">Manage Projects</p>
                  <p className="text-sm text-gray-500">Update progress & deliverables</p>
                </div>
              </Button>
            </Link>
            <Button className="w-full justify-start h-auto p-4" variant="outline" disabled>
              <Package className="h-5 w-5 mr-3" />
              <div className="text-left">
                <p className="font-medium">Upload Deliverables</p>
                <p className="text-sm text-gray-500">Coming soon</p>
              </div>
            </Button>
            <Button className="w-full justify-start h-auto p-4" variant="outline" disabled>
              <BarChart3 className="h-5 w-5 mr-3" />
              <div className="text-left">
                <p className="font-medium">Progress Reports</p>
                <p className="text-sm text-gray-500">Coming soon</p>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SocialActorDashboard;