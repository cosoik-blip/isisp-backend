import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardContent 
} from '../components/ui/card';
import { Button } from '../components/ui/button';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription
} from '../components/ui/dialog';
import {
  BookOpen,
  Download,
  FileText,
  User,
  Building,
  Heart,
  Globe,
  Eye,
  Calendar,
  FileDown,
  Info,
  ArrowLeft
} from 'lucide-react';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const UserGuides = () => {
  const [guides, setGuides] = useState([]);
  const [selectedGuide, setSelectedGuide] = useState(null);
  const [guideContent, setGuideContent] = useState('');
  const [showGuideDialog, setShowGuideDialog] = useState(false);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(null);
  
  const user = JSON.parse(localStorage.getItem('user')) || {};

  useEffect(() => {
    fetchGuides();
  }, []);

  const fetchGuides = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/user-guides`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setGuides(response.data);
    } catch (error) {
      console.error('Error fetching guides:', error);
      toast.error('Failed to load user guides');
    } finally {
      setLoading(false);
    }
  };

  const openGuide = async (guide) => {
    try {
      setSelectedGuide(guide);
      const response = await axios.get(`${BACKEND_URL}/api/user-guides/${guide.id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setGuideContent(response.data.content);
      setShowGuideDialog(true);
    } catch (error) {
      console.error('Error loading guide:', error);
      toast.error('Failed to load guide content');
    }
  };

  const downloadGuide = async (guide, format = 'markdown') => {
    try {
      setDownloading(guide.id);
      const response = await axios.get(`${BACKEND_URL}/api/user-guides/${guide.id}/download?format=${format}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        responseType: 'blob'
      });

      const blob = new Blob([response.data], { 
        type: format === 'txt' ? 'text/plain' : 'text/markdown' 
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = guide.filename.replace('.md', format === 'txt' ? '.txt' : '.md');
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      
      toast.success(`Guide downloaded successfully!`);
    } catch (error) {
      console.error('Error downloading guide:', error);
      toast.error('Failed to download guide');
    } finally {
      setDownloading(null);
    }
  };

  const getRoleIcon = (role) => {
    switch (role) {
      case 'administrator': return User;
      case 'investor': return Building;
      case 'social_actor': return Heart;
      default: return Globe;
    }
  };

  const getRoleColor = (role) => {
    switch (role) {
      case 'administrator': return 'text-blue-600 bg-blue-50';
      case 'investor': return 'text-green-600 bg-green-50';
      case 'social_actor': return 'text-purple-600 bg-purple-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const isRelevantForUser = (guide) => {
    // Show role-specific guides and general guides
    return guide.role === 'all' || guide.role === user.role || user.role === 'administrator';
  };

  const formatMarkdownForDisplay = (markdown) => {
    // Simple markdown to HTML conversion for basic display
    return markdown
      .replace(/^### (.*$)/gim, '<h3 class="text-lg font-semibold mt-4 mb-2">$1</h3>')
      .replace(/^## (.*$)/gim, '<h2 class="text-xl font-semibold mt-6 mb-3">$1</h2>')
      .replace(/^# (.*$)/gim, '<h1 class="text-2xl font-bold mt-8 mb-4">$1</h1>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/`(.*?)`/g, '<code class="bg-gray-100 px-1 rounded">$1</code>')
      .replace(/\n/g, '<br>');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link 
            to="/dashboard" 
            className="flex items-center space-x-2 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Back to Dashboard</span>
          </Link>
          <div className="border-l border-gray-300 h-8"></div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <BookOpen className="h-7 w-7 text-blue-600" />
              <span>User Guides & Documentation</span>
            </h2>
            <p className="text-gray-600 mt-1">
              Comprehensive guides and documentation for effective platform usage
            </p>
          </div>
        </div>
      </div>

      {/* Quick Info */}
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-start space-x-3">
            <Info className="h-5 w-5 text-blue-600 mt-0.5" />
            <div>
              <h3 className="font-medium text-blue-900">Guide Access Information</h3>
              <p className="text-sm text-blue-700 mt-1">
                {user.role === 'administrator' ? 
                  "As an administrator, you have access to all user guides including role-specific documentation." :
                  `As a ${user.role?.replace('_', ' ')}, you can access guides relevant to your role plus general platform documentation.`
                }
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* User Guides Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {guides.filter(isRelevantForUser).map((guide) => {
          const RoleIcon = getRoleIcon(guide.role);
          const roleColorClass = getRoleColor(guide.role);

          return (
            <Card key={guide.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-base mb-2">{guide.title}</CardTitle>
                    <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${roleColorClass}`}>
                      <RoleIcon className="h-3 w-3 mr-1" />
                      {guide.role === 'all' ? 'All Users' : guide.role.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="pt-0">
                <p className="text-sm text-gray-600 mb-3 line-clamp-3">{guide.description}</p>
                
                <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                  <div className="flex items-center space-x-1">
                    <FileText className="h-3 w-3" />
                    <span>{guide.pages}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-3 w-3" />
                    <span>Updated {guide.updated}</span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => openGuide(guide)}
                      className="flex-1"
                    >
                      <Eye className="h-3 w-3 mr-1" />
                      Read Online
                    </Button>
                    
                    <Button
                      size="sm"
                      onClick={() => downloadGuide(guide, 'txt')}
                      disabled={downloading === guide.id}
                      className="flex-1"
                    >
                      <Download className="h-3 w-3 mr-1" />
                      {downloading === guide.id ? 'Downloading...' : 'Download'}
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => downloadGuide(guide, 'html')}
                      disabled={downloading === guide.id}
                      className="text-green-600 border-green-300 hover:bg-green-50"
                    >
                      <FileDown className="h-3 w-3 mr-1" />
                      Word Format
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => downloadGuide(guide, 'markdown')}
                      disabled={downloading === guide.id}
                    >
                      <FileDown className="h-3 w-3 mr-1" />
                      Markdown
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Guide Content Dialog */}
      <Dialog open={showGuideDialog} onOpenChange={setShowGuideDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <BookOpen className="h-5 w-5 text-blue-600" />
              <span>{selectedGuide?.title}</span>
            </DialogTitle>
            <DialogDescription>
              {selectedGuide?.description}
            </DialogDescription>
          </DialogHeader>
          
          <div className="mt-6">
            <div className="flex items-center justify-between mb-4">
              <div className="text-sm text-gray-500">
                {selectedGuide?.pages} • Updated {selectedGuide?.updated}
              </div>
              <div className="flex space-x-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => downloadGuide(selectedGuide, 'html')}
                  disabled={downloading === selectedGuide?.id}
                  className="text-green-600 border-green-300 hover:bg-green-50"
                >
                  <Download className="h-3 w-3 mr-1" />
                  Word Format
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => downloadGuide(selectedGuide, 'txt')}
                  disabled={downloading === selectedGuide?.id}
                >
                  <Download className="h-3 w-3 mr-1" />
                  TXT
                </Button>
                <Button
                  size="sm"
                  onClick={() => downloadGuide(selectedGuide, 'markdown')}
                  disabled={downloading === selectedGuide?.id}
                >
                  <FileDown className="h-3 w-3 mr-1" />
                  Markdown
                </Button>
              </div>
            </div>
            
            <div className="prose prose-sm max-w-none">
              <div 
                className="whitespace-pre-wrap font-mono text-sm bg-gray-50 p-4 rounded-lg border max-h-[60vh] overflow-y-auto"
                dangerouslySetInnerHTML={{ 
                  __html: formatMarkdownForDisplay(guideContent) 
                }}
              />
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default UserGuides;