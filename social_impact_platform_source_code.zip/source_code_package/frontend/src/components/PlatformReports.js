import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardContent 
} from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import {
  BarChart3,
  ArrowLeft,
  Users,
  FileText,
  Activity,
  Download,
  TrendingUp,
  Eye,
  BookOpen,
  Calendar,
  Clock,
  RefreshCw,
  Filter,
  Star,
  Bookmark
} from 'lucide-react';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const PlatformReports = () => {
  const [overviewData, setOverviewData] = useState(null);
  const [userReport, setUserReport] = useState(null);
  const [contentReport, setContentReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedReport, setSelectedReport] = useState('overview');

  useEffect(() => {
    fetchAllReports();
  }, []);

  const fetchAllReports = async () => {
    try {
      setLoading(true);
      console.log('Fetching reports...');
      
      // Fetch reports one by one with better error handling
      try {
        const overviewRes = await axios.get(`${BACKEND_URL}/api/admin/reports/overview`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        console.log('Overview data received:', overviewRes.data);
        setOverviewData(overviewRes.data);
      } catch (error) {
        console.error('Overview fetch error:', error);
        toast.error('Failed to load overview report');
      }

      try {
        const userRes = await axios.get(`${BACKEND_URL}/api/admin/reports/users`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        console.log('User data received:', userRes.data);
        setUserReport(userRes.data);
      } catch (error) {
        console.error('User report fetch error:', error);
        toast.error('Failed to load user report');
      }

      try {
        const contentRes = await axios.get(`${BACKEND_URL}/api/admin/reports/content`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        console.log('Content data received:', contentRes.data);
        setContentReport(contentRes.data);
      } catch (error) {
        console.error('Content report fetch error:', error);
        toast.error('Failed to load content report');
      }

    } catch (error) {
      console.error('General error fetching reports:', error);
      toast.error('Failed to load reports');
    } finally {
      setLoading(false);
    }
  };

  const refreshReports = async () => {
    setRefreshing(true);
    await fetchAllReports();
    setRefreshing(false);
    toast.success('Reports refreshed successfully!');
  };

  const addSampleData = async () => {
    try {
      await axios.post(`${BACKEND_URL}/api/admin/add-sample-data`, {}, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      toast.success('Sample data added successfully! Refreshing reports...');
      await fetchAllReports();
    } catch (error) {
      console.error('Error adding sample data:', error);
      toast.error('Failed to add sample data');
    }
  };

  const exportReport = (reportType) => {
    let data, filename;
    
    switch (reportType) {
      case 'overview':
        data = overviewData;
        filename = 'platform_overview_report.json';
        break;
      case 'users':
        data = userReport;
        filename = 'user_activity_report.json';
        break;
      case 'content':
        data = contentReport;
        filename = 'content_performance_report.json';
        break;
      default:
        return;
    }

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
    
    toast.success('JSON report exported successfully!');
  };

  const exportPDF = async (reportType) => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/admin/reports/${reportType}/export-pdf`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        responseType: 'blob'
      });

      const blob = new Blob([response.data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${reportType}_report_${new Date().toISOString().split('T')[0]}.pdf`;
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
      
      toast.success('PDF report exported successfully!');
    } catch (error) {
      console.error('Error exporting PDF:', error);
      toast.error('Failed to export PDF report');
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  const formatDateTime = (dateString) => {
    return new Date(dateString).toLocaleString();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link 
            to="/dashboard" 
            className="flex items-center space-x-2 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Back to Dashboard</span>
          </Link>
          <div className="border-l border-gray-300 h-8"></div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <BarChart3 className="h-7 w-7 text-blue-600" />
              <span>Platform Reports & Analytics</span>
            </h2>
            <p className="text-gray-600 mt-1">
              Comprehensive insights into platform usage and performance
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            onClick={addSampleData}
            className="text-purple-600 border-purple-300 hover:bg-purple-50"
          >
            <TrendingUp className="h-4 w-4 mr-2" />
            Add Sample Data
          </Button>
          <Button
            variant="outline"
            onClick={refreshReports}
            disabled={refreshing}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh Data
          </Button>
          <Button onClick={() => exportReport(selectedReport)}>
            <Download className="h-4 w-4 mr-2" />
            Export JSON
          </Button>
          <Button onClick={() => exportPDF(selectedReport)} className="bg-red-600 hover:bg-red-700">
            <FileText className="h-4 w-4 mr-2" />
            Export PDF
          </Button>
        </div>
      </div>

      {/* Report Selector */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-4">
            <Filter className="h-5 w-5 text-gray-500" />
            <Select value={selectedReport} onValueChange={setSelectedReport}>
              <SelectTrigger className="w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="overview">Platform Overview</SelectItem>
                <SelectItem value="users">User Activity Report</SelectItem>
                <SelectItem value="content">Content Performance</SelectItem>
              </SelectContent>
            </Select>
            <span className="text-sm text-gray-500">
              Last updated: {overviewData && formatDateTime(overviewData.generated_at)}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Debug Information */}
      {!loading && (
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="text-sm">
              <h4 className="font-medium text-blue-900 mb-2">Debug Information:</h4>
              <p>Overview Data: {overviewData ? '✅ Loaded' : '❌ Not loaded'}</p>
              <p>User Report: {userReport ? '✅ Loaded' : '❌ Not loaded'}</p>
              <p>Content Report: {contentReport ? '✅ Loaded' : '❌ Not loaded'}</p>
              <p>Backend URL: {BACKEND_URL}</p>
              <p>Token: {localStorage.getItem('token') ? '✅ Present' : '❌ Missing'}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Overview Report */}
      {selectedReport === 'overview' && (
        <div>
          {overviewData ? (
        <div className="space-y-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Users className="h-8 w-8 text-blue-600" />
                  <div>
                    <p className="text-2xl font-bold">{overviewData.user_statistics.total_users}</p>
                    <p className="text-sm text-gray-500">Total Users</p>
                    <p className="text-xs text-green-600">
                      {overviewData.user_statistics.active_users_this_week} active this week
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <FileText className="h-8 w-8 text-green-600" />
                  <div>
                    <p className="text-2xl font-bold">{overviewData.content_statistics.total_instruments}</p>
                    <p className="text-sm text-gray-500">Instruments</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Eye className="h-8 w-8 text-purple-600" />
                  <div>
                    <p className="text-2xl font-bold">{overviewData.activity_statistics.total_reads}</p>
                    <p className="text-sm text-gray-500">Total Reads</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Download className="h-8 w-8 text-orange-600" />
                  <div>
                    <p className="text-2xl font-bold">{overviewData.activity_statistics.total_downloads}</p>
                    <p className="text-sm text-gray-500">Downloads</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Users by Role */}
          <Card>
            <CardHeader>
              <CardTitle>User Distribution by Role</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {overviewData.user_statistics.users_by_role.map((role) => {
                  const percentage = Math.round((role.count / overviewData.user_statistics.total_users) * 100);
                  return (
                    <div key={role._id}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium capitalize">{role._id?.replace('_', ' ') || 'Unknown'}</span>
                        <span className="text-sm text-gray-600">{role.count} users ({percentage}%)</span>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Popular Content */}
          <Card>
            <CardHeader>
              <CardTitle>Most Popular Content</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {overviewData.popular_content.map((instrument, index) => (
                  <div key={instrument.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Badge variant="outline">#{index + 1}</Badge>
                      <div>
                        <h4 className="font-medium">{instrument.title}</h4>
                        <p className="text-sm text-gray-600">by {instrument.created_by_name}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <Eye className="h-3 w-3" />
                        <span>{instrument.view_count || 0}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Download className="h-3 w-3" />
                        <span>{instrument.downloads || 0}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Star className="h-3 w-3" />
                        <span>{instrument.rating || 0}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-gray-500">No overview data available. Try adding sample data or refreshing.</p>
          </CardContent>
        </Card>
      )}
        </div>
      )}

      {/* User Activity Report */}
      {selectedReport === 'users' && userReport && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Top Active Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {userReport.user_engagement.slice(0, 10).map((user, index) => (
                  <div key={user.user_id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Badge variant="outline">#{index + 1}</Badge>
                      <div>
                        <h4 className="font-medium">{user.username}</h4>
                        <Badge className="text-xs">
                          {user.role.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </Badge>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-sm text-gray-600">
                      <div className="text-center">
                        <p className="font-medium">{user.total_reads}</p>
                        <p className="text-xs">Reads</p>
                      </div>
                      <div className="text-center">
                        <p className="font-medium">{user.total_time_hours}h</p>
                        <p className="text-xs">Time</p>
                      </div>
                      <div className="text-center">
                        <p className="font-medium">{user.avg_progress}%</p>
                        <p className="text-xs">Avg Progress</p>
                      </div>
                      <div className="text-center">
                        <p className="font-medium">{user.completion_rate}%</p>
                        <p className="text-xs">Completion</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>User Registration Trend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {userReport.registration_trend.map((month) => (
                  <div key={month._id} className="flex justify-between items-center p-3 border rounded-lg">
                    <span className="font-medium">{month._id}</span>
                    <Badge variant="outline">{month.new_users} new users</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Content Performance Report */}
      {selectedReport === 'content' && contentReport && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Content Performance Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {contentReport.content_performance.slice(0, 15).map((content, index) => (
                  <div key={content._id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Badge variant="outline">#{index + 1}</Badge>
                      <div className="flex-1">
                        <h4 className="font-medium line-clamp-1">{content.title}</h4>
                        <p className="text-sm text-gray-600">
                          {content.category} • by {content.created_by_name}
                        </p>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-sm text-gray-600">
                      <div className="text-center">
                        <p className="font-medium">{content.view_count}</p>
                        <p className="text-xs">Views</p>
                      </div>
                      <div className="text-center">
                        <p className="font-medium">{content.downloads}</p>
                        <p className="text-xs">Downloads</p>
                      </div>
                      <div className="text-center">
                        <p className="font-medium">{content.rating.toFixed(1)}</p>
                        <p className="text-xs">Rating</p>
                      </div>
                      <div className="text-center">
                        <p className="font-medium">{content.file_size_mb}</p>
                        <p className="text-xs">MB</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Performance by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {contentReport.category_performance.map((category) => (
                  <div key={category._id} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium capitalize">{category._id}</h4>
                      <Badge variant="outline">{category.total_instruments} instruments</Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="font-medium">{category.total_views.toLocaleString()}</p>
                        <p className="text-gray-600">Total Views</p>
                      </div>
                      <div>
                        <p className="font-medium">{category.total_downloads.toLocaleString()}</p>
                        <p className="text-gray-600">Total Downloads</p>
                      </div>
                      <div>
                        <p className="font-medium">{category.avg_rating.toFixed(1)}</p>
                        <p className="text-gray-600">Avg Rating</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default PlatformReports;