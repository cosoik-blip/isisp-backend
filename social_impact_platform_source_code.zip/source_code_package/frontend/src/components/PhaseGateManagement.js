import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Checkbox } from './ui/checkbox';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  CheckCircle2, 
  Clock, 
  XCircle, 
  Plus, 
  Calendar, 
  User, 
  Flag,
  ArrowRight,
  Target,
  AlertTriangle
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const PhaseGateManagement = ({ projectId, user }) => {
  const [phaseGates, setPhaseGates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showReviewDialog, setShowReviewDialog] = useState(false);
  const [selectedGate, setSelectedGate] = useState(null);
  const [formData, setFormData] = useState({
    phase: '',
    gate_type: '',
    criteria_met: {}
  });
  const [reviewData, setReviewData] = useState({
    status: '',
    review_notes: ''
  });

  useEffect(() => {
    fetchPhaseGates();
  }, [projectId]);

  const fetchPhaseGates = async () => {
    try {
      const response = await axios.get(`${API}/projects/${projectId}/phase-gates`);
      setPhaseGates(response.data);
    } catch (error) {
      toast.error('Failed to load phase gates');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateGate = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API}/projects/${projectId}/phase-gates`, formData);
      toast.success('Phase gate created successfully!');
      setShowCreateDialog(false);
      setFormData({
        phase: '',
        gate_type: '',
        criteria_met: {}
      });
      fetchPhaseGates();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to create phase gate');
    }
  };

  const handleReviewGate = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`${API}/projects/${projectId}/phase-gates/${selectedGate.id}`, reviewData);
      toast.success('Phase gate review completed!');
      setShowReviewDialog(false);
      setSelectedGate(null);
      setReviewData({ status: '', review_notes: '' });
      fetchPhaseGates();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to review phase gate');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved': return <CheckCircle2 className="h-4 w-4 text-green-500" />;
      case 'rejected': return <XCircle className="h-4 w-4 text-red-500" />;
      case 'pending': return <Clock className="h-4 w-4 text-yellow-500" />;
      default: return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getPhaseColor = (phase) => {
    const colorMap = {
      initiating: 'bg-blue-100 text-blue-800',
      planning: 'bg-purple-100 text-purple-800',
      executing: 'bg-orange-100 text-orange-800',
      closing: 'bg-green-100 text-green-800'
    };
    return colorMap[phase] || 'bg-gray-100 text-gray-800';
  };

  const getCriteriaProgress = (criteria) => {
    if (!criteria || Object.keys(criteria).length === 0) return 0;
    const total = Object.keys(criteria).length;
    const met = Object.values(criteria).filter(Boolean).length;
    return (met / total) * 100;
  };

  const criteriaTemplates = {
    RfP: {
      'Project Charter Approved': false,
      'Stakeholders Identified': false,
      'Initial Risk Assessment Complete': false,
      'Budget Approved': false,
      'Team Assigned': false
    },
    RfE: {
      'Planning Complete': false,
      'Resources Allocated': false,
      'Quality Plan Approved': false,
      'Communication Plan Ready': false,
      'Baseline Established': false
    },
    RfC: {
      'All Deliverables Complete': false,
      'Quality Acceptance Achieved': false,
      'Final Report Submitted': false,
      'Lessons Learned Documented': false,
      'Stakeholder Sign-off Obtained': false
    }
  };

  const updateCriteria = (criterion, value) => {
    setFormData({
      ...formData,
      criteria_met: {
        ...formData.criteria_met,
        [criterion]: value
      }
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold flex items-center space-x-2">
            <Flag className="h-5 w-5 text-blue-600" />
            <span>Phase Gate Management</span>
          </h3>
          <p className="text-sm text-gray-600">Manage project phase transitions and approvals</p>
        </div>
        {user.role === 'social_actor' && (
          <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <DialogTrigger asChild>
              <Button data-testid="create-phase-gate-button">
                <Plus className="h-4 w-4 mr-2" />
                Request Phase Gate Review
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Request Phase Gate Review</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreateGate} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phase">Project Phase</Label>
                    <Select value={formData.phase} onValueChange={(value) => setFormData({...formData, phase: value})}>
                      <SelectTrigger data-testid="phase-select">
                        <SelectValue placeholder="Select phase" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="initiating">Initiating</SelectItem>
                        <SelectItem value="planning">Planning</SelectItem>
                        <SelectItem value="executing">Executing</SelectItem>
                        <SelectItem value="closing">Closing</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="gate-type">Gate Type</Label>
                    <Select value={formData.gate_type} onValueChange={(value) => {
                      setFormData({
                        ...formData, 
                        gate_type: value,
                        criteria_met: criteriaTemplates[value] || {}
                      });
                    }}>
                      <SelectTrigger data-testid="gate-type-select">
                        <SelectValue placeholder="Select gate type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="RfP">Ready for Planning (RfP)</SelectItem>
                        <SelectItem value="RfE">Ready for Execution (RfE)</SelectItem>
                        <SelectItem value="RfC">Ready for Closing (RfC)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {formData.gate_type && criteriaTemplates[formData.gate_type] && (
                  <div className="space-y-3">
                    <Label>Phase Gate Criteria</Label>
                    <div className="space-y-2 p-4 bg-gray-50 rounded-lg">
                      {Object.entries(criteriaTemplates[formData.gate_type]).map(([criterion, defaultValue]) => (
                        <div key={criterion} className="flex items-center space-x-2">
                          <Checkbox
                            checked={formData.criteria_met[criterion] || false}
                            onCheckedChange={(checked) => updateCriteria(criterion, checked)}
                          />
                          <label className="text-sm font-medium">{criterion}</label>
                        </div>
                      ))}
                      
                      <div className="mt-3 pt-3 border-t">
                        <div className="flex justify-between items-center mb-1">
                          <span className="text-sm text-gray-600">Criteria Completion</span>
                          <span className="text-sm font-medium">{Math.round(getCriteriaProgress(formData.criteria_met))}%</span>
                        </div>
                        <Progress value={getCriteriaProgress(formData.criteria_met)} />
                      </div>
                    </div>
                  </div>
                )}

                <div className="flex justify-end space-x-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setShowCreateDialog(false)}>
                    Cancel
                  </Button>
                  <Button 
                    type="submit" 
                    disabled={getCriteriaProgress(formData.criteria_met) < 100}
                    data-testid="submit-phase-gate"
                  >
                    Submit for Review
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Phase Gates List */}
      <div className="space-y-4">
        {phaseGates.map((gate) => (
          <Card key={gate.id} className="hover:shadow-md transition-shadow" data-testid={`phase-gate-${gate.id}`}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-4">
                  <div className="p-3 rounded-full bg-blue-100">
                    <Flag className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h4 className="font-semibold text-lg">{gate.gate_type}</h4>
                      <Badge className={getPhaseColor(gate.phase)}>
                        {gate.phase}
                      </Badge>
                      <Badge className={getStatusColor(gate.status)}>
                        <div className="flex items-center space-x-1">
                          {getStatusIcon(gate.status)}
                          <span>{gate.status}</span>
                        </div>
                      </Badge>
                    </div>
                    
                    <div className="mb-4">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium text-gray-700">Criteria Completion</span>
                        <span className="text-sm text-gray-600">{Math.round(getCriteriaProgress(gate.criteria_met))}%</span>
                      </div>
                      <Progress value={getCriteriaProgress(gate.criteria_met)} />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                      <div className="space-y-2">
                        <h5 className="font-medium text-sm text-gray-700">Criteria Status</h5>
                        <div className="space-y-1">
                          {Object.entries(gate.criteria_met || {}).map(([criterion, met]) => (
                            <div key={criterion} className="flex items-center space-x-2 text-sm">
                              {met ? (
                                <CheckCircle2 className="h-4 w-4 text-green-500" />
                              ) : (
                                <XCircle className="h-4 w-4 text-red-500" />
                              )}
                              <span className={met ? 'text-green-700' : 'text-red-700'}>{criterion}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {gate.review_notes && (
                        <div className="space-y-2">
                          <h5 className="font-medium text-sm text-gray-700">Review Notes</h5>
                          <p className="text-sm text-gray-600 p-3 bg-gray-50 rounded-lg">{gate.review_notes}</p>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-4 w-4" />
                        <span>Requested: {new Date(gate.created_at).toLocaleDateString()}</span>
                      </div>
                      {gate.approved_at && (
                        <div className="flex items-center space-x-1">
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                          <span>Approved: {new Date(gate.approved_at).toLocaleDateString()}</span>
                        </div>
                      )}
                      {gate.approved_by && (
                        <div className="flex items-center space-x-1">
                          <User className="h-4 w-4" />
                          <span>Approved by: {gate.approved_by}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  {user.role === 'administrator' && gate.status === 'pending' && (
                    <Button
                      size="sm"
                      onClick={() => {
                        setSelectedGate(gate);
                        setShowReviewDialog(true);
                      }}
                      data-testid={`review-gate-${gate.id}`}
                    >
                      <Target className="h-4 w-4 mr-2" />
                      Review
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        
        {phaseGates.length === 0 && (
          <div className="text-center py-12 text-gray-500">
            <Flag className="h-16 w-16 mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No phase gates created yet</h3>
            <p className="mb-4">Phase gates help ensure project quality and readiness before moving to the next phase.</p>
            {user.role === 'social_actor' && (
              <Button onClick={() => setShowCreateDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Request First Phase Gate Review
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Review Dialog */}
      <Dialog open={showReviewDialog} onOpenChange={setShowReviewDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Phase Gate Review</DialogTitle>
          </DialogHeader>
          {selectedGate && (
            <form onSubmit={handleReviewGate} className="space-y-4">
              <div className="space-y-3">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium mb-2">{selectedGate.gate_type} - {selectedGate.phase}</h4>
                  <div className="space-y-1">
                    {Object.entries(selectedGate.criteria_met || {}).map(([criterion, met]) => (
                      <div key={criterion} className="flex items-center space-x-2 text-sm">
                        {met ? (
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                        ) : (
                          <XCircle className="h-4 w-4 text-red-500" />
                        )}
                        <span className={met ? 'text-green-700' : 'text-red-700'}>{criterion}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="review-status">Review Decision</Label>
                <Select value={reviewData.status} onValueChange={(value) => setReviewData({...reviewData, status: value})}>
                  <SelectTrigger data-testid="review-status-select">
                    <SelectValue placeholder="Select review decision" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="approved">Approve</SelectItem>
                    <SelectItem value="rejected">Reject</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="review-notes">Review Notes</Label>
                <Textarea
                  id="review-notes"
                  value={reviewData.review_notes}
                  onChange={(e) => setReviewData({...reviewData, review_notes: e.target.value})}
                  placeholder="Provide feedback and recommendations..."
                  rows={4}
                  required
                  data-testid="review-notes-input"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button type="button" variant="outline" onClick={() => setShowReviewDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit" data-testid="submit-review">
                  Submit Review
                </Button>
              </div>
            </form>
          )}
        </DialogContent>
      </Dialog>

      {/* Phase Gate Process Info */}
      <Card className="bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-blue-900">
            <ArrowRight className="h-5 w-5" />
            <span>Phase Gate Process</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-blue-800 space-y-2">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="font-medium">Ready for Planning (RfP)</p>
              <p>Ensures project is properly initiated with clear charter, identified stakeholders, and approved budget before moving to detailed planning.</p>
            </div>
            <div>
              <p className="font-medium">Ready for Execution (RfE)</p>
              <p>Verifies that comprehensive planning is complete, resources are allocated, and the project team is ready to begin implementation.</p>
            </div>
            <div>
              <p className="font-medium">Ready for Closing (RfC)</p>
              <p>Confirms all deliverables are complete, quality standards met, and proper documentation is in place before project closure.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PhaseGateManagement;