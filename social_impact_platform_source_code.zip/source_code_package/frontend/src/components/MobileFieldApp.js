import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  Smartphone, 
  MapPin, 
  Camera, 
  Wifi,
  WifiOff,
  Upload,
  Download,
  CheckCircle2,
  Clock,
  AlertTriangle,
  User,
  Calendar,
  FileText,
  Image,
  Navigation,
  Battery,
  Signal,
  RotateCcw,
  Save,
  Send,
  Edit3,
  Plus,
  Eye,
  Target,
  Activity,
  Settings,
  Zap,
  Shield,
  Globe
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const MobileFieldApp = ({ projectId, user }) => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [location, setLocation] = useState(null);
  const [locationError, setLocationError] = useState(null);
  const [fieldData, setFieldData] = useState([]);
  const [pendingSync, setPendingSync] = useState([]);
  const [isMobileView, setIsMobileView] = useState(false);
  const [selectedForm, setSelectedForm] = useState('inspection');
  const [loading, setLoading] = useState(false);
  const [syncStatus, setSyncStatus] = useState('idle'); // idle, syncing, success, error
  
  // Mobile-optimized form states
  const [inspectionForm, setInspectionForm] = useState({
    location: '',
    coordinates: null,
    status: 'pending',
    notes: '',
    photos: [],
    timestamp: new Date().toISOString(),
    inspector: user?.username || 'Unknown',
    priority: 'medium'
  });

  const [deliveryForm, setDeliveryForm] = useState({
    item_name: '',
    quantity: '',
    condition: 'good',
    recipient: '',
    location: '',
    coordinates: null,
    delivery_notes: '',
    photos: [],
    timestamp: new Date().toISOString(),
    delivered_by: user?.username || 'Unknown'
  });

  const [incidentForm, setIncidentForm] = useState({
    incident_type: 'safety',
    severity: 'medium',
    description: '',
    location: '',
    coordinates: null,
    action_taken: '',
    photos: [],
    timestamp: new Date().toISOString(),
    reported_by: user?.username || 'Unknown'
  });

  // Detect mobile device and viewport
  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 768 || /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
      setIsMobileView(mobile);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Monitor online/offline status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      toast.success('Back online! Syncing data...');
      syncPendingData();
    };
    
    const handleOffline = () => {
      setIsOnline(false);
      toast.warning('You are offline. Data will be saved locally.');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Get current location
  const getCurrentLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setLocationError('Geolocation is not supported by this browser');
      return;
    }

    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const coords = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: new Date().toISOString()
        };
        setLocation(coords);
        setLocationError(null);
        setLoading(false);
        
        // Update current form with coordinates
        switch(selectedForm) {
          case 'inspection':
            setInspectionForm(prev => ({...prev, coordinates: coords}));
            break;
          case 'delivery':
            setDeliveryForm(prev => ({...prev, coordinates: coords}));
            break;
          case 'incident':
            setIncidentForm(prev => ({...prev, coordinates: coords}));
            break;
        }
        
        toast.success('Location acquired successfully');
      },
      (error) => {
        setLocationError(error.message);
        setLoading(false);
        toast.error(`Location error: ${error.message}`);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 300000 }
    );
  }, [selectedForm]);

  // Auto-get location on component mount
  useEffect(() => {
    getCurrentLocation();
  }, [getCurrentLocation]);

  // Load field data from localStorage on offline mode
  useEffect(() => {
    const stored = localStorage.getItem(`fieldData_${projectId}`);
    const pending = localStorage.getItem(`pendingSync_${projectId}`);
    
    if (stored) {
      setFieldData(JSON.parse(stored));
    }
    if (pending) {
      setPendingSync(JSON.parse(pending));
    }
  }, [projectId]);

  // Save data locally
  const saveLocally = (data, type) => {
    const timestamp = new Date().toISOString();
    const fieldEntry = {
      id: `${type}_${timestamp}`,
      type,
      data,
      timestamp,
      synced: false,
      user: user?.username
    };
    
    const updatedFieldData = [...fieldData, fieldEntry];
    const updatedPending = [...pendingSync, fieldEntry];
    
    setFieldData(updatedFieldData);
    setPendingSync(updatedPending);
    
    localStorage.setItem(`fieldData_${projectId}`, JSON.stringify(updatedFieldData));
    localStorage.setItem(`pendingSync_${projectId}`, JSON.stringify(updatedPending));
    
    toast.success('Data saved locally');
    return fieldEntry;
  };

  // Sync pending data when online
  const syncPendingData = async () => {
    if (!isOnline || pendingSync.length === 0) return;
    
    setSyncStatus('syncing');
    let syncedCount = 0;
    
    try {
      for (const entry of pendingSync) {
        try {
          await axios.post(`${API}/projects/${projectId}/field-data`, {
            type: entry.type,
            data: entry.data,
            timestamp: entry.timestamp,
            user: entry.user
          });
          
          syncedCount++;
          
          // Update local storage to mark as synced
          const updatedFieldData = fieldData.map(item => 
            item.id === entry.id ? {...item, synced: true} : item
          );
          setFieldData(updatedFieldData);
          localStorage.setItem(`fieldData_${projectId}`, JSON.stringify(updatedFieldData));
          
        } catch (error) {
          console.error(`Failed to sync entry ${entry.id}:`, error);
        }
      }
      
      // Remove synced items from pending
      const remainingPending = pendingSync.filter(entry => {
        const synced = fieldData.find(item => item.id === entry.id && item.synced);
        return !synced;
      });
      
      setPendingSync(remainingPending);
      localStorage.setItem(`pendingSync_${projectId}`, JSON.stringify(remainingPending));
      
      setSyncStatus('success');
      toast.success(`Synced ${syncedCount} field entries`);
      
    } catch (error) {
      setSyncStatus('error');
      toast.error('Sync failed. Will retry when online.');
    }
  };

  // Handle form submissions
  const handleSubmitInspection = (e) => {
    e.preventDefault();
    const entry = saveLocally(inspectionForm, 'inspection');
    
    if (isOnline) {
      syncPendingData();
    }
    
    // Reset form
    setInspectionForm({
      location: '',
      coordinates: location,
      status: 'pending', 
      notes: '',
      photos: [],
      timestamp: new Date().toISOString(),
      inspector: user?.username || 'Unknown',
      priority: 'medium'
    });
  };

  const handleSubmitDelivery = (e) => {
    e.preventDefault();
    const entry = saveLocally(deliveryForm, 'delivery');
    
    if (isOnline) {
      syncPendingData();
    }
    
    // Reset form
    setDeliveryForm({
      item_name: '',
      quantity: '',
      condition: 'good',
      recipient: '',
      location: '',
      coordinates: location,
      delivery_notes: '',
      photos: [],
      timestamp: new Date().toISOString(),
      delivered_by: user?.username || 'Unknown'
    });
  };

  const handleSubmitIncident = (e) => {
    e.preventDefault();
    const entry = saveLocally(incidentForm, 'incident');
    
    if (isOnline) {
      syncPendingData();
    }
    
    // Reset form
    setIncidentForm({
      incident_type: 'safety',
      severity: 'medium',
      description: '',
      location: '',
      coordinates: location,
      action_taken: '',
      photos: [],
      timestamp: new Date().toISOString(),
      reported_by: user?.username || 'Unknown'
    });
  };

  // Simulated photo capture (in real app would use camera API)
  const handlePhotoCapture = (formType) => {
    const mockPhoto = {
      id: Date.now(),
      url: `data:image/svg+xml;base64,${btoa('<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><rect width="100" height="100" fill="#f0f0f0"/><text x="50" y="50" text-anchor="middle" dy=".3em">📷</text></svg>')}`,
      timestamp: new Date().toISOString()
    };
    
    switch(formType) {
      case 'inspection':
        setInspectionForm(prev => ({...prev, photos: [...prev.photos, mockPhoto]}));
        break;
      case 'delivery':
        setDeliveryForm(prev => ({...prev, photos: [...prev.photos, mockPhoto]}));
        break;
      case 'incident':
        setIncidentForm(prev => ({...prev, photos: [...prev.photos, mockPhoto]}));
        break;
    }
    
    toast.success('Photo captured');
  };

  const formatCoordinates = (coords) => {
    if (!coords) return 'Location not available';
    return `${coords.latitude.toFixed(6)}, ${coords.longitude.toFixed(6)}`;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'in_progress': return 'bg-blue-100 text-blue-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const MobileHeader = () => (
    <div className={`bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 ${isMobileView ? 'rounded-t-lg' : 'rounded-lg mb-4'}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Smartphone className="h-6 w-6" />
          <div>
            <h2 className="text-lg font-semibold">Mobile Field App</h2>
            <p className="text-sm opacity-90">Field data collection</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          {isOnline ? (
            <div className="flex items-center space-x-1 text-green-300">
              <Wifi className="h-4 w-4" />
              <span className="text-xs">Online</span>
            </div>
          ) : (
            <div className="flex items-center space-x-1 text-red-300">
              <WifiOff className="h-4 w-4" />
              <span className="text-xs">Offline</span>
            </div>
          )}
          {pendingSync.length > 0 && (
            <Badge className="bg-yellow-500 text-white">
              {pendingSync.length} pending
            </Badge>
          )}
        </div>
      </div>
    </div>
  );

  const LocationStatus = () => (
    <Card className="mb-4">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <MapPin className={`h-5 w-5 ${location ? 'text-green-600' : 'text-gray-400'}`} />
            <div>
              <p className="font-medium">GPS Location</p>
              <p className="text-sm text-gray-600">
                {location ? formatCoordinates(location) : 'Location not available'}
              </p>
              {location && (
                <p className="text-xs text-gray-500">
                  Accuracy: {location.accuracy?.toFixed(0)}m
                </p>
              )}
            </div>
          </div>
          <Button
            size="sm"
            onClick={getCurrentLocation}
            disabled={loading}
            data-testid="get-location-button"
          >
            {loading ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <Navigation className="h-4 w-4" />
            )}
          </Button>
        </div>
        {locationError && (
          <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-sm text-red-700">
            {locationError}
          </div>
        )}
      </CardContent>
    </Card>
  );

  const InspectionForm = () => (
    <form onSubmit={handleSubmitInspection} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="inspection-location">Location/Asset</Label>
        <Input
          id="inspection-location"
          value={inspectionForm.location}
          onChange={(e) => setInspectionForm({...inspectionForm, location: e.target.value})}
          placeholder="e.g., Building A - Room 101"
          required
          data-testid="inspection-location-input"
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="inspection-status">Status</Label>
          <Select 
            value={inspectionForm.status} 
            onValueChange={(value) => setInspectionForm({...inspectionForm, status: value})}
          >
            <SelectTrigger data-testid="inspection-status-select">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="failed">Failed</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="inspection-priority">Priority</Label>
          <Select 
            value={inspectionForm.priority} 
            onValueChange={(value) => setInspectionForm({...inspectionForm, priority: value})}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="inspection-notes">Inspection Notes</Label>
        <Textarea
          id="inspection-notes"
          value={inspectionForm.notes}
          onChange={(e) => setInspectionForm({...inspectionForm, notes: e.target.value})}
          placeholder="Detailed inspection findings..."
          rows={4}
          required
          data-testid="inspection-notes-input"
        />
      </div>
      
      <div className="space-y-2">
        <Label>Photos ({inspectionForm.photos.length})</Label>
        <div className="flex items-center space-x-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => handlePhotoCapture('inspection')}
            data-testid="capture-inspection-photo"
          >
            <Camera className="h-4 w-4 mr-2" />
            Capture Photo
          </Button>
          {inspectionForm.photos.length > 0 && (
            <Badge className="bg-blue-100 text-blue-800">
              {inspectionForm.photos.length} photo(s)
            </Badge>
          )}
        </div>
      </div>
      
      <Button 
        type="submit" 
        className="w-full" 
        data-testid="submit-inspection"
      >
        <Save className="h-4 w-4 mr-2" />
        Submit Inspection
      </Button>
    </form>
  );

  const DeliveryForm = () => (
    <form onSubmit={handleSubmitDelivery} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="delivery-item">Item Name</Label>
          <Input
            id="delivery-item"
            value={deliveryForm.item_name}
            onChange={(e) => setDeliveryForm({...deliveryForm, item_name: e.target.value})}
            placeholder="e.g., Laptops"
            required
            data-testid="delivery-item-input"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="delivery-quantity">Quantity</Label>
          <Input
            id="delivery-quantity"
            type="number"
            value={deliveryForm.quantity}
            onChange={(e) => setDeliveryForm({...deliveryForm, quantity: e.target.value})}
            placeholder="0"
            required
            data-testid="delivery-quantity-input"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="delivery-condition">Condition</Label>
          <Select 
            value={deliveryForm.condition} 
            onValueChange={(value) => setDeliveryForm({...deliveryForm, condition: value})}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="excellent">Excellent</SelectItem>
              <SelectItem value="good">Good</SelectItem>
              <SelectItem value="fair">Fair</SelectItem>
              <SelectItem value="poor">Poor</SelectItem>
              <SelectItem value="damaged">Damaged</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="delivery-recipient">Recipient</Label>
          <Input
            id="delivery-recipient"
            value={deliveryForm.recipient}
            onChange={(e) => setDeliveryForm({...deliveryForm, recipient: e.target.value})}
            placeholder="Recipient name"
            required
            data-testid="delivery-recipient-input"
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="delivery-location">Delivery Location</Label>
        <Input
          id="delivery-location"
          value={deliveryForm.location}
          onChange={(e) => setDeliveryForm({...deliveryForm, location: e.target.value})}
          placeholder="Delivery address"
          required
          data-testid="delivery-location-input"
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="delivery-notes">Delivery Notes</Label>
        <Textarea
          id="delivery-notes"
          value={deliveryForm.delivery_notes}
          onChange={(e) => setDeliveryForm({...deliveryForm, delivery_notes: e.target.value})}
          placeholder="Additional delivery information..."
          rows={3}
          data-testid="delivery-notes-input"
        />
      </div>
      
      <div className="space-y-2">
        <Label>Photos ({deliveryForm.photos.length})</Label>
        <div className="flex items-center space-x-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => handlePhotoCapture('delivery')}
            data-testid="capture-delivery-photo"
          >
            <Camera className="h-4 w-4 mr-2" />
            Capture Photo
          </Button>
          {deliveryForm.photos.length > 0 && (
            <Badge className="bg-green-100 text-green-800">
              {deliveryForm.photos.length} photo(s)
            </Badge>
          )}
        </div>
      </div>
      
      <Button 
        type="submit" 
        className="w-full" 
        data-testid="submit-delivery"
      >
        <Send className="h-4 w-4 mr-2" />
        Submit Delivery
      </Button>
    </form>
  );

  const IncidentForm = () => (
    <form onSubmit={handleSubmitIncident} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="incident-type">Incident Type</Label>
          <Select 
            value={incidentForm.incident_type} 
            onValueChange={(value) => setIncidentForm({...incidentForm, incident_type: value})}
          >
            <SelectTrigger data-testid="incident-type-select">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="safety">Safety</SelectItem>
              <SelectItem value="security">Security</SelectItem>
              <SelectItem value="equipment">Equipment</SelectItem>
              <SelectItem value="environmental">Environmental</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="incident-severity">Severity</Label>
          <Select 
            value={incidentForm.severity} 
            onValueChange={(value) => setIncidentForm({...incidentForm, severity: value})}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="incident-location">Location</Label>
        <Input
          id="incident-location"
          value={incidentForm.location}
          onChange={(e) => setIncidentForm({...incidentForm, location: e.target.value})}
          placeholder="Incident location"
          required
          data-testid="incident-location-input"
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="incident-description">Description</Label>
        <Textarea
          id="incident-description"
          value={incidentForm.description}
          onChange={(e) => setIncidentForm({...incidentForm, description: e.target.value})}
          placeholder="Detailed incident description..."
          rows={4}
          required
          data-testid="incident-description-input"
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="incident-action">Action Taken</Label>
        <Textarea
          id="incident-action"
          value={incidentForm.action_taken}
          onChange={(e) => setIncidentForm({...incidentForm, action_taken: e.target.value})}
          placeholder="What actions were taken to address the incident..."
          rows={3}
          data-testid="incident-action-input"
        />
      </div>
      
      <div className="space-y-2">
        <Label>Photos ({incidentForm.photos.length})</Label>
        <div className="flex items-center space-x-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => handlePhotoCapture('incident')}
            data-testid="capture-incident-photo"
          >
            <Camera className="h-4 w-4 mr-2" />
            Capture Photo
          </Button>
          {incidentForm.photos.length > 0 && (
            <Badge className="bg-red-100 text-red-800">
              {incidentForm.photos.length} photo(s)
            </Badge>
          )}
        </div>
      </div>
      
      <Button 
        type="submit" 
        className="w-full bg-red-600 hover:bg-red-700" 
        data-testid="submit-incident"
      >
        <AlertTriangle className="h-4 w-4 mr-2" />
        Submit Incident Report
      </Button>
    </form>
  );

  return (
    <div className={`space-y-4 ${isMobileView ? 'max-w-md mx-auto' : 'max-w-4xl'}`}>
      <MobileHeader />
      
      <LocationStatus />
      
      {/* Sync Status */}
      {pendingSync.length > 0 && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <RotateCcw className={`h-5 w-5 ${syncStatus === 'syncing' ? 'animate-spin' : ''} text-yellow-600`} />
                <div>
                  <p className="font-medium text-yellow-800">
                    {pendingSync.length} entries waiting to sync
                  </p>
                  <p className="text-sm text-yellow-700">
                    {isOnline ? 'Will sync automatically' : 'Will sync when online'}
                  </p>
                </div>
              </div>
              {isOnline && (
                <Button
                  size="sm"
                  onClick={syncPendingData}
                  disabled={syncStatus === 'syncing'}
                  data-testid="manual-sync-button"
                >
                  {syncStatus === 'syncing' ? 'Syncing...' : 'Sync Now'}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Mobile Forms */}
      <Card>
        <CardContent className="p-4">
          <Tabs value={selectedForm} onValueChange={setSelectedForm} className="space-y-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="inspection" data-testid="inspection-tab">
                <CheckCircle2 className="h-4 w-4 mr-2" />
                Inspection
              </TabsTrigger>
              <TabsTrigger value="delivery" data-testid="delivery-tab">
                <Send className="h-4 w-4 mr-2" />
                Delivery
              </TabsTrigger>
              <TabsTrigger value="incident" data-testid="incident-tab">
                <AlertTriangle className="h-4 w-4 mr-2" />
                Incident
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="inspection">
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <CheckCircle2 className="h-5 w-5 text-blue-600" />
                  <h3 className="text-lg font-semibold">Site Inspection</h3>
                </div>
                <InspectionForm />
              </div>
            </TabsContent>
            
            <TabsContent value="delivery">
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Send className="h-5 w-5 text-green-600" />
                  <h3 className="text-lg font-semibold">Delivery Confirmation</h3>
                </div>
                <DeliveryForm />
              </div>
            </TabsContent>
            
            <TabsContent value="incident">
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                  <h3 className="text-lg font-semibold">Incident Report</h3>
                </div>
                <IncidentForm />
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      {/* Field Data History */}
      {fieldData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="h-5 w-5 text-purple-600" />
              <span>Field Data History</span>
              <Badge className="bg-purple-100 text-purple-800">
                {fieldData.length} entries
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-60 overflow-y-auto">
              {fieldData.slice(-5).reverse().map((entry) => (
                <div key={entry.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${entry.synced ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                    <div>
                      <p className="font-medium capitalize">{entry.type}</p>
                      <p className="text-sm text-gray-600">
                        {new Date(entry.timestamp).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className={entry.synced ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}>
                      {entry.synced ? 'Synced' : 'Pending'}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Mobile App Features */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Zap className="h-5 w-5 text-orange-600" />
            <span>Mobile Features</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="flex items-center space-x-2">
              <WifiOff className="h-4 w-4 text-green-600" />
              <span>Offline Support</span>
            </div>
            <div className="flex items-center space-x-2">
              <MapPin className="h-4 w-4 text-blue-600" />
              <span>GPS Tracking</span>
            </div>
            <div className="flex items-center space-x-2">
              <Camera className="h-4 w-4 text-purple-600" />
              <span>Photo Capture</span>
            </div>
            <div className="flex items-center space-x-2">
              <RotateCcw className="h-4 w-4 text-orange-600" />
              <span>Auto Sync</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MobileFieldApp;