import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  Calendar, 
  Plus, 
  Clock, 
  Flag, 
  CheckCircle2, 
  AlertTriangle, 
  Users, 
  Edit3,
  Trash2,
  BarChart3,
  Target,
  ArrowRight,
  ArrowDown,
  ChevronRight,
  ChevronDown,
  Activity
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const GanttChart = ({ projectId, user }) => {
  const [tasks, setTasks] = useState([]);
  const [milestones, setMilestones] = useState([]);
  const [dependencies, setDependencies] = useState([]);
  const [timeline, setTimeline] = useState({});
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState('months'); // weeks, months, quarters
  const [selectedTask, setSelectedTask] = useState(null);
  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [showMilestoneDialog, setShowMilestoneDialog] = useState(false);
  const [expandedTasks, setExpandedTasks] = useState(new Set());
  
  const [taskFormData, setTaskFormData] = useState({
    name: '',
    description: '',
    start_date: '',
    end_date: '',
    assignee: '',
    priority: 'medium',
    progress: 0,
    parent_task_id: null,
    dependencies: []
  });

  const [milestoneFormData, setMilestoneFormData] = useState({
    name: '',
    description: '',
    target_date: '',
    status: 'pending'
  });

  useEffect(() => {
    fetchTimelineData();
  }, [projectId]);

  const fetchTimelineData = async () => {
    try {
      const [tasksRes, milestonesRes, dependenciesRes] = await Promise.all([
        axios.get(`${API}/projects/${projectId}/tasks`),
        axios.get(`${API}/projects/${projectId}/milestones`),
        axios.get(`${API}/projects/${projectId}/task-dependencies`)
      ]);
      
      setTasks(tasksRes.data);
      setMilestones(milestonesRes.data);
      setDependencies(dependenciesRes.data);
      
      // Calculate timeline bounds
      const allDates = [
        ...tasksRes.data.map(t => new Date(t.start_date)),
        ...tasksRes.data.map(t => new Date(t.end_date)),
        ...milestonesRes.data.map(m => new Date(m.target_date))
      ];
      
      if (allDates.length > 0) {
        const minDate = new Date(Math.min(...allDates));
        const maxDate = new Date(Math.max(...allDates));
        setTimeline({ start: minDate, end: maxDate });
      }
    } catch (error) {
      toast.error('Failed to load timeline data');
      console.error('Timeline fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTask = async (e) => {
    e.preventDefault();
    try {
      const taskData = {
        ...taskFormData,
        start_date: new Date(taskFormData.start_date).toISOString(),
        end_date: new Date(taskFormData.end_date).toISOString(),
        progress: parseInt(taskFormData.progress)
      };

      await axios.post(`${API}/projects/${projectId}/tasks`, taskData);
      toast.success('Task created successfully!');
      setShowTaskDialog(false);
      setTaskFormData({
        name: '',
        description: '',
        start_date: '',
        end_date: '',
        assignee: '',
        priority: 'medium',
        progress: 0,
        parent_task_id: null,
        dependencies: []
      });
      fetchTimelineData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to create task');
    }
  };

  const handleCreateMilestone = async (e) => {
    e.preventDefault();
    try {
      const milestoneData = {
        ...milestoneFormData,
        target_date: new Date(milestoneFormData.target_date).toISOString()
      };

      await axios.post(`${API}/projects/${projectId}/milestones`, milestoneData);
      toast.success('Milestone created successfully!');
      setShowMilestoneDialog(false);
      setMilestoneFormData({
        name: '',
        description: '',
        target_date: '',
        status: 'pending'
      });
      fetchTimelineData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to create milestone');
    }
  };

  const updateTaskProgress = async (taskId, progress) => {
    try {
      await axios.patch(`${API}/projects/${projectId}/tasks/${taskId}`, { progress });
      setTasks(tasks.map(task => 
        task.id === taskId ? { ...task, progress } : task
      ));
      toast.success('Task progress updated');
    } catch (error) {
      toast.error('Failed to update task progress');
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800';
      case 'in_progress': return 'bg-blue-100 text-blue-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'overdue': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const calculateTaskWidth = (startDate, endDate) => {
    if (!timeline.start || !timeline.end) return 0;
    
    const totalDuration = timeline.end.getTime() - timeline.start.getTime();
    const taskStart = new Date(startDate).getTime();
    const taskEnd = new Date(endDate).getTime();
    const taskDuration = taskEnd - taskStart;
    
    return Math.max((taskDuration / totalDuration) * 100, 2); // Minimum 2% width
  };

  const calculateTaskOffset = (startDate) => {
    if (!timeline.start || !timeline.end) return 0;
    
    const totalDuration = timeline.end.getTime() - timeline.start.getTime();
    const taskStart = new Date(startDate).getTime();
    const offset = taskStart - timeline.start.getTime();
    
    return (offset / totalDuration) * 100;
  };

  const generateTimelineHeader = () => {
    if (!timeline.start || !timeline.end) return [];
    
    const periods = [];
    const current = new Date(timeline.start);
    current.setDate(1); // Start from first day of month
    
    while (current <= timeline.end) {
      periods.push(new Date(current));
      current.setMonth(current.getMonth() + 1);
    }
    
    return periods;
  };

  const toggleTaskExpansion = (taskId) => {
    const newExpanded = new Set(expandedTasks);
    if (newExpanded.has(taskId)) {
      newExpanded.delete(taskId);
    } else {
      newExpanded.add(taskId);
    }
    setExpandedTasks(newExpanded);
  };

  const getTaskHierarchy = () => {
    const parentTasks = tasks.filter(task => !task.parent_task_id);
    const childTasks = tasks.filter(task => task.parent_task_id);
    
    return parentTasks.map(parent => ({
      ...parent,
      children: childTasks.filter(child => child.parent_task_id === parent.id)
    }));
  };

  const TaskRow = ({ task, level = 0, isChild = false }) => {
    const hasChildren = task.children && task.children.length > 0;
    const isExpanded = expandedTasks.has(task.id);
    const taskWidth = calculateTaskWidth(task.start_date, task.end_date);
    const taskOffset = calculateTaskOffset(task.start_date);
    
    return (
      <>
        <div className={`border-b border-gray-200 ${isChild ? 'bg-gray-50' : 'bg-white'}`}>
          <div className="grid grid-cols-12 gap-4 p-3 items-center">
            {/* Task Name Column */}
            <div className="col-span-4" style={{ paddingLeft: `${level * 20}px` }}>
              <div className="flex items-center space-x-2">
                {hasChildren && (
                  <button 
                    onClick={() => toggleTaskExpansion(task.id)}
                    className="p-1 hover:bg-gray-100 rounded"
                  >
                    {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                  </button>
                )}
                <div className={`w-3 h-3 rounded-full ${getPriorityColor(task.priority)}`}></div>
                <div>
                  <p className="font-medium text-sm">{task.name}</p>
                  <p className="text-xs text-gray-500">{task.assignee}</p>
                </div>
              </div>
            </div>
            
            {/* Dates Column */}
            <div className="col-span-2 text-xs text-gray-600">
              <div>{new Date(task.start_date).toLocaleDateString()}</div>
              <div>{new Date(task.end_date).toLocaleDateString()}</div>
            </div>
            
            {/* Status Column */}
            <div className="col-span-2">
              <Badge className={getStatusColor(task.status)}>
                {task.status.replace('_', ' ')}
              </Badge>
            </div>
            
            {/* Progress Column */}
            <div className="col-span-2">
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span>Progress</span>
                  <span>{task.progress}%</span>
                </div>
                <Progress value={task.progress} className="h-2" />
              </div>
            </div>
            
            {/* Timeline Visualization Column */}
            <div className="col-span-2 relative h-8">
              <div 
                className={`absolute top-1 h-6 rounded ${task.progress >= 100 ? 'bg-green-500' : 'bg-blue-500'} opacity-80`}
                style={{
                  left: `${taskOffset}%`,
                  width: `${taskWidth}%`
                }}
              >
                <div 
                  className="h-full bg-green-600 rounded"
                  style={{ width: `${task.progress}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Child Tasks */}
        {hasChildren && isExpanded && task.children.map(child => (
          <TaskRow 
            key={child.id} 
            task={child} 
            level={level + 1} 
            isChild={true}
          />
        ))}
      </>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const timelineHeaders = generateTimelineHeader();
  const taskHierarchy = getTaskHierarchy();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold flex items-center space-x-2">
            <BarChart3 className="h-5 w-5 text-blue-600" />
            <span>Gantt Chart & Timeline Management</span>
          </h3>
          <p className="text-sm text-gray-600">Project timeline, task dependencies, and milestone tracking</p>
        </div>
        <div className="flex items-center space-x-2">
          <Select value={viewMode} onValueChange={setViewMode}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="weeks">Weeks</SelectItem>
              <SelectItem value="months">Months</SelectItem>
              <SelectItem value="quarters">Quarters</SelectItem>
            </SelectContent>
          </Select>
          <Dialog open={showMilestoneDialog} onOpenChange={setShowMilestoneDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" data-testid="add-milestone-button">
                <Flag className="h-4 w-4 mr-2" />
                Add Milestone
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Milestone</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreateMilestone} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="milestone-name">Milestone Name</Label>
                  <Input
                    id="milestone-name"
                    value={milestoneFormData.name}
                    onChange={(e) => setMilestoneFormData({...milestoneFormData, name: e.target.value})}
                    placeholder="e.g., Project Kickoff"
                    required
                    data-testid="milestone-name-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="milestone-description">Description</Label>
                  <Textarea
                    id="milestone-description"
                    value={milestoneFormData.description}
                    onChange={(e) => setMilestoneFormData({...milestoneFormData, description: e.target.value})}
                    placeholder="Describe the milestone..."
                    rows={3}
                    data-testid="milestone-description-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="milestone-date">Target Date</Label>
                  <Input
                    id="milestone-date"
                    type="date"
                    value={milestoneFormData.target_date}
                    onChange={(e) => setMilestoneFormData({...milestoneFormData, target_date: e.target.value})}
                    required
                    data-testid="milestone-date-input"
                  />
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setShowMilestoneDialog(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" data-testid="create-milestone-submit">Create Milestone</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
          <Dialog open={showTaskDialog} onOpenChange={setShowTaskDialog}>
            <DialogTrigger asChild>
              <Button data-testid="add-task-button">
                <Plus className="h-4 w-4 mr-2" />
                Add Task
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Task</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleCreateTask} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="task-name">Task Name</Label>
                    <Input
                      id="task-name"
                      value={taskFormData.name}
                      onChange={(e) => setTaskFormData({...taskFormData, name: e.target.value})}
                      placeholder="e.g., Requirements Gathering"
                      required
                      data-testid="task-name-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="task-assignee">Assignee</Label>
                    <Input
                      id="task-assignee"
                      value={taskFormData.assignee}
                      onChange={(e) => setTaskFormData({...taskFormData, assignee: e.target.value})}
                      placeholder="e.g., John Doe"
                      data-testid="task-assignee-input"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="task-description">Description</Label>
                  <Textarea
                    id="task-description"
                    value={taskFormData.description}
                    onChange={(e) => setTaskFormData({...taskFormData, description: e.target.value})}
                    placeholder="Describe the task..."
                    rows={3}
                    data-testid="task-description-input"
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="start-date">Start Date</Label>
                    <Input
                      id="start-date"
                      type="date"
                      value={taskFormData.start_date}
                      onChange={(e) => setTaskFormData({...taskFormData, start_date: e.target.value})}
                      required
                      data-testid="task-start-date-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="end-date">End Date</Label>
                    <Input
                      id="end-date"
                      type="date"
                      value={taskFormData.end_date}
                      onChange={(e) => setTaskFormData({...taskFormData, end_date: e.target.value})}
                      required
                      data-testid="task-end-date-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="task-priority">Priority</Label>
                    <Select value={taskFormData.priority} onValueChange={(value) => setTaskFormData({...taskFormData, priority: value})}>
                      <SelectTrigger data-testid="task-priority-select">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="task-progress">Progress (%)</Label>
                  <Input
                    id="task-progress"
                    type="number"
                    min="0"
                    max="100"
                    value={taskFormData.progress}
                    onChange={(e) => setTaskFormData({...taskFormData, progress: e.target.value})}
                    data-testid="task-progress-input"
                  />
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <Button type="button" variant="outline" onClick={() => setShowTaskDialog(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" data-testid="create-task-submit">Create Task</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Timeline Header */}
      {timelineHeaders.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="grid grid-cols-12 gap-4 border-b pb-2 mb-4">
              <div className="col-span-4 font-medium">Task</div>
              <div className="col-span-2 font-medium">Dates</div>
              <div className="col-span-2 font-medium">Status</div>
              <div className="col-span-2 font-medium">Progress</div>
              <div className="col-span-2 font-medium">Timeline</div>
            </div>
            
            {/* Time Scale */}
            <div className="grid grid-cols-12 gap-4 mb-4">
              <div className="col-span-8"></div>
              <div className="col-span-4">
                <div className="flex justify-between text-xs text-gray-500 border-b pb-1">
                  {timelineHeaders.map((date, index) => (
                    <span key={index}>
                      {date.toLocaleDateString('en-US', { month: 'short', year: '2-digit' })}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tasks List */}
      <Card>
        <CardContent className="p-0">
          {taskHierarchy.length > 0 ? (
            taskHierarchy.map(task => (
              <TaskRow key={task.id} task={task} />
            ))
          ) : (
            <div className="text-center py-8 text-gray-500">
              <BarChart3 className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>No tasks defined yet</p>
              <p className="text-sm">Add tasks to start building your project timeline</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Milestones */}
      {milestones.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Flag className="h-5 w-5 text-purple-600" />
              <span>Project Milestones</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {milestones.map((milestone) => (
                <Card key={milestone.id} className="border-l-4 border-purple-500">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium">{milestone.name}</h4>
                      <Badge className={getStatusColor(milestone.status)}>
                        {milestone.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{milestone.description}</p>
                    <div className="flex items-center space-x-2 text-sm text-gray-500">
                      <Calendar className="h-4 w-4" />
                      <span>{new Date(milestone.target_date).toLocaleDateString()}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Critical Path Analysis */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="h-5 w-5 text-red-600" />
            <span>Critical Path Analysis</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-sm text-gray-600">
            <p className="mb-2">
              Critical path analysis helps identify the sequence of tasks that directly affect the project completion date.
            </p>
            {tasks.length > 0 ? (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                <p className="font-medium text-yellow-800">
                  📊 Critical Path: {tasks.filter(t => t.priority === 'critical' || t.priority === 'high').length} high-priority tasks identified
                </p>
                <p className="text-yellow-700 text-xs mt-1">
                  Focus on completing critical and high-priority tasks to maintain project timeline
                </p>
              </div>
            ) : (
              <p className="text-gray-500">Add tasks to generate critical path analysis</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GanttChart;