import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import AdministratorDashboard from './AdministratorDashboard';
import InvestorDashboard from './InvestorDashboard';
import SocialActorDashboard from './SocialActorDashboard';
import NotificationBell from './NotificationBell';
import { 
  Users, 
  TrendingUp, 
  DollarSign, 
  Activity, 
  BookOpen, 
  FileText,
  Heart, 
  Leaf, 
  BarChart3, 
  Clock,
  Target,
  AlertCircle,
  CheckCircle2,
  LogOut,
  Menu,
  X
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const Dashboard = ({ user, onLogout }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Route to role-specific dashboard
  const renderDashboard = () => {
    switch (user.role) {
      case 'administrator':
        return <AdministratorDashboard />;
      case 'investor':
        return <InvestorDashboard />;
      case 'social_actor':
        return <SocialActorDashboard />;
      default:
        return <AdministratorDashboard />;
    }
  };

  const getRoleDisplay = (role) => {
    switch (role) {
      case 'administrator': return 'Administrator';
      case 'investor': return 'Investor';
      case 'social_actor': return 'Social Actor';
      default: return 'User';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`fixed left-0 top-0 h-full w-64 bg-white shadow-xl transform transition-transform duration-300 ease-in-out z-50 lg:translate-x-0 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-6 border-b">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-800">POTC Platform</h2>
            <button 
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <p className="text-sm text-gray-600 mt-1">Physical Object Tracking</p>
        </div>

        <nav className="mt-6 px-4">
          <div className="space-y-2">
            <Link 
              to="/dashboard" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg bg-blue-50 text-blue-700 font-medium"
              data-testid="dashboard-nav-link"
            >
              <BarChart3 className="h-5 w-5" />
              <span>Dashboard</span>
            </Link>
            <Link 
              to="/projects" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-colors"
              data-testid="projects-nav-link"
            >
              <Activity className="h-5 w-5" />
              <span>Projects</span>
            </Link>
            <Link 
              to="/templates" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-colors"
              data-testid="templates-nav-link"
            >
              <BookOpen className="h-5 w-5" />
              <span>Electronic Library of Financial Instruments & Supporting Material</span>
            </Link>
            <Link 
              to="/guides" 
              className="flex items-center space-x-3 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-50 hover:text-gray-900 transition-colors"
              data-testid="guides-nav-link"
            >
              <FileText className="h-5 w-5" />
              <span>User Guides & Documentation</span>
            </Link>
          </div>
        </nav>

        <div className="absolute bottom-6 left-4 right-4">
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Users className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <p className="font-medium text-gray-900">{user.username}</p>
                <p className="text-sm text-gray-500">{getRoleDisplay(user.role)}</p>
                {user.organization_name && (
                  <p className="text-xs text-gray-400">{user.organization_name}</p>
                )}
              </div>
            </div>
            <Button 
              onClick={onLogout} 
              variant="outline" 
              size="sm" 
              className="w-full"
              data-testid="logout-button"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="lg:ml-64">
        <header className="bg-white shadow-sm border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 hover:bg-gray-100 rounded-lg"
                data-testid="sidebar-toggle"
              >
                <Menu className="h-5 w-5" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
                <p className="text-sm text-gray-600">Welcome back, {user.username}!</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <NotificationBell user={user} />
            </div>
          </div>
        </header>

        <main className="p-6">
          {renderDashboard()}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;