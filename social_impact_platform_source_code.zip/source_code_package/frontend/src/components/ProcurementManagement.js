import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Building2, 
  FileText, 
  Receipt, 
  TrendingUp, 
  Plus,
  Eye,
  Edit,
  DollarSign,
  Calendar,
  Phone,
  Mail,
  MapPin,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Star
} from 'lucide-react';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const ProcurementManagement = ({ projectId, user }) => {
  const [activeTab, setActiveTab] = useState('vendors');
  const [loading, setLoading] = useState(false);
  
  // Data states
  const [vendors, setVendors] = useState([]);
  const [purchaseOrders, setPurchaseOrders] = useState([]);
  const [contracts, setContracts] = useState([]);
  const [analytics, setAnalytics] = useState({});
  
  useEffect(() => {
    fetchProcurementData();
  }, [projectId]);

  const fetchProcurementData = async () => {
    setLoading(true);
    try {
      const [vendorsRes, ordersRes, contractsRes, analyticsRes] = await Promise.all([
        axios.get(`${API}/projects/${projectId}/vendors`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/purchase-orders`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/contracts`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/procurement-analytics`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        })
      ]);
      
      setVendors(vendorsRes.data);
      setPurchaseOrders(ordersRes.data);
      setContracts(contractsRes.data);
      setAnalytics(analyticsRes.data);
    } catch (error) {
      console.error('Failed to fetch procurement data:', error);
      toast.error('Failed to load procurement data');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount || 0);
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString();
  };

  const getStatusColor = (status) => {
    const colors = {
      'active': 'bg-green-100 text-green-800',
      'inactive': 'bg-gray-100 text-gray-800',
      'approved': 'bg-green-100 text-green-800',
      'pending': 'bg-yellow-100 text-yellow-800',
      'draft': 'bg-blue-100 text-blue-800',
      'rejected': 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  const getStatusIcon = (status) => {
    const icons = {
      'active': <CheckCircle2 className="h-4 w-4" />,
      'approved': <CheckCircle2 className="h-4 w-4" />,
      'pending': <Clock className="h-4 w-4" />,
      'draft': <Edit className="h-4 w-4" />,
      'rejected': <AlertTriangle className="h-4 w-4" />
    };
    return icons[status];
  };

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ));
  };

  // Analytics Overview Tab
  const AnalyticsTab = () => (
    <div className="space-y-6">
      {/* Key Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Purchase Orders</p>
                <p className="text-2xl font-bold">{analytics.total_purchase_orders || 0}</p>
                <p className="text-xs text-gray-500">
                  {analytics.approved_orders || 0} approved, {analytics.pending_orders || 0} pending
                </p>
              </div>
              <Receipt className="h-8 w-8 text-blue-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Spending</p>
                <p className="text-2xl font-bold">{formatCurrency(analytics.total_spending)}</p>
                <p className="text-xs text-gray-500">Approved orders only</p>
              </div>
              <DollarSign className="h-8 w-8 text-green-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Vendors</p>
                <p className="text-2xl font-bold">{analytics.vendor_count || 0}</p>
                <p className="text-xs text-gray-500">Registered suppliers</p>
              </div>
              <Building2 className="h-8 w-8 text-purple-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Approval Rate</p>
                <p className="text-2xl font-bold">{analytics.approval_rate || 0}%</p>
                <p className="text-xs text-gray-500">Order approval efficiency</p>
              </div>
              <TrendingUp className="h-8 w-8 text-yellow-600 opacity-20" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Procurement Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-3">
              <h4 className="font-medium text-green-700">Strengths</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <span>High vendor satisfaction</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <span>Efficient approval process</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium text-yellow-700">Opportunities</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm">
                  <Clock className="h-4 w-4 text-yellow-600" />
                  <span>Pending order processing</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <Clock className="h-4 w-4 text-yellow-600" />
                  <span>Contract renewal planning</span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="font-medium text-blue-700">Recommendations</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm">
                  <Building2 className="h-4 w-4 text-blue-600" />
                  <span>Diversify vendor base</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <FileText className="h-4 w-4 text-blue-600" />
                  <span>Automate reporting</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // Vendors Tab
  const VendorsTab = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Vendors</h3>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Add Vendor
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {vendors.map((vendor) => (
          <Card key={vendor.id} className="hover:shadow-md transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="text-base">{vendor.name}</span>
                <Badge className={getStatusColor(vendor.status)}>
                  {getStatusIcon(vendor.status)}
                  <span className="ml-1">{vendor.status}</span>
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm">
                  <Building2 className="h-4 w-4 text-gray-500" />
                  <span className="capitalize">{vendor.category?.replace('_', ' ')}</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <Mail className="h-4 w-4 text-gray-500" />
                  <span>{vendor.email}</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <Phone className="h-4 w-4 text-gray-500" />
                  <span>{vendor.phone}</span>
                </div>
                {vendor.rating && (
                  <div className="flex items-center space-x-2">
                    <div className="flex">{renderStars(vendor.rating)}</div>
                    <span className="text-sm text-gray-600">{vendor.rating}/5</span>
                  </div>
                )}
              </div>
              
              <div className="pt-2 border-t">
                <p className="text-xs text-gray-600 mb-2">Specialization:</p>
                <p className="text-sm">{vendor.specialization}</p>
              </div>
              
              <div className="flex space-x-2 pt-2">
                <Button size="sm" variant="outline" className="flex-1">
                  <Eye className="h-4 w-4 mr-1" />
                  View
                </Button>
                <Button size="sm" variant="outline" className="flex-1">
                  <Edit className="h-4 w-4 mr-1" />
                  Edit
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  // Purchase Orders Tab
  const PurchaseOrdersTab = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Purchase Orders</h3>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Create Order
        </Button>
      </div>
      
      <div className="space-y-4">
        {purchaseOrders.map((order) => (
          <Card key={order.id} className="hover:shadow-md transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div>
                  <span className="text-base">{order.order_number}</span>
                  <p className="text-sm text-gray-600 font-normal">{order.description}</p>
                </div>
                <Badge className={getStatusColor(order.status)}>
                  {getStatusIcon(order.status)}
                  <span className="ml-1 capitalize">{order.status}</span>
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <Building2 className="h-4 w-4 text-gray-500" />
                    <span>{order.vendor_name}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <DollarSign className="h-4 w-4 text-gray-500" />
                    <span className="font-medium">{formatCurrency(order.total_amount)}</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <span>Delivery: {formatDate(order.delivery_date)}</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-gray-600">Items: </span>
                    <span>{order.items?.length || 0}</span>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" className="flex-1">
                    <Eye className="h-4 w-4 mr-1" />
                    View
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1">
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                </div>
              </div>
              
              {order.notes && (
                <div className="pt-2 border-t">
                  <p className="text-xs text-gray-600 mb-1">Notes:</p>
                  <p className="text-sm text-gray-800">{order.notes}</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  // Contracts Tab
  const ContractsTab = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">Contracts</h3>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          New Contract
        </Button>
      </div>
      
      <div className="space-y-4">
        {contracts.map((contract) => (
          <Card key={contract.id} className="hover:shadow-md transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div>
                  <span className="text-base">{contract.title}</span>
                  <p className="text-sm text-gray-600 font-normal">{contract.contract_number}</p>
                </div>
                <Badge className={getStatusColor(contract.status)}>
                  {getStatusIcon(contract.status)}
                  <span className="ml-1 capitalize">{contract.status}</span>
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <Building2 className="h-4 w-4 text-gray-500" />
                    <span>{contract.vendor_name}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <DollarSign className="h-4 w-4 text-gray-500" />
                    <span className="font-medium">{formatCurrency(contract.contract_value)}</span>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex items-center space-x-2 text-sm">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <span>Start: {formatDate(contract.start_date)}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm">
                    <Calendar className="h-4 w-4 text-gray-500" />
                    <span>End: {formatDate(contract.end_date)}</span>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" className="flex-1">
                    <Eye className="h-4 w-4 mr-1" />
                    View
                  </Button>
                  <Button size="sm" variant="outline" className="flex-1">
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                </div>
              </div>
              
              {contract.description && (
                <div className="pt-2 border-t">
                  <p className="text-xs text-gray-600 mb-1">Description:</p>
                  <p className="text-sm text-gray-800">{contract.description}</p>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Building2 className="h-6 w-6 text-blue-600" />
              <span>Procurement Management</span>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={fetchProcurementData}
              data-testid="refresh-procurement-button"
            >
              <TrendingUp className="h-4 w-4 mr-1" />
              Refresh
            </Button>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="analytics" data-testid="analytics-tab">
            <TrendingUp className="h-4 w-4 mr-2" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="vendors" data-testid="vendors-tab">
            <Building2 className="h-4 w-4 mr-2" />
            Vendors
          </TabsTrigger>
          <TabsTrigger value="orders" data-testid="orders-tab">
            <Receipt className="h-4 w-4 mr-2" />
            Purchase Orders
          </TabsTrigger>
          <TabsTrigger value="contracts" data-testid="contracts-tab">
            <FileText className="h-4 w-4 mr-2" />
            Contracts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="analytics">
          <AnalyticsTab />
        </TabsContent>

        <TabsContent value="vendors">
          <VendorsTab />
        </TabsContent>

        <TabsContent value="orders">
          <PurchaseOrdersTab />
        </TabsContent>

        <TabsContent value="contracts">
          <ContractsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProcurementManagement;