import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { toast } from 'sonner';
import { 
  Bell, 
  BellOff,
  Check,
  CheckCheck,
  X,
  AlertTriangle,
  Info,
  Clock,
  Settings,
  Filter,
  Trash2,
  Eye,
  EyeOff,
  Smartphone,
  TrendingUp,
  DollarSign,
  Shield,
  FileCheck,
  Users,
  Megaphone,
  Activity
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const NotificationCenter = ({ user }) => {
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState('all'); // all, unread, read
  const [preferences, setPreferences] = useState({});
  const [showPreferences, setShowPreferences] = useState(false);

  // Load notifications on component mount
  useEffect(() => {
    fetchNotifications();
    fetchUnreadCount();
    fetchPreferences();
  }, []);

  const fetchNotifications = async (unreadOnly = false) => {
    try {
      setLoading(true);
      const response = await axios.get(`${API}/notifications`, {
        params: { unread_only: unreadOnly, limit: 50 },
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setNotifications(response.data);
    } catch (error) {
      console.error('Failed to fetch notifications:', error);
      toast.error('Failed to load notifications');
    } finally {
      setLoading(false);
    }
  };

  const fetchUnreadCount = async () => {
    try {
      const response = await axios.get(`${API}/notifications/unread-count`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setUnreadCount(response.data.unread_count);
    } catch (error) {
      console.error('Failed to fetch unread count:', error);
    }
  };

  const fetchPreferences = async () => {
    try {
      const response = await axios.get(`${API}/notification-preferences`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setPreferences(response.data);
    } catch (error) {
      console.error('Failed to fetch preferences:', error);
    }
  };

  const markAsRead = async (notificationId) => {
    try {
      await axios.patch(`${API}/notifications/${notificationId}/read`, {}, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      // Update local state
      setNotifications(notifications.map(n => 
        n.id === notificationId ? { ...n, read: true, read_at: new Date().toISOString() } : n
      ));
      setUnreadCount(prev => Math.max(0, prev - 1));
      toast.success('Marked as read');
    } catch (error) {
      console.error('Failed to mark as read:', error);
      toast.error('Failed to mark as read');
    }
  };

  const markAllAsRead = async () => {
    try {
      await axios.patch(`${API}/notifications/mark-all-read`, {}, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      // Update local state
      setNotifications(notifications.map(n => ({ ...n, read: true, read_at: new Date().toISOString() })));
      setUnreadCount(0);
      toast.success('All notifications marked as read');
    } catch (error) {
      console.error('Failed to mark all as read:', error);
      toast.error('Failed to mark all as read');
    }
  };

  const deleteNotification = async (notificationId) => {
    try {
      await axios.delete(`${API}/notifications/${notificationId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      // Update local state
      const deletedNotification = notifications.find(n => n.id === notificationId);
      setNotifications(notifications.filter(n => n.id !== notificationId));
      
      if (deletedNotification && !deletedNotification.read) {
        setUnreadCount(prev => Math.max(0, prev - 1));
      }
      
      toast.success('Notification deleted');
    } catch (error) {
      console.error('Failed to delete notification:', error);
      toast.error('Failed to delete notification');
    }
  };

  const updatePreferences = async (newPreferences) => {
    try {
      await axios.put(`${API}/notification-preferences`, newPreferences, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      setPreferences(newPreferences);
      toast.success('Preferences updated');
    } catch (error) {
      console.error('Failed to update preferences:', error);
      toast.error('Failed to update preferences');
    }
  };

  const getEventIcon = (eventType) => {
    switch (eventType) {
      case 'mobile_field_update': return <Smartphone className="h-4 w-4 text-blue-600" />;
      case 'project_milestone': return <Activity className="h-4 w-4 text-green-600" />;
      case 'financial_approval': return <DollarSign className="h-4 w-4 text-yellow-600" />;
      case 'compliance_deadline': return <Shield className="h-4 w-4 text-red-600" />;
      case 'quality_issue': return <AlertTriangle className="h-4 w-4 text-orange-600" />;
      case 'procurement_updates': return <FileCheck className="h-4 w-4 text-purple-600" />;
      case 'beneficiary_update': return <Users className="h-4 w-4 text-teal-600" />;
      case 'system_announcement': return <Megaphone className="h-4 w-4 text-indigo-600" />;
      default: return <Info className="h-4 w-4 text-gray-600" />;
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatTimeAgo = (dateString) => {
    const now = new Date();
    const date = new Date(dateString);
    const diffInMinutes = Math.floor((now - date) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  const filteredNotifications = notifications.filter(notification => {
    if (filter === 'unread') return !notification.read;
    if (filter === 'read') return notification.read;
    return true;
  });

  const PreferencesDialog = () => (
    <Dialog open={showPreferences} onOpenChange={setShowPreferences}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Settings className="h-5 w-5" />
            <span>Notification Preferences</span>
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-3">
            {[
              { key: 'mobile_field_updates', label: 'Mobile Field Updates', icon: <Smartphone className="h-4 w-4" /> },
              { key: 'project_milestones', label: 'Project Milestones', icon: <Activity className="h-4 w-4" /> },
              { key: 'financial_approvals', label: 'Financial Approvals', icon: <DollarSign className="h-4 w-4" /> },
              { key: 'compliance_deadlines', label: 'Compliance Deadlines', icon: <Shield className="h-4 w-4" /> },
              { key: 'quality_issues', label: 'Quality Issues', icon: <AlertTriangle className="h-4 w-4" /> },
              { key: 'procurement_updates', label: 'Procurement Updates', icon: <FileCheck className="h-4 w-4" /> },
              { key: 'system_announcements', label: 'System Announcements', icon: <Megaphone className="h-4 w-4" /> }
            ].map(({ key, label, icon }) => (
              <div key={key} className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  {icon}
                  <Label htmlFor={key}>{label}</Label>
                </div>
                <Switch
                  id={key}
                  checked={preferences[key] || false}
                  onCheckedChange={(checked) => {
                    const newPreferences = { ...preferences, [key]: checked };
                    updatePreferences(newPreferences);
                  }}
                />
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );

  return (
    <div className="space-y-4">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Bell className="h-5 w-5 text-blue-600" />
              <span>Notifications</span>
              {unreadCount > 0 && (
                <Badge className="bg-red-500 text-white">
                  {unreadCount}
                </Badge>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setShowPreferences(true)}
                data-testid="notification-preferences-button"
              >
                <Settings className="h-4 w-4 mr-1" />
                Settings
              </Button>
              {unreadCount > 0 && (
                <Button
                  size="sm"
                  onClick={markAllAsRead}
                  data-testid="mark-all-read-button"
                >
                  <CheckCheck className="h-4 w-4 mr-1" />
                  Mark All Read
                </Button>
              )}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* Filter Tabs */}
          <Tabs value={filter} onValueChange={setFilter} className="mb-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all" data-testid="filter-all">
                All ({notifications.length})
              </TabsTrigger>
              <TabsTrigger value="unread" data-testid="filter-unread">
                Unread ({unreadCount})
              </TabsTrigger>
              <TabsTrigger value="read" data-testid="filter-read">
                Read ({notifications.length - unreadCount})
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Notifications List */}
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="w-6 h-6 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              </div>
            ) : filteredNotifications.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <BellOff className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>No notifications found</p>
              </div>
            ) : (
              filteredNotifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-3 border rounded-lg transition-colors ${
                    !notification.read 
                      ? 'bg-blue-50 border-blue-200' 
                      : 'bg-white border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3 flex-1">
                      {getEventIcon(notification.event_type)}
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm ${!notification.read ? 'font-semibold' : 'font-normal'}`}>
                          {notification.message}
                        </p>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-xs text-gray-500">
                            {formatTimeAgo(notification.created_at)}
                          </span>
                          <Badge 
                            className={`text-xs ${getPriorityColor(notification.priority)}`}
                            variant="outline"
                          >
                            {notification.priority}
                          </Badge>
                          {notification.read && (
                            <Badge variant="outline" className="text-xs bg-gray-100 text-gray-600">
                              Read
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {/* Action Buttons */}
                    <div className="flex items-center space-x-1 ml-2">
                      {!notification.read && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => markAsRead(notification.id)}
                          data-testid={`mark-read-${notification.id}`}
                        >
                          <Check className="h-3 w-3" />
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => deleteNotification(notification.id)}
                        className="text-red-600 hover:text-red-700"
                        data-testid={`delete-${notification.id}`}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      <PreferencesDialog />
    </div>
  );
};

export default NotificationCenter;