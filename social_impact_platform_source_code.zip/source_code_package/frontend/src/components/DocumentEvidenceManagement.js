import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  Upload, 
  FileText, 
  Image, 
  Video, 
  MapPin, 
  Calendar,
  User,
  Shield,
  BarChart3,
  Filter,
  Search,
  Download,
  Eye,
  Edit3,
  Trash2,
  Camera,
  Receipt,
  ShieldCheck,
  Award,
  FileBarChart,
  Plus,
  Clock,
  CheckCircle2,
  AlertCircle,
  Tag
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const DocumentEvidenceManagement = ({ projectId, user }) => {
  const [documents, setDocuments] = useState([]);
  const [categories, setCategories] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState(null);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [uploadForm, setUploadForm] = useState({
    title: '',
    description: '',
    category: 'general',
    phase: '',
    activity: '',
    tags: ''
  });

  useEffect(() => {
    fetchDocuments();
    fetchCategories();
    fetchAnalytics();
  }, [projectId]);

  const fetchDocuments = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/projects/${projectId}/document-evidence`);
      setDocuments(response.data);
    } catch (error) {
      console.error('Error fetching documents:', error);
      toast.error('Failed to load documents');
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/projects/${projectId}/document-evidence/categories`);
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchAnalytics = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/projects/${projectId}/document-evidence/analytics`);
      setAnalytics(response.data);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    }
  };

  const handleUploadDocument = async () => {
    try {
      const tags = uploadForm.tags ? uploadForm.tags.split(',').map(tag => tag.trim()) : [];
      
      const response = await axios.post(
        `${BACKEND_URL}/api/projects/${projectId}/document-evidence`,
        null,
        {
          params: {
            title: uploadForm.title,
            description: uploadForm.description,
            category: uploadForm.category,
            phase: uploadForm.phase,
            activity: uploadForm.activity,
            tags: tags
          }
        }
      );
      
      setDocuments([...documents, response.data]);
      setUploadDialogOpen(false);
      setUploadForm({
        title: '',
        description: '',
        category: 'general',
        phase: '',
        activity: '',
        tags: ''
      });
      toast.success('Document evidence uploaded successfully');
      fetchAnalytics(); // Refresh analytics
    } catch (error) {
      console.error('Error uploading document:', error);
      toast.error('Failed to upload document');
    }
  };

  const handleDeleteDocument = async (documentId) => {
    try {
      await axios.delete(`${BACKEND_URL}/api/projects/${projectId}/document-evidence/${documentId}`);
      setDocuments(documents.filter(doc => doc.id !== documentId));
      toast.success('Document deleted successfully');
      fetchAnalytics(); // Refresh analytics
    } catch (error) {
      console.error('Error deleting document:', error);
      toast.error('Failed to delete document');
    }
  };

  const getIconForCategory = (categoryId) => {
    const iconMap = {
      photos_videos: Camera,
      contracts: FileText,
      invoices: Receipt,
      permits: ShieldCheck,
      reports: FileBarChart,
      certificates: Award,
      gps_data: MapPin
    };
    return iconMap[categoryId] || FileText;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'verified': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredDocuments = documents.filter(doc => {
    const matchesCategory = selectedCategory === 'all' || doc.category === selectedCategory;
    const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doc.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         doc.tags?.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Document Evidence Management</h2>
          <p className="text-gray-600">Organize and track project evidence with automatic timestamping</p>
        </div>
        {user.role !== 'investor' && (
          <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center space-x-2">
                <Upload className="h-4 w-4" />
                <span>Upload Evidence</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Upload Document Evidence</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Title *</Label>
                    <Input
                      id="title"
                      value={uploadForm.title}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Enter document title"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select value={uploadForm.category} onValueChange={(value) => setUploadForm(prev => ({ ...prev, category: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General</SelectItem>
                        {categories.map(cat => (
                          <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={uploadForm.description}
                    onChange={(e) => setUploadForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe this evidence document"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phase">Project Phase</Label>
                    <Input
                      id="phase"
                      value={uploadForm.phase}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, phase: e.target.value }))}
                      placeholder="e.g., training_delivery"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="activity">Activity</Label>
                    <Input
                      id="activity"
                      value={uploadForm.activity}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, activity: e.target.value }))}
                      placeholder="e.g., equipment_setup"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="tags">Tags (comma-separated)</Label>
                  <Input
                    id="tags"
                    value={uploadForm.tags}
                    onChange={(e) => setUploadForm(prev => ({ ...prev, tags: e.target.value }))}
                    placeholder="e.g., delivery, receipt, equipment"
                  />
                </div>
                
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setUploadDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleUploadDocument} disabled={!uploadForm.title}>
                    Upload Evidence
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Analytics Overview */}
      {analytics && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <FileText className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Documents</p>
                  <p className="text-2xl font-bold text-gray-900">{analytics.total_documents}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Verified</p>
                  <p className="text-2xl font-bold text-gray-900">{analytics.verification_status?.verified || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-yellow-600" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Pending</p>
                  <p className="text-2xl font-bold text-gray-900">{analytics.verification_status?.pending || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <BarChart3 className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Storage Used</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {analytics.storage_usage?.total_size_mb ? `${analytics.storage_usage.total_size_mb.toFixed(1)}MB` : '0MB'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters and Search */}
      <div className="flex flex-col sm:flex-row gap-4 items-center">
        <div className="flex items-center space-x-2">
          <Filter className="h-4 w-4 text-gray-500" />
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map(cat => (
                <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex items-center space-x-2 flex-1">
          <Search className="h-4 w-4 text-gray-500" />
          <Input
            placeholder="Search documents, descriptions, or tags..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1"
          />
        </div>
      </div>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDocuments.map(document => {
          const IconComponent = getIconForCategory(document.category);
          return (
            <Card key={document.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-2">
                    <IconComponent className="h-5 w-5 text-blue-600" />
                    <CardTitle className="text-base line-clamp-1">{document.title}</CardTitle>
                  </div>
                  <Badge className={getStatusColor(document.verification_status)}>
                    {document.verification_status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-sm text-gray-600 mb-3 line-clamp-2">{document.description}</p>
                
                <div className="space-y-2 mb-4">
                  {document.phase && (
                    <div className="flex items-center text-xs text-gray-500">
                      <Calendar className="h-3 w-3 mr-1" />
                      <span>Phase: {document.phase}</span>
                    </div>
                  )}
                  {document.activity && (
                    <div className="flex items-center text-xs text-gray-500">
                      <span>Activity: {document.activity}</span>
                    </div>
                  )}
                  <div className="flex items-center text-xs text-gray-500">
                    <User className="h-3 w-3 mr-1" />
                    <span>{new Date(document.uploaded_at).toLocaleDateString()}</span>
                  </div>
                  {document.file_size > 0 && (
                    <div className="flex items-center text-xs text-gray-500">
                      <span>Size: {formatFileSize(document.file_size)}</span>
                    </div>
                  )}
                </div>

                {/* Tags */}
                {document.tags && document.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-3">
                    {document.tags.slice(0, 3).map((tag, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        <Tag className="h-2 w-2 mr-1" />
                        {tag}
                      </Badge>
                    ))}
                    {document.tags.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{document.tags.length - 3} more
                      </Badge>
                    )}
                  </div>
                )}

                {/* Location Data */}
                {document.metadata?.location_data && (
                  <div className="flex items-center text-xs text-gray-500 mb-3">
                    <MapPin className="h-3 w-3 mr-1" />
                    <span className="truncate">{document.metadata.location_data.address || 'GPS Location Available'}</span>
                  </div>
                )}

                {/* Actions */}
                <div className="flex justify-between items-center">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedDocument(document);
                      setViewDialogOpen(true);
                    }}
                  >
                    <Eye className="h-3 w-3 mr-1" />
                    View
                  </Button>
                  
                  {user.role !== 'investor' && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteDocument(document.id)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Empty State */}
      {filteredDocuments.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <FileText className="h-16 w-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No documents found</h3>
            <p className="text-gray-500 mb-4">
              {searchTerm || selectedCategory !== 'all' 
                ? 'No documents match your current filters' 
                : 'Upload your first document evidence to get started'}
            </p>
            {user.role !== 'investor' && !searchTerm && selectedCategory === 'all' && (
              <Button onClick={() => setUploadDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Upload Evidence
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Document Details Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              {selectedDocument && (
                <>
                  {React.createElement(getIconForCategory(selectedDocument.category), { className: 'h-5 w-5' })}
                  <span>{selectedDocument.title}</span>
                </>
              )}
            </DialogTitle>
          </DialogHeader>
          {selectedDocument && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-700">Category</Label>
                  <p className="text-sm text-gray-900">
                    {categories.find(cat => cat.id === selectedDocument.category)?.name || selectedDocument.category}
                  </p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Status</Label>
                  <Badge className={getStatusColor(selectedDocument.verification_status)}>
                    {selectedDocument.verification_status}
                  </Badge>
                </div>
              </div>
              
              <div>
                <Label className="text-sm font-medium text-gray-700">Description</Label>
                <p className="text-sm text-gray-900">{selectedDocument.description}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                {selectedDocument.phase && (
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Phase</Label>
                    <p className="text-sm text-gray-900">{selectedDocument.phase}</p>
                  </div>
                )}
                {selectedDocument.activity && (
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Activity</Label>
                    <p className="text-sm text-gray-900">{selectedDocument.activity}</p>
                  </div>
                )}
              </div>
              
              {selectedDocument.tags && selectedDocument.tags.length > 0 && (
                <div>
                  <Label className="text-sm font-medium text-gray-700">Tags</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {selectedDocument.tags.map((tag, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              
              {selectedDocument.metadata?.location_data && (
                <div>
                  <Label className="text-sm font-medium text-gray-700">Location</Label>
                  <p className="text-sm text-gray-900">
                    {selectedDocument.metadata.location_data.address || 
                     `${selectedDocument.metadata.location_data.latitude}, ${selectedDocument.metadata.location_data.longitude}`}
                  </p>
                </div>
              )}
              
              <div className="grid grid-cols-3 gap-4 text-xs text-gray-500">
                <div>
                  <Label className="text-sm font-medium text-gray-700">File Size</Label>
                  <p>{formatFileSize(selectedDocument.file_size)}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">Uploaded</Label>
                  <p>{new Date(selectedDocument.uploaded_at).toLocaleString()}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-700">File Type</Label>
                  <p>{selectedDocument.file_type}</p>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default DocumentEvidenceManagement;