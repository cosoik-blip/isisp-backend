import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Avatar, AvatarFallback } from './ui/avatar';
import { toast } from 'sonner';
import { 
  Library, 
  Plus, 
  Search,
  Filter,
  Download,
  Eye,
  Edit3,
  Trash2,
  Upload,
  FileText,
  Image,
  Video,
  Package,
  Star,
  Calendar,
  User,
  Tag,
  BarChart3,
  TrendingUp,
  Clock,
  Target,
  Award,
  BookOpen,
  GraduationCap,
  Heart,
  Building,
  Leaf,
  Sprout,
  Scale,
  Shield,
  Zap,
  Bookmark,
  Languages,
  Globe,
  MessageSquare,
  MessageCircle,
  Reply,
  ThumbsUp,
  Sliders3,
  History,
  Save,
  Share2,
  PlayCircle,
  VolumeX,
  FolderPlus,
  Collection,
  UserPlus,
  Filter as FilterIcon,
  SortAsc,
  SortDesc,
  BookmarkPlus,
  ArrowLeft,
  ArrowRight,
  ExternalLink,
  Play,
  Pause,
  Volume2,
  Maximize,
  Minimize,
  Settings,
  CheckCircle
} from 'lucide-react';
import UniversalComments from './UniversalComments';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;

const TemplateLibrary = ({ user }) => {
  const [instruments, setInstruments] = useState([]);
  const [categories, setCategories] = useState([]);
  const [filteredInstruments, setFilteredInstruments] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedLanguage, setSelectedLanguage] = useState('all');
  const [selectedFileFormat, setSelectedFileFormat] = useState('all');
  const [selectedContentType, setSelectedContentType] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('newest');
  const [viewMode, setViewMode] = useState('grid'); // grid or list
  
  // User personalization
  const [userBookmarks, setUserBookmarks] = useState([]);
  const [showBookmarksOnly, setShowBookmarksOnly] = useState(false);
  
  // Phase 2 & 3: New state variables
  const [activeTab, setActiveTab] = useState('library'); // library, discussions, collections, analytics
  const [discussions, setDiscussions] = useState([]);
  const [userCollections, setUserCollections] = useState([]);
  const [popularInstruments, setPopularInstruments] = useState([]);
  const [trendingInstruments, setTrendingInstruments] = useState([]);
  const [searchHistory, setSearchHistory] = useState([]);
  const [savedSearches, setSavedSearches] = useState([]);
  
  // NEW PERSONALIZATION FEATURES
  // A) Reading History & Progress
  const [readingHistory, setReadingHistory] = useState([]);
  const [readingProgress, setReadingProgress] = useState({});
  const [continueReading, setContinueReading] = useState([]);
  
  // B) Personal Notes & Annotations
  const [userNotes, setUserNotes] = useState([]);
  const [showNotesDialog, setShowNotesDialog] = useState(false);
  const [selectedInstrumentNotes, setSelectedInstrumentNotes] = useState([]);
  const [newNote, setNewNote] = useState({ content: '', tags: [], note_type: 'general' });
  
  // C) Personalized Recommendations
  const [recommendations, setRecommendations] = useState([]);
  const [recommendationReason, setRecommendationReason] = useState({});
  
  // D) Enhanced User Profile
  const [userProfile, setUserProfile] = useState(null);
  const [userPreferences, setUserPreferences] = useState({});
  const [personalizedDashboard, setPersonalizedDashboard] = useState(null);
  const [showProfileDialog, setShowProfileDialog] = useState(false);
  
  // Advanced search state
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);
  const [advancedFilters, setAdvancedFilters] = useState({
    author: '',
    publisher: '',
    dateFrom: '',
    dateTo: '',
    minRating: '',
    hasGreekContent: null,
    sdgAlignment: '',
    tags: ''
  });
  
  // Dialog states
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [showInstrumentDetails, setShowInstrumentDetails] = useState(false);
  const [selectedInstrument, setSelectedInstrument] = useState(null);
  const [showDiscussionDialog, setShowDiscussionDialog] = useState(false);
  const [showCollectionDialog, setShowCollectionDialog] = useState(false);
  const [showFileViewerDialog, setShowFileViewerDialog] = useState(false);
  const [currentViewingFile, setCurrentViewingFile] = useState(null);
  
  // Discussion states
  const [selectedDiscussion, setSelectedDiscussion] = useState(null);
  const [discussionReplies, setDiscussionReplies] = useState([]);
  const [showReplyForm, setShowReplyForm] = useState(false);
  const [editingInstrument, setEditingInstrument] = useState(null);
  
  const [uploadForm, setUploadForm] = useState({
    title: '',
    description: '',
    detailed_description: '',
    category: '',
    subcategory: '',
    content_type: 'financial_instrument',
    file_format: 'pdf',
    language: 'en',
    tags: '',
    keywords: '',
    authors: '',
    publisher: '',
    isbn_doi: '',
    legal_framework: '',
    jurisdiction: '',
    journal_name: '',
    volume_issue: '',
    is_peer_reviewed: false,
    nda_required: false,
    target_audience: [],
    complexity_level: 'medium',
    estimated_reading_time: '',
    prerequisites: '',
    sdg_alignment: ''
  });

  useEffect(() => {
    fetchInstruments();
    fetchCategories();
    fetchUserBookmarks();
    fetchUserCollections();
    fetchSearchHistory();
    fetchSavedSearches();
    fetchPopularInstruments();
    fetchTrendingInstruments();
    
    // NEW PERSONALIZATION FEATURES
    fetchReadingHistory();
    fetchPersonalizedRecommendations();
    fetchUserProfile();
    fetchPersonalizedDashboard();
    
    if (user.role === 'administrator') {
      fetchAnalytics();
    }
  }, []);

  useEffect(() => {
    filterAndSortInstruments();
  }, [instruments, selectedCategory, selectedLanguage, selectedFileFormat, selectedContentType, searchTerm, sortBy, showBookmarksOnly, userBookmarks]);

  const fetchInstruments = async () => {
    try {
      // Fetch all instruments without filtering for client-side filtering
      const response = await axios.get(`${BACKEND_URL}/api/template-library`, {
        headers: { 
          Authorization: `Bearer ${localStorage.getItem('token')}` 
        }
      });
      setInstruments(response.data);
    } catch (error) {
      console.error('Error fetching financial instruments:', error);
      toast.error('Failed to load financial instruments');
    } finally {
      setLoading(false);
    }
  };

  const fetchUserBookmarks = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/template-library/bookmarks`);
      setUserBookmarks(response.data.map(item => item.id));
    } catch (error) {
      console.error('Error fetching bookmarks:', error);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/template-library/categories`);
      setCategories(response.data);
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchAnalytics = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/template-library/analytics`, {
        headers: { 
          Authorization: `Bearer ${localStorage.getItem('token')}` 
        }
      });
      setAnalytics(response.data);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    }
  };

  // =============================================================================
  // NEW PERSONALIZATION FETCH FUNCTIONS
  // =============================================================================

  // A) Reading History & Progress Functions
  const fetchReadingHistory = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/user/reading-history`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setReadingHistory(response.data);
      
      // Separate continue reading items
      const incomplete = response.data.filter(item => !item.completed && item.progress_percentage > 0);
      setContinueReading(incomplete);
    } catch (error) {
      console.error('Error fetching reading history:', error);
    }
  };

  const trackReadingProgress = async (instrumentId, progressData) => {
    try {
      await axios.post(`${BACKEND_URL}/api/user/reading-history/${instrumentId}`, progressData, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      // Update local progress state
      setReadingProgress(prev => ({
        ...prev,
        [instrumentId]: progressData
      }));
      
      // Refresh reading history
      fetchReadingHistory();
    } catch (error) {
      console.error('Error tracking reading progress:', error);
    }
  };

  const getReadingProgress = async (instrumentId) => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/user/reading-progress/${instrumentId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching reading progress:', error);
      return { progress_percentage: 0, completed: false };
    }
  };

  // B) Notes & Annotations Functions
  const fetchUserNotes = async (instrumentId = null) => {
    try {
      const url = instrumentId 
        ? `${BACKEND_URL}/api/user/notes/${instrumentId}`
        : `${BACKEND_URL}/api/user/notes`;
        
      const response = await axios.get(url, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      if (instrumentId) {
        setSelectedInstrumentNotes(response.data);
      } else {
        setUserNotes(response.data);
      }
    } catch (error) {
      console.error('Error fetching user notes:', error);
    }
  };

  const createNote = async (instrumentId, noteData) => {
    try {
      await axios.post(`${BACKEND_URL}/api/user/notes/${instrumentId}`, noteData, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      // Refresh notes
      fetchUserNotes(instrumentId);
      fetchUserNotes(); // All notes
      
      toast.success('Note created successfully!');
      setNewNote({ content: '', tags: [], note_type: 'general' });
    } catch (error) {
      console.error('Error creating note:', error);
      toast.error('Failed to create note');
    }
  };

  const deleteNote = async (noteId) => {
    try {
      await axios.delete(`${BACKEND_URL}/api/user/notes/${noteId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      // Refresh notes
      fetchUserNotes();
      toast.success('Note deleted successfully!');
    } catch (error) {
      console.error('Error deleting note:', error);
      toast.error('Failed to delete note');
    }
  };

  // C) Personalized Recommendations
  const fetchPersonalizedRecommendations = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/user/recommendations`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setRecommendations(response.data.recommendations);
      setRecommendationReason(response.data.recommendation_reason);
    } catch (error) {
      console.error('Error fetching recommendations:', error);
    }
  };

  // D) Enhanced User Profile & Preferences
  const fetchUserProfile = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/user/profile`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setUserProfile(response.data);
      setUserPreferences(response.data.preferences);
    } catch (error) {
      console.error('Error fetching user profile:', error);
    }
  };

  const updateUserPreferences = async (newPreferences) => {
    try {
      await axios.put(`${BACKEND_URL}/api/user/preferences`, newPreferences, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      setUserPreferences(newPreferences);
      toast.success('Preferences updated successfully!');
      
      // Refresh recommendations based on new preferences
      fetchPersonalizedRecommendations();
    } catch (error) {
      console.error('Error updating preferences:', error);
      toast.error('Failed to update preferences');
    }
  };

  const fetchPersonalizedDashboard = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/user/dashboard`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      setPersonalizedDashboard(response.data);
    } catch (error) {
      console.error('Error fetching personalized dashboard:', error);
    }
  };

  const filterAndSortInstruments = () => {
    let filtered = instruments.filter(instrument => {
      const matchesCategory = selectedCategory === 'all' || instrument.category === selectedCategory;
      const matchesLanguage = selectedLanguage === 'all' || instrument.language === selectedLanguage;
      const matchesFileFormat = selectedFileFormat === 'all' || instrument.file_format === selectedFileFormat;
      const matchesContentType = selectedContentType === 'all' || instrument.content_type === selectedContentType;
      const matchesBookmark = !showBookmarksOnly || userBookmarks.includes(instrument.id);
      const matchesSearch = instrument.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           instrument.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           (instrument.detailed_description && instrument.detailed_description.toLowerCase().includes(searchTerm.toLowerCase())) ||
                           instrument.tags?.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase())) ||
                           instrument.keywords?.some(keyword => keyword.toLowerCase().includes(searchTerm.toLowerCase()));
      
      return matchesCategory && matchesLanguage && matchesFileFormat && matchesContentType && matchesBookmark && matchesSearch;
    });

    // Sort instruments
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.created_at) - new Date(a.created_at);
        case 'oldest':
          return new Date(a.created_at) - new Date(b.created_at);
        case 'most_popular':
          return (b.downloads || 0) - (a.downloads || 0);
        case 'most_viewed':
          return (b.view_count || 0) - (a.view_count || 0);
        case 'highest_rated':
          return (b.rating || 0) - (a.rating || 0);
        case 'most_bookmarked':
          return (b.bookmarks || 0) - (a.bookmarks || 0);
        case 'alphabetical':
          return a.title.localeCompare(b.title);
        default:
          return 0;
      }
    });

    setFilteredInstruments(filtered);
  };

  const handleBookmarkToggle = async (instrumentId) => {
    try {
      const response = await axios.post(`${BACKEND_URL}/api/template-library/${instrumentId}/bookmark`, {}, {
        headers: { 
          Authorization: `Bearer ${localStorage.getItem('token')}` 
        }
      });
      
      if (response.data.bookmarked) {
        setUserBookmarks([...userBookmarks, instrumentId]);
        toast.success('Added to bookmarks');
      } else {
        setUserBookmarks(userBookmarks.filter(id => id !== instrumentId));
        toast.success('Removed from bookmarks');
      }
      
      // Update the instrument's bookmark count in local state
      setInstruments(prevInstruments => 
        prevInstruments.map(inst => 
          inst.id === instrumentId 
            ? { ...inst, bookmarks: (inst.bookmarks || 0) + (response.data.bookmarked ? 1 : -1) }
            : inst
        )
      );
    } catch (error) {
      console.error('Error toggling bookmark:', error);
      toast.error('Failed to update bookmark');
    }
  };

  const recordView = async (instrumentId) => {
    try {
      await axios.post(`${BACKEND_URL}/api/template-library/${instrumentId}/view`, {}, {
        headers: { 
          Authorization: `Bearer ${localStorage.getItem('token')}` 
        }
      });
    } catch (error) {
      console.error('Error recording view:', error);
    }
  };

  const handleUploadInstrument = async (e) => {
    e.preventDefault();
    try {
      const instrumentData = {
        ...uploadForm,
        tags: uploadForm.tags.split(',').map(tag => tag.trim()),
        keywords: uploadForm.keywords.split(',').map(keyword => keyword.trim()),
        authors: uploadForm.authors.split(',').map(author => author.trim()),
        prerequisites: uploadForm.prerequisites.split(',').map(item => item.trim()),
        sdg_alignment: uploadForm.sdg_alignment.split(',').map(item => parseInt(item.trim())).filter(item => !isNaN(item))
      };

      const isEditing = editingInstrument !== null;

      if (isEditing) {
        await axios.put(`${BACKEND_URL}/api/template-library/${editingInstrument}`, instrumentData, {
          headers: { 
            Authorization: `Bearer ${localStorage.getItem('token')}` 
          }
        });
        toast.success('Financial instrument updated successfully!');
      } else {
        await axios.post(`${BACKEND_URL}/api/template-library`, instrumentData, {
          headers: { 
            Authorization: `Bearer ${localStorage.getItem('token')}` 
          }
        });
        toast.success('Financial instrument uploaded successfully!');
      }

      setShowUploadDialog(false);
      resetUploadForm();
      fetchInstruments();
      if (user.role === 'administrator') {
        fetchAnalytics();
      }
    } catch (error) {
      console.error('Error uploading financial instrument:', error);
      toast.error(`Failed to ${editingInstrument ? 'update' : 'upload'} financial instrument`);
    }
  };

  const handleDownloadInstrument = async (instrumentId) => {
    try {
      if (!instrumentId) {
        toast.error('Invalid instrument ID');
        return;
      }
      
      const response = await axios.get(`${BACKEND_URL}/api/template-library/${instrumentId}/download`, {
        headers: { 
          Authorization: `Bearer ${localStorage.getItem('token')}` 
        },
        responseType: 'blob'
      });
      
      // Get filename from Content-Disposition header or use default
      const contentDisposition = response.headers['content-disposition'];
      let filename = 'download';
      if (contentDisposition) {
        const filenameMatch = contentDisposition.match(/filename="?([^"]+)"?/);
        if (filenameMatch) {
          filename = filenameMatch[1];
        }
      }
      
      // Create blob and download
      const blob = new Blob([response.data], { type: response.headers['content-type'] });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = filename;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      toast.success('Download started');
      
      // Record view
      await recordView(instrumentId);
      
      // Update the instrument's download count in the UI
      setInstruments(instruments.map(inst => 
        inst.id === instrumentId 
          ? { ...inst, downloads: (inst.downloads || 0) + 1, usage_count: (inst.usage_count || 0) + 1 }
          : inst
      ));
    } catch (error) {
      console.error('Error downloading:', error);
      toast.error('Failed to download');
    }
  };

  const handleDeleteInstrument = async (instrumentId) => {
    if (!window.confirm('Are you sure you want to delete this financial instrument?')) return;

    try {
      await axios.delete(`${BACKEND_URL}/api/template-library/${instrumentId}`, {
        headers: { 
          Authorization: `Bearer ${localStorage.getItem('token')}` 
        }
      });
      toast.success('Financial instrument deleted successfully!');
      fetchInstruments();
      if (user.role === 'administrator') {
        fetchAnalytics();
      }
    } catch (error) {
      console.error('Error deleting:', error);
      toast.error('Failed to delete financial instrument');
    }
  };

  const handleRateInstrument = async (instrumentId, rating) => {
    try {
      await axios.post(`${BACKEND_URL}/api/template-library/${instrumentId}/rate`, { rating }, {
        headers: { 
          Authorization: `Bearer ${localStorage.getItem('token')}` 
        }
      });
      toast.success('Rating submitted successfully!');
      fetchInstruments();
    } catch (error) {
      console.error('Error rating:', error);
      toast.error('Failed to submit rating');
    }
  };

  const resetUploadForm = () => {
    setUploadForm({
      title: '',
      description: '',
      detailed_description: '',
      category: '',
      subcategory: '',
      content_type: 'financial_instrument',
      file_format: 'pdf',
      language: 'en',
      tags: '',
      keywords: '',
      authors: '',
      publisher: '',
      isbn_doi: '',
      legal_framework: '',
      jurisdiction: '',
      journal_name: '',
      volume_issue: '',
      is_peer_reviewed: false,
      nda_required: false,
      target_audience: [],
      complexity_level: 'medium',
      estimated_reading_time: '',
      prerequisites: '',
      sdg_alignment: ''
    });
    setEditingInstrument(null);
  };

  const getCategoryIcon = (categoryId) => {
    const iconMap = {
      financial_instruments: TrendingUp,
      bibliography: BookOpen,
      publications: FileText,
      supporting_materials: Package,
      multimedia: Video,
      // Legacy categories for backward compatibility
      education: GraduationCap,
      healthcare: Heart,
      infrastructure: Building,
      economic_development: TrendingUp,
      environment: Leaf,
      agriculture: Sprout,
      governance: Scale,
      emergency_response: Shield
    };
    return iconMap[categoryId] || BookOpen;
  };

  const getContentTypeIcon = (contentType) => {
    switch (contentType) {
      case 'financial_instrument': return TrendingUp;
      case 'bibliography': return BookOpen;
      case 'supporting_material': return Package;
      case 'document': return FileText;
      case 'image': return Image;
      case 'video': return Video;
      case 'mixed': return Package;
      default: return FileText;
    }
  };

  const getFileFormatIcon = (fileFormat) => {
    switch (fileFormat?.toLowerCase()) {
      case 'pdf': return FileText;
      case 'epub': return BookOpen;
      case 'wma': return Video; // Using Video icon for audio
      case 'wmv': return Video;
      case 'mp4': return Video;
      case 'docx': return FileText;
      default: return FileText;
    }
  };

  const getComplexityColor = (level) => {
    switch (level) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-blue-100 text-blue-800';
      case 'high': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const StarRating = ({ rating, onRate, readonly = false }) => {
    return (
      <div className="flex items-center space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-4 w-4 ${
              star <= rating 
                ? 'text-yellow-400 fill-current' 
                : 'text-gray-300'
            } ${!readonly ? 'cursor-pointer hover:text-yellow-400' : ''}`}
            onClick={() => !readonly && onRate && onRate(star)}
          />
        ))}
        <span className="text-sm text-gray-600 ml-2">({rating.toFixed(1)})</span>
      </div>
    );
  };

  // Phase 2 & 3: New API Functions
  
  // Discussion Forum Functions
  const fetchDiscussions = async (instrumentId) => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/template-library/${instrumentId}/discussions`);
      setDiscussions(response.data);
    } catch (error) {
      console.error('Error fetching discussions:', error);
    }
  };

  const createDiscussion = async (instrumentId, discussionData) => {
    try {
      const response = await axios.post(`${BACKEND_URL}/api/template-library/${instrumentId}/discussions`, discussionData);
      toast.success('Discussion created successfully!');
      fetchDiscussions(instrumentId);
      return response.data;
    } catch (error) {
      console.error('Error creating discussion:', error);
      toast.error('Failed to create discussion');
    }
  };

  const fetchDiscussionReplies = async (threadId) => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/discussions/${threadId}/replies`);
      setDiscussionReplies(response.data);
    } catch (error) {
      console.error('Error fetching replies:', error);
    }
  };

  const createReply = async (threadId, replyData) => {
    try {
      const response = await axios.post(`${BACKEND_URL}/api/discussions/${threadId}/replies`, replyData);
      toast.success('Reply posted successfully!');
      fetchDiscussionReplies(threadId);
      return response.data;
    } catch (error) {
      console.error('Error creating reply:', error);
      toast.error('Failed to post reply');
    }
  };

  // Advanced Search Functions
  const performAdvancedSearch = async (searchParams) => {
    try {
      const params = new URLSearchParams();
      
      if (searchTerm) params.append('query', searchTerm);
      if (selectedCategory && selectedCategory !== 'all') params.append('category', selectedCategory);
      if (selectedContentType && selectedContentType !== 'all') params.append('content_type', selectedContentType);
      if (selectedLanguage && selectedLanguage !== 'all') params.append('language', selectedLanguage);
      if (selectedFileFormat && selectedFileFormat !== 'all') params.append('file_format', selectedFileFormat);
      
      // Advanced filters
      Object.keys(advancedFilters).forEach(key => {
        const value = advancedFilters[key];
        if (value && value !== '') {
          params.append(key === 'hasGreekContent' ? 'has_greek_content' : key.replace(/([A-Z])/g, '_$1').toLowerCase(), value);
        }
      });
      
      params.append('sort_by', sortBy);
      
      const response = await axios.get(`${BACKEND_URL}/api/template-library/advanced-search?${params}`);
      setFilteredInstruments(response.data.results);
      
      return response.data;
    } catch (error) {
      console.error('Error performing advanced search:', error);
      toast.error('Search failed');
      return null;
    }
  };

  const fetchSearchHistory = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/template-library/search-history`);
      setSearchHistory(response.data);
    } catch (error) {
      console.error('Error fetching search history:', error);
    }
  };

  const fetchSavedSearches = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/template-library/saved-searches`);
      setSavedSearches(response.data);
    } catch (error) {
      console.error('Error fetching saved searches:', error);
    }
  };

  const saveSearch = async (name, query, filters) => {
    try {
      const response = await axios.post(`${BACKEND_URL}/api/template-library/saved-searches`, {
        name,
        query,
        filters
      });
      toast.success('Search saved successfully!');
      fetchSavedSearches();
    } catch (error) {
      console.error('Error saving search:', error);
      toast.error('Failed to save search');
    }
  };

  // Collections Functions
  const fetchUserCollections = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/template-library/collections`);
      setUserCollections(response.data);
    } catch (error) {
      console.error('Error fetching collections:', error);
    }
  };

  const createCollection = async (collectionData) => {
    try {
      const response = await axios.post(`${BACKEND_URL}/api/template-library/collections`, collectionData);
      toast.success('Collection created successfully!');
      fetchUserCollections();
      return response.data;
    } catch (error) {
      console.error('Error creating collection:', error);
      toast.error('Failed to create collection');
    }
  };

  const addToCollection = async (collectionId, instrumentId) => {
    try {
      await axios.post(`${BACKEND_URL}/api/template-library/collections/${collectionId}/instruments/${instrumentId}`);
      toast.success('Added to collection!');
      fetchUserCollections();
    } catch (error) {
      console.error('Error adding to collection:', error);
      toast.error('Failed to add to collection');
    }
  };

  // Analytics Functions
  const fetchPopularInstruments = async (timePeriod = 'week') => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/template-library/analytics/popular?time_period=${timePeriod}&limit=10`);
      setPopularInstruments(response.data);
    } catch (error) {
      console.error('Error fetching popular instruments:', error);
    }
  };

  const fetchTrendingInstruments = async () => {
    try {
      const response = await axios.get(`${BACKEND_URL}/api/template-library/analytics/trending?limit=10`);
      setTrendingInstruments(response.data);
    } catch (error) {
      console.error('Error fetching trending instruments:', error);
    }
  };

  // File Viewing Functions
  const openFileViewer = async (instrumentId) => {
    try {
      // Get file metadata
      const metadataResponse = await axios.get(`${BACKEND_URL}/api/template-library/${instrumentId}/view`, {
        headers: { 
          Authorization: `Bearer ${localStorage.getItem('token')}` 
        }
      });
      
      // Fetch file content as blob for embedding
      const fileResponse = await axios.get(`${BACKEND_URL}/api/template-library/${instrumentId}/file`, {
        headers: { 
          Authorization: `Bearer ${localStorage.getItem('token')}` 
        },
        responseType: 'blob'
      });
      
      // Get content type from response headers  
      const contentType = fileResponse.headers['content-type'] || 'application/octet-stream';
      
      // Create object URL for embedding
      const blob = new Blob([fileResponse.data], { type: contentType });
      const file_url = window.URL.createObjectURL(blob);
      
      const fileData = {
        ...metadataResponse.data,
        instrumentId,
        file_url,
        blob_url: file_url // Keep reference for cleanup
      };
      
      setCurrentViewingFile(fileData);
      setShowFileViewerDialog(true);
      
      // Record view
      await recordView(instrumentId);
    } catch (error) {
      console.error('Error opening file viewer:', error);
      toast.error('Failed to open file viewer');
    }
  };

  const openInNewTab = async (instrumentId) => {
    try {
      if (!instrumentId) {
        toast.error('Invalid instrument ID');
        return;
      }
      
      // Download the file as blob first, then create object URL
      const response = await axios.get(`${BACKEND_URL}/api/template-library/${instrumentId}/file`, {
        headers: { 
          Authorization: `Bearer ${localStorage.getItem('token')}` 
        },
        responseType: 'blob'
      });
      
      // Create object URL and open in new tab
      const blob = new Blob([response.data], { type: response.headers['content-type'] });
      const url = window.URL.createObjectURL(blob);
      window.open(url, '_blank');
      
      // Clean up the object URL after a delay
      setTimeout(() => {
        window.URL.revokeObjectURL(url);
      }, 1000);
      
      toast.success('File opened in new tab');
      
      // Record view
      await recordView(instrumentId);
    } catch (error) {
      console.error('Error opening file in new tab:', error);
      toast.error('Failed to open file in new tab');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <Link 
            to="/dashboard" 
            className="flex items-center space-x-2 px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-100 hover:text-gray-900 transition-colors"
          >
            <BarChart3 className="h-5 w-5" />
            <span>Back to Dashboard</span>
          </Link>
          <div className="border-l border-gray-300 h-8"></div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <Library className="h-7 w-7 text-blue-600" />
              <span>Electronic Library of Financial Instruments & Supporting Material</span>
              
              {/* Missing Feature: Notification Bell */}
              <Button 
                variant="ghost" 
                size="sm"
                onClick={async () => {
                  try {
                    const response = await axios.get(`${BACKEND_URL}/api/template-library/notifications?unread_only=true`);
                    const unreadCount = response.data.length;
                    
                    if (unreadCount > 0) {
                      toast.info(`You have ${unreadCount} new notification(s)`);
                    } else {
                      toast.info('No new notifications');
                    }
                  } catch (error) {
                    console.error('Error fetching notifications:', error);
                  }
                }}
                className="ml-4"
              >
                <div className="relative">
                  <User className="h-5 w-5" />
                  {/* Notification badge - would show actual count in real implementation */}
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                    2
                  </span>
                </div>
              </Button>
            </h2>
            <p className="text-gray-600">Pre-built templates and financial instruments for different types of social investments</p>
            {user?.role === 'administrator' && (
              <div className="mt-2 px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium inline-block">
                🔧 Admin Mode: Edit & Delete buttons enabled
              </div>
            )}
          </div>
        </div>
        {user?.role === 'administrator' && (
          <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
            <DialogTrigger asChild>
              <Button className="flex items-center space-x-2">
                <Upload className="h-4 w-4" />
                <span>Upload Financial Instrument</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{editingInstrument ? 'Edit Financial Instrument' : 'Upload New Financial Instrument'}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleUploadInstrument} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Financial Instrument Title *</Label>
                    <Input
                      id="title"
                      value={uploadForm.title}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Enter financial instrument title"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Category *</Label>
                    <Select value={uploadForm.category} onValueChange={(value) => setUploadForm(prev => ({ ...prev, category: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(cat => (
                          <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={uploadForm.description}
                    onChange={(e) => setUploadForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe the financial instrument and its use cases"
                    className="min-h-[100px]"
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="content_type">Content Type</Label>
                    <Select value={uploadForm.content_type} onValueChange={(value) => setUploadForm(prev => ({ ...prev, content_type: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select content type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="document">Document</SelectItem>
                        <SelectItem value="image">Image</SelectItem>
                        <SelectItem value="video">Video</SelectItem>
                        <SelectItem value="mixed">Mixed Content</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="complexity_level">Complexity Level</Label>
                    <Select value={uploadForm.complexity_level} onValueChange={(value) => setUploadForm(prev => ({ ...prev, complexity_level: value }))}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select complexity" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="estimated_duration">Estimated Duration</Label>
                    <Input
                      id="estimated_duration"
                      value={uploadForm.estimated_duration}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, estimated_duration: e.target.value }))}
                      placeholder="e.g., 6-12 months"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="tags">Tags (comma-separated)</Label>
                    <Input
                      id="tags"
                      value={uploadForm.tags}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, tags: e.target.value }))}
                      placeholder="e.g., education, technology, rural"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="budget_range">Budget Range</Label>
                    <Input
                      id="budget_range"
                      value={uploadForm.budget_range}
                      onChange={(e) => setUploadForm(prev => ({ ...prev, budget_range: e.target.value }))}
                      placeholder="e.g., $10,000 - $50,000"
                    />
                  </div>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => {
                    setShowUploadDialog(false);
                    resetUploadForm();
                  }}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={!uploadForm.title || !uploadForm.category}>
                    {editingInstrument ? 'Update Financial Instrument' : 'Upload Financial Instrument'}
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Analytics Dashboard (Admin Only) */}
      {user.role === 'administrator' && analytics && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Library className="h-5 w-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Financial Instruments</p>
                  <p className="text-2xl font-bold text-gray-900">{analytics.total_templates}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Download className="h-5 w-5 text-green-600" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Downloads</p>
                  <p className="text-2xl font-bold text-gray-900">{analytics.total_downloads}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <Star className="h-5 w-5 text-yellow-600" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Average Rating</p>
                  <p className="text-2xl font-bold text-gray-900">{analytics.average_rating}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5 text-purple-600" />
                <div>
                  <p className="text-sm font-medium text-gray-600">Most Popular</p>
                  <p className="text-sm font-bold text-gray-900 truncate">
                    {analytics.popular_templates?.[0]?.title || 'None'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters and Search */}
      <div className="flex flex-col lg:flex-row gap-4 items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Filter className="h-4 w-4 text-gray-500" />
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map(cat => (
                  <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="oldest">Oldest</SelectItem>
              <SelectItem value="most_popular">Most Popular</SelectItem>
              <SelectItem value="highest_rated">Highest Rated</SelectItem>
              <SelectItem value="alphabetical">A-Z</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center space-x-2 flex-1 max-w-md">
          <Search className="h-4 w-4 text-gray-500" />
          <Input
            placeholder="Search financial instruments, codes (e.g., FIN-SIB-001), or content..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1"
          />
          {/* Full-text search indicator */}
          {searchTerm && searchTerm.length > 3 && (
            <Badge variant="outline" className="text-xs">
              {searchTerm.match(/^[A-Z]{3}-[A-Z]{3}-\d{3}$/) ? 'Code Search' : 'Full-text'}
            </Badge>
          )}
        </div>
      </div>

      {/* Phase 3: Analytics & Trending Section */}
      {(popularInstruments.length > 0 || trendingInstruments.length > 0) && (
        <div className="mb-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-gray-900">Popular & Trending</h3>
            <div className="flex items-center space-x-2">
              <Badge variant="outline">{popularInstruments.length} Popular</Badge>
              <Badge variant="outline">{trendingInstruments.length} Trending</Badge>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Popular This Week */}
            {popularInstruments.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center">
                    <TrendingUp className="h-4 w-4 mr-2 text-green-600" />
                    Popular This Week
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {popularInstruments.slice(0, 3).map((instrument, index) => (
                      <div key={instrument.id} className="flex items-center justify-between p-2 rounded hover:bg-gray-50">
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-medium text-gray-500">#{index + 1}</span>
                          <button 
                            onClick={() => {
                              setSelectedInstrument(instrument);
                              setShowInstrumentDetails(true);
                            }}
                            className="text-sm font-medium text-blue-600 hover:text-blue-800 text-left"
                          >
                            {instrument.title.length > 40 ? `${instrument.title.substring(0, 40)}...` : instrument.title}
                          </button>
                        </div>
                        <div className="flex items-center space-x-1 text-xs text-gray-500">
                          <Eye className="h-3 w-3" />
                          <span>{instrument.view_count || 0}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
            
            {/* Trending */}
            {trendingInstruments.length > 0 && (
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base flex items-center">
                    <Zap className="h-4 w-4 mr-2 text-orange-600" />
                    Trending Now
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {trendingInstruments.slice(0, 3).map((instrument, index) => (
                      <div key={instrument.id} className="flex items-center justify-between p-2 rounded hover:bg-gray-50">
                        <div className="flex items-center space-x-2">
                          <span className="text-xs font-medium text-gray-500">#{index + 1}</span>
                          <button 
                            onClick={() => {
                              setSelectedInstrument(instrument);
                              setShowInstrumentDetails(true);
                            }}
                            className="text-sm font-medium text-blue-600 hover:text-blue-800 text-left"
                          >
                            {instrument.title.length > 40 ? `${instrument.title.substring(0, 40)}...` : instrument.title}
                          </button>
                        </div>
                        <div className="flex items-center space-x-1 text-xs text-gray-500">
                          <Download className="h-3 w-3" />
                          <span>{instrument.downloads || 0}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      )}

      {/* PERSONALIZED DASHBOARD SECTION */}
      {personalizedDashboard && (
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
              <User className="h-5 w-5 text-blue-600" />
              <span>Your Personalized Dashboard</span>
            </h3>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowProfileDialog(true)}
              className="text-blue-600 border-blue-300"
            >
              <Settings className="h-4 w-4 mr-2" />
              Profile & Settings
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Clock className="h-4 w-4 text-green-600" />
                  <div>
                    <p className="text-xs text-gray-500">This Week</p>
                    <p className="font-semibold">{personalizedDashboard.quick_stats?.instruments_this_week || 0} reads</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Bookmark className="h-4 w-4 text-blue-600" />
                  <div>
                    <p className="text-xs text-gray-500">Bookmarks</p>
                    <p className="font-semibold">{personalizedDashboard.quick_stats?.total_bookmarks || 0}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Edit3 className="h-4 w-4 text-purple-600" />
                  <div>
                    <p className="text-xs text-gray-500">Notes</p>
                    <p className="font-semibold">{personalizedDashboard.quick_stats?.total_notes || 0}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <TrendingUp className="h-4 w-4 text-orange-600" />
                  <div>
                    <p className="text-xs text-gray-500">Progress</p>
                    <p className="font-semibold">{continueReading.length} ongoing</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Continue Reading Section */}
          {continueReading.length > 0 && (
            <div className="mb-6">
              <h4 className="font-medium text-gray-900 mb-3 flex items-center space-x-2">
                <BookOpen className="h-4 w-4" />
                <span>Continue Reading</span>
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {continueReading.slice(0, 3).map((item) => (
                  <Card key={item.id} className="hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-4">
                      <h5 className="font-medium text-sm mb-2 line-clamp-2">{item.instrument_title}</h5>
                      <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full" 
                          style={{ width: `${item.progress_percentage}%` }}
                        ></div>
                      </div>
                      <p className="text-xs text-gray-500">{Math.round(item.progress_percentage)}% complete</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Personalized Recommendations */}
          {recommendations.length > 0 && (
            <div>
              <h4 className="font-medium text-gray-900 mb-3 flex items-center space-x-2">
                <Target className="h-4 w-4" />
                <span>Recommended for You</span>
                <Badge variant="outline" className="text-xs">
                  Based on {recommendationReason.role_based} interests
                </Badge>
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {recommendations.slice(0, 4).map((rec) => (
                  <Card key={rec.id} className="hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-4">
                      <h5 className="font-medium text-sm mb-2 line-clamp-2">{rec.title}</h5>
                      <p className="text-xs text-gray-500 mb-2 line-clamp-2">{rec.description}</p>
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className="text-xs">{rec.category}</Badge>
                        <div className="flex items-center space-x-1">
                          <Star className="h-3 w-3 text-yellow-500 fill-current" />
                          <span className="text-xs">{rec.rating || 0}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredInstruments.map((instrument) => {
          const IconComponent = getCategoryIcon(instrument.category);
          const ContentIcon = getContentTypeIcon(instrument.content_type);
          const FileFormatIcon = getFileFormatIcon(instrument.file_format);
          
          return (
            <Card key={instrument.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-2">
                    <IconComponent className="h-5 w-5 text-blue-600" />
                    <div className="flex-1">
                      <CardTitle className="text-base line-clamp-2">{instrument.title}</CardTitle>
                      <p className="text-xs text-gray-500 mt-1">
                        by {instrument.created_by_name} • {instrument.language === 'el' ? '🇬🇷' : '🌍'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className={getComplexityColor(instrument.complexity_level)}>
                      {instrument.complexity_level}
                    </Badge>
                    {userBookmarks.includes(instrument.id) && (
                      <Bookmark className="h-4 w-4 text-yellow-500 fill-current" />
                    )}
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <p className="text-sm text-gray-600 mb-3 line-clamp-2">{instrument.description}</p>
                
                {/* READING PROGRESS BAR */}
                {readingProgress[instrument.id] && readingProgress[instrument.id].progress_percentage > 0 && (
                  <div className="mb-3">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-gray-500">Reading Progress</span>
                      <span className="text-xs text-blue-600 font-medium">
                        {Math.round(readingProgress[instrument.id].progress_percentage)}%
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-1.5">
                      <div 
                        className="bg-blue-600 h-1.5 rounded-full transition-all duration-300" 
                        style={{ width: `${readingProgress[instrument.id].progress_percentage}%` }}
                      ></div>
                    </div>
                    {readingProgress[instrument.id].completed && (
                      <div className="flex items-center space-x-1 mt-1">
                        <CheckCircle className="h-3 w-3 text-green-500" />
                        <span className="text-xs text-green-600">Completed</span>
                      </div>
                    )}
                  </div>
                )}
                
                <div className="space-y-2 mb-4">
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <div className="flex items-center space-x-1">
                      <ContentIcon className="h-3 w-3" />
                      <span>{instrument.content_type.replace('_', ' ')}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <FileFormatIcon className="h-3 w-3" />
                      <span>{instrument.file_format?.toUpperCase()}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <div className="flex items-center space-x-1">
                      <Download className="h-3 w-3" />
                      <span>{instrument.downloads} downloads</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-3 w-3" />
                      <span>{new Date(instrument.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <div className="flex items-center space-x-1">
                      <Eye className="h-3 w-3" />
                      <span>{instrument.view_count || 0} views</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Bookmark className="h-3 w-3" />
                      <span>{instrument.bookmarks || 0} bookmarks</span>
                    </div>
                  </div>
                </div>

                {/* Tags */}
                {instrument.tags && instrument.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-3">
                    {instrument.tags.slice(0, 3).map((tag, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                    {instrument.tags.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{instrument.tags.length - 3}
                      </Badge>
                    )}
                  </div>
                )}

                {/* Rating */}
                <div className="mb-3">
                  <StarRating 
                    rating={instrument.rating || 0} 
                    onRate={(rating) => handleRateInstrument(instrument.id, rating)}
                    readonly={user.role === 'investor'}
                  />
                </div>

                {/* Actions */}
                <div className="space-y-2">
                  {/* Main Action Buttons */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-1 flex-wrap gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={async () => {
                          setSelectedInstrument(instrument);
                          setShowInstrumentDetails(true);
                          recordView(instrument.id);
                          
                          // Track reading progress
                          const currentProgress = await getReadingProgress(instrument.id);
                          if (!currentProgress.completed) {
                            trackReadingProgress(instrument.id, {
                              progress_percentage: Math.max(currentProgress.progress_percentage || 0, 5),
                              time_spent_seconds: (currentProgress.time_spent_seconds || 0) + 30,
                              last_position: "viewing_details",
                              completed: false
                            });
                          }
                        }}
                      >
                        <Eye className="h-3 w-3 mr-1" />
                        View
                      </Button>
                      
                      {/* Phase 2: File Viewer Button */}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={async () => {
                          openFileViewer(instrument.id);
                          
                          // Track reading session start
                          const currentProgress = await getReadingProgress(instrument.id);
                          trackReadingProgress(instrument.id, {
                            progress_percentage: Math.max(currentProgress.progress_percentage || 0, 10),
                            time_spent_seconds: (currentProgress.time_spent_seconds || 0) + 60,
                            last_position: "reading_content",
                            completed: false
                          });
                        }}
                        title="View/Read content inline"
                      >
                        <PlayCircle className="h-3 w-3 mr-1" />
                        Read
                      </Button>
                      
                      <Button
                        size="sm"
                        onClick={() => handleDownloadInstrument(instrument.id)}
                      >
                        <Download className="h-3 w-3 mr-1" />
                        Download
                      </Button>
                      
                      {/* Phase 2: Discussion Button */}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          fetchDiscussions(instrument.id);
                          setSelectedInstrument(instrument);
                          setShowDiscussionDialog(true);
                        }}
                        title="Join discussion about this instrument"
                      >
                        <MessageCircle className="h-3 w-3 mr-1" />
                        Discuss
                      </Button>
                      
                      <Button
                        size="sm"
                        variant={userBookmarks.includes(instrument.id) ? "default" : "outline"}
                        onClick={() => handleBookmarkToggle(instrument.id)}
                      >
                        <Bookmark className={`h-3 w-3 mr-1 ${userBookmarks.includes(instrument.id) ? 'fill-current' : ''}`} />
                        {userBookmarks.includes(instrument.id) ? 'Saved' : 'Save'}
                      </Button>
                      
                      {/* Personal Notes Button */}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedInstrument(instrument);
                          fetchUserNotes(instrument.id);
                          setShowNotesDialog(true);
                        }}
                        title="View/Add personal notes"
                        className="text-purple-600 hover:bg-purple-50 border-purple-300"
                      >
                        <Edit3 className="h-3 w-3 mr-1" />
                        Notes
                        {/* Show notes count if any exist */}
                        {userNotes.filter(note => note.instrument_id === instrument.id).length > 0 && (
                          <Badge variant="secondary" className="ml-1 h-4 w-4 p-0 flex items-center justify-center text-xs">
                            {userNotes.filter(note => note.instrument_id === instrument.id).length}
                          </Badge>
                        )}
                      </Button>
                    </div>
                  </div>

                  {/* Admin Actions Row - Always visible for admins */}
                  {user?.role === 'administrator' && (
                    <div className="flex items-center justify-between pt-2 border-t border-gray-100">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs text-gray-500 font-medium">Admin Actions:</span>
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-blue-600 hover:bg-blue-50 border-blue-300 font-bold"
                          title="Edit Financial Instrument"
                          onClick={() => {
                            setEditingInstrument(instrument.id);
                            const metadata = instrument.metadata || {};
                            setUploadForm({
                              title: instrument.title,
                              description: instrument.description,
                              detailed_description: instrument.detailed_description || '',
                              category: instrument.category,
                              subcategory: instrument.subcategory || '',
                              content_type: instrument.content_type || 'financial_instrument',
                              file_format: instrument.file_format || 'pdf',
                              language: instrument.language || 'en',
                              tags: instrument.tags?.join(', ') || '',
                              keywords: instrument.keywords?.join(', ') || '',
                              authors: instrument.authors?.join(', ') || '',
                              publisher: instrument.publisher || '',
                              isbn_doi: instrument.isbn_doi || '',
                              legal_framework: instrument.legal_framework || '',
                              jurisdiction: instrument.jurisdiction || '',
                              journal_name: instrument.journal_name || '',
                              volume_issue: instrument.volume_issue || '',
                              is_peer_reviewed: instrument.is_peer_reviewed || false,
                              nda_required: instrument.nda_required || false,
                              target_audience: metadata?.target_audience || [],
                              complexity_level: metadata?.complexity_level || 'medium',
                              estimated_reading_time: metadata?.estimated_reading_time || '',
                              prerequisites: metadata?.prerequisites?.join(', ') || '',
                              sdg_alignment: metadata?.sdg_alignment?.join(', ') || '',
                              estimated_duration: instrument.estimated_duration || '',
                              budget_range: instrument.budget_range || ''
                            });
                            setShowUploadDialog(true);
                          }}
                        >
                          <Edit3 className="h-3 w-3 mr-1" />
                          EDIT
                        </Button>
                        
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeleteInstrument(instrument.id)}
                          className="text-red-600 hover:bg-red-50 border-red-300 font-bold"
                          title="Delete Financial Instrument"
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          DELETE
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Empty State */}
      {filteredInstruments.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Library className="h-16 w-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No financial instruments found</h3>
            <p className="text-gray-500 mb-4">
              {searchTerm || selectedCategory !== 'all' 
                ? 'No financial instruments match your current filters' 
                : 'The electronic library is empty'}
            </p>
            {user.role === 'administrator' && !searchTerm && selectedCategory === 'all' && (
              <Button onClick={() => setShowUploadDialog(true)}>
                <Upload className="h-4 w-4 mr-2" />
                Upload First Financial Instrument
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Instrument Details Dialog */}
      <Dialog open={showInstrumentDetails} onOpenChange={setShowInstrumentDetails}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              {selectedInstrument && (
                <>
                  {React.createElement(getCategoryIcon(selectedInstrument.category), { className: 'h-6 w-6' })}
                  <span>{selectedInstrument.title}</span>
                </>
              )}
            </DialogTitle>
          </DialogHeader>
          {selectedInstrument && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Description</Label>
                    <p className="text-sm text-gray-900">{selectedInstrument.description}</p>
                    {selectedInstrument.detailed_description && (
                      <div className="mt-2">
                        <Label className="text-sm font-medium text-gray-700">Detailed Description</Label>
                        <p className="text-sm text-gray-900 mt-1">{selectedInstrument.detailed_description}</p>
                      </div>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Category</Label>
                      <p className="text-sm text-gray-900">
                        {categories.find(cat => cat.id === selectedInstrument.category)?.name || selectedInstrument.category}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Content Type</Label>
                      <p className="text-sm text-gray-900">{selectedInstrument.content_type.replace('_', ' ')}</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Complexity</Label>
                      <Badge className={getComplexityColor(selectedInstrument.complexity_level)}>
                        {selectedInstrument.complexity_level}
                      </Badge>
                    </div>
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Language</Label>
                      <p className="text-sm text-gray-900">
                        {selectedInstrument.language === 'el' ? 'Greek 🇬🇷' : 'English 🌍'}
                      </p>
                    </div>
                  </div>

                  {/* Missing Feature: Standardized Coding System */}
                  {selectedInstrument.standardized_code && (
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Standardized Code</Label>
                      <div className="flex items-center space-x-2 mt-1">
                        <Badge variant="outline" className="font-mono">
                          {selectedInstrument.standardized_code}
                        </Badge>
                        {selectedInstrument.instrument_classification && (
                          <span className="text-xs text-gray-500">
                            v{selectedInstrument.instrument_classification.version}
                          </span>
                        )}
                      </div>
                      {selectedInstrument.classification_tags && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {selectedInstrument.classification_tags.map((tag, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {tag}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Document Structure Info */}
                  {selectedInstrument.document_structure && (
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Document Structure</Label>
                      <div className="text-sm text-gray-900 mt-1">
                        <div className="flex items-center space-x-4">
                          <span>{selectedInstrument.document_structure.total_pages} pages</span>
                          <span>{selectedInstrument.document_structure.chapters?.length || 0} chapters</span>
                          {selectedInstrument.document_structure.has_glossary && (
                            <Badge variant="outline" className="text-xs">Glossary</Badge>
                          )}
                          {selectedInstrument.document_structure.has_appendices && (
                            <Badge variant="outline" className="text-xs">Appendices</Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Authors and Publication Info */}
                  {selectedInstrument.authors && selectedInstrument.authors.length > 0 && (
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Authors</Label>
                      <p className="text-sm text-gray-900">{selectedInstrument.authors.join(', ')}</p>
                    </div>
                  )}

                  {selectedInstrument.publisher && (
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Publisher</Label>
                      <p className="text-sm text-gray-900">{selectedInstrument.publisher}</p>
                    </div>
                  )}
                </div>
                
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">Statistics</Label>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>Downloads: {selectedInstrument.downloads}</div>
                      <div>Rating: {(selectedInstrument.rating || 0).toFixed(1)}/5</div>
                      <div>Views: {selectedInstrument.view_count || 0}</div>
                      <div>Bookmarks: {selectedInstrument.bookmarks || 0}</div>
                      <div>File Size: {formatFileSize(selectedInstrument.file_size || 0)}</div>
                      <div>Version: {selectedInstrument.version || '1.0'}</div>
                    </div>
                  </div>

                  {selectedInstrument.file_format && (
                    <div>
                      <Label className="text-sm font-medium text-gray-700">File Format</Label>
                      <p className="text-sm text-gray-900">{selectedInstrument.file_format.toUpperCase()}</p>
                    </div>
                  )}

                  {selectedInstrument.legal_framework && (
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Legal Framework</Label>
                      <p className="text-sm text-gray-900">{selectedInstrument.legal_framework}</p>
                    </div>
                  )}

                  {selectedInstrument.metadata?.sdg_alignment && selectedInstrument.metadata.sdg_alignment.length > 0 && (
                    <div>
                      <Label className="text-sm font-medium text-gray-700">SDG Alignment</Label>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {selectedInstrument.metadata.sdg_alignment.map((sdg) => (
                          <Badge key={sdg} variant="outline" className="text-xs">
                            SDG {sdg}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              {selectedInstrument.tags && selectedInstrument.tags.length > 0 && (
                <div>
                  <Label className="text-sm font-medium text-gray-700">Tags</Label>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {selectedInstrument.tags.map((tag, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="flex justify-between items-center pt-4 border-t">
                <div className="text-sm text-gray-500">
                  Created by {selectedInstrument.created_by_name} on {new Date(selectedInstrument.created_at).toLocaleDateString()}
                </div>
                <div className="flex items-center space-x-2">
                  <Button onClick={() => handleDownloadInstrument(selectedInstrument.id)}>
                    <Download className="h-4 w-4 mr-2" />
                    Download Financial Instrument
                  </Button>
                  
                  {/* Missing Feature: Citation Management */}
                  <Button 
                    variant="outline"
                    onClick={async () => {
                      try {
                        const response = await axios.get(`${BACKEND_URL}/api/template-library/${selectedInstrument.id}/citation?format=all`);
                        const citations = response.data.citations || response.data.all_formats;
                        
                        // Create a simple dialog showing citation formats
                        const citationText = `
APA: ${citations.apa}

MLA: ${citations.mla}

Chicago: ${citations.chicago}

Harvard: ${citations.harvard}

Vancouver: ${citations.vancouver}
                        `;
                        
                        // Copy to clipboard and show in alert (in real app, would use proper dialog)
                        navigator.clipboard.writeText(citationText);
                        alert('Citations copied to clipboard!\n\n' + citationText);
                        toast.success('Citations copied to clipboard!');
                      } catch (error) {
                        console.error('Error fetching citations:', error);
                        toast.error('Failed to generate citations');
                      }
                    }}
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Cite This
                  </Button>

                  {/* Reading Statistics Button */}
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={async () => {
                      try {
                        const response = await axios.get(`${BACKEND_URL}/api/template-library/reading-statistics`);
                        const stats = response.data.statistics;
                        const achievements = response.data.achievements;
                        
                        const statsText = `Your Reading Statistics:
📚 Total Reading Time: ${stats.total_reading_time || 0} minutes
📖 Documents Completed: ${stats.documents_read || 0}
⭐ Total Sessions: ${stats.total_sessions || 0}

Achievements: ${achievements.map(a => `${a.icon} ${a.name}`).join(', ') || 'None yet'}`;
                        
                        alert(statsText);
                      } catch (error) {
                        console.error('Error fetching reading stats:', error);
                        toast.error('Failed to load reading statistics');
                      }
                    }}
                  >
                    <BarChart3 className="h-4 w-4 mr-2" />
                    My Stats
                  </Button>
                </div>
              </div>

              {/* Comments for the instrument */}
              <div className="pt-4 border-t">
                <UniversalComments 
                  projectId="template_library" 
                  user={user} 
                  itemType="template" 
                  itemId={selectedInstrument.id}
                  title={`Comments for ${selectedInstrument.title}`} 
                />
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* General Template Library Comments */}
      <div className="mt-8">
        <UniversalComments 
          projectId="template_library" 
          user={user} 
          itemType="template_library" 
          title="Electronic Library Feedback & Suggestions" 
        />
      </div>

      {/* Phase 2: Discussion Dialog */}
      <Dialog open={showDiscussionDialog} onOpenChange={setShowDiscussionDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <MessageSquare className="h-5 w-5 text-blue-600" />
              <span>Discussion: {selectedInstrument?.title}</span>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {discussions.length > 0 ? (
              <div className="space-y-4">
                {discussions.map(discussion => (
                  <Card key={discussion.id}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-medium">{discussion.title}</h4>
                        <Badge className={discussion.language === 'el' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'}>
                          {discussion.language === 'el' ? '🇬🇷 Greek' : '🌍 English'}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{discussion.content}</p>
                      {discussion.content_el && discussion.content_el !== discussion.content && (
                        <p className="text-sm text-gray-600 mb-2 border-l-2 border-blue-200 pl-2">{discussion.content_el}</p>
                      )}
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <div className="flex items-center space-x-4">
                          <span>by {discussion.author_name}</span>
                          <span>{new Date(discussion.created_at).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span>{discussion.replies_count} replies</span>
                          <span>{discussion.likes_count} likes</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No discussions yet</h3>
                <p className="text-gray-500">Be the first to start a discussion about this financial instrument!</p>
              </div>
            )}
            
            {/* New Discussion Form */}
            <div className="border-t pt-4">
              <h4 className="font-medium mb-3">Start a new discussion</h4>
              <div className="space-y-3">
                <Input placeholder="Discussion title" />
                <textarea 
                  className="w-full p-3 border rounded-md resize-none" 
                  rows="3" 
                  placeholder="What would you like to discuss about this financial instrument?"
                ></textarea>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Select defaultValue="en">
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">🌍 English</SelectItem>
                        <SelectItem value="el">🇬🇷 Greek</SelectItem>
                        <SelectItem value="multilingual">🌐 Both</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button>
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Post Discussion
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Phase 2: File Viewer Dialog */}
      <Dialog open={showFileViewerDialog} onOpenChange={(open) => {
        setShowFileViewerDialog(open);
        if (!open && currentViewingFile?.blob_url) {
          // Cleanup blob URL when dialog closes
          window.URL.revokeObjectURL(currentViewingFile.blob_url);
        }
      }}>
        <DialogContent className="max-w-6xl max-h-[95vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <PlayCircle className="h-5 w-5 text-blue-600" />
                <span>{currentViewingFile?.title}</span>
                <Badge variant="outline">{currentViewingFile?.file_format?.toUpperCase()}</Badge>
              </div>
              <div className="flex items-center space-x-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => openInNewTab(currentViewingFile?.instrumentId)}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Open in New Tab
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleDownloadInstrument(currentViewingFile?.instrumentId)}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              </div>
            </DialogTitle>
          </DialogHeader>
          <div className="flex-1 min-h-[60vh] bg-gray-50 rounded-lg">
            {currentViewingFile ? (
              <div className="h-full">
                {/* Embed actual file content */}
                {currentViewingFile.file_format === 'pdf' && (
                  <div className="h-full relative">
                    <iframe
                      src={currentViewingFile.file_url}
                      className="w-full h-full rounded-lg border-0"
                      title={currentViewingFile.title}
                      onError={(e) => {
                        // Show fallback message if PDF fails to load
                        const iframe = e.target;
                        iframe.style.display = 'none';
                        const fallback = iframe.parentElement.querySelector('.pdf-fallback');
                        if (fallback) fallback.style.display = 'block';
                      }}
                    />
                    <div className="pdf-fallback absolute inset-0 flex items-center justify-center bg-gray-50 rounded-lg" style={{display: 'none'}}>
                      <div className="text-center">
                        <FileText className="h-16 w-16 text-red-500 mx-auto mb-4" />
                        <h3 className="text-lg font-medium mb-2">PDF Viewer</h3>
                        <p className="text-gray-600 mb-4">
                          Unable to display PDF inline. Please use the buttons below to access the file.
                        </p>
                        <div className="space-x-2">
                          <Button onClick={() => openInNewTab(currentViewingFile?.instrumentId)}>
                            <ExternalLink className="h-4 w-4 mr-2" />
                            Open in New Tab
                          </Button>
                          <Button onClick={() => handleDownloadInstrument(currentViewingFile?.instrumentId)}>
                            <Download className="h-4 w-4 mr-2" />
                            Download
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                {currentViewingFile.file_format === 'wmv' && (
                  <div className="h-full flex items-center justify-center">
                    <div className="text-center max-w-md">
                      <Video className="h-20 w-20 text-purple-500 mx-auto mb-4" />
                      <h3 className="text-xl font-medium mb-2">WMV Video File</h3>
                      <p className="text-gray-600 mb-4">
                        WMV format cannot be played directly in the browser. Please download the file to play it with your media player.
                      </p>
                      <div className="space-x-2">
                        <Button onClick={() => handleDownloadInstrument(currentViewingFile?.instrumentId)}>
                          <Download className="h-4 w-4 mr-2" />
                          Download Video
                        </Button>
                        <Button variant="outline" onClick={() => openInNewTab(currentViewingFile?.instrumentId)}>
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Open in New Tab
                        </Button>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        Supports: Windows Media Player, VLC, and other media players
                      </p>
                    </div>
                  </div>
                )}
                {currentViewingFile.file_format === 'wma' && (
                  <div className="flex items-center justify-center h-full">
                    <div className="text-center max-w-md">
                      <Volume2 className="h-20 w-20 text-green-500 mx-auto mb-4" />
                      <h3 className="text-xl font-medium mb-2">WMA Audio File</h3>
                      <p className="text-gray-600 mb-4">
                        WMA format cannot be played directly in the browser. Please download the file to play it with your audio player.
                      </p>
                      <div className="space-x-2">
                        <Button onClick={() => handleDownloadInstrument(currentViewingFile?.instrumentId)}>
                          <Download className="h-4 w-4 mr-2" />
                          Download Audio
                        </Button>
                        <Button variant="outline" onClick={() => openInNewTab(currentViewingFile?.instrumentId)}>
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Open in New Tab
                        </Button>
                      </div>
                      <p className="text-xs text-gray-500 mt-2">
                        Supports: Windows Media Player, VLC, and other audio players
                      </p>
                    </div>
                  </div>
                )}
                {!['pdf', 'wmv', 'wma'].includes(currentViewingFile.file_format) && (
                  <div className="text-center flex items-center justify-center h-full">
                    <div>
                      <div className="mb-4">
                        <FileText className="h-16 w-16 text-gray-500 mx-auto mb-4" />
                      </div>
                      <h3 className="text-lg font-medium mb-2">{currentViewingFile.file_format?.toUpperCase()} File</h3>
                      <p className="text-gray-600 mb-4">
                        This file format cannot be previewed inline. Please download to view.
                      </p>
                      <div className="space-x-2">
                        <Button onClick={() => openInNewTab(currentViewingFile?.instrumentId)}>
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Open in New Tab
                        </Button>
                        <Button 
                          variant="outline"
                          onClick={() => handleDownloadInstrument(currentViewingFile?.instrumentId)}
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Download
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center flex items-center justify-center h-full">
                <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Loading file viewer...</p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Phase 3: Collection Dialog */}
      <Dialog open={showCollectionDialog} onOpenChange={setShowCollectionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <FolderPlus className="h-5 w-5 text-blue-600" />
              <span>Create New Collection</span>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Collection Name</Label>
              <Input placeholder="My Reading List" />
            </div>
            <div>
              <Label>Collection Name (Greek) - Optional</Label>
              <Input placeholder="Η Λίστα Ανάγνωσής Μου" />
            </div>
            <div>
              <Label>Description</Label>
              <textarea 
                className="w-full p-3 border rounded-md resize-none" 
                rows="3" 
                placeholder="Describe what this collection is for..."
              ></textarea>
            </div>
            <div className="flex items-center space-x-2">
              <input type="checkbox" id="public" />
              <Label htmlFor="public">Make this collection public</Label>
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowCollectionDialog(false)}>
                Cancel
              </Button>
              <Button>
                <FolderPlus className="h-4 w-4 mr-2" />
                Create Collection
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* PERSONAL NOTES DIALOG */}
      <Dialog open={showNotesDialog} onOpenChange={setShowNotesDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Edit3 className="h-5 w-5 text-purple-600" />
              <span>Personal Notes - {selectedInstrument?.title}</span>
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Add New Note */}
            <div className="border rounded-lg p-4 bg-purple-50">
              <h4 className="font-medium mb-3">Add New Note</h4>
              <div className="space-y-3">
                <div>
                  <Label>Note Content</Label>
                  <Textarea
                    value={newNote.content}
                    onChange={(e) => setNewNote(prev => ({ ...prev, content: e.target.value }))}
                    placeholder="Write your note here..."
                    className="min-h-[80px]"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Tags (comma-separated)</Label>
                    <Input
                      value={newNote.tags.join(', ')}
                      onChange={(e) => setNewNote(prev => ({ 
                        ...prev, 
                        tags: e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag) 
                      }))}
                      placeholder="important, review, action-item"
                    />
                  </div>
                  <div>
                    <Label>Note Type</Label>
                    <Select 
                      value={newNote.note_type} 
                      onValueChange={(value) => setNewNote(prev => ({ ...prev, note_type: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General Note</SelectItem>
                        <SelectItem value="highlight">Highlight</SelectItem>
                        <SelectItem value="question">Question</SelectItem>
                        <SelectItem value="action">Action Item</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button 
                  onClick={() => createNote(selectedInstrument?.id, newNote)}
                  disabled={!newNote.content.trim()}
                  className="w-full"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Note
                </Button>
              </div>
            </div>
            
            {/* Existing Notes */}
            <div>
              <h4 className="font-medium mb-3">Your Notes ({selectedInstrumentNotes.length})</h4>
              <div className="space-y-3">
                {selectedInstrumentNotes.length === 0 ? (
                  <p className="text-gray-500 text-center py-8">No notes yet. Add your first note above!</p>
                ) : (
                  selectedInstrumentNotes.map((note) => (
                    <Card key={note.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <Badge variant="outline" className="text-xs">
                                {note.note_type}
                              </Badge>
                              <span className="text-xs text-gray-500">
                                {new Date(note.created_at).toLocaleDateString()}
                              </span>
                            </div>
                            <p className="text-sm mb-2">{note.content}</p>
                            {note.tags && note.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1">
                                {note.tags.map((tag, index) => (
                                  <Badge key={index} variant="secondary" className="text-xs">
                                    #{tag}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteNote(note.id)}
                            className="text-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* USER PROFILE & PREFERENCES DIALOG */}
      <Dialog open={showProfileDialog} onOpenChange={setShowProfileDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <User className="h-5 w-5 text-blue-600" />
              <span>Your Profile & Preferences</span>
            </DialogTitle>
          </DialogHeader>
          
          {userProfile && (
            <div className="space-y-6">
              {/* User Statistics */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <BookOpen className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                    <h4 className="font-medium">Instruments Read</h4>
                    <p className="text-2xl font-bold text-blue-600">
                      {userProfile.reading_statistics?.total_instruments_accessed || 0}
                    </p>
                    <p className="text-xs text-gray-500">
                      {userProfile.reading_statistics?.completed_instruments || 0} completed
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4 text-center">
                    <Clock className="h-8 w-8 text-green-600 mx-auto mb-2" />
                    <h4 className="font-medium">Reading Time</h4>
                    <p className="text-2xl font-bold text-green-600">
                      {userProfile.reading_statistics?.total_reading_time_hours || 0}h
                    </p>
                    <p className="text-xs text-gray-500">Total time spent</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4 text-center">
                    <Target className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                    <h4 className="font-medium">Completion Rate</h4>
                    <p className="text-2xl font-bold text-purple-600">
                      {userProfile.reading_statistics?.average_completion_rate || 0}%
                    </p>
                    <p className="text-xs text-gray-500">Average progress</p>
                  </CardContent>
                </Card>
              </div>

              {/* Favorite Categories */}
              {userProfile.favorite_categories && userProfile.favorite_categories.length > 0 && (
                <div>
                  <h4 className="font-medium mb-3">Your Favorite Categories</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {userProfile.favorite_categories.map((cat, index) => (
                      <Card key={index}>
                        <CardContent className="p-3">
                          <div className="flex justify-between items-center">
                            <span className="font-medium text-sm">{cat._id}</span>
                            <Badge variant="outline">{cat.count} reads</Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {/* Preferences Settings */}
              <div>
                <h4 className="font-medium mb-4">Preferences</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Notification Settings */}
                  <Card>
                    <CardContent className="p-4">
                      <h5 className="font-medium mb-3">Notifications</h5>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm">New instruments</span>
                          <input
                            type="checkbox"
                            checked={userPreferences.notification_settings?.new_instruments}
                            onChange={(e) => setUserPreferences(prev => ({
                              ...prev,
                              notification_settings: {
                                ...prev.notification_settings,
                                new_instruments: e.target.checked
                              }
                            }))}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Recommendations</span>
                          <input
                            type="checkbox"
                            checked={userPreferences.notification_settings?.recommendations}
                            onChange={(e) => setUserPreferences(prev => ({
                              ...prev,
                              notification_settings: {
                                ...prev.notification_settings,
                                recommendations: e.target.checked
                              }
                            }))}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm">Discussion replies</span>
                          <input
                            type="checkbox"
                            checked={userPreferences.notification_settings?.discussion_replies}
                            onChange={(e) => setUserPreferences(prev => ({
                              ...prev,
                              notification_settings: {
                                ...prev.notification_settings,
                                discussion_replies: e.target.checked
                              }
                            }))}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Display Settings */}
                  <Card>
                    <CardContent className="p-4">
                      <h5 className="font-medium mb-3">Display</h5>
                      <div className="space-y-3">
                        <div>
                          <Label className="text-sm">Items per page</Label>
                          <Select 
                            value={userPreferences.display_preferences?.items_per_page?.toString() || "12"}
                            onValueChange={(value) => setUserPreferences(prev => ({
                              ...prev,
                              display_preferences: {
                                ...prev.display_preferences,
                                items_per_page: parseInt(value)
                              }
                            }))}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="6">6 items</SelectItem>
                              <SelectItem value="12">12 items</SelectItem>
                              <SelectItem value="24">24 items</SelectItem>
                              <SelectItem value="48">48 items</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label className="text-sm">Default sort</Label>
                          <Select 
                            value={userPreferences.display_preferences?.sort_default || "newest"}
                            onValueChange={(value) => setUserPreferences(prev => ({
                              ...prev,
                              display_preferences: {
                                ...prev.display_preferences,
                                sort_default: value
                              }
                            }))}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="newest">Newest first</SelectItem>
                              <SelectItem value="oldest">Oldest first</SelectItem>
                              <SelectItem value="most_popular">Most popular</SelectItem>
                              <SelectItem value="highest_rated">Highest rated</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Save Button */}
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setShowProfileDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={() => updateUserPreferences(userPreferences)}>
                  <Settings className="h-4 w-4 mr-2" />
                  Save Preferences
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default TemplateLibrary;