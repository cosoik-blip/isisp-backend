import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { 
  TrendingUp, 
  DollarSign, 
  Target, 
  Users, 
  Globe, 
  Leaf, 
  Building, 
  Calculator,
  BarChart3,
  CheckCircle2,
  Plus,
  Edit,
  Save,
  RefreshCw,
  Award,
  Zap,
  Heart,
  Shield
} from 'lucide-react';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const SROICalculator = ({ projectId, user }) => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(false);
  
  // Data states
  const [dashboardData, setDashboardData] = useState({});
  const [sroiData, setSroiData] = useState({});
  const [tocData, setTocData] = useState({});
  const [sdgsData, setSdgsData] = useState({});
  const [esgData, setEsgData] = useState({});
  
  // Editing states
  const [editingSroi, setEditingSroi] = useState(false);
  const [editingToc, setEditingToc] = useState(false);

  useEffect(() => {
    fetchAllData();
  }, [projectId]);

  const fetchAllData = async () => {
    setLoading(true);
    try {
      const [dashboardRes, sroiRes, tocRes, sdgsRes, esgRes] = await Promise.all([
        axios.get(`${API}/projects/${projectId}/impact-dashboard`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/sroi-calculation`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/theory-of-change`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/sdgs-alignment`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/esg-indicators`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        })
      ]);
      
      setDashboardData(dashboardRes.data);
      setSroiData(sroiRes.data);
      setTocData(tocRes.data);
      setSdgsData(sdgsRes.data);
      setEsgData(esgRes.data);
    } catch (error) {
      console.error('Failed to fetch impact data:', error);
      toast.error('Failed to load impact data');
    } finally {
      setLoading(false);
    }
  };

  const updateSroiData = async (newSroiData) => {
    try {
      const response = await axios.post(`${API}/projects/${projectId}/sroi-calculation`, newSroiData, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      setSroiData({...sroiData, ...newSroiData, sroi_ratio: response.data.sroi_ratio});
      setEditingSroi(false);
      toast.success('SROI calculation updated successfully');
      
      // Refresh dashboard
      fetchAllData();
    } catch (error) {
      console.error('Failed to update SROI:', error);
      toast.error('Failed to update SROI calculation');
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0
    }).format(amount || 0);
  };

  const getImpactColor = (score) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-blue-600';
    if (score >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getImpactBg = (score) => {
    if (score >= 80) return 'bg-green-100';
    if (score >= 60) return 'bg-blue-100';
    if (score >= 40) return 'bg-yellow-100';
    return 'bg-red-100';
  };

  // Impact Dashboard Tab
  const ImpactDashboard = () => (
    <div className="space-y-6">
      {/* Overall Impact Score */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Award className="h-6 w-6 text-purple-600" />
              <span>Overall Impact Score</span>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={fetchAllData}
              data-testid="refresh-impact-button"
            >
              <RefreshCw className="h-4 w-4 mr-1" />
              Refresh
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center">
            <div className={`text-6xl font-bold ${getImpactColor(dashboardData.overall_impact_score)}`}>
              {dashboardData.overall_impact_score?.toFixed(1) || 0}
            </div>
            <p className="text-gray-600 mt-2">Out of 100 points</p>
            <div className={`inline-block px-4 py-2 rounded-full mt-4 ${getImpactBg(dashboardData.overall_impact_score)}`}>
              <span className={`font-semibold ${getImpactColor(dashboardData.overall_impact_score)}`}>
                {dashboardData.overall_impact_score >= 80 ? 'Exceptional Impact' :
                 dashboardData.overall_impact_score >= 60 ? 'Strong Impact' :
                 dashboardData.overall_impact_score >= 40 ? 'Moderate Impact' : 'Developing Impact'}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Key Impact Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">SROI Ratio</p>
                <p className="text-3xl font-bold text-green-600">
                  {dashboardData.summary?.sroi_ratio?.toFixed(2) || '0.00'}:1
                </p>
                <p className="text-xs text-gray-500">Social return per $ invested</p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">SDGs Aligned</p>
                <p className="text-3xl font-bold text-blue-600">
                  {dashboardData.summary?.aligned_sdgs_count || 0}/17
                </p>
                <p className="text-xs text-gray-500">UN Sustainable Development Goals</p>
              </div>
              <Globe className="h-8 w-8 text-blue-600 opacity-20" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">ESG Score</p>
                <p className="text-3xl font-bold text-purple-600">
                  {dashboardData.summary?.esg_score?.toFixed(1) || '0.0'}
                </p>
                <p className="text-xs text-gray-500">Environmental, Social & Governance</p>
              </div>
              <Shield className="h-8 w-8 text-purple-600 opacity-20" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Impact Summary */}
      <Card>
        <CardHeader>
          <CardTitle>Impact Summary</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-green-700 mb-3">Strengths</h4>
              <div className="space-y-2">
                {dashboardData.summary?.sroi_ratio >= 3 && (
                  <div className="flex items-center space-x-2 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span>Strong SROI ratio demonstrates value creation</span>
                  </div>
                )}
                {dashboardData.summary?.aligned_sdgs_count >= 3 && (
                  <div className="flex items-center space-x-2 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span>Significant SDG alignment across multiple goals</span>
                  </div>
                )}
                {dashboardData.summary?.esg_score >= 75 && (
                  <div className="flex items-center space-x-2 text-sm">
                    <CheckCircle2 className="h-4 w-4 text-green-600" />
                    <span>Excellent ESG performance</span>
                  </div>
                )}
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold text-blue-700 mb-3">Impact Areas</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-sm">
                  <Users className="h-4 w-4 text-blue-600" />
                  <span>Community empowerment and skills development</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <Zap className="h-4 w-4 text-blue-600" />
                  <span>Economic growth and job creation</span>
                </div>
                <div className="flex items-center space-x-2 text-sm">
                  <Heart className="h-4 w-4 text-blue-600" />
                  <span>Social inclusion and equality</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // SROI Calculator Tab
  const SROICalculatorTab = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Calculator className="h-6 w-6 text-green-600" />
              <span>SROI Calculator</span>
            </div>
            <Button
              size="sm"
              variant={editingSroi ? "default" : "outline"}
              onClick={() => setEditingSroi(!editingSroi)}
            >
              {editingSroi ? <Save className="h-4 w-4 mr-1" /> : <Edit className="h-4 w-4 mr-1" />}
              {editingSroi ? 'Save' : 'Edit'}
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            {/* Total Investment */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Total Investment</label>
              {editingSroi ? (
                <Input
                  type="number"
                  value={sroiData.total_investment || 0}
                  onChange={(e) => setSroiData({...sroiData, total_investment: parseFloat(e.target.value)})}
                />
              ) : (
                <div className="text-2xl font-bold text-blue-600">{formatCurrency(sroiData.total_investment)}</div>
              )}
            </div>

            {/* Total Social Value */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Total Social Value</label>
              {editingSroi ? (
                <Input
                  type="number"
                  value={sroiData.total_social_value || 0}
                  onChange={(e) => setSroiData({...sroiData, total_social_value: parseFloat(e.target.value)})}
                />
              ) : (
                <div className="text-2xl font-bold text-green-600">{formatCurrency(sroiData.total_social_value)}</div>
              )}
            </div>

            {/* SROI Ratio */}
            <div className="space-y-2">
              <label className="text-sm font-medium">SROI Ratio</label>
              <div className="text-3xl font-bold text-purple-600">
                {sroiData.sroi_ratio?.toFixed(2) || '0.00'}:1
              </div>
              <p className="text-xs text-gray-500">Return per dollar invested</p>
            </div>
          </div>

          {editingSroi && (
            <div className="flex space-x-2">
              <Button onClick={() => updateSroiData(sroiData)}>
                <Save className="h-4 w-4 mr-1" />
                Save Changes
              </Button>
              <Button variant="outline" onClick={() => setEditingSroi(false)}>
                Cancel
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* SROI Components */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Inputs & Outputs */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Inputs & Outputs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-blue-700 mb-2">Inputs</h4>
                {(sroiData.inputs || []).map((input, index) => (
                  <div key={index} className="text-sm p-2 bg-blue-50 rounded">
                    <div className="font-medium">{input.type}</div>
                    <div className="text-gray-600">{formatCurrency(input.amount)} - {input.description}</div>
                  </div>
                ))}
              </div>
              
              <div>
                <h4 className="font-medium text-green-700 mb-2">Outputs</h4>
                {(sroiData.outputs || []).map((output, index) => (
                  <div key={index} className="text-sm p-2 bg-green-50 rounded">
                    <div className="font-medium">{output.type}</div>
                    <div className="text-gray-600">{output.quantity} - {output.description}</div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Outcomes & Impacts */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Outcomes & Impacts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-purple-700 mb-2">Outcomes</h4>
                {(sroiData.outcomes || []).map((outcome, index) => (
                  <div key={index} className="text-sm p-2 bg-purple-50 rounded">
                    <div className="font-medium">{outcome.type}</div>
                    <div className="text-gray-600">{formatCurrency(outcome.value)} - {outcome.description}</div>
                  </div>
                ))}
              </div>
              
              <div>
                <h4 className="font-medium text-orange-700 mb-2">Impacts</h4>
                {(sroiData.impacts || []).map((impact, index) => (
                  <div key={index} className="text-sm p-2 bg-orange-50 rounded">
                    <div className="font-medium">{impact.type}</div>
                    <div className="text-gray-600">{formatCurrency(impact.value)} - {impact.description}</div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sensitivity Analysis */}
      {sroiData.sensitivity_analysis && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Sensitivity Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {Object.entries(sroiData.sensitivity_analysis).map(([scenario, data]) => (
                <div key={scenario} className="text-center p-4 border rounded-lg">
                  <div className="text-lg font-semibold capitalize">{scenario}</div>
                  <div className="text-2xl font-bold text-purple-600">{data.sroi_ratio}:1</div>
                  <div className="text-sm text-gray-600">{data.description}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );

  // SDGs Alignment Tab
  const SDGsAlignmentTab = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Globe className="h-6 w-6 text-blue-600" />
            <span>UN Sustainable Development Goals Alignment</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600">
                {sdgsData.overall_alignment_score || 0}%
              </div>
              <p className="text-gray-600">Overall SDG Alignment Score</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {(sdgsData.goals || []).map((goal) => (
              <Card key={goal.goal} className={`${goal.aligned ? 'bg-blue-50 border-blue-200' : 'bg-gray-50'}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <div className="font-bold text-blue-600">SDG {goal.goal}</div>
                      <div className="text-sm font-medium">{goal.name}</div>
                    </div>
                    {goal.aligned && (
                      <CheckCircle2 className="h-5 w-5 text-green-600" />
                    )}
                  </div>
                  
                  {goal.aligned && (
                    <div className="space-y-2">
                      <div className="text-xs text-gray-600">
                        Targets: {goal.targets.join(', ')}
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full" 
                          style={{width: `${goal.progress}%`}}
                        ></div>
                      </div>
                      <div className="text-xs text-right text-gray-600">
                        {goal.progress}% Progress
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // ESG Indicators Tab
  const ESGIndicatorsTab = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Shield className="h-6 w-6 text-purple-600" />
              <span>ESG Indicators Dashboard</span>
            </div>
            <div className="text-2xl font-bold text-purple-600">
              {esgData.overall_esg_score || 0}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="environmental" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="environmental" className="flex items-center space-x-1">
                <Leaf className="h-4 w-4" />
                <span>Environmental</span>
              </TabsTrigger>
              <TabsTrigger value="social" className="flex items-center space-x-1">
                <Users className="h-4 w-4" />
                <span>Social</span>
              </TabsTrigger>
              <TabsTrigger value="governance" className="flex items-center space-x-1">
                <Building className="h-4 w-4" />
                <span>Governance</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="environmental" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {esgData.environmental && Object.entries(esgData.environmental).map(([key, indicator]) => (
                  <Card key={key}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-medium capitalize">{key.replace('_', ' ')}</div>
                        <Badge className={indicator.trend === 'improving' ? 'bg-green-100 text-green-800' : 
                                        indicator.trend === 'stable' ? 'bg-blue-100 text-blue-800' : 
                                        'bg-yellow-100 text-yellow-800'}>
                          {indicator.trend}
                        </Badge>
                      </div>
                      <div className="text-2xl font-bold">{indicator.value} {indicator.unit}</div>
                      <div className="text-xs text-gray-500">Target: {indicator.target} {indicator.unit}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="social" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {esgData.social && Object.entries(esgData.social).map(([key, indicator]) => (
                  <Card key={key}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-medium capitalize">{key.replace('_', ' ')}</div>
                        <Badge className={indicator.trend === 'improving' ? 'bg-green-100 text-green-800' : 
                                        indicator.trend === 'stable' ? 'bg-blue-100 text-blue-800' : 
                                        'bg-yellow-100 text-yellow-800'}>
                          {indicator.trend}
                        </Badge>
                      </div>
                      <div className="text-2xl font-bold">{indicator.value} {indicator.unit}</div>
                      <div className="text-xs text-gray-500">Target: {indicator.target} {indicator.unit}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="governance" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {esgData.governance && Object.entries(esgData.governance).map(([key, indicator]) => (
                  <Card key={key}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-medium capitalize">{key.replace('_', ' ')}</div>
                        <Badge className={indicator.trend === 'improving' ? 'bg-green-100 text-green-800' : 
                                        indicator.trend === 'stable' ? 'bg-blue-100 text-blue-800' : 
                                        'bg-yellow-100 text-yellow-800'}>
                          {indicator.trend}
                        </Badge>
                      </div>
                      <div className="text-2xl font-bold">{indicator.value} {indicator.unit}</div>
                      <div className="text-xs text-gray-500">Target: {indicator.target} {indicator.unit}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-8 h-8 border-4 border-purple-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Award className="h-6 w-6 text-purple-600" />
              <span>SROI Calculator & Social Impact Tools</span>
            </div>
            <Button
              size="sm"
              variant="outline"
              onClick={fetchAllData}
              data-testid="refresh-sroi-button"
            >
              <RefreshCw className="h-4 w-4 mr-1" />
              Refresh All
            </Button>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="dashboard" data-testid="impact-dashboard-tab">
            <BarChart3 className="h-4 w-4 mr-2" />
            Impact Dashboard
          </TabsTrigger>
          <TabsTrigger value="sroi" data-testid="sroi-calculator-tab">
            <Calculator className="h-4 w-4 mr-2" />
            SROI Calculator
          </TabsTrigger>
          <TabsTrigger value="sdgs" data-testid="sdgs-alignment-tab">
            <Globe className="h-4 w-4 mr-2" />
            SDGs Alignment
          </TabsTrigger>
          <TabsTrigger value="esg" data-testid="esg-indicators-tab">
            <Shield className="h-4 w-4 mr-2" />
            ESG Indicators
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard">
          <ImpactDashboard />
        </TabsContent>

        <TabsContent value="sroi">
          <SROICalculatorTab />
        </TabsContent>

        <TabsContent value="sdgs">
          <SDGsAlignmentTab />
        </TabsContent>

        <TabsContent value="esg">
          <ESGIndicatorsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SROICalculator;