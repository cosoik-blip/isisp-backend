import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  Shield, 
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Plus,
  Edit3,
  Eye,
  FileCheck,
  Activity,
  TrendingUp,
  Users,
  Calendar,
  MapPin,
  Camera,
  CheckSquare,
  Square,
  Target,
  Wrench,
  ClipboardCheck,
  BarChart3,
  AlertOctagon
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const QualityAssuranceModule = ({ projectId, user }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(false);
  
  // Data states
  const [qaTemplates, setQaTemplates] = useState([]);
  const [qaInspections, setQaInspections] = useState([]);
  const [nonConformances, setNonConformances] = useState([]);
  const [correctiveActions, setCorrectiveActions] = useState([]);
  const [qualityMetrics, setQualityMetrics] = useState({});
  
  // Form states
  const [showCreateTemplate, setShowCreateTemplate] = useState(false);
  const [showCreateInspection, setShowCreateInspection] = useState(false);
  const [showCreateNC, setShowCreateNC] = useState(false);
  const [showCreateAction, setShowCreateAction] = useState(false);

  // Form data states
  const [templateForm, setTemplateForm] = useState({
    name: '',
    description: '',
    category: 'installation',
    checklist_items: []
  });

  const [inspectionForm, setInspectionForm] = useState({
    template_id: '',
    item_name: '',
    item_type: 'equipment_installation',
    inspection_date: new Date().toISOString().split('T')[0],
    status: 'passed',
    score: 100,
    notes: ''
  });

  const [ncForm, setNcForm] = useState({
    title: '',
    description: '',
    category: 'equipment_defect',
    severity: 'medium',
    location: '',
    impact: '',
    immediate_action: ''
  });

  const [actionForm, setActionForm] = useState({
    title: '',
    description: '',
    category: 'equipment_replacement',
    assigned_to: '',
    due_date: '',
    priority: 'medium',
    estimated_cost: 0
  });

  useEffect(() => {
    fetchQAData();
  }, [projectId]);

  const fetchQAData = async () => {
    setLoading(true);
    try {
      const [templatesRes, inspectionsRes, ncRes, actionsRes, metricsRes] = await Promise.all([
        axios.get(`${API}/projects/${projectId}/qa-templates`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/qa-inspections`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/non-conformances`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/corrective-actions`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        }),
        axios.get(`${API}/projects/${projectId}/quality-metrics`, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        })
      ]);
      
      setQaTemplates(templatesRes.data);
      setQaInspections(inspectionsRes.data);
      setNonConformances(ncRes.data);
      setCorrectiveActions(actionsRes.data);
      setQualityMetrics(metricsRes.data);
    } catch (error) {
      console.error('Failed to fetch QA data:', error);
      toast.error('Failed to load Quality Assurance data');
    } finally {
      setLoading(false);
    }
  };

  const createTemplate = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API}/projects/${projectId}/qa-templates`, templateForm, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      setShowCreateTemplate(false);
      setTemplateForm({ name: '', description: '', category: 'installation', checklist_items: [] });
      fetchQAData();
      toast.success('QA template created successfully');
    } catch (error) {
      console.error('Failed to create template:', error);
      toast.error('Failed to create QA template');
    }
  };

  const createInspection = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API}/projects/${projectId}/qa-inspections`, inspectionForm, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      setShowCreateInspection(false);
      setInspectionForm({
        template_id: '',
        item_name: '',
        item_type: 'equipment_installation',
        inspection_date: new Date().toISOString().split('T')[0],
        status: 'passed',
        score: 100,
        notes: ''
      });
      fetchQAData();
      toast.success('QA inspection recorded successfully');
    } catch (error) {
      console.error('Failed to create inspection:', error);
      toast.error('Failed to record QA inspection');
    }
  };

  const createNonConformance = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API}/projects/${projectId}/non-conformances`, {
        ...ncForm,
        reported_date: new Date().toISOString()
      }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      setShowCreateNC(false);
      setNcForm({
        title: '',
        description: '',
        category: 'equipment_defect',
        severity: 'medium',
        location: '',
        impact: '',
        immediate_action: ''
      });
      fetchQAData();
      toast.success('Non-conformance reported successfully');
    } catch (error) {
      console.error('Failed to create non-conformance:', error);
      toast.error('Failed to report non-conformance');
    }
  };

  const createCorrectiveAction = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API}/projects/${projectId}/corrective-actions`, actionForm, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      
      setShowCreateAction(false);
      setActionForm({
        title: '',
        description: '',
        category: 'equipment_replacement',
        assigned_to: '',
        due_date: '',
        priority: 'medium',
        estimated_cost: 0
      });
      fetchQAData();
      toast.success('Corrective action created successfully');
    } catch (error) {
      console.error('Failed to create corrective action:', error);
      toast.error('Failed to create corrective action');
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'passed': case 'completed': case 'closed': return 'bg-green-100 text-green-800';
      case 'failed': case 'open': return 'bg-red-100 text-red-800';
      case 'in_progress': case 'planned': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'bg-red-500 text-white';
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  // Overview Tab Component
  const OverviewTab = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="h-8 w-8 text-green-600" />
            <div>
              <p className="text-2xl font-bold">{qualityMetrics.pass_rate || 0}%</p>
              <p className="text-sm text-gray-600">Pass Rate</p>
              <p className="text-xs text-gray-500">
                {qualityMetrics.passed_inspections || 0}/{qualityMetrics.total_inspections || 0} inspections
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="h-8 w-8 text-yellow-600" />
            <div>
              <p className="text-2xl font-bold">{qualityMetrics.open_non_conformances || 0}</p>
              <p className="text-sm text-gray-600">Open Issues</p>
              <p className="text-xs text-gray-500">
                {qualityMetrics.total_non_conformances || 0} total non-conformances
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-2">
            <Activity className="h-8 w-8 text-blue-600" />
            <div>
              <p className="text-2xl font-bold">{qualityMetrics.action_completion_rate || 0}%</p>
              <p className="text-sm text-gray-600">Action Completion</p>
              <p className="text-xs text-gray-500">
                {qualityMetrics.completed_actions || 0}/{qualityMetrics.total_corrective_actions || 0} actions
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-2">
            <ClipboardCheck className="h-8 w-8 text-purple-600" />
            <div>
              <p className="text-2xl font-bold">{qaTemplates.length}</p>
              <p className="text-sm text-gray-600">QA Templates</p>
              <p className="text-xs text-gray-500">
                {qualityMetrics.total_inspections || 0} inspections completed
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  // Templates Tab Component
  const TemplatesTab = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">QA Templates</h3>
        <Dialog open={showCreateTemplate} onOpenChange={setShowCreateTemplate}>
          <DialogTrigger asChild>
            <Button data-testid="create-template-button">
              <Plus className="h-4 w-4 mr-2" />
              Create Template
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create QA Template</DialogTitle>
            </DialogHeader>
            <form onSubmit={createTemplate} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="template-name">Template Name</Label>
                <Input
                  id="template-name"
                  value={templateForm.name}
                  onChange={(e) => setTemplateForm({...templateForm, name: e.target.value})}
                  placeholder="e.g., Equipment Installation Checklist"
                  required
                  data-testid="template-name-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="template-description">Description</Label>
                <Textarea
                  id="template-description"
                  value={templateForm.description}
                  onChange={(e) => setTemplateForm({...templateForm, description: e.target.value})}
                  placeholder="Template description..."
                  rows={3}
                  data-testid="template-description-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="template-category">Category</Label>
                <Select 
                  value={templateForm.category} 
                  onValueChange={(value) => setTemplateForm({...templateForm, category: value})}
                >
                  <SelectTrigger data-testid="template-category-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="installation">Installation</SelectItem>
                    <SelectItem value="training">Training</SelectItem>
                    <SelectItem value="infrastructure">Infrastructure</SelectItem>
                    <SelectItem value="documentation">Documentation</SelectItem>
                    <SelectItem value="safety">Safety</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" className="w-full" data-testid="submit-template">
                Create Template
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {qaTemplates.map((template) => (
          <Card key={template.id}>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="text-sm font-medium">{template.name}</span>
                <Badge variant="outline">{template.category}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-3">{template.description}</p>
              <div className="flex items-center space-x-4 text-xs text-gray-500">
                <span>Items: {template.checklist_items?.length || 0}</span>
                <span>Created: {formatDate(template.created_at)}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  // Inspections Tab Component  
  const InspectionsTab = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">QA Inspections</h3>
        <Dialog open={showCreateInspection} onOpenChange={setShowCreateInspection}>
          <DialogTrigger asChild>
            <Button data-testid="create-inspection-button">
              <Plus className="h-4 w-4 mr-2" />
              Record Inspection
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Record QA Inspection</DialogTitle>
            </DialogHeader>
            <form onSubmit={createInspection} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="inspection-item">Item Name</Label>
                <Input
                  id="inspection-item"
                  value={inspectionForm.item_name}
                  onChange={(e) => setInspectionForm({...inspectionForm, item_name: e.target.value})}
                  placeholder="e.g., Laptop Installation - Room 101"
                  required
                  data-testid="inspection-item-input"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="inspection-type">Type</Label>
                  <Select 
                    value={inspectionForm.item_type} 
                    onValueChange={(value) => setInspectionForm({...inspectionForm, item_type: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="equipment_installation">Equipment Installation</SelectItem>
                      <SelectItem value="training_delivery">Training Delivery</SelectItem>
                      <SelectItem value="infrastructure">Infrastructure</SelectItem>
                      <SelectItem value="safety_check">Safety Check</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="inspection-status">Status</Label>
                  <Select 
                    value={inspectionForm.status} 
                    onValueChange={(value) => setInspectionForm({...inspectionForm, status: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="passed">Passed</SelectItem>
                      <SelectItem value="failed">Failed</SelectItem>
                      <SelectItem value="conditional">Conditional</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="inspection-score">Score (0-100)</Label>
                <Input
                  id="inspection-score"
                  type="number"
                  min="0"
                  max="100"
                  value={inspectionForm.score}
                  onChange={(e) => setInspectionForm({...inspectionForm, score: parseInt(e.target.value)})}
                  data-testid="inspection-score-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="inspection-notes">Notes</Label>
                <Textarea
                  id="inspection-notes"
                  value={inspectionForm.notes}
                  onChange={(e) => setInspectionForm({...inspectionForm, notes: e.target.value})}
                  placeholder="Inspection notes and findings..."
                  rows={3}
                  data-testid="inspection-notes-input"
                />
              </div>
              <Button type="submit" className="w-full" data-testid="submit-inspection">
                Record Inspection
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-3">
        {qaInspections.map((inspection) => (
          <Card key={inspection.id}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3">
                    {inspection.status === 'passed' ? (
                      <CheckCircle2 className="h-5 w-5 text-green-600" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-600" />
                    )}
                    <div>
                      <h4 className="font-medium">{inspection.item_name}</h4>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <span>{inspection.item_type?.replace('_', ' ')}</span>
                        <span>{formatDate(inspection.inspection_date)}</span>
                        <span>Score: {inspection.score}/100</span>
                      </div>
                    </div>
                  </div>
                  {inspection.notes && (
                    <p className="text-sm text-gray-600 mt-2 ml-8">{inspection.notes}</p>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className={getStatusColor(inspection.status)}>
                    {inspection.status}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  // Non-conformances Tab Component
  const NonConformancesTab = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Non-conformances</h3>
        <Dialog open={showCreateNC} onOpenChange={setShowCreateNC}>
          <DialogTrigger asChild>
            <Button data-testid="create-nc-button">
              <Plus className="h-4 w-4 mr-2" />
              Report Issue
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Report Non-conformance</DialogTitle>
            </DialogHeader>
            <form onSubmit={createNonConformance} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="nc-title">Title</Label>
                <Input
                  id="nc-title"
                  value={ncForm.title}
                  onChange={(e) => setNcForm({...ncForm, title: e.target.value})}
                  placeholder="Brief issue description"
                  required
                  data-testid="nc-title-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="nc-description">Description</Label>
                <Textarea
                  id="nc-description"
                  value={ncForm.description}
                  onChange={(e) => setNcForm({...ncForm, description: e.target.value})}
                  placeholder="Detailed issue description..."
                  rows={3}
                  required
                  data-testid="nc-description-input"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nc-category">Category</Label>
                  <Select 
                    value={ncForm.category} 
                    onValueChange={(value) => setNcForm({...ncForm, category: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="equipment_defect">Equipment Defect</SelectItem>
                      <SelectItem value="documentation_error">Documentation Error</SelectItem>
                      <SelectItem value="process_failure">Process Failure</SelectItem>
                      <SelectItem value="safety_issue">Safety Issue</SelectItem>
                      <SelectItem value="training_gap">Training Gap</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="nc-severity">Severity</Label>
                  <Select 
                    value={ncForm.severity} 
                    onValueChange={(value) => setNcForm({...ncForm, severity: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="critical">Critical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="nc-location">Location</Label>
                <Input
                  id="nc-location"
                  value={ncForm.location}
                  onChange={(e) => setNcForm({...ncForm, location: e.target.value})}
                  placeholder="Where the issue occurred"
                  data-testid="nc-location-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="nc-immediate-action">Immediate Action Taken</Label>
                <Textarea
                  id="nc-immediate-action"
                  value={ncForm.immediate_action}
                  onChange={(e) => setNcForm({...ncForm, immediate_action: e.target.value})}
                  placeholder="Actions taken to address the immediate issue..."
                  rows={3}
                  data-testid="nc-immediate-action-input"
                />
              </div>
              <Button type="submit" className="w-full" data-testid="submit-nc">
                Report Non-conformance
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-3">
        {nonConformances.map((nc) => (
          <Card key={nc.id}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <AlertOctagon className="h-5 w-5 text-red-600" />
                    <div>
                      <h4 className="font-medium">{nc.title}</h4>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <span>{nc.category?.replace('_', ' ')}</span>
                        <span>{formatDate(nc.reported_date)}</span>
                        <span>{nc.location}</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{nc.description}</p>
                  {nc.immediate_action && (
                    <div className="text-sm">
                      <span className="font-medium">Action Taken: </span>
                      <span className="text-gray-600">{nc.immediate_action}</span>
                    </div>
                  )}
                </div>
                <div className="flex flex-col items-end space-y-1">
                  <Badge className={getSeverityColor(nc.severity)}>
                    {nc.severity}
                  </Badge>
                  <Badge className={getStatusColor(nc.status)}>
                    {nc.status}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  // Corrective Actions Tab Component
  const CorrectiveActionsTab = () => (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Corrective Actions</h3>
        <Dialog open={showCreateAction} onOpenChange={setShowCreateAction}>
          <DialogTrigger asChild>
            <Button data-testid="create-action-button">
              <Plus className="h-4 w-4 mr-2" />
              Create Action
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Corrective Action</DialogTitle>
            </DialogHeader>
            <form onSubmit={createCorrectiveAction} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="action-title">Title</Label>
                <Input
                  id="action-title"
                  value={actionForm.title}
                  onChange={(e) => setActionForm({...actionForm, title: e.target.value})}
                  placeholder="Action title"
                  required
                  data-testid="action-title-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="action-description">Description</Label>
                <Textarea
                  id="action-description"
                  value={actionForm.description}
                  onChange={(e) => setActionForm({...actionForm, description: e.target.value})}
                  placeholder="Detailed action description..."
                  rows={3}
                  data-testid="action-description-input"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="action-assigned">Assigned To</Label>
                  <Input
                    id="action-assigned"
                    value={actionForm.assigned_to}
                    onChange={(e) => setActionForm({...actionForm, assigned_to: e.target.value})}
                    placeholder="Person responsible"
                    data-testid="action-assigned-input"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="action-due-date">Due Date</Label>
                  <Input
                    id="action-due-date"
                    type="date"
                    value={actionForm.due_date}
                    onChange={(e) => setActionForm({...actionForm, due_date: e.target.value})}
                    data-testid="action-due-date-input"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="action-priority">Priority</Label>
                <Select 
                  value={actionForm.priority} 
                  onValueChange={(value) => setActionForm({...actionForm, priority: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit" className="w-full" data-testid="submit-action">
                Create Action
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-3">
        {correctiveActions.map((action) => (
          <Card key={action.id}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <Wrench className="h-5 w-5 text-blue-600" />
                    <div>
                      <h4 className="font-medium">{action.title}</h4>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <span>Assigned: {action.assigned_to}</span>
                        <span>Due: {formatDate(action.due_date)}</span>
                        <span>Priority: {action.priority}</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{action.description}</p>
                  {action.progress !== undefined && (
                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{action.progress}%</span>
                      </div>
                      <Progress value={action.progress} className="h-2" />
                    </div>
                  )}
                </div>
                <div className="flex flex-col items-end space-y-1">
                  <Badge className={getSeverityColor(action.priority)}>
                    {action.priority}
                  </Badge>
                  <Badge className={getStatusColor(action.status)}>
                    {action.status}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-6 w-6 text-blue-600" />
            <span>Quality Assurance Module</span>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview" data-testid="overview-tab">
            <BarChart3 className="h-4 w-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="templates" data-testid="templates-tab">
            <ClipboardCheck className="h-4 w-4 mr-2" />
            Templates
          </TabsTrigger>
          <TabsTrigger value="inspections" data-testid="inspections-tab">
            <CheckCircle2 className="h-4 w-4 mr-2" />
            Inspections
          </TabsTrigger>
          <TabsTrigger value="nonconformances" data-testid="nonconformances-tab">
            <AlertTriangle className="h-4 w-4 mr-2" />
            Issues
          </TabsTrigger>
          <TabsTrigger value="actions" data-testid="actions-tab">
            <Wrench className="h-4 w-4 mr-2" />
            Actions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <OverviewTab />
        </TabsContent>

        <TabsContent value="templates">
          <TemplatesTab />
        </TabsContent>

        <TabsContent value="inspections">
          <InspectionsTab />
        </TabsContent>

        <TabsContent value="nonconformances">
          <NonConformancesTab />
        </TabsContent>

        <TabsContent value="actions">
          <CorrectiveActionsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default QualityAssuranceModule;