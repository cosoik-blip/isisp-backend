import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner';
import { 
  AlertTriangle, 
  Bug, 
  Plus, 
  Clock, 
  CheckCircle2,
  AlertCircle,
  TrendingUp,
  User,
  Calendar,
  Edit3,
  Trash2
} from 'lucide-react';
import UniversalComments from './UniversalComments';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const RiskIssueManagement = ({ projectId, user }) => {
  const [risks, setRisks] = useState([]);
  const [issues, setIssues] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showRiskDialog, setShowRiskDialog] = useState(false);
  const [showIssueDialog, setShowIssueDialog] = useState(false);
  const [riskFormData, setRiskFormData] = useState({
    title: '',
    description: '',
    probability: 1,
    impact: 1,
    mitigation_strategy: '',
    contingency_plan: '',
    owner_id: user.id
  });
  const [issueFormData, setIssueFormData] = useState({
    title: '',
    description: '',
    priority: '',
    assigned_to: ''
  });
  const [editingRisk, setEditingRisk] = useState(null);
  const [editingIssue, setEditingIssue] = useState(null);

  useEffect(() => {
    fetchRisksAndIssues();
  }, [projectId]);

  const fetchRisksAndIssues = async () => {
    try {
      const [risksRes, issuesRes] = await Promise.all([
        axios.get(`${API}/projects/${projectId}/risks`),
        axios.get(`${API}/projects/${projectId}/issues`)
      ]);
      setRisks(risksRes.data);
      setIssues(issuesRes.data);
    } catch (error) {
      toast.error('Failed to load risks and issues');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateRisk = async (e) => {
    e.preventDefault();
    try {
      const isEditing = editingRisk !== null;

      if (isEditing) {
        await axios.put(`${API}/projects/${projectId}/risks/${editingRisk}`, riskFormData, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        toast.success('Risk updated successfully!');
      } else {
        await axios.post(`${API}/projects/${projectId}/risks`, riskFormData, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        toast.success('Risk created successfully!');
      }
      
      setShowRiskDialog(false);
      setRiskFormData({
        title: '',
        description: '',
        probability: 1,
        impact: 1,
        mitigation_strategy: '',
        contingency_plan: '',
        owner_id: user.id
      });
      setEditingRisk(null);
      fetchRisksAndIssues();
    } catch (error) {
      toast.error(error.response?.data?.detail || `Failed to ${editingRisk ? 'update' : 'create'} risk`);
    }
  };

  const handleDeleteRisk = async (riskId) => {
    if (!window.confirm('Are you sure you want to delete this risk?')) {
      return;
    }

    try {
      await axios.delete(`${API}/projects/${projectId}/risks/${riskId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      toast.success('Risk deleted successfully!');
      fetchRisksAndIssues();
    } catch (error) {
      console.error('Failed to delete risk:', error);
      toast.error('Failed to delete risk');
    }
  };

  const handleCreateIssue = async (e) => {
    e.preventDefault();
    try {
      const isEditing = editingIssue !== null;

      if (isEditing) {
        await axios.put(`${API}/projects/${projectId}/issues/${editingIssue}`, issueFormData, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        toast.success('Issue updated successfully!');
      } else {
        await axios.post(`${API}/projects/${projectId}/issues`, issueFormData, {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
        });
        toast.success('Issue created successfully!');
      }
      
      setShowIssueDialog(false);
      setIssueFormData({
        title: '',
        description: '',
        priority: '',
        assigned_to: ''
      });
      setEditingIssue(null);
      fetchRisksAndIssues();
    } catch (error) {
      toast.error(error.response?.data?.detail || `Failed to ${editingIssue ? 'update' : 'create'} issue`);
    }
  };

  const handleDeleteIssue = async (issueId) => {
    if (!window.confirm('Are you sure you want to delete this issue?')) {
      return;
    }

    try {
      await axios.delete(`${API}/projects/${projectId}/issues/${issueId}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      toast.success('Issue deleted successfully!');
      fetchRisksAndIssues();
    } catch (error) {
      console.error('Failed to delete issue:', error);
      toast.error('Failed to delete issue');
    }
  };

  const getRiskLevelColor = (level) => {
    switch (level) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'critical': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'low': return 'bg-blue-100 text-blue-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'urgent': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'open': return 'bg-red-100 text-red-800';
      case 'in_progress': return 'bg-blue-100 text-blue-800';
      case 'resolved': return 'bg-green-100 text-green-800';
      case 'closed': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="risks" className="space-y-4">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="risks" className="flex items-center space-x-2">
            <AlertTriangle className="h-4 w-4" />
            <span>Risk Register ({risks.length})</span>
          </TabsTrigger>
          <TabsTrigger value="issues" className="flex items-center space-x-2">
            <Bug className="h-4 w-4" />
            <span>Issue Log ({issues.length})</span>
          </TabsTrigger>
        </TabsList>

        {/* Risks Tab */}
        <TabsContent value="risks" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Risk Management</h3>
            <Dialog open={showRiskDialog} onOpenChange={setShowRiskDialog}>
              <DialogTrigger asChild>
                <Button data-testid="add-risk-button">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Risk
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>{editingRisk ? 'Edit Risk' : 'Add New Risk'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateRisk} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="risk-title">Risk Title</Label>
                    <Input
                      id="risk-title"
                      value={riskFormData.title}
                      onChange={(e) => setRiskFormData({...riskFormData, title: e.target.value})}
                      placeholder="e.g., Technology Infrastructure Delays"
                      required
                      data-testid="risk-title-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="risk-description">Description</Label>
                    <Textarea
                      id="risk-description"
                      value={riskFormData.description}
                      onChange={(e) => setRiskFormData({...riskFormData, description: e.target.value})}
                      placeholder="Describe the risk in detail..."
                      rows={3}
                      required
                      data-testid="risk-description-input"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="probability">Probability (1-5)</Label>
                      <Select value={riskFormData.probability.toString()} onValueChange={(value) => setRiskFormData({...riskFormData, probability: parseInt(value)})}>
                        <SelectTrigger data-testid="risk-probability-select">
                          <SelectValue placeholder="Select probability" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 - Very Low</SelectItem>
                          <SelectItem value="2">2 - Low</SelectItem>
                          <SelectItem value="3">3 - Medium</SelectItem>
                          <SelectItem value="4">4 - High</SelectItem>
                          <SelectItem value="5">5 - Very High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="impact">Impact (1-5)</Label>
                      <Select value={riskFormData.impact.toString()} onValueChange={(value) => setRiskFormData({...riskFormData, impact: parseInt(value)})}>
                        <SelectTrigger data-testid="risk-impact-select">
                          <SelectValue placeholder="Select impact" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 - Very Low</SelectItem>
                          <SelectItem value="2">2 - Low</SelectItem>
                          <SelectItem value="3">3 - Medium</SelectItem>
                          <SelectItem value="4">4 - High</SelectItem>
                          <SelectItem value="5">5 - Very High</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mitigation">Mitigation Strategy</Label>
                    <Textarea
                      id="mitigation"
                      value={riskFormData.mitigation_strategy}
                      onChange={(e) => setRiskFormData({...riskFormData, mitigation_strategy: e.target.value})}
                      placeholder="How will this risk be mitigated?"
                      rows={2}
                      required
                      data-testid="risk-mitigation-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contingency">Contingency Plan (Optional)</Label>
                    <Textarea
                      id="contingency"
                      value={riskFormData.contingency_plan}
                      onChange={(e) => setRiskFormData({...riskFormData, contingency_plan: e.target.value})}
                      placeholder="What's the backup plan if mitigation fails?"
                      rows={2}
                      data-testid="risk-contingency-input"
                    />
                  </div>
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => {
                      setShowRiskDialog(false);
                      setEditingRisk(null);
                      setRiskFormData({
                        title: '',
                        description: '',
                        probability: 1,
                        impact: 1,
                        mitigation_strategy: '',
                        contingency_plan: '',
                        owner_id: user.id
                      });
                    }}>
                      Cancel
                    </Button>
                    <Button type="submit" data-testid="create-risk-submit">{editingRisk ? 'Update Risk' : 'Create Risk'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-4">
            {risks.map((risk) => (
              <Card key={risk.id} className="border-l-4 border-l-orange-500" data-testid={`risk-card-${risk.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h4 className="font-semibold text-gray-900">{risk.title}</h4>
                        <Badge className={getRiskLevelColor(risk.level)}>
                          {risk.level} ({risk.risk_score})
                        </Badge>
                      </div>
                      <p className="text-gray-600 text-sm mb-3">{risk.description}</p>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="font-medium text-gray-700">Probability:</p>
                          <p className="text-gray-600">{risk.probability}/5</p>
                        </div>
                        <div>
                          <p className="font-medium text-gray-700">Impact:</p>
                          <p className="text-gray-600">{risk.impact}/5</p>
                        </div>
                      </div>
                      
                      <div className="mt-3">
                        <p className="font-medium text-gray-700 text-sm">Mitigation Strategy:</p>
                        <p className="text-gray-600 text-sm">{risk.mitigation_strategy}</p>
                      </div>
                      
                      {risk.contingency_plan && (
                        <div className="mt-2">
                          <p className="font-medium text-gray-700 text-sm">Contingency Plan:</p>
                          <p className="text-gray-600 text-sm">{risk.contingency_plan}</p>
                        </div>
                      )}
                    </div>
                    <div className="ml-4 flex items-center space-x-2">
                      <AlertTriangle className={`h-6 w-6 ${risk.level === 'critical' ? 'text-red-500' : risk.level === 'high' ? 'text-orange-500' : 'text-yellow-500'}`} />
                      
                      {/* Edit/Delete Actions for Admin and Social Actor */}
                      {user.role !== 'investor' && (
                        <div className="flex items-center space-x-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              setRiskFormData({
                                title: risk.title,
                                description: risk.description,
                                probability: risk.probability,
                                impact: risk.impact,
                                mitigation_strategy: risk.mitigation_strategy,
                                contingency_plan: risk.contingency_plan,
                                owner_id: risk.owner_id
                              });
                              setEditingRisk(risk.id);
                              setShowRiskDialog(true);
                            }}
                            className="text-blue-600 hover:text-blue-800"
                          >
                            <Edit3 className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteRisk(risk.id)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Comments for individual risk */}
                  <div className="mt-4 pt-4 border-t">
                    <UniversalComments 
                      projectId={projectId} 
                      user={user} 
                      itemType="risk" 
                      itemId={risk.id}
                      title={`Comments for ${risk.title}`} 
                    />
                  </div>
                </CardContent>
              </Card>
            ))}
            {risks.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <AlertTriangle className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No risks identified yet</p>
                <p className="text-sm">Add risks to improve project planning</p>
              </div>
            )}
          </div>
          
          {/* Universal Comments for Risks */}
          <UniversalComments 
            projectId={projectId} 
            user={user} 
            itemType="risks" 
            title="Risk Management Comments & Feedback" 
          />
        </TabsContent>

        {/* Issues Tab */}
        <TabsContent value="issues" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Issue Management</h3>
            <Dialog open={showIssueDialog} onOpenChange={setShowIssueDialog}>
              <DialogTrigger asChild>
                <Button data-testid="add-issue-button">
                  <Plus className="h-4 w-4 mr-2" />
                  Report Issue
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>{editingIssue ? 'Edit Issue' : 'Report New Issue'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleCreateIssue} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="issue-title">Issue Title</Label>
                    <Input
                      id="issue-title"
                      value={issueFormData.title}
                      onChange={(e) => setIssueFormData({...issueFormData, title: e.target.value})}
                      placeholder="e.g., Equipment delivery delayed"
                      required
                      data-testid="issue-title-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="issue-description">Description</Label>
                    <Textarea
                      id="issue-description"
                      value={issueFormData.description}
                      onChange={(e) => setIssueFormData({...issueFormData, description: e.target.value})}
                      placeholder="Describe the issue in detail..."
                      rows={4}
                      required
                      data-testid="issue-description-input"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="priority">Priority</Label>
                    <Select value={issueFormData.priority} onValueChange={(value) => setIssueFormData({...issueFormData, priority: value})}>
                      <SelectTrigger data-testid="issue-priority-select">
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex justify-end space-x-2 pt-4">
                    <Button type="button" variant="outline" onClick={() => {
                      setShowIssueDialog(false);
                      setEditingIssue(null);
                      setIssueFormData({
                        title: '',
                        description: '',
                        priority: '',
                        assigned_to: ''
                      });
                    }}>
                      Cancel
                    </Button>
                    <Button type="submit" data-testid="create-issue-submit">{editingIssue ? 'Update Issue' : 'Report Issue'}</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-4">
            {issues.map((issue) => (
              <Card key={issue.id} className="border-l-4 border-l-red-500" data-testid={`issue-card-${issue.id}`}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h4 className="font-semibold text-gray-900">{issue.title}</h4>
                        <Badge className={getPriorityColor(issue.priority)}>
                          {issue.priority}
                        </Badge>
                        <Badge className={getStatusColor(issue.status)}>
                          {issue.status.replace('_', ' ')}
                        </Badge>
                      </div>
                      <p className="text-gray-600 text-sm mb-3">{issue.description}</p>
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <div className="flex items-center space-x-1">
                          <User className="h-4 w-4" />
                          <span>Reported by: {issue.reporter_id}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-4 w-4" />
                          <span>{new Date(issue.created_at).toLocaleDateString()}</span>
                        </div>
                      </div>
                      
                      {issue.resolution_strategy && (
                        <div className="mt-3">
                          <p className="font-medium text-gray-700 text-sm">Resolution Strategy:</p>
                          <p className="text-gray-600 text-sm">{issue.resolution_strategy}</p>
                        </div>
                      )}
                    </div>
                    <div className="ml-4 flex items-center space-x-2">
                      {issue.status === 'resolved' ? (
                        <CheckCircle2 className="h-6 w-6 text-green-500" />
                      ) : issue.status === 'in_progress' ? (
                        <Clock className="h-6 w-6 text-blue-500" />
                      ) : (
                        <Bug className="h-6 w-6 text-red-500" />
                      )}
                      
                      {/* Edit/Delete Actions for Admin and Social Actor */}
                      {user.role !== 'investor' && (
                        <div className="flex items-center space-x-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => {
                              setIssueFormData({
                                title: issue.title,
                                description: issue.description,
                                priority: issue.priority,
                                assigned_to: issue.assigned_to
                              });
                              setEditingIssue(issue.id);
                              setShowIssueDialog(true);
                            }}
                            className="text-blue-600 hover:text-blue-800"
                          >
                            <Edit3 className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteIssue(issue.id)}
                            className="text-red-600 hover:text-red-800"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Comments for individual issue */}
                  <div className="mt-4 pt-4 border-t">
                    <UniversalComments 
                      projectId={projectId} 
                      user={user} 
                      itemType="issue" 
                      itemId={issue.id}
                      title={`Comments for ${issue.title}`} 
                    />
                  </div>
                </CardContent>
              </Card>
            ))}
            {issues.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Bug className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No issues reported yet</p>
                <p className="text-sm">Issues will appear here when reported</p>
              </div>
            )}
          </div>
          
          {/* Universal Comments for Issues */}
          <UniversalComments 
            projectId={projectId} 
            user={user} 
            itemType="issues" 
            title="Issue Management Comments & Feedback" 
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default RiskIssueManagement;