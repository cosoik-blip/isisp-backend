import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { toast } from 'sonner';
import { 
  TrendingUp, 
  DollarSign, 
  Activity, 
  BookOpen, 
  Heart, 
  Leaf, 
  BarChart3, 
  Clock,
  Target,
  AlertCircle,
  CheckCircle2,
  PieChart,
  Briefcase,
  Award,
  TrendingDown
} from 'lucide-react';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const InvestorDashboard = () => {
  const [dashboardData, setDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const response = await axios.get(`${API}/dashboard`);
      setDashboardData(response.data);
    } catch (error) {
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'education': return <BookOpen className="h-5 w-5" />;
      case 'care': return <Heart className="h-5 w-5" />;
      case 'environment': return <Leaf className="h-5 w-5" />;
      default: return <Activity className="h-5 w-5" />;
    }
  };

  const getCategoryColor = (category) => {
    switch (category) {
      case 'education': return 'bg-blue-100 text-blue-800';
      case 'care': return 'bg-green-100 text-green-800';
      case 'environment': return 'bg-emerald-100 text-emerald-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'executing': return 'bg-green-100 text-green-800';
      case 'planning': return 'bg-yellow-100 text-yellow-800';
      case 'initiating': return 'bg-blue-100 text-blue-800';
      case 'closing': return 'bg-purple-100 text-purple-800';
      case 'on_hold': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', { 
      style: 'currency', 
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  const StatCard = ({ title, value, icon: Icon, subtitle, color = "blue", trend = null }) => (
    <Card className="hover-lift transition-all duration-300" data-testid={`investor-stat-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-sm font-medium text-gray-600">{title}</p>
            <p className={`text-2xl font-bold text-${color}-600`}>{value}</p>
            {subtitle && (
              <p className="text-xs text-gray-500">{subtitle}</p>
            )}
            {trend && (
              <div className={`flex items-center space-x-1 text-xs ${trend.positive ? 'text-green-600' : 'text-red-600'}`}>
                {trend.positive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                <span>{trend.value}</span>
              </div>
            )}
          </div>
          <div className={`p-3 rounded-full bg-${color}-100`}>
            <Icon className={`h-6 w-6 text-${color}-600`} />
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center space-x-3">
            <Briefcase className="h-8 w-8 text-green-600" />
            <span>Investment Portfolio</span>
          </h1>
          <p className="text-gray-600 mt-1">Track your social impact investments and returns</p>
        </div>
        <Button className="bg-gradient-to-r from-green-600 to-emerald-600">
          <PieChart className="h-4 w-4 mr-2" />
          Portfolio Analysis
        </Button>
      </div>

      {/* Investment Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Investment"
          value={formatCurrency(dashboardData?.total_investment || 0)}
          icon={DollarSign}
          subtitle="Deployed capital"
          color="green"
        />
        <StatCard
          title="Portfolio Size"
          value={dashboardData?.portfolio_size || 0}
          icon={Briefcase}
          subtitle="Funded projects"
          color="blue"
        />
        <StatCard
          title="Active Investments"
          value={dashboardData?.active_investments || 0}
          icon={TrendingUp}
          subtitle="Currently executing"
          color="orange"
        />
        <StatCard
          title="Completed Projects"
          value={dashboardData?.completed_projects || 0}
          icon={Award}
          subtitle="Successfully closed"
          color="purple"
        />
      </div>

      {/* Investment Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Target className="h-5 w-5 text-green-600" />
              <span>Investment Utilization</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Capital Deployed</span>
                <span className="font-semibold">
                  {dashboardData?.total_investment ? 
                    Math.round((dashboardData.total_spent / dashboardData.total_investment) * 100) : 0}%
                </span>
              </div>
              <Progress 
                value={dashboardData?.total_investment ? 
                  (dashboardData.total_spent / dashboardData.total_investment) * 100 : 0} 
              />
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500">Deployed: {formatCurrency(dashboardData?.total_spent || 0)}</span>
                <span className="text-gray-500">Committed: {formatCurrency(dashboardData?.total_investment || 0)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <BarChart3 className="h-5 w-5 text-blue-600" />
              <span>Impact Metrics</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{dashboardData?.portfolio_size || 0}</p>
                <p className="text-sm text-gray-600">Social Impact Projects</p>
              </div>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="font-semibold text-blue-600">Education</p>
                  <p className="text-xs text-gray-500">1 project</p>
                </div>
                <div>
                  <p className="font-semibold text-green-600">Healthcare</p>
                  <p className="text-xs text-gray-500">1 project</p>
                </div>
                <div>
                  <p className="font-semibold text-emerald-600">Environment</p>
                  <p className="text-xs text-gray-500">1 project</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Investment Portfolio */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-blue-600" />
            <span>Your Investment Portfolio</span>
          </CardTitle>
          <Link to="/projects">
            <Button variant="outline" size="sm" data-testid="investor-view-all-investments">
              View All Investments
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {dashboardData?.recent_projects?.map((project) => (
              <div key={project.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-center space-x-4">
                  <div className="p-2 rounded-full bg-gray-100">
                    {getCategoryIcon(project.category)}
                  </div>
                  <div>
                    <Link 
                      to={`/projects/${project.id}`}
                      className="font-medium text-gray-900 hover:text-blue-600 transition-colors"
                      data-testid={`investor-project-link-${project.id}`}
                    >
                      {project.title}
                    </Link>
                    <div className="flex items-center space-x-2 mt-1">
                      <Badge className={getCategoryColor(project.category)}>
                        {project.category}
                      </Badge>
                      <Badge className={getStatusColor(project.status)}>
                        {project.status.replace('_', ' ')}
                      </Badge>
                      <span className="text-xs text-gray-500">
                        Investment: {formatCurrency(project.budget)}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-sm font-medium">{Math.round(project.progress)}%</span>
                    {project.progress >= 75 ? (
                      <CheckCircle2 className="h-4 w-4 text-green-500" />
                    ) : project.progress >= 25 ? (
                      <Clock className="h-4 w-4 text-yellow-500" />
                    ) : (
                      <AlertCircle className="h-4 w-4 text-red-500" />
                    )}
                  </div>
                  <Progress value={project.progress} className="w-24" />
                  <p className="text-xs text-gray-500 mt-1">
                    Spent: {formatCurrency(project.actual_cost)}
                  </p>
                </div>
              </div>
            ))}
            {(!dashboardData?.recent_projects || dashboardData.recent_projects.length === 0) && (
              <div className="text-center py-8 text-gray-500">
                <Briefcase className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No investments found. Start by funding your first project!</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card data-testid="investor-quick-actions">
        <CardHeader>
          <CardTitle>Investment Management</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link to="/projects">
              <Button className="w-full justify-start h-auto p-4" variant="outline">
                <Activity className="h-5 w-5 mr-3" />
                <div className="text-left">
                  <p className="font-medium">View Investments</p>
                  <p className="text-sm text-gray-500">Monitor your portfolio</p>
                </div>
              </Button>
            </Link>
            <Button className="w-full justify-start h-auto p-4" variant="outline" disabled>
              <BarChart3 className="h-5 w-5 mr-3" />
              <div className="text-left">
                <p className="font-medium">Impact Reports</p>
                <p className="text-sm text-gray-500">Coming soon</p>
              </div>
            </Button>
            <Button className="w-full justify-start h-auto p-4" variant="outline" disabled>
              <Target className="h-5 w-5 mr-3" />
              <div className="text-left">
                <p className="font-medium">ROI Analysis</p>
                <p className="text-sm text-gray-500">Coming soon</p>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default InvestorDashboard;