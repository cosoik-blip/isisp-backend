import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import axios from 'axios';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import ProjectDetails from './components/ProjectDetails';
import Projects from './components/Projects';
import TemplateLibrary from './components/TemplateLibrary';
import UserGuides from './components/UserGuides';
import UserManagement from './components/UserManagement';
import PlatformReports from './components/PlatformReports';
import PlatformSettings from './components/PlatformSettings';
import { Toaster } from './components/ui/sonner';
import './App.css';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

// Set up axios interceptor for auth token
const setupAxiosInterceptors = (token) => {
  // Clear any existing interceptors
  axios.interceptors.request.clear();
  axios.interceptors.response.clear();
  
  if (token) {
    // Set default Authorization header
    axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    
    // Add request interceptor to ensure token is always included
    axios.interceptors.request.use(
      (config) => {
        // Always add token to requests if available
        const currentToken = localStorage.getItem('token');
        if (currentToken) {
          config.headers.Authorization = `Bearer ${currentToken}`;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );
    
    // Add response interceptor to handle token expiration
    axios.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response?.status === 401) {
          // Token expired or invalid, clear local storage and reload page
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          delete axios.defaults.headers.common['Authorization'];
          // Force reload to redirect to login
          window.location.reload();
        }
        return Promise.reject(error);
      }
    );
  } else {
    // Clear authorization header when no token
    delete axios.defaults.headers.common['Authorization'];
  }
};

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const savedUser = localStorage.getItem('user');
    
    if (token && savedUser) {
      try {
        const userData = JSON.parse(savedUser);
        setUser(userData);
        setupAxiosInterceptors(token);
      } catch (error) {
        console.error('Error parsing stored user data:', error);
        localStorage.removeItem('token');
        localStorage.removeItem('user');
      }
    }
    setLoading(false);
  }, []);

  const login = async (username, password) => {
    try {
      const response = await axios.post(`${API}/auth/login`, {
        username,
        password
      });

      const { access_token, user: userData } = response.data;
      
      if (!access_token || !userData) {
        return { success: false, error: 'Invalid response from server' };
      }
      
      localStorage.setItem('token', access_token);
      localStorage.setItem('user', JSON.stringify(userData));
      setupAxiosInterceptors(access_token);
      setUser(userData);
      
      return { success: true };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.detail || 'Login failed' 
      };
    }
  };

  const register = async (username, email, password, role) => {
    try {
      const response = await axios.post(`${API}/auth/register`, {
        username,
        email,
        password,
        role
      });

      const { access_token, user: userData } = response.data;
      
      localStorage.setItem('token', access_token);
      localStorage.setItem('user', JSON.stringify(userData));
      setupAxiosInterceptors(access_token);
      setUser(userData);
      
      return { success: true };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.detail || 'Registration failed' 
      };
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setupAxiosInterceptors(null);
    setUser(null);
  };

  const initializeSampleData = async () => {
    try {
      await axios.post(`${API}/init-sample-data`);
      return { success: true };
    } catch (error) {
      return { 
        success: false, 
        error: error.response?.data?.detail || 'Failed to initialize sample data' 
      };
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route 
            path="/login" 
            element={
              !user ? (
                <Login 
                  onLogin={login} 
                  onRegister={register}
                  onInitializeSampleData={initializeSampleData}
                />
              ) : (
                <Navigate to="/dashboard" />
              )
            } 
          />
          <Route 
            path="/dashboard" 
            element={
              user ? (
                <Dashboard user={user} onLogout={logout} />
              ) : (
                <Navigate to="/login" />
              )
            } 
          />
          <Route 
            path="/projects" 
            element={
              user ? (
                <Projects user={user} onLogout={logout} />
              ) : (
                <Navigate to="/login" />
              )
            } 
          />
          <Route 
            path="/projects/:id" 
            element={
              user ? (
                <ProjectDetails user={user} onLogout={logout} />
              ) : (
                <Navigate to="/login" />
              )
            } 
          />
          <Route 
            path="/templates" 
            element={
              user ? (
                <div className="min-h-screen bg-gray-50">
                  <div className="container mx-auto px-4 py-8">
                    <TemplateLibrary user={user} />
                  </div>
                </div>
              ) : (
                <Navigate to="/login" />
              )
            } 
          />
          <Route 
            path="/guides" 
            element={
              user ? (
                <div className="min-h-screen bg-gray-50">
                  <div className="container mx-auto px-4 py-8">
                    <UserGuides user={user} />
                  </div>
                </div>
              ) : (
                <Navigate to="/login" />
              )
            } 
          />
          <Route 
            path="/admin/users" 
            element={
              user && user.role === 'administrator' ? (
                <div className="min-h-screen bg-gray-50">
                  <div className="container mx-auto px-4 py-8">
                    <UserManagement user={user} />
                  </div>
                </div>
              ) : (
                <Navigate to="/login" />
              )
            } 
          />
          <Route 
            path="/admin/reports" 
            element={
              user && user.role === 'administrator' ? (
                <div className="min-h-screen bg-gray-50">
                  <div className="container mx-auto px-4 py-8">
                    <PlatformReports user={user} />
                  </div>
                </div>
              ) : (
                <Navigate to="/login" />
              )
            } 
          />
          <Route 
            path="/admin/settings" 
            element={
              user && user.role === 'administrator' ? (
                <div className="min-h-screen bg-gray-50">
                  <div className="container mx-auto px-4 py-8">
                    <PlatformSettings user={user} />
                  </div>
                </div>
              ) : (
                <Navigate to="/login" />
              )
            } 
          />
          <Route path="/" element={<Navigate to="/dashboard" />} />
        </Routes>
      </BrowserRouter>
      <Toaster />
    </div>
  );
}

export default App;