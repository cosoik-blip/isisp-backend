from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, UploadFile, File
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field
from typing import List, Optional, Dict
from datetime import datetime, timezone, timedelta
import jwt
import os
import logging
import uuid
import hashlib
import random
from pathlib import Path
import os
from enum import Enum
import aiofiles

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Security
import hashlib
security = HTTPBearer()
SECRET_KEY = "your-secret-key-change-in-production"
ALGORITHM = "HS256"

app = FastAPI()
api_router = APIRouter(prefix="/api")

# Enums
class UserRole(str, Enum):
    ADMINISTRATOR = "administrator"
    INVESTOR = "investor" 
    SOCIAL_ACTOR = "social_actor"

class ProjectStatus(str, Enum):
    INITIATING = "initiating"
    PLANNING = "planning"
    EXECUTING = "executing"
    CLOSING = "closing"
    ON_HOLD = "on_hold"

class ProjectCategory(str, Enum):
    EDUCATION = "education"
    CARE = "care"
    ENVIRONMENT = "environment"

class ProjectPhase(str, Enum):
    INITIATING = "initiating"
    PLANNING = "planning"
    EXECUTING = "executing"
    CLOSING = "closing"

class PhaseGateStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"

class KPIType(str, Enum):
    QUANTITATIVE = "quantitative"
    QUALITATIVE = "qualitative"
    IMPACT = "impact"

class DeliverableStatus(str, Enum):
    PLANNED = "planned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CERTIFIED = "certified"

class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class IssueStatus(str, Enum):
    OPEN = "open"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    CLOSED = "closed"

class IssuePriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"

class ChangeRequestStatus(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    IMPLEMENTED = "implemented"

class DocumentType(str, Enum):
    PROJECT_CHARTER = "project_charter"
    BUSINESS_CASE = "business_case"
    RISK_PLAN = "risk_plan"
    QUALITY_PLAN = "quality_plan"
    PROGRESS_REPORT = "progress_report"
    STAKEHOLDER_REGISTER = "stakeholder_register"
    PHASE_GATE_REVIEW = "phase_gate_review"
    QA_CHECKLIST = "qa_checklist"
    OTHER = "other"

class NotificationType(str, Enum):
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    SUCCESS = "success"

class StakeholderInfluence(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

class StakeholderInterest(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"

class QACheckStatus(str, Enum):
    PENDING = "pending"
    PASSED = "passed"
    FAILED = "failed"
    NOT_APPLICABLE = "not_applicable"

# Models
class User(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    username: str
    email: str
    role: UserRole
    organization_name: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class UserCreate(BaseModel):
    username: str
    email: str
    password: str
    role: UserRole
    organization_name: Optional[str] = None

class UserLogin(BaseModel):
    username: str
    password: str

class Project(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    description: str
    category: ProjectCategory
    start_date: datetime
    end_date: datetime
    status: ProjectStatus
    budget: float
    actual_cost: float = 0.0
    owner_id: str  # Social Actor ID
    investor_id: Optional[str] = None  # Investor ID
    progress: float = 0.0
    phase: ProjectPhase = ProjectPhase.INITIATING
    phase_approved: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class ProjectCreate(BaseModel):
    title: str
    description: str
    category: ProjectCategory
    start_date: datetime
    end_date: datetime
    budget: float
    investor_id: Optional[str] = None

# Phase Gate Management
class PhaseGate(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_id: str
    phase: ProjectPhase
    gate_type: str  # RfP, RfE, RfC
    status: PhaseGateStatus = PhaseGateStatus.PENDING
    criteria_met: Dict[str, bool] = {}
    reviewer_id: Optional[str] = None
    review_notes: Optional[str] = None
    approved_by: Optional[str] = None
    approved_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class PhaseGateCreate(BaseModel):
    phase: ProjectPhase
    gate_type: str
    criteria_met: Dict[str, bool]

class PhaseGateUpdate(BaseModel):
    status: PhaseGateStatus
    review_notes: Optional[str] = None

# Document Management
class Document(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_id: str
    title: str
    description: str
    document_type: DocumentType
    file_path: Optional[str] = None
    template_content: Optional[Dict] = None
    version: str = "1.0"
    uploaded_by: str
    approved: bool = False
    approved_by: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class DocumentCreate(BaseModel):
    title: str
    description: str
    document_type: DocumentType
    template_content: Optional[Dict] = None
    version: Optional[str] = "1.0"

# Stakeholder Management
class Stakeholder(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_id: str
    name: str
    organization: str
    role: str
    contact_email: str
    contact_phone: Optional[str] = None
    influence: StakeholderInfluence
    interest: StakeholderInterest
    communication_plan: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class StakeholderCreate(BaseModel):
    name: str
    organization: str
    role: str
    contact_email: str
    contact_phone: Optional[str] = None
    influence: StakeholderInfluence
    interest: StakeholderInterest
    communication_plan: Optional[str] = None

# Quality Assurance
class QAChecklist(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_id: str
    title: str
    description: str
    checklist_items: List[Dict[str, str]] = []  # [{"item": "Check X", "status": "pending", "notes": ""}]
    assigned_to: str
    completed_by: Optional[str] = None
    completion_date: Optional[datetime] = None
    overall_status: QACheckStatus = QACheckStatus.PENDING
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class QAChecklistCreate(BaseModel):
    title: str
    description: str
    checklist_items: List[Dict[str, str]]
    assigned_to: str

class QAChecklistUpdate(BaseModel):
    checklist_items: List[Dict[str, str]]
    overall_status: QACheckStatus
    completion_notes: Optional[str] = None

# Notification System
class Notification(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    project_id: Optional[str] = None
    title: str
    message: str
    notification_type: NotificationType
    read: bool = False
    read_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class NotificationCreate(BaseModel):
    user_id: str
    project_id: Optional[str] = None
    title: str
    message: str
    notification_type: NotificationType

# Existing models (KPI, Deliverable, Risk, Issue, etc.) remain the same
class KPI(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_id: str
    name: str
    type: KPIType
    baseline_value: float
    target_value: float
    actual_value: float = 0.0
    unit: str
    status: str = "active"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class KPICreate(BaseModel):
    name: str
    type: KPIType
    baseline_value: float
    target_value: float
    unit: str

class KPIUpdate(BaseModel):
    actual_value: float

class Deliverable(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_id: str
    name: str
    description: str
    due_date: datetime
    status: DeliverableStatus = DeliverableStatus.PLANNED
    certification_status: bool = False
    evidence_files: List[str] = []
    location_data: Optional[dict] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class DeliverableCreate(BaseModel):
    name: str
    description: str
    due_date: datetime

class DeliverableUpdate(BaseModel):
    status: DeliverableStatus
    certification_status: Optional[bool] = None

class Risk(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_id: str
    title: str
    description: str
    probability: int = Field(ge=1, le=5)
    impact: int = Field(ge=1, le=5)
    risk_score: int = Field(default=0)
    level: RiskLevel = RiskLevel.LOW
    mitigation_strategy: str
    contingency_plan: Optional[str] = None
    owner_id: str
    status: str = "active"
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class RiskCreate(BaseModel):
    title: str
    description: str
    probability: int = Field(ge=1, le=5)
    impact: int = Field(ge=1, le=5)
    mitigation_strategy: str
    contingency_plan: Optional[str] = None
    owner_id: str

class Issue(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_id: str
    title: str
    description: str
    priority: IssuePriority
    status: IssueStatus = IssueStatus.OPEN
    reporter_id: str
    assigned_to: Optional[str] = None
    resolution_strategy: Optional[str] = None
    resolution_notes: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    resolved_at: Optional[datetime] = None

class IssueCreate(BaseModel):
    title: str
    description: str
    priority: IssuePriority
    assigned_to: Optional[str] = None

class IssueUpdate(BaseModel):
    status: IssueStatus
    resolution_strategy: Optional[str] = None
    resolution_notes: Optional[str] = None
    assigned_to: Optional[str] = None

class ChangeRequest(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_id: str
    title: str
    description: str
    requested_by: str
    impact_assessment: dict
    status: ChangeRequestStatus = ChangeRequestStatus.PENDING
    approved_by: Optional[str] = None
    implementation_notes: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    approved_at: Optional[datetime] = None

class ChangeRequestCreate(BaseModel):
    title: str
    description: str
    impact_assessment: dict

class ChangeRequestUpdate(BaseModel):
    status: ChangeRequestStatus
    implementation_notes: Optional[str] = None

class SROICalculation(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    project_id: str
    inputs_cost: float
    outcomes_value: float
    sroi_ratio: float = 0.0
    calculation_notes: str
    calculated_by: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SROICreate(BaseModel):
    inputs_cost: float
    outcomes_value: float
    calculation_notes: str

# Helper functions
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return hashlib.sha256(plain_password.encode()).hexdigest() == hashed_password

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(hours=24)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def calculate_risk_level(probability: int, impact: int) -> RiskLevel:
    score = probability * impact
    if score <= 5:
        return RiskLevel.LOW
    elif score <= 10:
        return RiskLevel.MEDIUM
    elif score <= 15:
        return RiskLevel.HIGH
    else:
        return RiskLevel.CRITICAL

async def create_notification(user_id: str, title: str, message: str, notification_type: NotificationType, project_id: Optional[str] = None):
    notification = Notification(
        user_id=user_id,
        project_id=project_id,
        title=title,
        message=message,
        notification_type=notification_type
    )
    await db.notifications.insert_one(notification.dict())

async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        user_id: str = payload.get("sub")
        if user_id is None:
            raise HTTPException(status_code=401, detail="Invalid authentication")
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid authentication")
    
    user = await db.users.find_one({"id": user_id})
    if user is None:
        raise HTTPException(status_code=401, detail="User not found")
    return User(**user)

# Authentication endpoints
@api_router.post("/auth/register")
async def register(user_data: UserCreate):
    existing_user = await db.users.find_one({"username": user_data.username})
    if existing_user:
        raise HTTPException(status_code=400, detail="Username already exists")
    
    user = User(
        username=user_data.username,
        email=user_data.email,
        role=user_data.role,
        organization_name=user_data.organization_name
    )
    
    user_dict = user.dict()
    user_dict["password_hash"] = hash_password(user_data.password)
    
    await db.users.insert_one(user_dict)
    access_token = create_access_token({"sub": user.id})
    return {"access_token": access_token, "token_type": "bearer", "user": user}

@api_router.post("/auth/login")
async def login(user_data: UserLogin):
    user = await db.users.find_one({"username": user_data.username})
    if not user or not verify_password(user_data.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    access_token = create_access_token({"sub": user["id"]})
    return {"access_token": access_token, "token_type": "bearer", "user": User(**user)}

# Test endpoint to create users directly (temporary)
@api_router.post("/create-test-users")
async def create_test_users():
    # Clear existing users
    await db.users.delete_many({})
    
    # Create the three user accounts
    test_users = [
        {
            "id": str(uuid.uuid4()),
            "username": "admin",
            "email": "admin@isisp.org", 
            "role": "administrator",
            "organization_name": "ISISP Platform",
            "password_hash": hash_password("admin123"),
            "created_at": datetime.now(timezone.utc)
        },
        {
            "id": str(uuid.uuid4()),
            "username": "investor_demo",
            "email": "investor@fundingcorp.com",
            "role": "investor",
            "organization_name": "Impact Investment Fund",
            "password_hash": hash_password("investor123"),
            "created_at": datetime.now(timezone.utc)
        },
        {
            "id": str(uuid.uuid4()),
            "username": "social_demo",
            "email": "manager@socialimpact.org",
            "role": "social_actor",
            "organization_name": "Community Development Solutions", 
            "password_hash": hash_password("social123"),
            "created_at": datetime.now(timezone.utc)
        }
    ]
    
    for user_data in test_users:
        await db.users.insert_one(user_data)
    
    return {"message": "Test users created successfully", "users": [
        {"username": "admin", "password": "admin123", "role": "administrator"},
        {"username": "investor_demo", "password": "investor123", "role": "investor"},
        {"username": "social_demo", "password": "social123", "role": "social_actor"}
    ]}

# Project endpoints
@api_router.get("/projects", response_model=List[Project])
async def get_projects(current_user: User = Depends(get_current_user)):
    if current_user.role == UserRole.ADMINISTRATOR:
        projects = await db.projects.find().to_list(1000)
    elif current_user.role == UserRole.INVESTOR:
        projects = await db.projects.find({"investor_id": current_user.id}).to_list(1000)
    else:  # SOCIAL_ACTOR
        projects = await db.projects.find({"owner_id": current_user.id}).to_list(1000)
    
    return [Project(**project) for project in projects]

@api_router.post("/projects", response_model=Project)
async def create_project(project_data: ProjectCreate, current_user: User = Depends(get_current_user)):
    if current_user.role not in [UserRole.ADMINISTRATOR, UserRole.SOCIAL_ACTOR]:
        raise HTTPException(status_code=403, detail="Only administrators and social actors can create projects")
    
    project = Project(**project_data.dict(), owner_id=current_user.id, status=ProjectStatus.INITIATING)
    await db.projects.insert_one(project.dict())
    
    # Create notification for investor if assigned
    if project_data.investor_id:
        await create_notification(
            project_data.investor_id,
            "New Project Created",
            f"A new project '{project.title}' has been created and assigned to you for funding.",
            NotificationType.INFO,
            project.id
        )
    
    return project

@api_router.get("/projects/{project_id}", response_model=Project)
async def get_project(project_id: str, current_user: User = Depends(get_current_user)):
    project = await db.projects.find_one({"id": project_id})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    project_obj = Project(**project)
    
    # Check permissions
    if (current_user.role == UserRole.INVESTOR and project_obj.investor_id != current_user.id) or \
       (current_user.role == UserRole.SOCIAL_ACTOR and project_obj.owner_id != current_user.id):
        raise HTTPException(status_code=403, detail="Access denied")
    
    return project_obj

# Phase Gate Management endpoints
@api_router.get("/projects/{project_id}/phase-gates", response_model=List[PhaseGate])
async def get_project_phase_gates(project_id: str, current_user: User = Depends(get_current_user)):
    phase_gates = await db.phase_gates.find({"project_id": project_id}).to_list(1000)
    return [PhaseGate(**gate) for gate in phase_gates]

@api_router.post("/projects/{project_id}/phase-gates", response_model=PhaseGate)
async def create_phase_gate(project_id: str, gate_data: PhaseGateCreate, current_user: User = Depends(get_current_user)):
    gate = PhaseGate(**gate_data.dict(), project_id=project_id)
    await db.phase_gates.insert_one(gate.dict())
    
    # Notify administrator about phase gate review
    admins = await db.users.find({"role": "administrator"}).to_list(1000)
    for admin in admins:
        await create_notification(
            admin["id"],
            "Phase Gate Review Required",
            f"Project phase gate review required for {gate_data.gate_type}",
            NotificationType.WARNING,
            project_id
        )
    
    return gate

@api_router.put("/projects/{project_id}/phase-gates/{gate_id}", response_model=PhaseGate)
async def update_phase_gate(project_id: str, gate_id: str, gate_data: PhaseGateUpdate, current_user: User = Depends(get_current_user)):
    if current_user.role != UserRole.ADMINISTRATOR:
        raise HTTPException(status_code=403, detail="Only administrators can approve phase gates")
    
    update_dict = gate_data.dict(exclude_unset=True)
    if gate_data.status == PhaseGateStatus.APPROVED:
        update_dict["approved_by"] = current_user.id
        update_dict["approved_at"] = datetime.now(timezone.utc)
        
        # Update project phase if approved
        await db.projects.update_one({"id": project_id}, {"$set": {"phase_approved": True}})
    
    await db.phase_gates.update_one({"id": gate_id}, {"$set": update_dict})
    updated_gate = await db.phase_gates.find_one({"id": gate_id})
    return PhaseGate(**updated_gate)

# Document Management endpoints
@api_router.get("/projects/{project_id}/documents", response_model=List[Document])
async def get_project_documents(project_id: str, current_user: User = Depends(get_current_user)):
    documents = await db.documents.find({"project_id": project_id}).to_list(1000)
    return [Document(**doc) for doc in documents]

@api_router.post("/projects/{project_id}/documents", response_model=Document)
async def create_document(project_id: str, doc_data: DocumentCreate, current_user: User = Depends(get_current_user)):
    document = Document(**doc_data.dict(), project_id=project_id, uploaded_by=current_user.id)
    await db.documents.insert_one(document.dict())
    return document

@api_router.get("/document-templates")
async def get_document_templates():
    templates = {
        "project_charter": {
            "title": "Project Charter Template",
            "sections": [
                {"name": "Project Overview", "fields": ["title", "description", "objectives"]},
                {"name": "Scope", "fields": ["in_scope", "out_of_scope", "assumptions"]},
                {"name": "Stakeholders", "fields": ["project_sponsor", "project_manager", "key_stakeholders"]},
                {"name": "Success Criteria", "fields": ["kpis", "deliverables", "timeline"]},
                {"name": "Budget", "fields": ["total_budget", "budget_breakdown", "funding_source"]}
            ]
        },
        "business_case": {
            "title": "Business Case Template",
            "sections": [
                {"name": "Executive Summary", "fields": ["problem_statement", "proposed_solution", "benefits"]},
                {"name": "Options Analysis", "fields": ["option1", "option2", "recommended_option"]},
                {"name": "Financial Analysis", "fields": ["costs", "benefits", "roi", "payback_period"]},
                {"name": "Risk Assessment", "fields": ["key_risks", "mitigation_strategies"]}
            ]
        },
        "risk_plan": {
            "title": "Risk Management Plan Template",
            "sections": [
                {"name": "Risk Identification", "fields": ["risk_categories", "identification_methods"]},
                {"name": "Risk Assessment", "fields": ["probability_scale", "impact_scale", "risk_matrix"]},
                {"name": "Risk Response", "fields": ["response_strategies", "contingency_plans"]},
                {"name": "Risk Monitoring", "fields": ["review_frequency", "escalation_procedures"]}
            ]
        }
    }
    return templates

# Stakeholder Management endpoints
@api_router.get("/projects/{project_id}/stakeholders", response_model=List[Stakeholder])
async def get_project_stakeholders(project_id: str, current_user: User = Depends(get_current_user)):
    stakeholders = await db.stakeholders.find({"project_id": project_id}).to_list(1000)
    return [Stakeholder(**stakeholder) for stakeholder in stakeholders]

@api_router.post("/projects/{project_id}/stakeholders", response_model=Stakeholder)
async def create_stakeholder(project_id: str, stakeholder_data: StakeholderCreate, current_user: User = Depends(get_current_user)):
    stakeholder = Stakeholder(**stakeholder_data.dict(), project_id=project_id)
    await db.stakeholders.insert_one(stakeholder.dict())
    return stakeholder

# Quality Assurance endpoints
@api_router.get("/projects/{project_id}/qa-checklists", response_model=List[QAChecklist])
async def get_project_qa_checklists(project_id: str, current_user: User = Depends(get_current_user)):
    checklists = await db.qa_checklists.find({"project_id": project_id}).to_list(1000)
    return [QAChecklist(**checklist) for checklist in checklists]

@api_router.post("/projects/{project_id}/qa-checklists", response_model=QAChecklist)
async def create_qa_checklist(project_id: str, checklist_data: QAChecklistCreate, current_user: User = Depends(get_current_user)):
    checklist = QAChecklist(**checklist_data.dict(), project_id=project_id)
    await db.qa_checklists.insert_one(checklist.dict())
    
    # Notify assigned person
    await create_notification(
        checklist_data.assigned_to,
        "New QA Checklist Assigned",
        f"You have been assigned a new quality assurance checklist: {checklist_data.title}",
        NotificationType.INFO,
        project_id
    )
    
    return checklist

@api_router.put("/projects/{project_id}/qa-checklists/{checklist_id}", response_model=QAChecklist)
async def update_qa_checklist(project_id: str, checklist_id: str, checklist_data: QAChecklistUpdate, current_user: User = Depends(get_current_user)):
    update_dict = checklist_data.dict(exclude_unset=True)
    
    if checklist_data.overall_status in [QACheckStatus.PASSED, QACheckStatus.FAILED]:
        update_dict["completed_by"] = current_user.id
        update_dict["completion_date"] = datetime.now(timezone.utc)
    
    await db.qa_checklists.update_one({"id": checklist_id}, {"$set": update_dict})
    updated_checklist = await db.qa_checklists.find_one({"id": checklist_id})
    return QAChecklist(**updated_checklist)

# Old notification endpoints removed - replaced by Advanced Notification System APIs below

# Existing endpoints (Risk, Issue, KPI, Deliverable, SROI, etc.) - keeping them as they are
@api_router.get("/projects/{project_id}/risks", response_model=List[Risk])
async def get_project_risks(project_id: str, current_user: User = Depends(get_current_user)):
    risks = await db.risks.find({"project_id": project_id}).to_list(1000)
    return [Risk(**risk) for risk in risks]

@api_router.post("/projects/{project_id}/risks", response_model=Risk)
async def create_risk(project_id: str, risk_data: RiskCreate, current_user: User = Depends(get_current_user)):
    risk_score = risk_data.probability * risk_data.impact
    level = calculate_risk_level(risk_data.probability, risk_data.impact)
    
    risk = Risk(
        **risk_data.dict(), 
        project_id=project_id, 
        risk_score=risk_score,
        level=level
    )
    await db.risks.insert_one(risk.dict())
    
    # Send notifications for critical risks
    if level == RiskLevel.CRITICAL:
        project = await db.projects.find_one({"id": project_id})
        if project and project.get("investor_id"):
            await create_notification(
                project["investor_id"],
                "Critical Risk Identified",
                f"A critical risk has been identified in project: {risk.title}",
                NotificationType.ERROR,
                project_id
            )
    
    return risk

@api_router.get("/projects/{project_id}/issues", response_model=List[Issue])
async def get_project_issues(project_id: str, current_user: User = Depends(get_current_user)):
    issues = await db.issues.find({"project_id": project_id}).to_list(1000)
    return [Issue(**issue) for issue in issues]

@api_router.post("/projects/{project_id}/issues", response_model=Issue)
async def create_issue(project_id: str, issue_data: IssueCreate, current_user: User = Depends(get_current_user)):
    issue = Issue(**issue_data.dict(), project_id=project_id, reporter_id=current_user.id)
    await db.issues.insert_one(issue.dict())
    
    # Send notifications for urgent issues
    if issue_data.priority == IssuePriority.URGENT:
        admins = await db.users.find({"role": "administrator"}).to_list(1000)
        for admin in admins:
            await create_notification(
                admin["id"],
                "Urgent Issue Reported",
                f"An urgent issue has been reported: {issue.title}",
                NotificationType.ERROR,
                project_id
            )
    
    return issue

@api_router.put("/projects/{project_id}/issues/{issue_id}", response_model=Issue)
async def update_issue(project_id: str, issue_id: str, issue_data: IssueUpdate, current_user: User = Depends(get_current_user)):
    update_dict = issue_data.dict(exclude_unset=True)
    
    if issue_data.status == IssueStatus.RESOLVED:
        update_dict["resolved_at"] = datetime.now(timezone.utc)
    
    await db.issues.update_one({"id": issue_id}, {"$set": update_dict})
    updated_issue = await db.issues.find_one({"id": issue_id})
    return Issue(**updated_issue)

@api_router.get("/projects/{project_id}/changes", response_model=List[ChangeRequest])
async def get_project_changes(project_id: str, current_user: User = Depends(get_current_user)):
    changes = await db.changes.find({"project_id": project_id}).to_list(1000)
    return [ChangeRequest(**change) for change in changes]

@api_router.post("/projects/{project_id}/changes", response_model=ChangeRequest)
async def create_change_request(project_id: str, change_data: ChangeRequestCreate, current_user: User = Depends(get_current_user)):
    change = ChangeRequest(**change_data.dict(), project_id=project_id, requested_by=current_user.id)
    await db.changes.insert_one(change.dict())
    return change

@api_router.put("/projects/{project_id}/changes/{change_id}", response_model=ChangeRequest)
async def update_change_request(project_id: str, change_id: str, change_data: ChangeRequestUpdate, current_user: User = Depends(get_current_user)):
    if current_user.role != UserRole.ADMINISTRATOR and change_data.status in [ChangeRequestStatus.APPROVED, ChangeRequestStatus.REJECTED]:
        raise HTTPException(status_code=403, detail="Only administrators can approve/reject changes")
    
    update_dict = change_data.dict(exclude_unset=True)
    if change_data.status == ChangeRequestStatus.APPROVED:
        update_dict["approved_by"] = current_user.id
        update_dict["approved_at"] = datetime.now(timezone.utc)
    
    await db.changes.update_one({"id": change_id}, {"$set": update_dict})
    updated_change = await db.changes.find_one({"id": change_id})
    return ChangeRequest(**updated_change)

@api_router.get("/projects/{project_id}/sroi", response_model=List[SROICalculation])
async def get_project_sroi(project_id: str, current_user: User = Depends(get_current_user)):
    sroi_calculations = await db.sroi.find({"project_id": project_id}).to_list(1000)
    return [SROICalculation(**calc) for calc in sroi_calculations]

# Gantt Chart & Timeline Management APIs
@api_router.get("/projects/{project_id}/tasks")
async def get_project_tasks(project_id: str):
    tasks = await db.tasks.find({"project_id": project_id}).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for task in tasks:
        if '_id' in task:
            del task['_id']
    return tasks

@api_router.post("/projects/{project_id}/tasks")
async def create_task(project_id: str, task_data: dict):
    task = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **task_data,
        "created_at": datetime.now(timezone.utc)
    }
    await db.tasks.insert_one(task)
    # Remove MongoDB ObjectId before returning
    if '_id' in task:
        del task['_id']
    return task

@api_router.patch("/projects/{project_id}/tasks/{task_id}")
async def update_task(project_id: str, task_id: str, update_data: dict):
    await db.tasks.update_one(
        {"id": task_id, "project_id": project_id},
        {"$set": update_data}
    )
    return {"message": "Task updated successfully"}

@api_router.get("/projects/{project_id}/milestones")
async def get_project_milestones(project_id: str):
    milestones = await db.milestones.find({"project_id": project_id}).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for milestone in milestones:
        if '_id' in milestone:
            del milestone['_id']
    return milestones

@api_router.post("/projects/{project_id}/milestones")
async def create_milestone(project_id: str, milestone_data: dict):
    milestone = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **milestone_data,
        "created_at": datetime.now(timezone.utc)
    }
    await db.milestones.insert_one(milestone)
    # Remove MongoDB ObjectId before returning
    if '_id' in milestone:
        del milestone['_id']
    return milestone

@api_router.get("/projects/{project_id}/task-dependencies")
async def get_task_dependencies(project_id: str):
    dependencies = await db.task_dependencies.find({"project_id": project_id}).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for dependency in dependencies:
        if '_id' in dependency:
            del dependency['_id']
    return dependencies

# Financial Management APIs
@api_router.get("/projects/{project_id}/budget")
async def get_project_budget(project_id: str):
    budget = await db.project_budgets.find_one({"project_id": project_id})
    if not budget:
        # Return default budget based on project
        project = await db.projects.find_one({"id": project_id})
        return {"project_id": project_id, "total_budget": project.get("budget", 0) if project else 0}
    # Remove MongoDB ObjectId before returning
    if '_id' in budget:
        del budget['_id']
    return budget

@api_router.get("/projects/{project_id}/expenses")
async def get_project_expenses(project_id: str, period: str = "current_month"):
    expenses = await db.expenses.find({"project_id": project_id}).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for expense in expenses:
        if '_id' in expense:
            del expense['_id']
    return expenses

@api_router.post("/projects/{project_id}/expenses")
async def create_expense(project_id: str, expense_data: dict):
    expense = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **expense_data,
        "created_at": datetime.now(timezone.utc)
    }
    await db.expenses.insert_one(expense)
    # Remove MongoDB ObjectId before returning
    if '_id' in expense:
        del expense['_id']
    return expense

@api_router.patch("/projects/{project_id}/expenses/{expense_id}")
async def update_expense(project_id: str, expense_id: str, update_data: dict):
    await db.expenses.update_one(
        {"id": expense_id, "project_id": project_id},
        {"$set": update_data}
    )
    return {"message": "Expense updated successfully"}

@api_router.get("/projects/{project_id}/payments")
async def get_project_payments(project_id: str, period: str = "current_month"):
    payments = await db.payments.find({"project_id": project_id}).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for payment in payments:
        if '_id' in payment:
            del payment['_id']
    return payments

@api_router.post("/projects/{project_id}/payments")
async def create_payment(project_id: str, payment_data: dict):
    payment = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **payment_data,
        "created_at": datetime.now(timezone.utc)
    }
    await db.payments.insert_one(payment)
    # Remove MongoDB ObjectId before returning
    if '_id' in payment:
        del payment['_id']
    return payment

@api_router.patch("/projects/{project_id}/payments/{payment_id}")
async def update_payment(project_id: str, payment_id: str, update_data: dict):
    await db.payments.update_one(
        {"id": payment_id, "project_id": project_id},
        {"$set": update_data}
    )
    return {"message": "Payment updated successfully"}

@api_router.get("/projects/{project_id}/budget-categories")
async def get_budget_categories(project_id: str):
    categories = await db.budget_categories.find({"project_id": project_id}).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for category in categories:
        if '_id' in category:
            del category['_id']
    return categories

@api_router.post("/projects/{project_id}/budget-categories")
async def create_budget_category(project_id: str, category_data: dict):
    category = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **category_data,
        "created_at": datetime.now(timezone.utc)
    }
    await db.budget_categories.insert_one(category)
    # Remove MongoDB ObjectId before returning
    if '_id' in category:
        del category['_id']
    return category

# Beneficiary Tracking APIs
@api_router.get("/projects/{project_id}/beneficiaries")
async def get_project_beneficiaries(project_id: str):
    beneficiaries = await db.beneficiaries.find({"project_id": project_id}).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for beneficiary in beneficiaries:
        if '_id' in beneficiary:
            del beneficiary['_id']
    return beneficiaries

@api_router.post("/projects/{project_id}/beneficiaries")
async def create_beneficiary(project_id: str, beneficiary_data: dict):
    beneficiary = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **beneficiary_data,
        "created_at": datetime.now(timezone.utc)
    }
    await db.beneficiaries.insert_one(beneficiary)
    # Remove MongoDB ObjectId before returning
    if '_id' in beneficiary:
        del beneficiary['_id']
    return beneficiary

@api_router.get("/projects/{project_id}/beneficiary-outcomes")
async def get_beneficiary_outcomes(project_id: str):
    outcomes = await db.beneficiary_outcomes.find({"project_id": project_id}).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for outcome in outcomes:
        if '_id' in outcome:
            del outcome['_id']
    return outcomes

@api_router.post("/projects/{project_id}/beneficiary-outcomes")
async def create_beneficiary_outcome(project_id: str, outcome_data: dict):
    outcome = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **outcome_data,
        "created_at": datetime.now(timezone.utc)
    }
    await db.beneficiary_outcomes.insert_one(outcome)
    # Remove MongoDB ObjectId before returning
    if '_id' in outcome:
        del outcome['_id']
    return outcome

# Compliance & Audit APIs
@api_router.get("/projects/{project_id}/compliance-items")
async def get_compliance_items(project_id: str):
    items = await db.compliance_items.find({"project_id": project_id}).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for item in items:
        if '_id' in item:
            del item['_id']
    return items

@api_router.post("/projects/{project_id}/compliance-items")
async def create_compliance_item(project_id: str, item_data: dict):
    item = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **item_data,
        "created_at": datetime.now(timezone.utc)
    }
    await db.compliance_items.insert_one(item)
    # Remove MongoDB ObjectId before returning
    if '_id' in item:
        del item['_id']
    return item

@api_router.patch("/projects/{project_id}/compliance-items/{item_id}")
async def update_compliance_item(project_id: str, item_id: str, update_data: dict):
    await db.compliance_items.update_one(
        {"id": item_id, "project_id": project_id},
        {"$set": update_data}
    )
    return {"message": "Compliance item updated successfully"}

@api_router.get("/projects/{project_id}/certifications")
async def get_certifications(project_id: str):
    certifications = await db.certifications.find({"project_id": project_id}).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for certification in certifications:
        if '_id' in certification:
            del certification['_id']
    return certifications

@api_router.post("/projects/{project_id}/certifications")
async def create_certification(project_id: str, cert_data: dict):
    certification = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **cert_data,
        "created_at": datetime.now(timezone.utc)
    }
    await db.certifications.insert_one(certification)
    # Remove MongoDB ObjectId before returning
    if '_id' in certification:
        del certification['_id']
    return certification

@api_router.get("/projects/{project_id}/audit-trail")
async def get_audit_trail(project_id: str):
    audit_entries = await db.audit_trail.find({"project_id": project_id}).sort("timestamp", -1).to_list(length=100)
    # Convert MongoDB documents to JSON-serializable format
    for entry in audit_entries:
        if '_id' in entry:
            del entry['_id']
    return audit_entries

# Video Verification System APIs
@api_router.get("/projects/{project_id}/videos")
async def get_project_videos(project_id: str):
    videos = await db.videos.find({"project_id": project_id}).sort("uploaded_at", -1).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for video in videos:
        if '_id' in video:
            del video['_id']
    return videos

@api_router.post("/projects/{project_id}/videos")
async def upload_video(project_id: str, video_data: dict):
    video = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **video_data,
        "verification_status": "pending",
        "uploaded_at": datetime.now(timezone.utc),
        "created_at": datetime.now(timezone.utc)
    }
    await db.videos.insert_one(video)
    
    # Create verification request
    verification_request = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        "video_id": video["id"],
        "status": "pending",
        "submitted_by": video_data.get("uploaded_by", "Unknown"),
        "submitted_at": datetime.now(timezone.utc),
        "created_at": datetime.now(timezone.utc)
    }
    await db.video_verification_requests.insert_one(verification_request)
    
    # Remove MongoDB ObjectId before returning
    if '_id' in video:
        del video['_id']
    return video

@api_router.patch("/projects/{project_id}/videos/{video_id}")
async def update_video(project_id: str, video_id: str, update_data: dict):
    await db.videos.update_one(
        {"id": video_id, "project_id": project_id},
        {"$set": update_data}
    )
    return {"message": "Video updated successfully"}

@api_router.delete("/projects/{project_id}/videos/{video_id}")
async def delete_video(project_id: str, video_id: str):
    # Delete video record
    await db.videos.delete_one({"id": video_id, "project_id": project_id})
    
    # Delete associated verification requests and reviews
    await db.video_verification_requests.delete_many({
        "video_id": video_id, 
        "project_id": project_id
    })
    await db.video_reviews.delete_many({
        "video_id": video_id, 
        "project_id": project_id
    })
    
    return {"message": "Video deleted successfully"}

@api_router.get("/projects/{project_id}/video-verification-requests")
async def get_verification_requests(project_id: str):
    requests = await db.video_verification_requests.find({
        "project_id": project_id
    }).sort("submitted_at", -1).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for request in requests:
        if '_id' in request:
            del request['_id']
    return requests

@api_router.post("/projects/{project_id}/video-reviews")
async def create_video_review(project_id: str, review_data: dict):
    review = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **review_data,
        "reviewed_at": datetime.now(timezone.utc),
        "created_at": datetime.now(timezone.utc)
    }
    await db.video_reviews.insert_one(review)
    
    # Update verification request status
    await db.video_verification_requests.update_one(
        {"video_id": review_data["video_id"], "project_id": project_id},
        {"$set": {"status": "completed"}}
    )
    
    # Remove MongoDB ObjectId before returning
    if '_id' in review:
        del review['_id']
    return review

@api_router.get("/projects/{project_id}/video-reviews")
async def get_video_reviews(project_id: str):
    reviews = await db.video_reviews.find({
        "project_id": project_id
    }).sort("reviewed_at", -1).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for review in reviews:
        if '_id' in review:
            del review['_id']
    return reviews

# Mobile Field Application APIs
@api_router.get("/projects/{project_id}/field-data")
async def get_field_data(project_id: str):
    field_data = await db.field_data.find({
        "project_id": project_id
    }).sort("timestamp", -1).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for entry in field_data:
        if '_id' in entry:
            del entry['_id']
    return field_data

@api_router.post("/projects/{project_id}/field-data")
async def create_field_data(project_id: str, field_entry: dict, current_user: User = Depends(get_current_user)):
    entry = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **field_entry,
        "created_at": datetime.now(timezone.utc)
    }
    await db.field_data.insert_one(entry)
    
    # Create notification for field data submission
    data_type = field_entry.get("type", "field data")
    location = field_entry.get("data", {}).get("location", "Unknown location")
    
    await create_event_notification(
        event_type="mobile_field_update",
        message=f"New {data_type} submitted from {location}",
        user_id=current_user.id,
        related_id=entry["id"],
        project_id=project_id,
        priority="medium"
    )
    
    # Remove MongoDB ObjectId before returning
    if '_id' in entry:
        del entry['_id']
    return entry

@api_router.get("/projects/{project_id}/mobile-sync")
async def get_mobile_sync_data(project_id: str):
    # Get all relevant data for mobile sync
    field_data = await db.field_data.find({"project_id": project_id}).to_list(length=None)
    tasks = await db.tasks.find({"project_id": project_id}).to_list(length=None)
    deliverables = await db.deliverables.find({"project_id": project_id}).to_list(length=None)
    
    # Clean MongoDB ObjectIds
    for entry in field_data:
        if '_id' in entry:
            del entry['_id']
    for task in tasks:
        if '_id' in task:
            del task['_id']
    for deliverable in deliverables:
        if '_id' in deliverable:
            del deliverable['_id']
    
    return {
        "field_data": field_data,
        "tasks": tasks,
        "deliverables": deliverables,
        "sync_timestamp": datetime.now(timezone.utc).isoformat()
    }

@api_router.post("/projects/{project_id}/mobile-batch-sync")
async def batch_sync_mobile_data(project_id: str, batch_data: dict):
    results = {
        "successful": 0,
        "failed": 0,
        "errors": []
    }
    
    entries = batch_data.get("entries", [])
    
    for entry_data in entries:
        try:
            entry = {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                **entry_data,
                "created_at": datetime.now(timezone.utc)
            }
            await db.field_data.insert_one(entry)
            results["successful"] += 1
        except Exception as e:
            results["failed"] += 1
            results["errors"].append(str(e))
    
    return results

# Advanced Notification System APIs
@api_router.get("/notifications")
async def get_user_notifications(
    current_user: User = Depends(get_current_user),
    unread_only: bool = False,
    limit: int = 50
):
    """Get notifications for current user"""
    query = {"user_id": current_user.id}
    if unread_only:
        query["read"] = False
    
    notifications = await db.notifications.find(query).sort("created_at", -1).limit(limit).to_list(length=None)
    
    # Convert MongoDB documents to JSON-serializable format and ensure compatibility
    result = []
    for notification in notifications:
        if '_id' in notification:
            del notification['_id']
        
        # Ensure backward compatibility with old notification format
        if 'title' not in notification and 'message' in notification:
            notification['title'] = notification['message'][:50] + "..." if len(notification['message']) > 50 else notification['message']
        
        if 'notification_type' not in notification:
            notification['notification_type'] = notification.get('event_type', 'info')
        
        result.append(notification)
    
    return result

@api_router.post("/notifications")
async def create_notification_endpoint(notification_data: dict):
    """Create a new notification via API endpoint"""
    notification = {
        "id": str(uuid.uuid4()),
        **notification_data,
        "read": False,
        "created_at": datetime.now(timezone.utc)
    }
    
    # Ensure required fields are present for backward compatibility
    if 'title' not in notification and 'message' in notification:
        notification['title'] = notification['message'][:50] + "..." if len(notification['message']) > 50 else notification['message']
    
    if 'notification_type' not in notification:
        notification['notification_type'] = notification.get('event_type', 'info')
    
    await db.notifications.insert_one(notification)
    
    # Remove MongoDB ObjectId before returning
    if '_id' in notification:
        del notification['_id']
    
    return notification

@api_router.patch("/notifications/{notification_id}/read")
async def mark_notification_read(
    notification_id: str, 
    current_user: User = Depends(get_current_user)
):
    """Mark notification as read"""
    result = await db.notifications.update_one(
        {"id": notification_id, "user_id": current_user.id},
        {"$set": {"read": True, "read_at": datetime.now(timezone.utc)}}
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Notification not found")
    
    return {"message": "Notification marked as read"}

@api_router.patch("/notifications/mark-all-read")
async def mark_all_notifications_read(current_user: User = Depends(get_current_user)):
    """Mark all notifications as read for current user"""
    result = await db.notifications.update_many(
        {"user_id": current_user.id, "read": False},
        {"$set": {"read": True, "read_at": datetime.now(timezone.utc)}}
    )
    
    return {"message": f"Marked {result.modified_count} notifications as read"}

@api_router.delete("/notifications/{notification_id}")
async def delete_notification(
    notification_id: str,
    current_user: User = Depends(get_current_user)
):
    """Delete a notification"""
    result = await db.notifications.delete_one(
        {"id": notification_id, "user_id": current_user.id}
    )
    
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Notification not found")
    
    return {"message": "Notification deleted"}

@api_router.get("/notifications/unread-count")
async def get_unread_count(current_user: User = Depends(get_current_user)):
    """Get count of unread notifications"""
    count = await db.notifications.count_documents({
        "user_id": current_user.id,
        "read": False
    })
    
    return {"unread_count": count}

# Notification Preferences APIs
@api_router.get("/notification-preferences")
async def get_notification_preferences(current_user: User = Depends(get_current_user)):
    """Get user notification preferences"""
    preferences = await db.notification_preferences.find_one({"user_id": current_user.id})
    
    if not preferences:
        # Return default preferences
        return {
            "user_id": current_user.id,
            "mobile_field_updates": True,
            "project_milestones": True,
            "financial_approvals": True,
            "compliance_deadlines": True,
            "quality_issues": True,
            "procurement_updates": True,
            "system_announcements": True
        }
    
    if '_id' in preferences:
        del preferences['_id']
    
    return preferences

@api_router.put("/notification-preferences")
async def update_notification_preferences(
    preferences: dict,
    current_user: User = Depends(get_current_user)
):
    """Update user notification preferences"""
    preferences_data = {
        "user_id": current_user.id,
        **preferences,
        "updated_at": datetime.now(timezone.utc)
    }
    
    await db.notification_preferences.update_one(
        {"user_id": current_user.id},
        {"$set": preferences_data},
        upsert=True
    )
    
    return {"message": "Notification preferences updated"}

# Notification Event Triggers
async def create_event_notification(
    event_type: str,
    message: str,
    user_id: str,
    related_id: str = None,
    project_id: str = None,
    priority: str = "medium"
):
    """Helper function to create event-based notifications"""
    notification = {
        "id": str(uuid.uuid4()),
        "user_id": user_id,
        "event_type": event_type,
        "message": message,
        "related_id": related_id,
        "project_id": project_id,
        "priority": priority,
        "read": False,
        "created_at": datetime.now(timezone.utc)
    }
    
    await db.notifications.insert_one(notification)
    return notification

# Quality Assurance Module APIs
@api_router.get("/projects/{project_id}/qa-templates")
async def get_qa_templates(project_id: str, current_user: User = Depends(get_current_user)):
    """Get QA checklist templates for project"""
    templates = await db.qa_templates.find({
        "project_id": project_id
    }).to_list(length=None)
    
    # Convert MongoDB documents to JSON-serializable format
    for template in templates:
        if '_id' in template:
            del template['_id']
    
    return templates

@api_router.post("/projects/{project_id}/qa-templates")
async def create_qa_template(
    project_id: str, 
    template_data: dict, 
    current_user: User = Depends(get_current_user)
):
    """Create QA checklist template"""
    template = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **template_data,
        "created_by": current_user.id,
        "created_at": datetime.now(timezone.utc)
    }
    await db.qa_templates.insert_one(template)
    
    # Create notification
    await create_event_notification(
        event_type="quality_update",
        message=f"New QA template created: {template_data.get('name', 'Unnamed template')}",
        user_id=current_user.id,
        related_id=template["id"],
        project_id=project_id
    )
    
    # Remove MongoDB ObjectId before returning
    if '_id' in template:
        del template['_id']
    
    return template

@api_router.get("/projects/{project_id}/qa-inspections")
async def get_qa_inspections(project_id: str, current_user: User = Depends(get_current_user)):
    """Get QA inspections for project"""
    inspections = await db.qa_inspections.find({
        "project_id": project_id
    }).sort("inspection_date", -1).to_list(length=None)
    
    # Convert MongoDB documents to JSON-serializable format
    for inspection in inspections:
        if '_id' in inspection:
            del inspection['_id']
    
    return inspections

@api_router.post("/projects/{project_id}/qa-inspections")
async def create_qa_inspection(
    project_id: str, 
    inspection_data: dict, 
    current_user: User = Depends(get_current_user)
):
    """Create QA inspection record"""
    inspection = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **inspection_data,
        "inspector": current_user.username,
        "inspector_id": current_user.id,
        "created_at": datetime.now(timezone.utc)
    }
    await db.qa_inspections.insert_one(inspection)
    
    # Create notification if inspection failed
    status = inspection_data.get("status", "passed")
    if status == "failed":
        await create_event_notification(
            event_type="quality_issue",
            message=f"QA inspection failed: {inspection_data.get('item_name', 'Unknown item')}",
            user_id=current_user.id,
            related_id=inspection["id"],
            project_id=project_id,
            priority="high"
        )
    
    # Remove MongoDB ObjectId before returning
    if '_id' in inspection:
        del inspection['_id']
    
    return inspection

@api_router.patch("/projects/{project_id}/qa-inspections/{inspection_id}")
async def update_qa_inspection(
    project_id: str,
    inspection_id: str,
    inspection_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Update QA inspection record"""
    update_data = {
        **inspection_data,
        "updated_by": current_user.id,
        "updated_at": datetime.now(timezone.utc)
    }
    
    result = await db.qa_inspections.update_one(
        {"id": inspection_id, "project_id": project_id},
        {"$set": update_data}
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="QA inspection not found")
    
    return {"message": "QA inspection updated successfully"}

@api_router.get("/projects/{project_id}/non-conformances")
async def get_non_conformances(project_id: str, current_user: User = Depends(get_current_user)):
    """Get non-conformance records for project"""
    non_conformances = await db.non_conformances.find({
        "project_id": project_id
    }).sort("reported_date", -1).to_list(length=None)
    
    # Convert MongoDB documents to JSON-serializable format
    for nc in non_conformances:
        if '_id' in nc:
            del nc['_id']
    
    return non_conformances

@api_router.post("/projects/{project_id}/non-conformances")
async def create_non_conformance(
    project_id: str,
    nc_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Create non-conformance record"""
    non_conformance = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **nc_data,
        "reported_by": current_user.username,
        "reporter_id": current_user.id,
        "status": "open",
        "created_at": datetime.now(timezone.utc)
    }
    await db.non_conformances.insert_one(non_conformance)
    
    # Create high priority notification
    severity = nc_data.get("severity", "medium")
    priority = "high" if severity in ["high", "critical"] else "medium"
    
    await create_event_notification(
        event_type="quality_issue",
        message=f"Non-conformance reported: {nc_data.get('title', 'Quality issue')}",
        user_id=current_user.id,
        related_id=non_conformance["id"],
        project_id=project_id,
        priority=priority
    )
    
    # Remove MongoDB ObjectId before returning
    if '_id' in non_conformance:
        del non_conformance['_id']
    
    return non_conformance

@api_router.patch("/projects/{project_id}/non-conformances/{nc_id}")
async def update_non_conformance(
    project_id: str,
    nc_id: str,
    nc_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Update non-conformance record"""
    update_data = {
        **nc_data,
        "updated_by": current_user.id,
        "updated_at": datetime.now(timezone.utc)
    }
    
    result = await db.non_conformances.update_one(
        {"id": nc_id, "project_id": project_id},
        {"$set": update_data}
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Non-conformance not found")
    
    return {"message": "Non-conformance updated successfully"}

@api_router.get("/projects/{project_id}/corrective-actions")
async def get_corrective_actions(project_id: str, current_user: User = Depends(get_current_user)):
    """Get corrective actions for project"""
    actions = await db.corrective_actions.find({
        "project_id": project_id
    }).sort("due_date", 1).to_list(length=None)
    
    # Convert MongoDB documents to JSON-serializable format
    for action in actions:
        if '_id' in action:
            del action['_id']
    
    return actions

@api_router.post("/projects/{project_id}/corrective-actions")
async def create_corrective_action(
    project_id: str,
    action_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Create corrective action"""
    action = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **action_data,
        "created_by": current_user.username,
        "creator_id": current_user.id,
        "status": "planned",
        "created_at": datetime.now(timezone.utc)
    }
    await db.corrective_actions.insert_one(action)
    
    # Create notification for assigned person
    assigned_to_id = action_data.get("assigned_to_id")
    if assigned_to_id:
        await create_event_notification(
            event_type="corrective_action_assigned",
            message=f"Corrective action assigned: {action_data.get('title', 'Quality action')}",
            user_id=assigned_to_id,
            related_id=action["id"],
            project_id=project_id,
            priority="medium"
        )
    
    # Remove MongoDB ObjectId before returning
    if '_id' in action:
        del action['_id']
    
    return action

@api_router.patch("/projects/{project_id}/corrective-actions/{action_id}")
async def update_corrective_action(
    project_id: str,
    action_id: str,
    action_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Update corrective action"""
    update_data = {
        **action_data,
        "updated_by": current_user.id,
        "updated_at": datetime.now(timezone.utc)
    }
    
    # If status changed to completed, notify creator
    if action_data.get("status") == "completed":
        action_record = await db.corrective_actions.find_one({"id": action_id, "project_id": project_id})
        if action_record:
            await create_event_notification(
                event_type="corrective_action_completed",
                message=f"Corrective action completed: {action_record.get('title', 'Quality action')}",
                user_id=action_record.get("creator_id"),
                related_id=action_id,
                project_id=project_id,
                priority="low"
            )
    
    result = await db.corrective_actions.update_one(
        {"id": action_id, "project_id": project_id},
        {"$set": update_data}
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Corrective action not found")
    
    return {"message": "Corrective action updated successfully"}

@api_router.get("/projects/{project_id}/quality-metrics")
async def get_quality_metrics(project_id: str, current_user: User = Depends(get_current_user)):
    """Get quality metrics summary for project"""
    # Get counts and calculations for quality metrics
    total_inspections = await db.qa_inspections.count_documents({"project_id": project_id})
    passed_inspections = await db.qa_inspections.count_documents({
        "project_id": project_id, 
        "status": "passed"
    })
    
    total_non_conformances = await db.non_conformances.count_documents({"project_id": project_id})
    open_non_conformances = await db.non_conformances.count_documents({
        "project_id": project_id, 
        "status": "open"
    })
    
    total_corrective_actions = await db.corrective_actions.count_documents({"project_id": project_id})
    completed_actions = await db.corrective_actions.count_documents({
        "project_id": project_id,
        "status": "completed"
    })
    
    # Calculate pass rate and completion rates
    pass_rate = (passed_inspections / total_inspections * 100) if total_inspections > 0 else 0
    action_completion_rate = (completed_actions / total_corrective_actions * 100) if total_corrective_actions > 0 else 0
    
    return {
        "project_id": project_id,
        "total_inspections": total_inspections,
        "passed_inspections": passed_inspections,
        "failed_inspections": total_inspections - passed_inspections,
        "pass_rate": round(pass_rate, 2),
        "total_non_conformances": total_non_conformances,
        "open_non_conformances": open_non_conformances,
        "closed_non_conformances": total_non_conformances - open_non_conformances,
        "total_corrective_actions": total_corrective_actions,
        "completed_actions": completed_actions,
        "pending_actions": total_corrective_actions - completed_actions,
        "action_completion_rate": round(action_completion_rate, 2),
        "calculated_at": datetime.now(timezone.utc).isoformat()
    }

# Advanced Analytics & AI APIs
@api_router.get("/projects/{project_id}/analytics/overview")
async def get_analytics_overview(project_id: str, current_user: User = Depends(get_current_user)):
    """Get comprehensive analytics overview for project"""
    # Gather data from multiple sources
    project = await db.projects.find_one({"id": project_id})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Calculate various metrics
    total_deliverables = await db.deliverables.count_documents({"project_id": project_id})
    completed_deliverables = await db.deliverables.count_documents({
        "project_id": project_id,
        "status": "completed"
    })
    
    total_tasks = await db.tasks.count_documents({"project_id": project_id})
    completed_tasks = await db.tasks.count_documents({
        "project_id": project_id,
        "status": "completed"
    })
    
    total_expenses = await db.expenses.aggregate([
        {"$match": {"project_id": project_id}},
        {"$group": {"_id": None, "total": {"$sum": "$amount"}}}
    ]).to_list(length=1)
    
    total_budget = await db.budget_categories.aggregate([
        {"$match": {"project_id": project_id}},
        {"$group": {"_id": None, "total": {"$sum": "$allocated_amount"}}}
    ]).to_list(length=1)
    
    field_data_count = await db.field_data.count_documents({"project_id": project_id})
    qa_pass_rate = 0
    if await db.qa_inspections.count_documents({"project_id": project_id}) > 0:
        passed_inspections = await db.qa_inspections.count_documents({
            "project_id": project_id,
            "status": "passed"
        })
        total_inspections = await db.qa_inspections.count_documents({"project_id": project_id})
        qa_pass_rate = (passed_inspections / total_inspections * 100) if total_inspections > 0 else 0
    
    deliverable_completion_rate = (completed_deliverables / total_deliverables * 100) if total_deliverables > 0 else 0
    task_completion_rate = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
    
    budget_utilization = 0
    if total_budget and total_expenses:
        budget_utilization = (total_expenses[0]["total"] / total_budget[0]["total"] * 100)
    
    return {
        "project_id": project_id,
        "project_name": project.get("name", "Unknown Project"),
        "overview_metrics": {
            "deliverable_completion_rate": round(deliverable_completion_rate, 2),
            "task_completion_rate": round(task_completion_rate, 2),
            "budget_utilization": round(budget_utilization, 2),
            "qa_pass_rate": round(qa_pass_rate, 2),
            "field_data_entries": field_data_count,
            "total_deliverables": total_deliverables,
            "completed_deliverables": completed_deliverables,
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks
        },
        "calculated_at": datetime.now(timezone.utc).isoformat()
    }

@api_router.post("/projects/{project_id}/analytics/ai-insights")
async def generate_ai_insights(
    project_id: str, 
    analysis_request: dict, 
    current_user: User = Depends(get_current_user)
):
    """Generate AI-powered insights using LLM"""
    import os
    from dotenv import load_dotenv
    from emergentintegrations.llm.chat import LlmChat, UserMessage
    
    load_dotenv()
    
    # Get project data for AI analysis
    project = await db.projects.find_one({"id": project_id})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Gather comprehensive project data
    deliverables = await db.deliverables.find({"project_id": project_id}).to_list(length=None)
    risks = await db.risks.find({"project_id": project_id}).to_list(length=None)
    field_data = await db.field_data.find({"project_id": project_id}).to_list(length=None)
    qa_inspections = await db.qa_inspections.find({"project_id": project_id}).to_list(length=None)
    non_conformances = await db.non_conformances.find({"project_id": project_id}).to_list(length=None)
    expenses = await db.expenses.find({"project_id": project_id}).to_list(length=None)
    
    # Prepare data summary for AI analysis
    data_summary = f"""
    Project: {project.get('name', 'Unknown')}
    Description: {project.get('description', 'No description')}
    
    Deliverables Summary:
    - Total: {len(deliverables)}
    - Completed: {len([d for d in deliverables if d.get('status') == 'completed'])}
    - In Progress: {len([d for d in deliverables if d.get('status') == 'in_progress'])}
    - Delayed: {len([d for d in deliverables if d.get('status') == 'delayed'])}
    
    Risk Summary:
    - Total Risks: {len(risks)}
    - High Priority: {len([r for r in risks if r.get('priority') == 'high'])}
    - Open Risks: {len([r for r in risks if r.get('status') == 'open'])}
    
    Field Data:
    - Field Entries: {len(field_data)}
    - Inspection Types: {len([f for f in field_data if f.get('type') == 'inspection'])}
    - Incident Reports: {len([f for f in field_data if f.get('type') == 'incident'])}
    
    Quality Assurance:
    - Total Inspections: {len(qa_inspections)}
    - Passed: {len([q for q in qa_inspections if q.get('status') == 'passed'])}
    - Failed: {len([q for q in qa_inspections if q.get('status') == 'failed'])}
    - Non-conformances: {len(non_conformances)}
    
    Financial Summary:
    - Total Expenses: {sum([e.get('amount', 0) for e in expenses])}
    - Expense Categories: {len(set([e.get('category') for e in expenses if e.get('category')]))}
    """
    
    analysis_type = analysis_request.get("type", "general")
    
    # Create AI chat instance
    chat = LlmChat(
        api_key=os.getenv("EMERGENT_LLM_KEY"),
        session_id=f"analytics_{project_id}_{analysis_type}",
        system_message="You are an advanced project analytics AI assistant specializing in social investment projects. Provide data-driven insights, identify patterns, suggest improvements, and predict potential risks or opportunities."
    ).with_model("openai", "gpt-4o")
    
    # Create analysis prompt based on type
    if analysis_type == "risk_assessment":
        prompt = f"""
        Analyze the following project data and provide a comprehensive risk assessment:
        {data_summary}
        
        Focus on:
        1. Current risk exposure and mitigation strategies
        2. Potential future risks based on current trends
        3. Quality issues that might escalate
        4. Financial risks and budget concerns
        5. Operational risks from field data patterns
        
        Provide specific, actionable recommendations.
        """
    elif analysis_type == "performance_prediction":
        prompt = f"""
        Based on the project data below, predict future performance and outcomes:
        {data_summary}
        
        Analyze:
        1. Likelihood of meeting project objectives
        2. Deliverable completion timeline predictions
        3. Budget utilization forecasts
        4. Quality trend analysis
        5. Resource optimization opportunities
        
        Provide confidence levels and specific recommendations.
        """
    elif analysis_type == "optimization_suggestions":
        prompt = f"""
        Review the project data and suggest optimization opportunities:
        {data_summary}
        
        Focus on:
        1. Process improvement opportunities
        2. Resource allocation optimization
        3. Quality enhancement strategies
        4. Cost reduction opportunities
        5. Workflow efficiency improvements
        
        Prioritize suggestions by impact and feasibility.
        """
    else:  # general analysis
        prompt = f"""
        Provide a comprehensive analysis of this social investment project:
        {data_summary}
        
        Include:
        1. Overall project health assessment
        2. Key performance indicators analysis
        3. Areas of concern and success factors
        4. Strategic recommendations for improvement
        5. Predicted outcomes and success probability
        
        Be specific and data-driven in your analysis.
        """
    
    try:
        # Send message to AI
        user_message = UserMessage(text=prompt)
        response = await chat.send_message(user_message)
        
        # Store AI insight in database
        insight_record = {
            "id": str(uuid.uuid4()),
            "project_id": project_id,
            "analysis_type": analysis_type,
            "insights": response,
            "generated_by": current_user.id,
            "data_snapshot": data_summary[:1000],  # Store truncated snapshot
            "created_at": datetime.now(timezone.utc)
        }
        
        await db.ai_insights.insert_one(insight_record)
        
        # Create notification for AI insights
        await create_event_notification(
            event_type="ai_insights_generated",
            message=f"AI insights generated: {analysis_type.replace('_', ' ').title()} analysis",
            user_id=current_user.id,
            related_id=insight_record["id"],
            project_id=project_id,
            priority="low"
        )
        
        return {
            "insight_id": insight_record["id"],
            "analysis_type": analysis_type,
            "insights": response,
            "generated_at": insight_record["created_at"]
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"AI analysis failed: {str(e)}")

@api_router.get("/projects/{project_id}/analytics/ai-insights")
async def get_ai_insights(
    project_id: str, 
    current_user: User = Depends(get_current_user),
    limit: int = 10
):
    """Get historical AI insights for project"""
    insights = await db.ai_insights.find({
        "project_id": project_id
    }).sort("created_at", -1).limit(limit).to_list(length=None)
    
    # Convert MongoDB documents to JSON-serializable format
    for insight in insights:
        if '_id' in insight:
            del insight['_id']
    
    return insights

@api_router.get("/projects/{project_id}/analytics/trends")
async def get_analytics_trends(
    project_id: str, 
    current_user: User = Depends(get_current_user),
    days: int = 30
):
    """Get analytics trends over specified time period"""
    end_date = datetime.now(timezone.utc)
    start_date = end_date - timedelta(days=days)
    
    # Get time-series data
    daily_field_data = await db.field_data.aggregate([
        {
            "$match": {
                "project_id": project_id,
                "created_at": {"$gte": start_date, "$lte": end_date}
            }
        },
        {
            "$group": {
                "_id": {
                    "date": {"$dateToString": {"format": "%Y-%m-%d", "date": "$created_at"}},
                    "type": "$type"
                },
                "count": {"$sum": 1}
            }
        },
        {"$sort": {"_id.date": 1}}
    ]).to_list(length=None)
    
    # Get expense trends
    expense_trends = await db.expenses.aggregate([
        {
            "$match": {
                "project_id": project_id,
                "date": {"$gte": start_date.isoformat(), "$lte": end_date.isoformat()}
            }
        },
        {
            "$group": {
                "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": {"$dateFromString": {"dateString": "$date"}}}},
                "total_amount": {"$sum": "$amount"},
                "count": {"$sum": 1}
            }
        },
        {"$sort": {"_id": 1}}
    ]).to_list(length=None)
    
    # Get QA trends
    qa_trends = await db.qa_inspections.aggregate([
        {
            "$match": {
                "project_id": project_id,
                "created_at": {"$gte": start_date, "$lte": end_date}
            }
        },
        {
            "$group": {
                "_id": {
                    "date": {"$dateToString": {"format": "%Y-%m-%d", "date": "$created_at"}},
                    "status": "$status"
                },
                "count": {"$sum": 1},
                "avg_score": {"$avg": "$score"}
            }
        },
        {"$sort": {"_id.date": 1}}
    ]).to_list(length=None)
    
    return {
        "project_id": project_id,
        "period": {
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "days": days
        },
        "trends": {
            "field_data": daily_field_data,
            "expenses": expense_trends,
            "quality_assurance": qa_trends
        },
        "calculated_at": datetime.now(timezone.utc).isoformat()
    }

@api_router.post("/projects/{project_id}/analytics/predictive-model")
async def generate_predictive_analysis(
    project_id: str,
    prediction_request: dict,
    current_user: User = Depends(get_current_user)
):
    """Generate predictive analysis using AI for project outcomes"""
    import os
    from dotenv import load_dotenv
    from emergentintegrations.llm.chat import LlmChat, UserMessage
    
    load_dotenv()
    
    # Get comprehensive historical data
    project = await db.projects.find_one({"id": project_id})
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Gather trend data for last 60 days
    end_date = datetime.now(timezone.utc)
    start_date = end_date - timedelta(days=60)
    
    # Get historical metrics
    deliverable_progress = await db.deliverables.find({
        "project_id": project_id
    }).to_list(length=None)
    
    expense_history = await db.expenses.find({
        "project_id": project_id
    }).to_list(length=None)
    
    field_data_history = await db.field_data.find({
        "project_id": project_id,
        "created_at": {"$gte": start_date}
    }).to_list(length=None)
    
    qa_history = await db.qa_inspections.find({
        "project_id": project_id,
        "created_at": {"$gte": start_date}
    }).to_list(length=None)
    
    prediction_type = prediction_request.get("type", "completion_timeline")
    
    # Prepare historical data summary
    historical_summary = f"""
    Historical Project Performance (Last 60 Days):
    
    Deliverables Trend:
    - Total Deliverables: {len(deliverable_progress)}
    - Completion Rate: {len([d for d in deliverable_progress if d.get('status') == 'completed']) / len(deliverable_progress) * 100:.1f}%
    - Average Progress: {sum([d.get('progress', 0) for d in deliverable_progress]) / len(deliverable_progress) if deliverable_progress else 0:.1f}%
    
    Financial Trend:
    - Total Spending: ${sum([e.get('amount', 0) for e in expense_history]):,.2f}
    - Monthly Burn Rate: ${sum([e.get('amount', 0) for e in expense_history]) / 2:,.2f}
    - Expense Categories: {len(set([e.get('category', 'Unknown') for e in expense_history]))}
    
    Field Activity Trend:
    - Field Entries: {len(field_data_history)}
    - Inspection Success Rate: {len([f for f in field_data_history if f.get('type') == 'inspection' and f.get('data', {}).get('status') == 'completed']) / max(len([f for f in field_data_history if f.get('type') == 'inspection']), 1) * 100:.1f}%
    - Incident Rate: {len([f for f in field_data_history if f.get('type') == 'incident']) / max(len(field_data_history), 1) * 100:.1f}%
    
    Quality Trend:
    - Inspection Pass Rate: {len([q for q in qa_history if q.get('status') == 'passed']) / max(len(qa_history), 1) * 100:.1f}%
    - Average Quality Score: {sum([q.get('score', 0) for q in qa_history]) / max(len(qa_history), 1):.1f}
    - Quality Trend: {"Improving" if len(qa_history) > 3 and qa_history[-1].get('score', 0) > qa_history[0].get('score', 0) else "Stable"}
    """
    
    # Create AI chat for predictions
    chat = LlmChat(
        api_key=os.getenv("EMERGENT_LLM_KEY"),
        session_id=f"prediction_{project_id}_{prediction_type}",
        system_message="You are an AI project analytics specialist focused on predictive modeling for social investment projects. Use historical data patterns to make evidence-based predictions with confidence intervals."
    ).with_model("openai", "gpt-4o")
    
    if prediction_type == "completion_timeline":
        prompt = f"""
        Based on the historical data, predict the project completion timeline:
        {historical_summary}
        
        Provide predictions for:
        1. Estimated completion date with confidence interval
        2. Risk factors that could delay completion
        3. Critical path items that need attention
        4. Probability of on-time completion
        5. Recommended actions to improve timeline
        
        Use data-driven analysis and provide specific dates and percentages.
        """
    elif prediction_type == "budget_forecast":
        prompt = f"""
        Analyze spending patterns and predict budget utilization:
        {historical_summary}
        
        Forecast:
        1. Total project cost at completion
        2. Monthly spending projections
        3. Risk of budget overrun with probability
        4. Cost optimization opportunities
        5. Resource allocation recommendations
        
        Provide specific financial figures and confidence levels.
        """
    elif prediction_type == "risk_probability":
        prompt = f"""
        Assess risk probability based on historical patterns:
        {historical_summary}
        
        Predict:
        1. Likelihood of major risks materializing
        2. Quality issues escalation probability
        3. Resource shortage risks
        4. Timeline delay probability
        5. Mitigation strategy effectiveness
        
        Include probability percentages and impact assessments.
        """
    else:  # success_probability
        prompt = f"""
        Predict overall project success probability:
        {historical_summary}
        
        Analyze:
        1. Overall success probability with confidence interval
        2. Key success factors and their current status
        3. Critical failure points and their likelihood
        4. Intervention points for improving success
        5. Comparative performance against similar projects
        
        Provide data-driven success metrics and recommendations.
        """
    
    try:
        # Generate AI predictions
        user_message = UserMessage(text=prompt)
        response = await chat.send_message(user_message)
        
        # Store prediction in database
        prediction_record = {
            "id": str(uuid.uuid4()),
            "project_id": project_id,
            "prediction_type": prediction_type,
            "predictions": response,
            "historical_data_summary": historical_summary[:1000],
            "generated_by": current_user.id,
            "created_at": datetime.now(timezone.utc)
        }
        
        await db.predictive_analytics.insert_one(prediction_record)
        
        return {
            "prediction_id": prediction_record["id"],
            "prediction_type": prediction_type,
            "predictions": response,
            "generated_at": prediction_record["created_at"],
            "data_period": "60 days"
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Predictive analysis failed: {str(e)}")

@api_router.get("/projects/{project_id}/analytics/predictions")
async def get_predictive_analytics(
    project_id: str,
    current_user: User = Depends(get_current_user),
    limit: int = 10
):
    """Get historical predictive analytics for project"""
    predictions = await db.predictive_analytics.find({
        "project_id": project_id
    }).sort("created_at", -1).limit(limit).to_list(length=None)
    
    # Convert MongoDB documents to JSON-serializable format  
    for prediction in predictions:
        if '_id' in prediction:
            del prediction['_id']
    
    return predictions

@api_router.post("/projects/{project_id}/sroi", response_model=SROICalculation)
async def create_sroi_calculation(project_id: str, sroi_data: SROICreate, current_user: User = Depends(get_current_user)):
    sroi_ratio = sroi_data.outcomes_value / sroi_data.inputs_cost if sroi_data.inputs_cost > 0 else 0
    
    sroi = SROICalculation(
        **sroi_data.dict(),
        project_id=project_id,
        sroi_ratio=sroi_ratio,
        calculated_by=current_user.id
    )
    await db.sroi.insert_one(sroi.dict())
    return sroi

# Procurement Management APIs
@api_router.get("/projects/{project_id}/vendors")
async def get_vendors(project_id: str, current_user: User = Depends(get_current_user)):
    """Get vendors for project"""
    vendors = await db.vendors.find({
        "project_id": project_id
    }).to_list(length=None)
    
    # Convert MongoDB documents to JSON-serializable format
    for vendor in vendors:
        if '_id' in vendor:
            del vendor['_id']
    
    return vendors

@api_router.post("/projects/{project_id}/vendors")
async def create_vendor(
    project_id: str, 
    vendor_data: dict, 
    current_user: User = Depends(get_current_user)
):
    """Create vendor record"""
    vendor = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **vendor_data,
        "created_by": current_user.id,
        "status": "active",
        "created_at": datetime.now(timezone.utc)
    }
    await db.vendors.insert_one(vendor)
    
    # Create notification
    await create_event_notification(
        event_type="procurement_updates",
        message=f"New vendor registered: {vendor_data.get('name', 'Unknown vendor')}",
        user_id=current_user.id,
        related_id=vendor["id"],
        project_id=project_id,
        priority="low"
    )
    
    if '_id' in vendor:
        del vendor['_id']
    
    return vendor

@api_router.get("/projects/{project_id}/purchase-orders")
async def get_purchase_orders(project_id: str, current_user: User = Depends(get_current_user)):
    """Get purchase orders for project"""
    orders = await db.purchase_orders.find({
        "project_id": project_id
    }).sort("created_at", -1).to_list(length=None)
    
    for order in orders:
        if '_id' in order:
            del order['_id']
    
    return orders

@api_router.post("/projects/{project_id}/purchase-orders")
async def create_purchase_order(
    project_id: str,
    order_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Create purchase order"""
    order = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **order_data,
        "created_by": current_user.id,
        "status": "draft",
        "created_at": datetime.now(timezone.utc)
    }
    await db.purchase_orders.insert_one(order)
    
    # Create notification for significant orders
    amount = order_data.get("total_amount", 0)
    if amount > 10000:  # High-value orders
        await create_event_notification(
            event_type="procurement_updates",
            message=f"High-value purchase order created: ${amount:,.2f} - {order_data.get('description', 'PO')}",
            user_id=current_user.id,
            related_id=order["id"],
            project_id=project_id,
            priority="medium"
        )
    
    if '_id' in order:
        del order['_id']
    
    return order

@api_router.patch("/projects/{project_id}/purchase-orders/{order_id}")
async def update_purchase_order(
    project_id: str,
    order_id: str,
    order_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Update purchase order"""
    update_data = {
        **order_data,
        "updated_by": current_user.id,
        "updated_at": datetime.now(timezone.utc)
    }
    
    # Notify on status changes
    if order_data.get("status") == "approved":
        await create_event_notification(
            event_type="procurement_updates",
            message=f"Purchase order approved: {order_data.get('description', 'PO')}",
            user_id=current_user.id,
            related_id=order_id,
            project_id=project_id,
            priority="medium"
        )
    
    result = await db.purchase_orders.update_one(
        {"id": order_id, "project_id": project_id},
        {"$set": update_data}
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Purchase order not found")
    
    return {"message": "Purchase order updated successfully"}

@api_router.get("/projects/{project_id}/contracts")
async def get_contracts(project_id: str, current_user: User = Depends(get_current_user)):
    """Get contracts for project"""
    contracts = await db.contracts.find({
        "project_id": project_id
    }).sort("start_date", -1).to_list(length=None)
    
    for contract in contracts:
        if '_id' in contract:
            del contract['_id']
    
    return contracts

@api_router.post("/projects/{project_id}/contracts")
async def create_contract(
    project_id: str,
    contract_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Create contract"""
    contract = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        **contract_data,
        "created_by": current_user.id,
        "status": "draft",
        "created_at": datetime.now(timezone.utc)
    }
    await db.contracts.insert_one(contract)
    
    if '_id' in contract:
        del contract['_id']
    
    return contract

@api_router.get("/projects/{project_id}/procurement-analytics")
async def get_procurement_analytics(project_id: str, current_user: User = Depends(get_current_user)):
    """Get procurement analytics for project"""
    # Calculate procurement metrics
    total_orders = await db.purchase_orders.count_documents({"project_id": project_id})
    approved_orders = await db.purchase_orders.count_documents({
        "project_id": project_id,
        "status": "approved"
    })
    
    total_spending = await db.purchase_orders.aggregate([
        {"$match": {"project_id": project_id, "status": "approved"}},
        {"$group": {"_id": None, "total": {"$sum": "$total_amount"}}}
    ]).to_list(length=1)
    
    vendor_count = await db.vendors.count_documents({"project_id": project_id})
    active_contracts = await db.contracts.count_documents({
        "project_id": project_id,
        "status": "active"
    })
    
    approval_rate = (approved_orders / total_orders * 100) if total_orders > 0 else 0
    
    return {
        "project_id": project_id,
        "total_purchase_orders": total_orders,
        "approved_orders": approved_orders,
        "pending_orders": total_orders - approved_orders,
        "approval_rate": round(approval_rate, 2),
        "total_spending": total_spending[0]["total"] if total_spending else 0,
        "vendor_count": vendor_count,
        "active_contracts": active_contracts,
        "calculated_at": datetime.now(timezone.utc).isoformat()
    }

@api_router.post("/projects/{project_id}/upload-evidence")
async def upload_evidence(
    project_id: str,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    upload_dir = Path("uploads") / project_id
    upload_dir.mkdir(parents=True, exist_ok=True)
    
    file_path = upload_dir / f"{uuid.uuid4()}_{file.filename}"
    async with aiofiles.open(file_path, 'wb') as f:
        content = await file.read()
        await f.write(content)
    
    return {"file_path": str(file_path), "filename": file.filename}

@api_router.get("/projects/{project_id}/kpis", response_model=List[KPI])
async def get_project_kpis(project_id: str, current_user: User = Depends(get_current_user)):
    kpis = await db.kpis.find({"project_id": project_id}).to_list(1000)
    return [KPI(**kpi) for kpi in kpis]

@api_router.post("/projects/{project_id}/kpis", response_model=KPI)
async def create_kpi(project_id: str, kpi_data: KPICreate, current_user: User = Depends(get_current_user)):
    kpi = KPI(**kpi_data.dict(), project_id=project_id)
    await db.kpis.insert_one(kpi.dict())
    return kpi

@api_router.put("/projects/{project_id}/kpis/{kpi_id}", response_model=KPI)
async def update_kpi(project_id: str, kpi_id: str, kpi_data: KPIUpdate, current_user: User = Depends(get_current_user)):
    if current_user.role != UserRole.SOCIAL_ACTOR:
        raise HTTPException(status_code=403, detail="Only social actors can update KPI values")
    
    await db.kpis.update_one({"id": kpi_id}, {"$set": kpi_data.dict()})
    updated_kpi = await db.kpis.find_one({"id": kpi_id})
    return KPI(**updated_kpi)

@api_router.get("/projects/{project_id}/deliverables", response_model=List[Deliverable])
async def get_project_deliverables(project_id: str, current_user: User = Depends(get_current_user)):
    deliverables = await db.deliverables.find({"project_id": project_id}).to_list(1000)
    return [Deliverable(**deliverable) for deliverable in deliverables]

@api_router.post("/projects/{project_id}/deliverables", response_model=Deliverable)
async def create_deliverable(project_id: str, deliverable_data: DeliverableCreate, current_user: User = Depends(get_current_user)):
    deliverable = Deliverable(**deliverable_data.dict(), project_id=project_id)
    await db.deliverables.insert_one(deliverable.dict())
    
    # Notify administrators about new deliverable
    admins = await db.users.find({"role": "administrator"}).to_list(1000)
    for admin in admins:
        await create_notification(
            admin["id"],
            "New Deliverable Created",
            f"A new deliverable '{deliverable.name}' has been created and requires review.",
            NotificationType.INFO,
            project_id
        )
    
    return deliverable

@api_router.put("/projects/{project_id}/deliverables/{deliverable_id}", response_model=Deliverable)
async def update_deliverable(project_id: str, deliverable_id: str, deliverable_data: DeliverableUpdate, current_user: User = Depends(get_current_user)):
    update_dict = deliverable_data.dict(exclude_unset=True)
    
    if "certification_status" in update_dict and current_user.role != UserRole.ADMINISTRATOR:
        raise HTTPException(status_code=403, detail="Only administrators can certify deliverables")
    
    if deliverable_data.certification_status:
        # Notify project team about certification
        project = await db.projects.find_one({"id": project_id})
        if project:
            notifications = [
                (project.get("owner_id"), "Deliverable Certified"),
                (project.get("investor_id"), "Deliverable Certified")
            ]
            for user_id, title in notifications:
                if user_id:
                    await create_notification(
                        user_id,
                        title,
                        f"A deliverable has been certified by the administrator.",
                        NotificationType.SUCCESS,
                        project_id
                    )
    
    await db.deliverables.update_one({"id": deliverable_id}, {"$set": update_dict})
    updated_deliverable = await db.deliverables.find_one({"id": deliverable_id})
    return Deliverable(**updated_deliverable)

@api_router.post("/projects/{project_id}/deliverables/{deliverable_id}/upload")
async def upload_deliverable_files(
    project_id: str, 
    deliverable_id: str,
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user)
):
    """Upload files for a deliverable"""
    
    # Validate file size (10MB limit)
    max_size = 10 * 1024 * 1024  # 10MB
    if file.size > max_size:
        raise HTTPException(status_code=400, detail="File size exceeds 10MB limit")
    
    # Validate file type
    allowed_types = {
        'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'text/plain', 'image/jpeg', 'image/png', 'image/gif', 'application/zip'
    }
    
    if file.content_type not in allowed_types:
        raise HTTPException(status_code=400, detail="File type not allowed")
    
    # Create uploads directory if it doesn't exist
    upload_dir = Path("uploads") / project_id / deliverable_id
    upload_dir.mkdir(parents=True, exist_ok=True)
    
    # Generate unique filename
    file_id = str(uuid.uuid4())
    file_extension = Path(file.filename).suffix
    unique_filename = f"{file_id}{file_extension}"
    file_path = upload_dir / unique_filename
    
    # Save file
    try:
        content = await file.read()
        with open(file_path, "wb") as f:
            f.write(content)
        
        # Store file metadata in database
        file_metadata = {
            "id": file_id,
            "deliverable_id": deliverable_id,
            "project_id": project_id,
            "original_filename": file.filename,
            "stored_filename": unique_filename,
            "file_size": len(content),
            "content_type": file.content_type,
            "upload_path": str(file_path),
            "uploaded_by": current_user.id,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        
        await db.deliverable_files.insert_one(file_metadata)
        
        # Update deliverable with file reference
        deliverable = await db.deliverables.find_one({"id": deliverable_id})
        if deliverable:
            files = deliverable.get("files", [])
            files.append({
                "id": file_id,
                "filename": file.filename,
                "size": len(content),
                "content_type": file.content_type
            })
            await db.deliverables.update_one(
                {"id": deliverable_id},
                {"$set": {"files": files, "updated_at": datetime.now(timezone.utc).isoformat()}}
            )
        
        return {
            "file_id": file_id,
            "filename": file.filename,
            "size": len(content),
            "message": "File uploaded successfully"
        }
        
    except Exception as e:
        # Clean up file if database operation fails
        if file_path.exists():
            file_path.unlink()
        raise HTTPException(status_code=500, detail=f"Failed to upload file: {str(e)}")

@api_router.get("/projects/{project_id}/deliverables/{deliverable_id}/files")
async def get_deliverable_files(
    project_id: str, 
    deliverable_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get all files for a deliverable"""
    files = await db.deliverable_files.find({"deliverable_id": deliverable_id}).to_list(length=None)
    
    # Remove MongoDB ObjectIds
    for file_data in files:
        if '_id' in file_data:
            del file_data['_id']
    
    return files

@api_router.get("/projects/{project_id}/deliverables/{deliverable_id}/files/{file_id}/download")
async def download_deliverable_file(
    project_id: str, 
    deliverable_id: str,
    file_id: str,
    current_user: User = Depends(get_current_user)
):
    """Download a deliverable file"""
    file_metadata = await db.deliverable_files.find_one({"id": file_id, "deliverable_id": deliverable_id})
    
    if not file_metadata:
        raise HTTPException(status_code=404, detail="File not found")
    
    file_path = Path(file_metadata["upload_path"])
    
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found on disk")
    
    return FileResponse(
        path=file_path,
        filename=file_metadata["original_filename"],
        media_type=file_metadata["content_type"]
    )

# =============================================================================
# Team Management APIs
# =============================================================================

@api_router.get("/projects/{project_id}/team-members")
async def get_team_members(project_id: str, current_user: User = Depends(get_current_user)):
    """Get all team members for a project"""
    team_members = await db.team_members.find({"project_id": project_id}).to_list(length=None)
    
    # Remove MongoDB ObjectIds
    for member in team_members:
        if '_id' in member:
            del member['_id']
    
    return team_members

@api_router.post("/projects/{project_id}/team-members")
async def add_team_member(project_id: str, member_data: dict, current_user: User = Depends(get_current_user)):
    """Add a team member to the project"""
    
    # Check if user has permission (only admins and social actors can add team members)
    if current_user.role not in ['admin', 'administrator', 'social_actor']:
        raise HTTPException(status_code=403, detail="Only administrators and social actors can add team members")
    
    # Validate required fields
    required_fields = ['first_name', 'last_name', 'position', 'email']
    for field in required_fields:
        if not member_data.get(field):
            raise HTTPException(status_code=400, detail=f"Missing required field: {field}")
    
    # Create team member
    team_member = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        "first_name": member_data["first_name"],
        "last_name": member_data["last_name"],
        "position": member_data["position"],
        "email": member_data["email"],
        "phone": member_data.get("phone", ""),
        "department": member_data.get("department", ""),
        "bio": member_data.get("bio", ""),
        "start_date": member_data.get("start_date", datetime.now(timezone.utc).isoformat()),
        "skills": member_data.get("skills", []),
        "responsibilities": member_data.get("responsibilities", []),
        "is_active": True,
        "added_by": current_user.id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.team_members.insert_one(team_member)
    
    # Notify project stakeholders
    project = await db.projects.find_one({"id": project_id})
    if project:
        stakeholders = [project.get("owner_id"), project.get("investor_id")]
        for user_id in stakeholders:
            if user_id and user_id != current_user.id:
                await create_notification(
                    user_id,
                    "New Team Member Added",
                    f"{member_data['first_name']} {member_data['last_name']} has been added to the project team as {member_data['position']}.",
                    NotificationType.INFO,
                    project_id
                )
    
    return {"id": team_member["id"], "message": "Team member added successfully"}

@api_router.patch("/projects/{project_id}/team-members/{member_id}")
async def update_team_member(project_id: str, member_id: str, member_data: dict, current_user: User = Depends(get_current_user)):
    """Update a team member"""
    
    # Check if user has permission
    if current_user.role not in ['admin', 'administrator', 'social_actor']:
        raise HTTPException(status_code=403, detail="Only administrators and social actors can update team members")
    
    # Check if member exists
    member = await db.team_members.find_one({"id": member_id, "project_id": project_id})
    if not member:
        raise HTTPException(status_code=404, detail="Team member not found")
    
    # Update member data
    update_data = {
        **member_data,
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.team_members.update_one({"id": member_id}, {"$set": update_data})
    
    return {"message": "Team member updated successfully"}

@api_router.delete("/projects/{project_id}/team-members/{member_id}")
async def remove_team_member(project_id: str, member_id: str, current_user: User = Depends(get_current_user)):
    """Remove a team member from the project"""
    
    # Check if user has permission
    if current_user.role not in ['admin', 'administrator', 'social_actor']:
        raise HTTPException(status_code=403, detail="Only administrators and social actors can remove team members")
    
    # Check if member exists
    member = await db.team_members.find_one({"id": member_id, "project_id": project_id})
    if not member:
        raise HTTPException(status_code=404, detail="Team member not found")
    
    # Mark as inactive instead of deleting
    await db.team_members.update_one(
        {"id": member_id}, 
        {"$set": {"is_active": False, "updated_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    # Notify stakeholders
    project = await db.projects.find_one({"id": project_id})
    if project:
        stakeholders = [project.get("owner_id"), project.get("investor_id")]
        for user_id in stakeholders:
            if user_id and user_id != current_user.id:
                await create_notification(
                    user_id,
                    "Team Member Removed",
                    f"{member['first_name']} {member['last_name']} has been removed from the project team.",
                    NotificationType.INFO,
                    project_id
                )
    
    return {"message": "Team member removed successfully"}

@api_router.get("/projects/{project_id}/team-overview")
async def get_team_overview(project_id: str, current_user: User = Depends(get_current_user)):
    """Get team overview with statistics"""
    
    # Get active team members
    team_members = await db.team_members.find({"project_id": project_id, "is_active": True}).to_list(length=None)
    
    # Get project details for social actor and investor info
    project = await db.projects.find_one({"id": project_id})
    
    # Calculate team statistics
    total_members = len(team_members)
    departments = set([member.get("department", "General") for member in team_members])
    positions = set([member.get("position") for member in team_members])
    
    # Get key stakeholders info (these would come from user database in future)
    stakeholders = []
    
    if project:
        # Social Actor (project owner)
        if project.get("owner_id"):
            social_actor = await db.users.find_one({"id": project["owner_id"]})
            if social_actor:
                stakeholders.append({
                    "id": social_actor["id"],
                    "name": social_actor.get("name", "Social Actor"),
                    "email": social_actor.get("email", ""),
                    "role": "Social Actor",
                    "organization": social_actor.get("organization", ""),
                    "type": "stakeholder"
                })
        
        # Investor
        if project.get("investor_id"):
            investor = await db.users.find_one({"id": project["investor_id"]})
            if investor:
                stakeholders.append({
                    "id": investor["id"],
                    "name": investor.get("name", "Investor"),
                    "email": investor.get("email", ""),
                    "role": "Investor",
                    "organization": investor.get("organization", ""),
                    "type": "stakeholder"
                })
    
    # Remove MongoDB ObjectIds from team members
    for member in team_members:
        if '_id' in member:
            del member['_id']
    
    return {
        "team_members": team_members,
        "stakeholders": stakeholders,
        "statistics": {
            "total_members": total_members,
            "departments_count": len(departments),
            "positions_count": len(positions),
            "departments": list(departments),
            "positions": list(positions)
        },
        "project_info": {
            "name": project.get("name") if project else "Unknown Project",
            "status": project.get("status") if project else "unknown"
        }
    }

# =============================================================================
# SROI Calculator & Social Impact Tools APIs
# =============================================================================

@api_router.get("/projects/{project_id}/sroi-calculation")
async def get_sroi_calculation(project_id: str, current_user: User = Depends(get_current_user)):
    """Get SROI calculation for project"""
    # Get existing SROI data or create default
    sroi_data = await db.sroi_calculations.find_one({"project_id": project_id})
    
    if not sroi_data:
        # Create default SROI calculation
        default_sroi = {
            "id": str(uuid.uuid4()),
            "project_id": project_id,
            "total_investment": 0,
            "total_social_value": 0,
            "sroi_ratio": 0,
            "calculation_date": datetime.now(timezone.utc).isoformat(),
            "inputs": [],
            "outputs": [],
            "outcomes": [],
            "impacts": [],
            "assumptions": [],
            "sensitivity_analysis": {},
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        
        await db.sroi_calculations.insert_one(default_sroi)
        sroi_data = default_sroi
    
    # Remove MongoDB ObjectId
    if '_id' in sroi_data:
        del sroi_data['_id']
    
    return sroi_data

@api_router.post("/projects/{project_id}/sroi-calculation")
async def update_sroi_calculation(project_id: str, sroi_data: dict, current_user: User = Depends(get_current_user)):
    """Update SROI calculation"""
    # Calculate SROI ratio
    total_investment = sroi_data.get("total_investment", 0)
    total_social_value = sroi_data.get("total_social_value", 0)
    
    if total_investment > 0:
        sroi_ratio = total_social_value / total_investment
    else:
        sroi_ratio = 0
    
    # Update calculation
    update_data = {
        **sroi_data,
        "sroi_ratio": sroi_ratio,
        "calculation_date": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.sroi_calculations.update_one(
        {"project_id": project_id},
        {"$set": update_data},
        upsert=True
    )
    
    # Notify stakeholders of SROI update
    project = await db.projects.find_one({"id": project_id})
    if project and sroi_ratio >= 3.0:  # High impact threshold
        stakeholders = [project.get("owner_id"), project.get("investor_id")]
        for user_id in stakeholders:
            if user_id:
                await create_notification(
                    user_id,
                    "High SROI Achieved",
                    f"Project SROI ratio of {sroi_ratio:.2f}:1 indicates exceptional social value creation.",
                    NotificationType.SUCCESS,
                    project_id
                )
    
    return {"sroi_ratio": sroi_ratio, "total_investment": total_investment, "total_social_value": total_social_value}

@api_router.get("/projects/{project_id}/theory-of-change")
async def get_theory_of_change(project_id: str, current_user: User = Depends(get_current_user)):
    """Get Theory of Change model for project"""
    toc_data = await db.theory_of_change.find_one({"project_id": project_id})
    
    if not toc_data:
        # Create default Theory of Change structure
        default_toc = {
            "id": str(uuid.uuid4()),
            "project_id": project_id,
            "vision": "",
            "long_term_goals": [],
            "intermediate_outcomes": [],
            "immediate_outcomes": [],
            "outputs": [],
            "activities": [],
            "inputs": [],
            "assumptions": [],
            "risk_factors": [],
            "indicators": [],
            "evidence_requirements": [],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        
        await db.theory_of_change.insert_one(default_toc)
        toc_data = default_toc
    
    if '_id' in toc_data:
        del toc_data['_id']
    
    return toc_data

@api_router.post("/projects/{project_id}/theory-of-change")
async def update_theory_of_change(project_id: str, toc_data: dict, current_user: User = Depends(get_current_user)):
    """Update Theory of Change model"""
    update_data = {
        **toc_data,
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.theory_of_change.update_one(
        {"project_id": project_id},
        {"$set": update_data},
        upsert=True
    )
    
    return {"message": "Theory of Change updated successfully"}

@api_router.get("/projects/{project_id}/sdgs-alignment")
async def get_sdgs_alignment(project_id: str, current_user: User = Depends(get_current_user)):
    """Get SDGs alignment for project"""
    sdgs_data = await db.sdgs_alignment.find_one({"project_id": project_id})
    
    if not sdgs_data:
        # Create default SDGs alignment with all 17 goals
        sdgs_goals = [
            {"goal": 1, "name": "No Poverty", "aligned": False, "targets": [], "progress": 0},
            {"goal": 2, "name": "Zero Hunger", "aligned": False, "targets": [], "progress": 0},
            {"goal": 3, "name": "Good Health and Well-being", "aligned": False, "targets": [], "progress": 0},
            {"goal": 4, "name": "Quality Education", "aligned": True, "targets": ["4.3", "4.4"], "progress": 65},
            {"goal": 5, "name": "Gender Equality", "aligned": False, "targets": [], "progress": 0},
            {"goal": 6, "name": "Clean Water and Sanitation", "aligned": False, "targets": [], "progress": 0},
            {"goal": 7, "name": "Affordable and Clean Energy", "aligned": False, "targets": [], "progress": 0},
            {"goal": 8, "name": "Decent Work and Economic Growth", "aligned": True, "targets": ["8.2", "8.6"], "progress": 45},
            {"goal": 9, "name": "Industry, Innovation and Infrastructure", "aligned": True, "targets": ["9.c"], "progress": 80},
            {"goal": 10, "name": "Reduced Inequality", "aligned": True, "targets": ["10.2"], "progress": 30},
            {"goal": 11, "name": "Sustainable Cities and Communities", "aligned": False, "targets": [], "progress": 0},
            {"goal": 12, "name": "Responsible Consumption and Production", "aligned": False, "targets": [], "progress": 0},
            {"goal": 13, "name": "Climate Action", "aligned": False, "targets": [], "progress": 0},
            {"goal": 14, "name": "Life Below Water", "aligned": False, "targets": [], "progress": 0},
            {"goal": 15, "name": "Life on Land", "aligned": False, "targets": [], "progress": 0},
            {"goal": 16, "name": "Peace and Justice Strong Institutions", "aligned": False, "targets": [], "progress": 0},
            {"goal": 17, "name": "Partnerships to achieve the Goal", "aligned": True, "targets": ["17.17"], "progress": 70}
        ]
        
        default_sdgs = {
            "id": str(uuid.uuid4()),
            "project_id": project_id,
            "goals": sdgs_goals,
            "overall_alignment_score": 58,
            "primary_goals": [4, 8, 9, 17],
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        
        await db.sdgs_alignment.insert_one(default_sdgs)
        sdgs_data = default_sdgs
    
    if '_id' in sdgs_data:
        del sdgs_data['_id']
    
    return sdgs_data

@api_router.post("/projects/{project_id}/sdgs-alignment")
async def update_sdgs_alignment(project_id: str, sdgs_data: dict, current_user: User = Depends(get_current_user)):
    """Update SDGs alignment"""
    # Calculate overall alignment score
    aligned_goals = [goal for goal in sdgs_data.get("goals", []) if goal.get("aligned")]
    total_progress = sum([goal.get("progress", 0) for goal in aligned_goals])
    goal_count = len(aligned_goals)
    
    if goal_count > 0:
        overall_score = total_progress / goal_count
    else:
        overall_score = 0
    
    update_data = {
        **sdgs_data,
        "overall_alignment_score": round(overall_score, 1),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.sdgs_alignment.update_one(
        {"project_id": project_id},
        {"$set": update_data},
        upsert=True
    )
    
    return {"overall_alignment_score": overall_score, "aligned_goals_count": goal_count}

@api_router.get("/projects/{project_id}/esg-indicators")
async def get_esg_indicators(project_id: str, current_user: User = Depends(get_current_user)):
    """Get ESG indicators for project"""
    esg_data = await db.esg_indicators.find_one({"project_id": project_id})
    
    if not esg_data:
        # Create default ESG indicators
        default_esg = {
            "id": str(uuid.uuid4()),
            "project_id": project_id,
            "environmental": {
                "carbon_footprint": {"value": 2.3, "unit": "tonnes CO2e", "target": 2.0, "trend": "decreasing"},
                "energy_efficiency": {"value": 85, "unit": "%", "target": 90, "trend": "improving"},
                "waste_reduction": {"value": 78, "unit": "%", "target": 80, "trend": "stable"},
                "renewable_energy": {"value": 45, "unit": "%", "target": 60, "trend": "improving"}
            },
            "social": {
                "beneficiaries_reached": {"value": 1250, "unit": "people", "target": 1500, "trend": "increasing"},
                "job_creation": {"value": 18, "unit": "jobs", "target": 25, "trend": "increasing"},
                "skills_development": {"value": 892, "unit": "people trained", "target": 1000, "trend": "increasing"},
                "gender_equality": {"value": 67, "unit": "% women participants", "target": 70, "trend": "improving"},
                "community_satisfaction": {"value": 4.2, "unit": "score (1-5)", "target": 4.5, "trend": "stable"}
            },
            "governance": {
                "transparency_score": {"value": 88, "unit": "%", "target": 90, "trend": "stable"},
                "stakeholder_engagement": {"value": 92, "unit": "%", "target": 95, "trend": "improving"},
                "compliance_rate": {"value": 96, "unit": "%", "target": 100, "trend": "stable"},
                "reporting_frequency": {"value": 12, "unit": "reports/year", "target": 12, "trend": "stable"},
                "risk_management": {"value": 85, "unit": "score", "target": 90, "trend": "improving"}
            },
            "overall_esg_score": 82.5,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "updated_at": datetime.now(timezone.utc).isoformat()
        }
        
        await db.esg_indicators.insert_one(default_esg)
        esg_data = default_esg
    
    if '_id' in esg_data:
        del esg_data['_id']
    
    return esg_data

@api_router.post("/projects/{project_id}/esg-indicators")
async def update_esg_indicators(project_id: str, esg_data: dict, current_user: User = Depends(get_current_user)):
    """Update ESG indicators"""
    # Calculate overall ESG score
    env_scores = [indicator.get("value", 0) for indicator in esg_data.get("environmental", {}).values() if isinstance(indicator, dict)]
    social_scores = [indicator.get("value", 0) for indicator in esg_data.get("social", {}).values() if isinstance(indicator, dict)]
    governance_scores = [indicator.get("value", 0) for indicator in esg_data.get("governance", {}).values() if isinstance(indicator, dict)]
    
    # Normalize scores (some are percentages, some are counts - normalize to 0-100 scale)
    def normalize_score(value, max_expected=100):
        return min(100, (value / max_expected) * 100) if max_expected > 0 else 0
    
    # Calculate weighted average (Environmental: 30%, Social: 40%, Governance: 30%)
    env_avg = sum(env_scores) / len(env_scores) if env_scores else 0
    social_avg = sum([normalize_score(s, 1500 if s > 100 else 100) for s in social_scores]) / len(social_scores) if social_scores else 0
    governance_avg = sum(governance_scores) / len(governance_scores) if governance_scores else 0
    
    overall_score = (env_avg * 0.3) + (social_avg * 0.4) + (governance_avg * 0.3)
    
    update_data = {
        **esg_data,
        "overall_esg_score": round(overall_score, 1),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.esg_indicators.update_one(
        {"project_id": project_id},
        {"$set": update_data},
        upsert=True
    )
    
    return {"overall_esg_score": overall_score}

@api_router.get("/projects/{project_id}/impact-dashboard")
async def get_impact_dashboard(project_id: str, current_user: User = Depends(get_current_user)):
    """Get comprehensive impact dashboard data"""
    # Fetch all impact-related data
    sroi_data = await db.sroi_calculations.find_one({"project_id": project_id})
    sdgs_data = await db.sdgs_alignment.find_one({"project_id": project_id})
    esg_data = await db.esg_indicators.find_one({"project_id": project_id})
    toc_data = await db.theory_of_change.find_one({"project_id": project_id})
    
    # Clean MongoDB ObjectIds
    for data in [sroi_data, sdgs_data, esg_data, toc_data]:
        if data and '_id' in data:
            del data['_id']
    
    # Calculate overall impact score
    sroi_score = (sroi_data.get("sroi_ratio", 0) * 20) if sroi_data else 0  # SROI of 5:1 = 100%
    sdgs_score = sdgs_data.get("overall_alignment_score", 0) if sdgs_data else 0
    esg_score = esg_data.get("overall_esg_score", 0) if esg_data else 0
    
    overall_impact_score = (sroi_score + sdgs_score + esg_score) / 3
    
    return {
        "overall_impact_score": round(overall_impact_score, 1),
        "sroi_calculation": sroi_data,
        "sdgs_alignment": sdgs_data,
        "esg_indicators": esg_data,
        "theory_of_change": toc_data,
        "summary": {
            "sroi_ratio": sroi_data.get("sroi_ratio", 0) if sroi_data else 0,
            "aligned_sdgs_count": len([g for g in sdgs_data.get("goals", []) if g.get("aligned")]) if sdgs_data else 0,
            "esg_score": esg_data.get("overall_esg_score", 0) if esg_data else 0,
            "last_updated": max([
                sroi_data.get("updated_at", ""),
                sdgs_data.get("updated_at", ""),
                esg_data.get("updated_at", ""),
                toc_data.get("updated_at", "") if toc_data else ""
            ])
        }
    }

# Enhanced dashboard with new modules data
@api_router.get("/dashboard")
async def get_dashboard_data(current_user: User = Depends(get_current_user)):
    if current_user.role == UserRole.ADMINISTRATOR:
        total_projects = await db.projects.count_documents({})
        active_projects = await db.projects.count_documents({"status": {"$in": ["executing", "planning"]}})
        total_users = await db.users.count_documents({})
        total_investors = await db.users.count_documents({"role": "investor"})
        total_social_actors = await db.users.count_documents({"role": "social_actor"})
        total_risks = await db.risks.count_documents({"status": "active"})
        open_issues = await db.issues.count_documents({"status": {"$in": ["open", "in_progress"]}})
        pending_changes = await db.changes.count_documents({"status": "pending"})
        pending_phase_gates = await db.phase_gates.count_documents({"status": "pending"})
        pending_qa_checklists = await db.qa_checklists.count_documents({"overall_status": "pending"})
        
        projects = await db.projects.find().sort("created_at", -1).limit(5).to_list(5)
        
        total_budget = 0
        total_spent = 0
        async for project in db.projects.find({}):
            total_budget += project.get("budget", 0)
            total_spent += project.get("actual_cost", 0)
        
        return {
            "role": "administrator",
            "total_projects": total_projects,
            "active_projects": active_projects,
            "total_users": total_users,
            "total_investors": total_investors,
            "total_social_actors": total_social_actors,
            "total_budget": total_budget,
            "total_spent": total_spent,
            "total_risks": total_risks,
            "open_issues": open_issues,
            "pending_changes": pending_changes,
            "pending_phase_gates": pending_phase_gates,
            "pending_qa_checklists": pending_qa_checklists,
            "recent_projects": [Project(**project) for project in projects]
        }
    
    elif current_user.role == UserRole.INVESTOR:
        funded_projects = await db.projects.find({"investor_id": current_user.id}).to_list(1000)
        total_investment = sum([p.get("budget", 0) for p in funded_projects])
        total_spent = sum([p.get("actual_cost", 0) for p in funded_projects])
        active_investments = len([p for p in funded_projects if p.get("status") in ["executing", "planning"]])
        
        sroi_calculations = await db.sroi.find({"project_id": {"$in": [p["id"] for p in funded_projects]}}).to_list(1000)
        avg_sroi = sum([calc.get("sroi_ratio", 0) for calc in sroi_calculations]) / len(sroi_calculations) if sroi_calculations else 0
        
        completed_projects = [p for p in funded_projects if p.get("status") == "closing"]
        
        return {
            "role": "investor",
            "total_investment": total_investment,
            "total_spent": total_spent,
            "portfolio_size": len(funded_projects),
            "active_investments": active_investments,
            "completed_projects": len(completed_projects),
            "avg_sroi": round(avg_sroi, 2),
            "recent_projects": [Project(**project) for project in funded_projects[-5:]]
        }
    
    else:  # SOCIAL_ACTOR
        owned_projects = await db.projects.find({"owner_id": current_user.id}).to_list(1000)
        total_budget = sum([p.get("budget", 0) for p in owned_projects])
        total_spent = sum([p.get("actual_cost", 0) for p in owned_projects])
        active_projects = len([p for p in owned_projects if p.get("status") in ["executing", "planning"]])
        
        pending_deliverables = 0
        open_issues = 0
        pending_qa_checklists = 0
        for project in owned_projects:
            deliverable_count = await db.deliverables.count_documents({
                "project_id": project["id"],
                "status": {"$in": ["planned", "in_progress"]}
            })
            issue_count = await db.issues.count_documents({
                "project_id": project["id"],
                "status": {"$in": ["open", "in_progress"]}
            })
            qa_count = await db.qa_checklists.count_documents({
                "project_id": project["id"],
                "assigned_to": current_user.id,
                "overall_status": "pending"
            })
            pending_deliverables += deliverable_count
            open_issues += issue_count
            pending_qa_checklists += qa_count
        
        return {
            "role": "social_actor",
            "total_projects": len(owned_projects),
            "active_projects": active_projects,
            "total_budget": total_budget,
            "total_spent": total_spent,
            "pending_deliverables": pending_deliverables,
            "open_issues": open_issues,
            "pending_qa_checklists": pending_qa_checklists,
            "recent_projects": [Project(**project) for project in owned_projects[-5:]]
        }

# Initialize sample data with comprehensive data including new modules
@api_router.post("/init-sample-data")
async def initialize_sample_data():
    # Clear existing data first
    collections = ['users', 'projects', 'kpis', 'deliverables', 'risks', 'issues', 'changes', 'sroi', 
                   'phase_gates', 'documents', 'stakeholders', 'qa_checklists', 'notifications',
                   'tasks', 'milestones', 'expenses', 'payments', 'budget_categories', 'beneficiaries',
                   'beneficiary_outcomes', 'compliance_items', 'certifications', 'audit_trail',
                   'videos', 'video_verification_requests', 'video_reviews', 'field_data',
                   'notification_preferences', 'qa_templates', 'qa_inspections', 'non_conformances', 
                   'corrective_actions', 'ai_insights', 'predictive_analytics', 'vendors', 
                   'purchase_orders', 'contracts', 'team_members', 'digital_checklists', 'document_evidence', 
                   'comments', 'contractual_milestones', 'contractual_compliance', 'template_library', 
                   'template_ratings', 'user_bookmarks', 'user_reading_progress', 'instrument_views',
                   'discussion_threads', 'discussion_replies', 'user_activities', 'search_history',
                   'saved_searches', 'user_collections', 'user_annotations', 'reading_sessions',
                   'user_reading_stats', 'notification_subscriptions', 'user_notifications']
    
    for collection in collections:
        await db[collection].delete_many({})
    
    # Create sample users
    sample_users = [
        {
            "id": str(uuid.uuid4()),
            "username": "admin",
            "email": "admin@isisp.org", 
            "role": "administrator",
            "organization_name": "ISISP Platform",
            "password_hash": hash_password("admin123"),
            "created_at": datetime.now(timezone.utc)
        },
        {
            "id": str(uuid.uuid4()),
            "username": "investor_demo",
            "email": "investor@fundingcorp.com",
            "role": "investor",
            "organization_name": "Impact Investment Fund",
            "password_hash": hash_password("investor123"),
            "created_at": datetime.now(timezone.utc)
        },
        {
            "id": str(uuid.uuid4()),
            "username": "social_demo",
            "email": "manager@socialimpact.org",
            "role": "social_actor",
            "organization_name": "Community Development Solutions", 
            "password_hash": hash_password("social123"),
            "created_at": datetime.now(timezone.utc)
        }
    ]
    
    user_ids = {}
    for user_data in sample_users:
        await db.users.insert_one(user_data)
        user_ids[user_data["role"]] = user_data["id"]
    
    # Create sample projects
    sample_projects = [
        {
            "id": str(uuid.uuid4()),
            "title": "Digital Literacy Program for Rural Communities",
            "description": "Comprehensive digital skills training program targeting underserved rural communities to bridge the digital divide",
            "category": "education",
            "start_date": datetime(2024, 1, 15),
            "end_date": datetime(2024, 12, 15),
            "budget": 150000.0,
            "actual_cost": 45000.0,
            "progress": 35.0,
            "status": "executing",
            "phase": "executing",
            "phase_approved": True,
            "owner_id": user_ids["social_actor"],
            "investor_id": user_ids["investor"],
            "created_at": datetime.now(timezone.utc)
        }
    ]
    
    project_ids = []
    for project_data in sample_projects:
        await db.projects.insert_one(project_data)
        project_ids.append(project_data["id"])
    
    if project_ids:
        project_id = project_ids[0]
        
        # Sample stakeholders
        stakeholders = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Community Leader",
                "organization": "Rural Development Committee",
                "role": "Local Representative",
                "contact_email": "leader@community.org",
                "influence": "high",
                "interest": "high",
                "communication_plan": "Monthly progress meetings",
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for stakeholder in stakeholders:
            await db.stakeholders.insert_one(stakeholder)
        
        # Sample QA checklist
        qa_checklist = {
            "id": str(uuid.uuid4()),
            "project_id": project_id,
            "title": "Equipment Delivery Verification",
            "description": "Quality check for delivered training equipment",
            "checklist_items": [
                {"item": "Verify equipment quantity matches order", "status": "pending", "notes": ""},
                {"item": "Check equipment condition", "status": "pending", "notes": ""},
                {"item": "Test equipment functionality", "status": "pending", "notes": ""}
            ],
            "assigned_to": user_ids["social_actor"],
            "overall_status": "pending",
            "created_at": datetime.now(timezone.utc)
        }
        
        await db.qa_checklists.insert_one(qa_checklist)
        
        # Sample phase gate
        phase_gate = {
            "id": str(uuid.uuid4()),
            "project_id": project_id,
            "phase": "executing",
            "gate_type": "RfE",
            "status": "approved",
            "criteria_met": {
                "planning_complete": True,
                "resources_allocated": True,
                "stakeholders_engaged": True
            },
            "approved_by": user_ids["administrator"],
            "approved_at": datetime.now(timezone.utc),
            "created_at": datetime.now(timezone.utc)
        }
        
        await db.phase_gates.insert_one(phase_gate)
        
        # Sample document
        document = {
            "id": str(uuid.uuid4()),
            "project_id": project_id,
            "title": "Project Charter - Digital Literacy Program",
            "description": "Official project charter document",
            "document_type": "project_charter",
            "template_content": {
                "title": "Digital Literacy Program for Rural Communities",
                "objectives": ["Train 500 community members", "Establish 3 learning centers"],
                "scope": "Digital skills training in 5 rural communities"
            },
            "version": "1.0",
            "uploaded_by": user_ids["social_actor"],
            "approved": True,
            "approved_by": user_ids["administrator"],
            "created_at": datetime.now(timezone.utc)
        }
        
        await db.documents.insert_one(document)
        
        # Sample KPIs for Advanced Reporting
        sample_kpis = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Community Members Trained",
                "type": "quantitative",
                "baseline_value": 0.0,
                "target_value": 500.0,
                "actual_value": 175.0,
                "unit": "people",
                "status": "active",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Digital Literacy Improvement",
                "type": "qualitative",
                "baseline_value": 2.0,
                "target_value": 4.5,
                "actual_value": 3.8,
                "unit": "rating (1-5)",
                "status": "active",
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for kpi in sample_kpis:
            await db.kpis.insert_one(kpi)
        
        # Sample Deliverables for Advanced Reporting
        sample_deliverables = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Training Materials Package",
                "description": "Comprehensive digital literacy training materials",
                "due_date": datetime(2024, 6, 15),
                "status": "completed",
                "certification_status": True,
                "evidence_files": ["training_materials_v1.pdf"],
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Community Learning Centers Setup",
                "description": "Establishment of 3 community learning centers",
                "due_date": datetime(2024, 8, 30),
                "status": "in_progress",
                "certification_status": False,
                "evidence_files": [],
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for deliverable in sample_deliverables:
            await db.deliverables.insert_one(deliverable)
        
        # Sample Risks for Advanced Reporting
        sample_risks = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Low Community Participation",
                "description": "Risk of low participation due to lack of awareness about digital literacy benefits",
                "probability": 3,
                "impact": 4,
                "risk_score": 12,
                "level": "medium",
                "mitigation_strategy": "Conduct awareness campaigns and community meetings",
                "contingency_plan": "Partner with local leaders for endorsement",
                "owner_id": user_ids["social_actor"],
                "status": "active",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Equipment Failure",
                "description": "Risk of training equipment malfunction or damage",
                "probability": 2,
                "impact": 3,
                "risk_score": 6,
                "level": "low",
                "mitigation_strategy": "Regular maintenance and backup equipment",
                "contingency_plan": "Emergency procurement process",
                "owner_id": user_ids["social_actor"],
                "status": "active",
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for risk in sample_risks:
            await db.risks.insert_one(risk)
        
        # Sample Issues for Advanced Reporting
        sample_issues = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Equipment Delivery Delay",
                "description": "Training equipment delivery is delayed by 2 weeks due to supply chain issues",
                "priority": "high",
                "status": "in_progress",
                "reporter_id": user_ids["social_actor"],
                "assigned_to": user_ids["administrator"],
                "resolution_strategy": "Expedite shipping and arrange temporary equipment",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Trainer Availability",
                "description": "One of the key trainers is unavailable for the next month",
                "priority": "medium",
                "status": "resolved",
                "reporter_id": user_ids["social_actor"],
                "assigned_to": user_ids["social_actor"],
                "resolution_strategy": "Recruited replacement trainer with similar expertise",
                "resolution_notes": "New trainer onboarded successfully",
                "resolved_at": datetime.now(timezone.utc),
                "created_at": datetime.now(timezone.utc) - timedelta(days=5)
            }
        ]
        
        for issue in sample_issues:
            await db.issues.insert_one(issue)
        
        # Sample SROI Calculations for Advanced Reporting
        sample_sroi = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "inputs_cost": 150000.0,
                "outcomes_value": 450000.0,
                "sroi_ratio": 3.0,
                "calculation_notes": "Based on estimated economic impact of digital literacy training over 3 years. Includes increased employment opportunities, improved business efficiency, and reduced digital divide costs.",
                "calculated_by": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for sroi in sample_sroi:
            await db.sroi.insert_one(sroi)
        
        # Sample Tasks for Gantt Chart
        sample_tasks = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Project Initiation & Planning",
                "description": "Initial project setup, stakeholder alignment, and detailed planning",
                "start_date": datetime(2024, 1, 1),
                "end_date": datetime(2024, 1, 31),
                "assignee": "Project Manager",
                "priority": "high",
                "progress": 100,
                "status": "completed",
                "parent_task_id": None,
                "dependencies": [],
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Community Engagement & Outreach",
                "description": "Building relationships with community leaders and potential beneficiaries",
                "start_date": datetime(2024, 2, 1),
                "end_date": datetime(2024, 3, 15),
                "assignee": "Community Liaison",
                "priority": "critical",
                "progress": 85,
                "status": "in_progress",
                "parent_task_id": None,
                "dependencies": [],
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Training Material Development",
                "description": "Creating comprehensive digital literacy training materials",
                "start_date": datetime(2024, 2, 15),
                "end_date": datetime(2024, 4, 30),
                "assignee": "Content Developer",
                "priority": "high",
                "progress": 60,
                "status": "in_progress",
                "parent_task_id": None,
                "dependencies": [],
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Infrastructure Setup",
                "description": "Setting up learning centers and technical infrastructure",
                "start_date": datetime(2024, 3, 1),
                "end_date": datetime(2024, 5, 31),
                "assignee": "Technical Team",
                "priority": "medium",
                "progress": 40,
                "status": "in_progress",
                "parent_task_id": None,
                "dependencies": [],
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Trainer Recruitment & Training",
                "description": "Recruiting and training qualified instructors",
                "start_date": datetime(2024, 4, 1),
                "end_date": datetime(2024, 6, 15),
                "assignee": "HR Manager",
                "priority": "high",
                "progress": 25,
                "status": "pending",
                "parent_task_id": None,
                "dependencies": [],
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for task in sample_tasks:
            await db.tasks.insert_one(task)
        
        # Sample Milestones for Gantt Chart
        sample_milestones = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Project Kickoff",
                "description": "Official project launch with all stakeholders",
                "target_date": datetime(2024, 1, 15),
                "status": "completed",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "First Training Cohort Start",
                "description": "Beginning of the first community training program",
                "target_date": datetime(2024, 6, 1),
                "status": "pending",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Mid-Project Review",
                "description": "Comprehensive project assessment and course correction",
                "target_date": datetime(2024, 9, 15),
                "status": "pending",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Project Completion",
                "description": "Final deliverables and project closure",
                "target_date": datetime(2024, 12, 31),
                "status": "pending",
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for milestone in sample_milestones:
            await db.milestones.insert_one(milestone)
        
        # Sample Budget for Financial Management
        project_budget = {
            "id": str(uuid.uuid4()),
            "project_id": project_id,
            "total_budget": 150000.0,
            "allocated_budget": 120000.0,
            "reserved_budget": 30000.0,
            "created_at": datetime.now(timezone.utc)
        }
        await db.project_budgets.insert_one(project_budget)
        
        # Sample Budget Categories
        budget_categories = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "category": "personnel",
                "allocated_amount": 60000.0,
                "period": "project",
                "description": "Staff salaries, consultant fees, and training costs",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "category": "equipment",
                "allocated_amount": 35000.0,
                "period": "project",
                "description": "Computers, tablets, and learning equipment",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "category": "materials",
                "allocated_amount": 15000.0,
                "period": "project",
                "description": "Training materials and educational resources",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "category": "utilities",
                "allocated_amount": 10000.0,
                "period": "project",
                "description": "Internet, electricity, and facility costs",
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for category in budget_categories:
            await db.budget_categories.insert_one(category)
        
        # Sample Expenses
        sample_expenses = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "category": "personnel",
                "description": "Project manager salary - January",
                "amount": 5000.0,
                "expense_type": "operational",
                "date": datetime(2024, 1, 31),
                "approval_status": "approved",
                "receipt_url": "",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "category": "equipment",
                "description": "Learning tablets for community centers",
                "amount": 8500.0,
                "expense_type": "capital",
                "date": datetime(2024, 2, 15),
                "approval_status": "approved",
                "receipt_url": "",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "category": "materials",
                "description": "Digital literacy training materials",
                "amount": 2500.0,
                "expense_type": "operational",
                "date": datetime(2024, 3, 1),
                "approval_status": "pending",
                "receipt_url": "",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "category": "utilities",
                "description": "Internet connectivity setup",
                "amount": 1200.0,
                "expense_type": "operational",
                "date": datetime(2024, 3, 15),
                "approval_status": "approved",
                "receipt_url": "",
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for expense in sample_expenses:
            await db.expenses.insert_one(expense)
        
        # Sample Payments
        sample_payments = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "recipient": "Community Technology Solutions",
                "amount": 12000.0,
                "description": "Hardware procurement and setup",
                "payment_method": "bank_transfer",
                "due_date": datetime(2024, 4, 15),
                "status": "pending",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "recipient": "Local Training Institute",
                "amount": 7500.0,
                "description": "Trainer certification and curriculum development",
                "payment_method": "check",
                "due_date": datetime(2024, 5, 1),
                "status": "pending",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "recipient": "Utility Provider",
                "amount": 800.0,
                "description": "Monthly internet service",
                "payment_method": "bank_transfer",
                "due_date": datetime(2024, 4, 1),
                "status": "completed",
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for payment in sample_payments:
            await db.payments.insert_one(payment)
        
        # Sample Beneficiaries for Beneficiary Tracking
        sample_beneficiaries = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "first_name": "Maria",
                "last_name": "Santos",
                "email": "maria.santos@email.com",
                "phone": "+1-555-0123",
                "age": 34,
                "gender": "female",
                "location": "Downtown Community Center",
                "education_level": "high_school",
                "employment_status": "unemployed",
                "household_size": 4,
                "income_level": "low",
                "special_needs": "Single mother seeking digital skills for employment",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "first_name": "Roberto",
                "last_name": "Martinez",
                "email": "roberto.martinez@email.com",
                "phone": "+1-555-0124",
                "age": 45,
                "gender": "male",
                "location": "East Side Community Center",
                "education_level": "primary",
                "employment_status": "self_employed",
                "household_size": 6,
                "income_level": "very_low",
                "special_needs": "Language barrier - Spanish primary",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "first_name": "Jennifer",
                "last_name": "Chen",
                "email": "jennifer.chen@email.com",
                "phone": "+1-555-0125",
                "age": 28,
                "gender": "female",
                "location": "North Community Center",
                "education_level": "college",
                "employment_status": "employed",
                "household_size": 2,
                "income_level": "moderate",
                "special_needs": "",
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        beneficiary_ids = []
        for beneficiary in sample_beneficiaries:
            beneficiary_ids.append(beneficiary["id"])
            await db.beneficiaries.insert_one(beneficiary)
        
        # Sample Beneficiary Outcomes
        sample_outcomes = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "beneficiary_id": beneficiary_ids[0],
                "outcome_type": "skill_development",
                "description": "Completed basic computer literacy course",
                "measurement_value": 85.0,
                "measurement_unit": "score",
                "date_recorded": datetime(2024, 3, 15),
                "impact_level": "high",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "beneficiary_id": beneficiary_ids[0],
                "outcome_type": "employment",
                "description": "Secured part-time remote work position",
                "measurement_value": 20.0,
                "measurement_unit": "hours/week",
                "date_recorded": datetime(2024, 3, 28),
                "impact_level": "high",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "beneficiary_id": beneficiary_ids[1],
                "outcome_type": "skill_development",
                "description": "Learned basic email and internet usage",
                "measurement_value": 75.0,
                "measurement_unit": "score",
                "date_recorded": datetime(2024, 3, 20),
                "impact_level": "medium",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "beneficiary_id": beneficiary_ids[2],
                "outcome_type": "income_increase",
                "description": "Used digital skills to improve business marketing",
                "measurement_value": 30.0,
                "measurement_unit": "percent increase",
                "date_recorded": datetime(2024, 3, 25),
                "impact_level": "high",
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for outcome in sample_outcomes:
            await db.beneficiary_outcomes.insert_one(outcome)
        
        # Sample Compliance Items
        sample_compliance = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "requirement": "Data Protection Compliance",
                "description": "Ensure all beneficiary data is handled according to GDPR requirements",
                "regulatory_body": "GDPR",
                "compliance_status": "compliant",
                "due_date": datetime(2024, 2, 15),
                "priority": "high",
                "evidence_required": "Data processing agreements, privacy policy, consent forms",
                "assigned_to": "Data Protection Officer",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "requirement": "Financial Reporting Standards",
                "description": "Comply with nonprofit financial reporting requirements",
                "regulatory_body": "IRS",
                "compliance_status": "pending",
                "due_date": datetime(2024, 4, 30),
                "priority": "medium",
                "evidence_required": "Annual financial statements, audit reports",
                "assigned_to": "Finance Manager",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "requirement": "Accessibility Standards",
                "description": "Ensure training materials meet ADA accessibility requirements",
                "regulatory_body": "ADA",
                "compliance_status": "under_review",
                "due_date": datetime(2024, 5, 15),
                "priority": "medium",
                "evidence_required": "Accessibility audit report, remediation plan",
                "assigned_to": "Program Coordinator",
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for item in sample_compliance:
            await db.compliance_items.insert_one(item)
        
        # Sample Certifications
        sample_certifications = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "ISO 9001:2015",
                "issuing_body": "ISO International",
                "certification_type": "quality",
                "issue_date": datetime(2023, 6, 1),
                "expiry_date": datetime(2026, 6, 1),
                "status": "active",
                "certificate_url": "https://example.com/iso9001-certificate",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Social Impact Certification",
                "issuing_body": "Social Enterprise Mark",
                "certification_type": "social",
                "issue_date": datetime(2023, 9, 15),
                "expiry_date": datetime(2024, 9, 15),
                "status": "active",
                "certificate_url": "https://example.com/social-impact-certificate",
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for cert in sample_certifications:
            await db.certifications.insert_one(cert)
        
        # Sample Audit Trail
        sample_audit_entries = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "action": "Project Created",
                "description": "Digital Literacy Program project was created",
                "performed_by": "Administrator",
                "resource_type": "project",
                "resource_id": project_id,
                "ip_address": "192.168.1.100",
                "timestamp": datetime.now(timezone.utc) - timedelta(days=30),
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "action": "Beneficiary Registered",
                "description": "New beneficiary Maria Santos was registered",
                "performed_by": "Social Actor",
                "resource_type": "beneficiary",
                "resource_id": beneficiary_ids[0],
                "ip_address": "192.168.1.101",
                "timestamp": datetime.now(timezone.utc) - timedelta(days=15),
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "action": "Compliance Status Updated",
                "description": "Data Protection Compliance marked as compliant",
                "performed_by": "Administrator",
                "resource_type": "compliance",
                "resource_id": sample_compliance[0]["id"],
                "ip_address": "192.168.1.100",
                "timestamp": datetime.now(timezone.utc) - timedelta(days=5),
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for entry in sample_audit_entries:
            await db.audit_trail.insert_one(entry)
        
        # Sample Videos for Video Verification System
        sample_videos = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Digital Learning Center Setup Verification",
                "description": "Complete setup and installation verification of the new digital learning center including equipment placement, connectivity testing, and safety compliance.",
                "verification_type": "installation_proof",
                "location": "Downtown Community Center - Room 204",
                "object_id": "DLC-001",
                "priority": "high",
                "verification_status": "approved",
                "uploaded_by": "field_technician_1",
                "file_size": 45678901,  # ~43.5 MB
                "duration": 125,  # seconds
                "thumbnail_url": "https://example.com/thumbnails/dlc-setup.jpg",
                "video_url": "https://example.com/videos/dlc-setup.mp4",
                "verification_score": 95,
                "uploaded_at": datetime(2024, 3, 10, 14, 30),
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Training Equipment Quality Inspection",
                "description": "Detailed quality inspection of newly delivered tablets, laptops, and training materials to ensure they meet project specifications.",
                "verification_type": "quality_inspection",
                "location": "East Side Community Center - Storage Room",
                "object_id": "EQ-BATCH-003",
                "priority": "medium",
                "verification_status": "approved",
                "uploaded_by": "quality_inspector",
                "file_size": 67891234,  # ~64.7 MB
                "duration": 89,
                "thumbnail_url": "https://example.com/thumbnails/equipment-inspection.jpg",
                "video_url": "https://example.com/videos/equipment-inspection.mp4",
                "verification_score": 92,
                "uploaded_at": datetime(2024, 3, 15, 10, 15),
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Beneficiary Training Session Documentation",
                "description": "Recording of Maria Santos completing her digital literacy assessment and demonstrating newly acquired computer skills.",
                "verification_type": "training_evidence",
                "location": "North Community Center - Training Room A",
                "object_id": "TRAINING-MS-001",
                "priority": "medium",
                "verification_status": "under_review",
                "uploaded_by": "training_coordinator",
                "file_size": 34567890,  # ~32.9 MB
                "duration": 156,
                "thumbnail_url": "https://example.com/thumbnails/training-session.jpg",
                "video_url": "https://example.com/videos/training-session.mp4",
                "verification_score": None,
                "uploaded_at": datetime(2024, 3, 20, 16, 45),
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Safety Compliance Check - Emergency Procedures",
                "description": "Demonstration of emergency evacuation procedures and safety equipment testing at the community center facility.",
                "verification_type": "safety_compliance",
                "location": "Downtown Community Center - All Floors",
                "object_id": "SAFETY-001",
                "priority": "critical",
                "verification_status": "pending",
                "uploaded_by": "safety_officer",
                "file_size": 78912345,  # ~75.2 MB
                "duration": 203,
                "thumbnail_url": "https://example.com/thumbnails/safety-check.jpg",
                "video_url": "https://example.com/videos/safety-check.mp4",
                "verification_score": None,
                "uploaded_at": datetime(2024, 3, 25, 9, 30),
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        video_ids = []
        for video in sample_videos:
            video_ids.append(video["id"])
            await db.videos.insert_one(video)
        
        # Sample Video Verification Requests
        sample_verification_requests = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "video_id": video_ids[2],  # Training session - under review
                "status": "pending",
                "submitted_by": "training_coordinator",
                "submitted_at": datetime(2024, 3, 20, 16, 50),
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "video_id": video_ids[3],  # Safety compliance - pending
                "status": "pending",
                "submitted_by": "safety_officer",
                "submitted_at": datetime(2024, 3, 25, 9, 35),
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for request in sample_verification_requests:
            await db.video_verification_requests.insert_one(request)
        
        # Sample Video Reviews
        sample_video_reviews = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "video_id": video_ids[0],  # Digital learning center setup
                "review_status": "approved",
                "review_notes": "Excellent documentation of the installation process. All safety protocols followed, equipment properly installed and tested. Setup meets all project specifications and quality standards.",
                "verification_score": 95,
                "compliance_check": True,
                "reviewed_by": "Administrator",
                "reviewed_at": datetime(2024, 3, 12, 11, 20),
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "video_id": video_ids[1],  # Equipment quality inspection
                "review_status": "approved",
                "review_notes": "Thorough quality inspection completed. All equipment items verified against specifications. Minor packaging damage noted on 2 tablets but devices are fully functional. Recommend acceptance with documented condition.",
                "verification_score": 92,
                "compliance_check": True,
                "reviewed_by": "Administrator",
                "reviewed_at": datetime(2024, 3, 16, 14, 45),
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for review in sample_video_reviews:
            await db.video_reviews.insert_one(review)
        
        # Sample Mobile Field Application Data
        sample_field_data = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "type": "inspection",
                "data": {
                    "location": "Downtown Community Center - Room 204",
                    "coordinates": {
                        "latitude": 40.7128,
                        "longitude": -74.0060,
                        "accuracy": 10.0,
                        "timestamp": datetime.now(timezone.utc).isoformat()
                    },
                    "status": "completed",
                    "notes": "Digital learning center setup inspection completed successfully. All equipment properly installed and functioning. WiFi connectivity tested and operational. Safety protocols verified.",
                    "photos": [
                        {
                            "id": 1710123456789,
                            "url": "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCI+PHJlY3Qgd2lkdGg9IjEwMCIgaGVpZ2h0PSIxMDAiIGZpbGw9IiNmMGYwZjAiLz48dGV4dCB4PSI1MCIgeT0iNTAiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj7wn5OXPC90ZXh0Pjwvc3ZnPg==",
                            "timestamp": datetime.now(timezone.utc).isoformat()
                        },
                        {
                            "id": 1710123456790,
                            "url": "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCI+PHJlY3Qgd2lkdGg9IjEwMCIgaGVpZ2h0PSIxMDAiIGZpbGw9IiNmMGYwZjAiLz48dGV4dCB4PSI1MCIgeT0iNTAiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj7wn5OXPC90ZXh0Pjwvc3ZnPg==",
                            "timestamp": datetime.now(timezone.utc).isoformat()
                        }
                    ],
                    "inspector": "admin",
                    "priority": "high"
                },
                "timestamp": datetime(2024, 3, 10, 15, 30).isoformat(),
                "user": "admin",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "type": "delivery",
                "data": {
                    "item_name": "Laptops",
                    "quantity": "25",
                    "condition": "excellent",
                    "recipient": "Downtown Community Center",
                    "location": "Downtown Community Center - Storage Room",
                    "coordinates": {
                        "latitude": 40.7128,
                        "longitude": -74.0060,
                        "accuracy": 8.0,
                        "timestamp": datetime.now(timezone.utc).isoformat()
                    },
                    "delivery_notes": "25 Dell laptops delivered in perfect condition. All units tested and configured with training software. Serial numbers documented and handed over to center coordinator.",
                    "photos": [
                        {
                            "id": 1710223456789,
                            "url": "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCI+PHJlY3Qgd2lkdGg9IjEwMCIgaGVpZ2h0PSIxMDAiIGZpbGw9IiNmMGYwZjAiLz48dGV4dCB4PSI1MCIgeT0iNTAiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj7wn5OXPC90ZXh0Pjwvc3ZnPg==",
                            "timestamp": datetime.now(timezone.utc).isoformat()
                        }
                    ],
                    "delivered_by": "admin"
                },
                "timestamp": datetime(2024, 3, 8, 11, 0).isoformat(),
                "user": "admin",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "type": "incident",
                "data": {
                    "incident_type": "equipment",
                    "severity": "medium",
                    "description": "One laptop screen flickering during training session. Issue appeared intermittently during use.",
                    "location": "East Side Community Center - Training Room B",
                    "coordinates": {
                        "latitude": 40.7589,
                        "longitude": -73.9851,
                        "accuracy": 12.0,
                        "timestamp": datetime.now(timezone.utc).isoformat()
                    },
                    "action_taken": "Laptop removed from training session, replacement unit provided. Technical support contacted for diagnostic and repair. Serial number documented for warranty claim.",
                    "photos": [
                        {
                            "id": 1710323456789,
                            "url": "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCI+PHJlY3Qgd2lkdGg9IjEwMCIgaGVpZ2h0PSIxMDAiIGZpbGw9IiNmMGYwZjAiLz48dGV4dCB4PSI1MCIgeT0iNTAiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj7wn5OXPC90ZXh0Pjwvc3ZnPg==",
                            "timestamp": datetime.now(timezone.utc).isoformat()
                        }
                    ],
                    "reported_by": "social_demo"
                },
                "timestamp": datetime(2024, 3, 12, 14, 45).isoformat(),
                "user": "social_demo",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "type": "inspection",
                "data": {
                    "location": "North Community Center - Training Room A",
                    "coordinates": {
                        "latitude": 40.7831,
                        "longitude": -73.9712,
                        "accuracy": 15.0,
                        "timestamp": datetime.now(timezone.utc).isoformat()
                    },
                    "status": "in_progress",
                    "notes": "Weekly facility inspection in progress. Checking equipment status, WiFi connectivity, and safety compliance. Initial findings show good condition overall.",
                    "photos": [
                        {
                            "id": 1710423456789,
                            "url": "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCI+PHJlY3Qgd2lkdGg9IjEwMCIgaGVpZ2h0PSIxMDAiIGZpbGw9IiNmMGYwZjAiLz48dGV4dCB4PSI1MCIgeT0iNTAiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGR5PSIuM2VtIj7wn5OXPC90ZXh0Pjwvc3ZnPg==",
                            "timestamp": datetime.now(timezone.utc).isoformat()
                        }
                    ],
                    "inspector": "social_demo",
                    "priority": "medium"
                },
                "timestamp": datetime(2024, 3, 15, 10, 15).isoformat(),
                "user": "social_demo",
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "type": "delivery",
                "data": {
                    "item_name": "Training Materials",
                    "quantity": "100",
                    "condition": "good",
                    "recipient": "Training Coordinator - Jennifer Chen",
                    "location": "All Community Centers",
                    "coordinates": {
                        "latitude": 40.7505,
                        "longitude": -73.9934,
                        "accuracy": 20.0,
                        "timestamp": datetime.now(timezone.utc).isoformat()
                    },
                    "delivery_notes": "Digital literacy workbooks and instructional materials delivered to all three training locations. Materials include beginner, intermediate, and advanced level content.",
                    "photos": [],
                    "delivered_by": "investor_demo"
                },
                "timestamp": datetime(2024, 3, 5, 9, 30).isoformat(),
                "user": "investor_demo",
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for field_entry in sample_field_data:
            await db.field_data.insert_one(field_entry)
        
        # Sample Notifications for Advanced Notification System
        sample_notifications = [
            {
                "id": str(uuid.uuid4()),
                "user_id": user_ids["administrator"],
                "event_type": "mobile_field_update",
                "message": "New inspection submitted from Downtown Community Center - Room 204",
                "related_id": sample_field_data[0]["id"],
                "project_id": project_id,
                "priority": "high",
                "read": False,
                "created_at": datetime.now(timezone.utc) - timedelta(hours=2)
            },
            {
                "id": str(uuid.uuid4()),
                "user_id": user_ids["social_actor"],
                "event_type": "compliance_deadline",
                "message": "Data Protection Compliance review deadline approaching in 5 days",
                "related_id": sample_compliance[0]["id"],
                "project_id": project_id,
                "priority": "high",
                "read": False,
                "created_at": datetime.now(timezone.utc) - timedelta(hours=4)
            },
            {
                "id": str(uuid.uuid4()),
                "user_id": user_ids["investor"],
                "event_type": "financial_approval",
                "message": "Purchase order for Community Technology Solutions requires approval - $12,000",
                "related_id": sample_payments[0]["id"],
                "project_id": project_id,
                "priority": "medium",
                "read": False,
                "created_at": datetime.now(timezone.utc) - timedelta(hours=6)
            },
            {
                "id": str(uuid.uuid4()),
                "user_id": user_ids["administrator"],
                "event_type": "project_milestone",
                "message": "Project milestone 'Equipment Installation' has been completed",
                "related_id": sample_milestones[0]["id"],
                "project_id": project_id,
                "priority": "medium",
                "read": True,
                "read_at": datetime.now(timezone.utc) - timedelta(hours=1),
                "created_at": datetime.now(timezone.utc) - timedelta(hours=8)
            },
            {
                "id": str(uuid.uuid4()),
                "user_id": user_ids["social_actor"],
                "event_type": "quality_issue",
                "message": "Equipment incident reported: Laptop screen flickering during training session",
                "related_id": sample_field_data[2]["id"],
                "project_id": project_id,
                "priority": "medium",
                "read": False,
                "created_at": datetime.now(timezone.utc) - timedelta(hours=12)
            },
            {
                "id": str(uuid.uuid4()),
                "user_id": user_ids["administrator"],
                "event_type": "system_announcement",
                "message": "Mobile Field Application has been successfully deployed and is ready for use",
                "related_id": None,
                "project_id": None,
                "priority": "low",
                "read": False,
                "created_at": datetime.now(timezone.utc) - timedelta(days=1)
            },
            {
                "id": str(uuid.uuid4()),
                "user_id": user_ids["investor"],
                "event_type": "beneficiary_update",
                "message": "New beneficiary outcome recorded: Maria Santos secured part-time remote work position",
                "related_id": sample_outcomes[1]["id"],
                "project_id": project_id,
                "priority": "low",
                "read": True,
                "read_at": datetime.now(timezone.utc) - timedelta(hours=2),
                "created_at": datetime.now(timezone.utc) - timedelta(days=2)
            }
        ]
        
        for notification in sample_notifications:
            await db.notifications.insert_one(notification)
        
        # Sample Notification Preferences
        sample_notification_preferences = [
            {
                "user_id": user_ids["administrator"],
                "mobile_field_updates": True,
                "project_milestones": True,
                "financial_approvals": True,
                "compliance_deadlines": True,
                "quality_issues": True,
                "procurement_updates": True,
                "system_announcements": True,
                "updated_at": datetime.now(timezone.utc)
            },
            {
                "user_id": user_ids["social_actor"],
                "mobile_field_updates": True,
                "project_milestones": True,
                "financial_approvals": False,
                "compliance_deadlines": True,
                "quality_issues": True,
                "procurement_updates": False,
                "system_announcements": True,
                "updated_at": datetime.now(timezone.utc)
            },
            {
                "user_id": user_ids["investor"],
                "mobile_field_updates": False,
                "project_milestones": True,
                "financial_approvals": True,
                "compliance_deadlines": True,
                "quality_issues": False,
                "procurement_updates": True,
                "system_announcements": False,
                "updated_at": datetime.now(timezone.utc)
            }
        ]
        
        for preferences in sample_notification_preferences:
            await db.notification_preferences.insert_one(preferences)
        
        # Sample Quality Assurance Module Data
        sample_qa_templates = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Equipment Installation Quality Checklist",
                "description": "Standard checklist for verifying equipment installation quality",
                "category": "installation",
                "checklist_items": [
                    {
                        "item": "Equipment properly mounted and secured",
                        "acceptance_criteria": "All bolts torqued to specification, no visible gaps",
                        "required": True
                    },
                    {
                        "item": "Electrical connections completed",
                        "acceptance_criteria": "All connections tight, proper gauge wire used",
                        "required": True
                    },
                    {
                        "item": "Safety labels and warnings posted",
                        "acceptance_criteria": "All required safety signage visible and legible",
                        "required": True
                    },
                    {
                        "item": "Equipment testing completed",
                        "acceptance_criteria": "Functional test performed and documented",
                        "required": True
                    }
                ],
                "created_by": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Training Delivery Quality Assessment",
                "description": "Quality checklist for training session delivery",
                "category": "training",
                "checklist_items": [
                    {
                        "item": "Training materials prepared and available",
                        "acceptance_criteria": "All handouts, presentations, and resources ready",
                        "required": True
                    },
                    {
                        "item": "Learning objectives clearly communicated",
                        "acceptance_criteria": "Participants understand session goals",
                        "required": True
                    },
                    {
                        "item": "Interactive elements included",
                        "acceptance_criteria": "Hands-on activities and Q&A sessions",
                        "required": False
                    },
                    {
                        "item": "Participant feedback collected",
                        "acceptance_criteria": "Feedback forms completed by 80% of participants",
                        "required": True
                    }
                ],
                "created_by": user_ids["social_actor"],
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        qa_template_ids = []
        for template in sample_qa_templates:
            qa_template_ids.append(template["id"])
            await db.qa_templates.insert_one(template)
        
        # Sample QA Inspections
        sample_qa_inspections = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "template_id": qa_template_ids[0],
                "item_name": "Laptop Station Setup - Room 204",
                "item_type": "equipment_installation",
                "inspection_date": datetime(2024, 3, 12),
                "status": "passed",
                "score": 95,
                "notes": "Installation completed to specification. Minor cable management improvement recommended.",
                "inspector": "admin",
                "inspector_id": user_ids["administrator"],
                "checklist_results": [
                    {"item": "Equipment properly mounted and secured", "result": "pass", "notes": "All laptops securely mounted"},
                    {"item": "Electrical connections completed", "result": "pass", "notes": "Power and network connections verified"},
                    {"item": "Safety labels and warnings posted", "result": "pass", "notes": "All required labels in place"},
                    {"item": "Equipment testing completed", "result": "pass", "notes": "All laptops tested and functional"}
                ],
                "photos": [
                    "inspection_photo_1.jpg",
                    "inspection_photo_2.jpg"
                ],
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "template_id": qa_template_ids[1],
                "item_name": "Digital Literacy Training Session - March 15",
                "item_type": "training_delivery",
                "inspection_date": datetime(2024, 3, 15),
                "status": "failed",
                "score": 70,
                "notes": "Training content good but participant engagement below standard. Feedback collection incomplete.",
                "inspector": "social_demo",
                "inspector_id": user_ids["social_actor"],
                "checklist_results": [
                    {"item": "Training materials prepared and available", "result": "pass", "notes": "All materials ready"},
                    {"item": "Learning objectives clearly communicated", "result": "pass", "notes": "Objectives presented clearly"},
                    {"item": "Interactive elements included", "result": "fail", "notes": "Limited hands-on activities"},
                    {"item": "Participant feedback collected", "result": "fail", "notes": "Only 60% feedback completion"}
                ],
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "template_id": qa_template_ids[0],
                "item_name": "WiFi Network Installation - All Centers",
                "item_type": "infrastructure",
                "inspection_date": datetime(2024, 3, 18),
                "status": "passed",
                "score": 100,
                "notes": "Excellent installation quality. All network components working optimally.",
                "inspector": "admin",
                "inspector_id": user_ids["administrator"],
                "checklist_results": [
                    {"item": "Equipment properly mounted and secured", "result": "pass", "notes": "All network equipment properly installed"},
                    {"item": "Electrical connections completed", "result": "pass", "notes": "Power connections verified"},
                    {"item": "Safety labels and warnings posted", "result": "pass", "notes": "Network safety labels applied"},
                    {"item": "Equipment testing completed", "result": "pass", "notes": "Network speed and connectivity tested"}
                ],
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        qa_inspection_ids = []
        for inspection in sample_qa_inspections:
            qa_inspection_ids.append(inspection["id"])
            await db.qa_inspections.insert_one(inspection)
        
        # Sample Non-conformances
        sample_non_conformances = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Laptop Screen Flickering Issue",
                "description": "Multiple laptops exhibiting intermittent screen flickering during training sessions. Issue affects approximately 3 units out of 25.",
                "category": "equipment_defect",
                "severity": "medium",
                "reported_date": datetime(2024, 3, 16),
                "location": "East Side Community Center",
                "reported_by": "social_demo",
                "reporter_id": user_ids["social_actor"],
                "status": "open",
                "impact": "Training disruptions, reduced participant satisfaction",
                "immediate_action": "Affected laptops removed from service, replacement units provided",
                "photos": ["flickering_screen_1.jpg"],
                "related_inspection_id": qa_inspection_ids[1],
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Training Material Version Mismatch",
                "description": "Discovered that some training materials are from previous version, causing confusion for participants.",
                "category": "documentation_error",
                "severity": "low",
                "reported_date": datetime(2024, 3, 20),
                "location": "All training centers",
                "reported_by": "social_demo",
                "reporter_id": user_ids["social_actor"],
                "status": "closed",
                "resolution": "All training materials updated to current version, distribution completed",
                "impact": "Minor participant confusion, easily resolved during sessions",
                "immediate_action": "Identified outdated materials, provided correct versions to trainers",
                "closed_date": datetime(2024, 3, 22),
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        nc_ids = []
        for nc in sample_non_conformances:
            nc_ids.append(nc["id"])
            await db.non_conformances.insert_one(nc)
        
        # Sample Corrective Actions
        sample_corrective_actions = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Replace Defective Laptops",
                "description": "Coordinate with supplier to replace laptops exhibiting screen flickering issue under warranty",
                "category": "equipment_replacement",
                "related_nc_id": nc_ids[0],
                "assigned_to": "Administrator",
                "assigned_to_id": user_ids["administrator"],
                "due_date": datetime(2024, 4, 15),
                "status": "in_progress",
                "priority": "medium",
                "estimated_cost": 0.0,  # Under warranty
                "progress": 60,
                "action_steps": [
                    {
                        "step": "Contact supplier technical support",
                        "status": "completed",
                        "completed_date": datetime(2024, 3, 17)
                    },
                    {
                        "step": "Submit warranty claim with documentation",
                        "status": "completed", 
                        "completed_date": datetime(2024, 3, 18)
                    },
                    {
                        "step": "Schedule replacement delivery",
                        "status": "in_progress",
                        "notes": "Awaiting supplier confirmation"
                    },
                    {
                        "step": "Install and test replacement units",
                        "status": "pending"
                    }
                ],
                "created_by": "Administrator",
                "creator_id": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Implement Training Material Version Control",
                "description": "Establish version control system for training materials to prevent future version mismatches",
                "category": "process_improvement",
                "related_nc_id": nc_ids[1],
                "assigned_to": "Social Actor",
                "assigned_to_id": user_ids["social_actor"],
                "due_date": datetime(2024, 4, 30),
                "status": "completed",
                "priority": "low",
                "estimated_cost": 500.0,
                "progress": 100,
                "completion_date": datetime(2024, 3, 25),
                "action_steps": [
                    {
                        "step": "Review current material management process",
                        "status": "completed",
                        "completed_date": datetime(2024, 3, 21)
                    },
                    {
                        "step": "Create version control checklist",
                        "status": "completed",
                        "completed_date": datetime(2024, 3, 23)
                    },
                    {
                        "step": "Train staff on new procedures",
                        "status": "completed",
                        "completed_date": datetime(2024, 3, 25)
                    }
                ],
                "created_by": "Social Actor",
                "creator_id": user_ids["social_actor"],
                "created_at": datetime.now(timezone.utc)
            }
        ]
        
        for action in sample_corrective_actions:
            await db.corrective_actions.insert_one(action)
        
        # Sample AI Insights and Predictive Analytics Data
        sample_ai_insights = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "analysis_type": "risk_assessment",
                "insights": "Based on current project data analysis, several key risk factors have been identified:\n\n1. **Equipment Risk (Medium)**: The laptop screen flickering issue indicates potential equipment quality concerns that could affect 10-15% of devices. Recommend establishing stronger QA protocols with suppliers.\n\n2. **Training Effectiveness (Low-Medium)**: Training completion rates are strong at 85%, but participant engagement metrics suggest room for improvement. Interactive elements should be increased by 30%.\n\n3. **Budget Utilization (Low)**: Current spend rate of 65% suggests good financial control, but may indicate resource underutilization. Consider accelerating beneficial activities.\n\n4. **Quality Assurance (Low)**: 95% inspection pass rate demonstrates strong quality management. The corrective action system is functioning effectively.\n\n**Recommendations**:\n- Implement predictive maintenance for equipment\n- Enhance training interactivity\n- Consider strategic budget reallocation\n- Maintain current QA standards",
                "generated_by": user_ids["administrator"],
                "data_snapshot": "Project overview with 25 deliverables, 8 risks, 5 field entries, 3 QA inspections",
                "created_at": datetime.now(timezone.utc) - timedelta(days=3)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "analysis_type": "performance_prediction",
                "insights": "**Project Performance Forecast**\n\n**Completion Probability**: 92% likelihood of on-time completion\n\n**Key Predictions**:\n\n1. **Timeline**: Current progress rate of 78% suggests completion by target date with 2-week buffer\n2. **Budget**: Projected final cost 103% of budget (+$15,000) due to equipment replacements\n3. **Quality**: Maintaining current QA standards will result in 95%+ success rate\n4. **Impact**: Expected to reach 85-90% of planned beneficiary outcomes\n\n**Performance Drivers**:\n- Strong project management (95% deliverable completion rate)\n- Effective quality control (minimal rework required)\n- Good stakeholder engagement (low conflict incidents)\n\n**Optimization Opportunities**:\n- Accelerate training rollout by 15% to create schedule buffer\n- Implement automated quality checks to reduce manual inspection time\n- Consider expanding beneficiary outreach based on current success rates\n\n**Confidence Level**: High (88%) based on consistent historical performance",
                "generated_by": user_ids["administrator"],
                "data_snapshot": "Performance analysis based on deliverables, timeline, budget, and quality metrics",
                "created_at": datetime.now(timezone.utc) - timedelta(days=5)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "analysis_type": "optimization_suggestions",
                "insights": "**Project Optimization Analysis**\n\n**High-Impact Optimizations**:\n\n1. **Resource Allocation** (Impact: High, Effort: Medium)\n   - Reallocate 20% of admin time to direct training delivery\n   - Expected outcome: 15% increase in training capacity\n\n2. **Process Automation** (Impact: High, Effort: High)\n   - Implement automated quality checklists for routine inspections\n   - Expected outcome: 30% reduction in QA processing time\n\n3. **Technology Enhancement** (Impact: Medium, Effort: Low)\n   - Deploy mobile-first training materials\n   - Expected outcome: 25% improvement in participant engagement\n\n**Cost Optimization**:\n- Equipment bulk purchasing could reduce costs by 12%\n- Centralized training reduces venue costs by $8,000\n- Streamlined documentation saves 40 hours/month\n\n**Quality Improvements**:\n- Implement peer review system for training materials\n- Add real-time feedback mechanisms\n- Create predictive quality scoring\n\n**ROI Projections**:\n- Process improvements: $25,000 annual savings\n- Quality enhancements: 20% better outcomes\n- Resource optimization: 15% efficiency gain",
                "generated_by": user_ids["social_actor"],
                "data_snapshot": "Optimization analysis covering resources, processes, technology, and costs",
                "created_at": datetime.now(timezone.utc) - timedelta(days=7)
            }
        ]
        
        for insight in sample_ai_insights:
            await db.ai_insights.insert_one(insight)
        
        # Sample Predictive Analytics
        sample_predictions = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "prediction_type": "completion_timeline",
                "predictions": "**Project Completion Timeline Prediction**\n\n**Estimated Completion**: April 28, 2024 (95% confidence)\n**Confidence Interval**: April 20 - May 10, 2024\n\n**Analysis**:\n\nBased on historical performance data showing 78% completion rate and consistent 2.3 deliverables completed per week:\n\n**Timeline Predictions**:\n- Remaining deliverables: 5.5 weeks at current pace\n- Critical path buffer: 1.5 weeks built-in\n- Risk adjustment: +0.8 weeks for equipment issues\n\n**Risk Factors**:\n1. Equipment replacement delays (15% probability, +1 week impact)\n2. Training schedule conflicts (25% probability, +0.5 week impact)\n3. Vendor delivery delays (10% probability, +2 weeks impact)\n\n**Probability Analysis**:\n- On-time completion (by May 1): 88%\n- Early completion (by April 25): 45%\n- Delayed completion (after May 10): 12%\n\n**Critical Success Factors**:\n- Maintain current QA standards (95% pass rate)\n- Resolve equipment issues by April 5\n- Keep training participant satisfaction above 85%\n\n**Recommendations**:\n1. Front-load equipment replacements\n2. Create 1-week schedule buffer for critical activities\n3. Implement weekly progress checkpoints",
                "historical_data_summary": "60-day analysis: 78% deliverable completion, 2.3/week completion rate, 95% QA pass rate",
                "generated_by": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc) - timedelta(days=2)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "prediction_type": "budget_forecast",
                "predictions": "**Budget Utilization Forecast**\n\n**Projected Final Cost**: $267,500 (103.1% of $259,500 budget)\n**Budget Overrun**: $8,000 (+3.1%)\n\n**Spending Analysis**:\n\n**Historical Pattern** (60-day trend):\n- Monthly burn rate: $43,250\n- Spending acceleration: 8% increase in month 2\n- Cost per deliverable: $10,700 average\n\n**Forecast by Category**:\n1. **Equipment**: $125,000 (105% of budget) - overrun due to replacements\n2. **Training**: $87,500 (98% of budget) - on track\n3. **Personnel**: $45,000 (102% of budget) - slight overrun\n4. **Operations**: $10,000 (95% of budget) - under budget\n\n**Risk Scenarios**:\n- **Best Case** (25% probability): $255,000 total (98.3%)\n- **Most Likely** (50% probability): $267,500 total (103.1%)\n- **Worst Case** (25% probability): $285,000 total (109.8%)\n\n**Cost Optimization Opportunities**:\n- Bulk equipment purchasing: -$7,500\n- Training material reuse: -$3,200\n- Vendor renegotiation: -$4,800\n- **Total Potential Savings**: $15,500\n\n**Financial Recommendations**:\n1. Secure additional $15,000 budget approval\n2. Implement cost tracking weekly\n3. Accelerate bulk purchasing agreements\n4. Monitor equipment replacement costs closely",
                "historical_data_summary": "Financial analysis: $173,250 spent, $43,250/month burn rate, 67% budget utilized",
                "generated_by": user_ids["investor"],
                "created_at": datetime.now(timezone.utc) - timedelta(days=4)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "prediction_type": "success_probability",
                "predictions": "**Project Success Probability Analysis**\n\n**Overall Success Probability**: 87% (High Confidence)\n\n**Success Metrics Breakdown**:\n\n**Primary Objectives**:\n- Digital literacy training completion: 92% probability\n- Equipment deployment success: 88% probability  \n- Community engagement targets: 85% probability\n- Quality standards maintenance: 95% probability\n\n**Key Success Indicators**:\n\n1. **Performance Metrics** (Current vs Target):\n   - Deliverable completion: 78% (Target: 80%) ✅\n   - Beneficiary satisfaction: 87% (Target: 85%) ✅\n   - Quality pass rate: 95% (Target: 90%) ✅\n   - Budget adherence: 97% (Target: 100%) ⚠️\n\n2. **Risk Mitigation Effectiveness**: 89%\n   - Equipment issues: Well managed (93%)\n   - Training quality: Exceeding standards (96%)\n   - Community adoption: Strong progress (84%)\n\n**Critical Success Factors**:\n- Stakeholder engagement level: High (92%)\n- Team performance: Excellent (94%)\n- Resource availability: Good (86%)\n- External dependencies: Manageable (81%)\n\n**Comparative Analysis**:\nPerformance vs similar projects: Top 15% percentile\n- Better quality outcomes (+12%)\n- Stronger community engagement (+18%)\n- More effective risk management (+8%)\n\n**Success Enhancement Opportunities**:\n1. Increase training interactivity (+3% success probability)\n2. Strengthen vendor relationships (+2% success probability)\n3. Expand community outreach (+4% success probability)\n\n**Final Assessment**: Project demonstrates strong success trajectory with manageable risks and excellent stakeholder satisfaction.",
                "historical_data_summary": "Success analysis: 87% satisfaction rate, 95% quality scores, 78% completion rate",
                "generated_by": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc) - timedelta(days=6)
            }
        ]
        
        for prediction in sample_predictions:
            await db.predictive_analytics.insert_one(prediction)
        
        # Sample Procurement Management Data
        sample_vendors = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Community Technology Solutions",
                "category": "technology_equipment",
                "contact_person": "Sarah Johnson",
                "email": "sarah.johnson@communitytechsolutions.com",
                "phone": "+1-555-0123",
                "address": "1234 Tech Street, Digital City, DC 12345",
                "rating": 4.8,
                "status": "active",
                "payment_terms": "NET 30",
                "certifications": ["ISO 9001", "SOC 2 Type II"],
                "specialization": "Educational technology and digital equipment",
                "created_by": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc) - timedelta(days=15)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Learning Materials Plus",
                "category": "educational_materials",
                "contact_person": "Michael Chen",
                "email": "m.chen@learningmaterialsplus.com",
                "phone": "+1-555-0456",
                "address": "789 Education Ave, Learning District, LD 67890",
                "rating": 4.5,
                "status": "active",
                "payment_terms": "NET 15",
                "certifications": ["EPA Green Certified"],
                "specialization": "Sustainable educational materials and supplies",
                "created_by": user_ids["social_actor"],
                "created_at": datetime.now(timezone.utc) - timedelta(days=20)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "name": "Digital Training Experts",
                "category": "professional_services",
                "contact_person": "Dr. Lisa Rodriguez",
                "email": "lisa.rodriguez@digitaltrainingexperts.com",
                "phone": "+1-555-0789",
                "address": "456 Training Blvd, Skill City, SC 54321",
                "rating": 4.9,
                "status": "active",
                "payment_terms": "NET 45",
                "certifications": ["PMI Certified", "Adult Education Accredited"],
                "specialization": "Digital literacy training and curriculum development",
                "created_by": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc) - timedelta(days=30)
            }
        ]
        
        vendor_ids = []
        for vendor in sample_vendors:
            vendor_ids.append(vendor["id"])
            await db.vendors.insert_one(vendor)
        
        # Sample Purchase Orders
        sample_purchase_orders = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "vendor_id": vendor_ids[0],
                "vendor_name": "Community Technology Solutions",
                "description": "Dell Laptops for Digital Literacy Training",
                "order_number": "PO-2024-001",
                "items": [
                    {
                        "name": "Dell Latitude 5520 Laptop",
                        "quantity": 25,
                        "unit_price": 899.99,
                        "total_price": 22499.75
                    },
                    {
                        "name": "Laptop Cases",
                        "quantity": 25,
                        "unit_price": 29.99,
                        "total_price": 749.75
                    }
                ],
                "subtotal": 23249.50,
                "tax_amount": 1859.96,
                "total_amount": 25109.46,
                "status": "approved",
                "created_by": user_ids["administrator"],
                "approved_by": user_ids["administrator"],
                "approved_date": datetime(2024, 3, 5),
                "delivery_date": datetime(2024, 3, 15),
                "notes": "Urgent order for training program launch",
                "created_at": datetime.now(timezone.utc) - timedelta(days=10)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "vendor_id": vendor_ids[1],
                "vendor_name": "Learning Materials Plus",
                "description": "Training Materials and Supplies",
                "order_number": "PO-2024-002",
                "items": [
                    {
                        "name": "Digital Literacy Workbooks",
                        "quantity": 100,
                        "unit_price": 24.95,
                        "total_price": 2495.00
                    },
                    {
                        "name": "USB Flash Drives (16GB)",
                        "quantity": 50,
                        "unit_price": 12.99,
                        "total_price": 649.50
                    }
                ],
                "subtotal": 3144.50,
                "tax_amount": 251.56,
                "total_amount": 3396.06,
                "status": "pending",
                "created_by": user_ids["social_actor"],
                "delivery_date": datetime(2024, 4, 1),
                "notes": "Supplementary materials for training sessions",
                "created_at": datetime.now(timezone.utc) - timedelta(days=5)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "vendor_id": vendor_ids[2],
                "vendor_name": "Digital Training Experts",
                "description": "Advanced Training Services Contract",
                "order_number": "PO-2024-003",
                "items": [
                    {
                        "name": "Digital Literacy Curriculum Development",
                        "quantity": 1,
                        "unit_price": 15000.00,
                        "total_price": 15000.00
                    },
                    {
                        "name": "Train-the-Trainer Sessions",
                        "quantity": 8,
                        "unit_price": 750.00,
                        "total_price": 6000.00
                    }
                ],
                "subtotal": 21000.00,
                "tax_amount": 1680.00,
                "total_amount": 22680.00,
                "status": "approved",
                "created_by": user_ids["administrator"],
                "approved_by": user_ids["investor"],
                "approved_date": datetime(2024, 2, 28),
                "delivery_date": datetime(2024, 5, 30),
                "notes": "Professional services for enhanced training delivery",
                "created_at": datetime.now(timezone.utc) - timedelta(days=15)
            }
        ]
        
        po_ids = []
        for order in sample_purchase_orders:
            po_ids.append(order["id"])
            await db.purchase_orders.insert_one(order)
        
        # Sample Contracts
        sample_contracts = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "vendor_id": vendor_ids[0],
                "vendor_name": "Community Technology Solutions",
                "title": "Technology Equipment Supply Agreement",
                "contract_number": "CT-2024-001",
                "contract_type": "supply_agreement",
                "value": 150000.00,
                "currency": "USD",
                "start_date": datetime(2024, 3, 1).isoformat(),
                "end_date": datetime(2024, 12, 31).isoformat(),
                "payment_terms": "NET 30",
                "deliverables": [
                    "25 Dell Latitude Laptops with specifications",
                    "Technical support for 12 months",
                    "On-site installation and setup",
                    "Training for technical staff"
                ],
                "terms_conditions": "Standard procurement terms apply. All equipment must meet specified technical requirements. Warranty period is 3 years from delivery date.",
                "status": "active",
                "created_by": user_ids["administrator"],
                "reviewed_by": user_ids["investor"],
                "created_at": datetime.now(timezone.utc) - timedelta(days=12)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "vendor_id": vendor_ids[2],
                "vendor_name": "Digital Training Experts",
                "title": "Professional Training Services Contract",
                "contract_number": "CT-2024-002",
                "contract_type": "service_agreement",
                "value": 45000.00,
                "currency": "USD",
                "start_date": datetime(2024, 3, 15).isoformat(),
                "end_date": datetime(2024, 6, 30).isoformat(),
                "payment_terms": "Milestone-based payments",
                "deliverables": [
                    "Custom digital literacy curriculum",
                    "8 train-the-trainer sessions",
                    "Training materials and resources",
                    "Performance assessment tools"
                ],
                "terms_conditions": "Payment upon milestone completion. Intellectual property rights retained by contractor with usage rights granted to project.",
                "status": "active",
                "created_by": user_ids["administrator"],
                "reviewed_by": user_ids["investor"],
                "created_at": datetime.now(timezone.utc) - timedelta(days=8)
            }
        ]
        
        for contract in sample_contracts:
            await db.contracts.insert_one(contract)
    
        # Sample SROI Calculations Data
        sample_sroi_calculations = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "total_investment": 180000,
                "total_social_value": 750000,
                "sroi_ratio": 4.17,
                "calculation_date": datetime.now(timezone.utc).isoformat(),
                "inputs": [
                    {"type": "Financial Investment", "amount": 150000, "description": "Primary funding"},
                    {"type": "In-kind Support", "amount": 30000, "description": "Equipment and facilities"}
                ],
                "outputs": [
                    {"type": "Training Sessions", "quantity": 48, "description": "Digital literacy workshops conducted"},
                    {"type": "Participants Trained", "quantity": 1250, "description": "Community members completed training"},
                    {"type": "Devices Distributed", "quantity": 300, "description": "Tablets and laptops provided"}
                ],
                "outcomes": [
                    {"type": "Improved Digital Skills", "value": 400000, "description": "Enhanced earning potential"},
                    {"type": "Job Placements", "value": 250000, "description": "New employment opportunities"},
                    {"type": "Business Growth", "value": 100000, "description": "Local business digital adoption"}
                ],
                "impacts": [
                    {"type": "Long-term Economic Growth", "value": 500000, "description": "Sustained community development"},
                    {"type": "Social Inclusion", "value": 150000, "description": "Reduced digital divide"},
                    {"type": "Innovation Capacity", "value": 100000, "description": "Enhanced local innovation"}
                ],
                "assumptions": [
                    "Skills acquired will be utilized for economic benefit",
                    "Job market demand for digital skills will continue",
                    "Community engagement will remain high"
                ],
                "sensitivity_analysis": {
                    "optimistic": {"sroi_ratio": 5.2, "description": "Best case scenario"},
                    "realistic": {"sroi_ratio": 4.17, "description": "Expected outcome"},
                    "pessimistic": {"sroi_ratio": 3.1, "description": "Conservative estimate"}
                },
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
        ]
        
        for sroi in sample_sroi_calculations:
            await db.sroi_calculations.insert_one(sroi)
        
        # Sample Theory of Change Data
        sample_theory_of_change = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "vision": "Empowered rural communities with comprehensive digital literacy skills contributing to sustainable economic development and reduced inequality.",
                "long_term_goals": [
                    "Reduce digital divide in rural areas by 70%",
                    "Increase household income by 30% through digital skills",
                    "Create sustainable digital ecosystem in rural communities"
                ],
                "intermediate_outcomes": [
                    "1,500 community members gain advanced digital skills",
                    "200 new digital economy jobs created",
                    "50 local businesses adopt digital technologies"
                ],
                "immediate_outcomes": [
                    "1,250 participants complete basic digital literacy training",
                    "300 participants receive device access",
                    "80% participant satisfaction rate achieved"
                ],
                "outputs": [
                    "48 training sessions delivered",
                    "Training materials developed in local language",
                    "300 devices distributed with technical support",
                    "Community digital hub established"
                ],
                "activities": [
                    "Conduct community needs assessment",
                    "Develop culturally appropriate training curriculum",
                    "Train local facilitators",
                    "Deliver progressive training modules",
                    "Provide ongoing technical support",
                    "Establish partnerships with local businesses"
                ],
                "inputs": [
                    "Funding: $180,000",
                    "Expert trainers and facilitators",
                    "Training materials and equipment",
                    "Community partnerships",
                    "Government support and permits"
                ],
                "assumptions": [
                    "Community members are motivated to learn digital skills",
                    "Local infrastructure supports digital connectivity",
                    "Economic opportunities exist for newly skilled individuals",
                    "Government policies support digital inclusion initiatives"
                ],
                "risk_factors": [
                    "Limited internet connectivity in remote areas",
                    "Resistance to technology adoption among older participants",
                    "Competition from urban job markets",
                    "Economic downturns affecting job creation"
                ],
                "indicators": [
                    "Number of participants completing training programs",
                    "Employment rate of training graduates",
                    "Income increase of participating households",
                    "Number of businesses adopting digital technologies",
                    "Community digital infrastructure development"
                ],
                "evidence_requirements": [
                    "Pre/post training assessments",
                    "Employment tracking surveys",
                    "Household income data",
                    "Business adoption case studies",
                    "Infrastructure development reports"
                ],
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
        ]
        
        for toc in sample_theory_of_change:
            await db.theory_of_change.insert_one(toc)
        
        # Sample Team Members Data
        sample_team_members = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "first_name": "Maria",
                "last_name": "Rodriguez",
                "position": "Project Manager",
                "email": "maria.rodriguez@communitytech.org",
                "phone": "+1-555-0123",
                "department": "Project Management",
                "bio": "Experienced project manager with 8+ years in social investment projects. Specialized in community development and digital literacy initiatives.",
                "start_date": "2024-01-15T00:00:00.000Z",
                "skills": ["Project Management", "Community Engagement", "Digital Literacy Training", "Stakeholder Management"],
                "responsibilities": ["Overall project coordination", "Stakeholder communication", "Progress monitoring", "Quality assurance"],
                "is_active": True,
                "added_by": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "first_name": "Ahmed",
                "last_name": "Hassan",
                "position": "Lead Trainer",
                "email": "ahmed.hassan@digitalskills.org",
                "phone": "+1-555-0124",
                "department": "Training & Development",
                "bio": "Digital skills expert with extensive experience in rural community training. Fluent in local languages and culturally sensitive training approaches.",
                "start_date": "2024-02-01T00:00:00.000Z",
                "skills": ["Digital Training", "Curriculum Development", "Adult Education", "Cross-cultural Communication"],
                "responsibilities": ["Training curriculum design", "Facilitator training", "Workshop delivery", "Participant assessment"],
                "is_active": True,
                "added_by": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "first_name": "Priya",
                "last_name": "Patel",
                "position": "Community Liaison",
                "email": "priya.patel@localpartners.org",
                "phone": "+1-555-0125",
                "department": "Community Relations",
                "bio": "Local community leader with deep understanding of regional needs and cultural dynamics. Acts as bridge between project team and community members.",
                "start_date": "2024-01-20T00:00:00.000Z",
                "skills": ["Community Engagement", "Local Language Fluency", "Cultural Mediation", "Outreach Coordination"],
                "responsibilities": ["Community outreach", "Participant recruitment", "Cultural guidance", "Local partnership development"],
                "is_active": True,
                "added_by": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "first_name": "David",
                "last_name": "Chen",
                "position": "Technical Coordinator",
                "email": "david.chen@techsupport.org",
                "phone": "+1-555-0126",
                "department": "Technical Support",
                "bio": "IT specialist responsible for technical infrastructure, device management, and ongoing technical support for participants.",
                "start_date": "2024-01-25T00:00:00.000Z",
                "skills": ["IT Support", "Device Management", "Network Setup", "Technical Training"],
                "responsibilities": ["Equipment setup and maintenance", "Technical troubleshooting", "Infrastructure management", "Technical support training"],
                "is_active": True,
                "added_by": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "first_name": "Sarah",
                "last_name": "Thompson",
                "position": "Monitoring & Evaluation Specialist",
                "email": "sarah.thompson@evaluation.org",
                "phone": "+1-555-0127",
                "department": "M&E",
                "bio": "Data analyst and evaluation expert focused on measuring project impact, tracking progress, and ensuring quality outcomes.",
                "start_date": "2024-02-15T00:00:00.000Z",
                "skills": ["Data Analysis", "Impact Measurement", "Survey Design", "Report Writing"],
                "responsibilities": ["Impact assessment", "Data collection", "Progress reporting", "Quality monitoring"],
                "is_active": True,
                "added_by": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat()
            }
        ]
        
        for member in sample_team_members:
            await db.team_members.insert_one(member)
        
        # Sample Digital Checklists Data
        sample_digital_checklists = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Laptop Setup and Configuration",
                "description": "Checklist for setting up and configuring laptops for digital literacy training",
                "template_type": "equipment_installation",
                "deliverable_id": str(uuid.uuid4()),
                "items": [
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Unpack laptops and check for physical damage",
                        "required": True,
                        "completed": True,
                        "completed_by": user_ids["administrator"],
                        "completed_at": datetime.now(timezone.utc) - timedelta(days=3),
                        "comments": "All 25 laptops received in good condition"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Install operating system and updates",
                        "required": True,
                        "completed": True,
                        "completed_by": user_ids["administrator"],
                        "completed_at": datetime.now(timezone.utc) - timedelta(days=2),
                        "comments": "Windows 11 installed with latest updates"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Install educational software packages",
                        "required": True,
                        "completed": True,
                        "completed_by": user_ids["administrator"],
                        "completed_at": datetime.now(timezone.utc) - timedelta(days=1),
                        "comments": "Microsoft Office, educational games, and basic programming tools installed"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Configure user accounts and permissions",
                        "required": True,
                        "completed": False,
                        "comments": "In progress - creating standard user accounts"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Test all hardware components",
                        "required": True,
                        "completed": False,
                        "comments": "Pending - will test after account setup"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Create user manual and quick reference",
                        "required": False,
                        "completed": False,
                        "comments": "Optional - will create based on user feedback"
                    }
                ],
                "status": "in_progress",
                "completion_percentage": 50,
                "created_by": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc) - timedelta(days=5),
                "updated_at": datetime.now(timezone.utc) - timedelta(hours=6)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Community Outreach Training Session",
                "description": "Pre-delivery checklist for community training sessions",
                "template_type": "training_delivery",
                "deliverable_id": str(uuid.uuid4()),
                "items": [
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Prepare training materials and handouts",
                        "required": True,
                        "completed": True,
                        "completed_by": user_ids["social_actor"],
                        "completed_at": datetime.now(timezone.utc) - timedelta(days=7),
                        "comments": "Materials prepared in local language with visual aids"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Reserve and set up training venue",
                        "required": True,
                        "completed": True,
                        "completed_by": user_ids["social_actor"],
                        "completed_at": datetime.now(timezone.utc) - timedelta(days=5),
                        "comments": "Community center booked, tables and chairs arranged"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Confirm participant attendance",
                        "required": True,
                        "completed": True,
                        "completed_by": user_ids["social_actor"],
                        "completed_at": datetime.now(timezone.utc) - timedelta(days=2),
                        "comments": "18 participants confirmed out of 20 invited"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Conduct training session",
                        "required": True,
                        "completed": True,
                        "completed_by": user_ids["social_actor"],
                        "completed_at": datetime.now(timezone.utc) - timedelta(days=1),
                        "comments": "Successfully delivered 4-hour training session"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Collect participant feedback forms",
                        "required": True,
                        "completed": True,
                        "completed_by": user_ids["social_actor"],
                        "completed_at": datetime.now(timezone.utc) - timedelta(days=1),
                        "comments": "Received feedback from all 18 participants - very positive"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Document training completion and outcomes",
                        "required": True,
                        "completed": False,
                        "comments": "Pending - preparing final report"
                    }
                ],
                "status": "active",
                "completion_percentage": 83,
                "created_by": user_ids["social_actor"],
                "created_at": datetime.now(timezone.utc) - timedelta(days=10),
                "updated_at": datetime.now(timezone.utc) - timedelta(hours=2)
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Project Quality Assurance Review",
                "description": "Quality assurance checklist for project milestone review",
                "template_type": "quality_assurance",
                "deliverable_id": str(uuid.uuid4()),
                "items": [
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Review all deliverables against project requirements",
                        "required": True,
                        "completed": True,
                        "completed_by": user_ids["administrator"],
                        "completed_at": datetime.now(timezone.utc) - timedelta(days=3),
                        "comments": "All major deliverables meet requirements"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Verify compliance with quality standards",
                        "required": True,
                        "completed": True,
                        "completed_by": user_ids["administrator"],
                        "completed_at": datetime.now(timezone.utc) - timedelta(days=2),
                        "comments": "ISO 9001 compliance verified"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Check documentation completeness",
                        "required": True,
                        "completed": False,
                        "comments": "Some technical documentation still pending"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Review beneficiary feedback and satisfaction",
                        "required": True,
                        "completed": False,
                        "comments": "Collecting final feedback surveys"
                    },
                    {
                        "id": str(uuid.uuid4()),
                        "text": "Prepare quality assessment report",
                        "required": True,
                        "completed": False,
                        "comments": "In progress - compiling findings"
                    }
                ],
                "status": "active",
                "completion_percentage": 40,
                "created_by": user_ids["administrator"],
                "created_at": datetime.now(timezone.utc) - timedelta(days=14),
                "updated_at": datetime.now(timezone.utc) - timedelta(hours=4)
            }
        ]
        
        for checklist in sample_digital_checklists:
            await db.digital_checklists.insert_one(checklist)
        
        # Sample Document Evidence Data
        sample_document_evidence = [
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Laptop Delivery Confirmation Photos",
                "description": "Visual evidence of laptop delivery to community center with signed receipt",
                "category": "photos_videos",
                "phase": "equipment_delivery",
                "activity": "laptop_distribution",
                "tags": ["delivery", "equipment", "receipt", "community_center"],
                "file_type": "image/jpeg",
                "file_size": 2457600,  # 2.4MB
                "file_path": "/uploads/evidence/laptop_delivery_photos.jpg",
                "thumbnail_path": "/uploads/evidence/thumbnails/laptop_delivery_photos_thumb.jpg",
                "metadata": {
                    "location_data": {
                        "latitude": 34.0522,
                        "longitude": -118.2437,
                        "accuracy": 5.0,
                        "address": "Community Center, Downtown District"
                    },
                    "device_info": "iPhone 14 Pro",
                    "camera_settings": {
                        "resolution": "4032x3024",
                        "timestamp": datetime.now(timezone.utc) - timedelta(days=5)
                    }
                },
                "uploaded_by": user_ids["social_actor"],
                "uploaded_at": datetime.now(timezone.utc) - timedelta(days=5),
                "created_at": datetime.now(timezone.utc) - timedelta(days=5),
                "updated_at": datetime.now(timezone.utc) - timedelta(days=5),
                "status": "uploaded",
                "verification_status": "verified",
                "access_level": "project_team"
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Training Materials Purchase Invoice",
                "description": "Invoice for educational software licenses and training materials",
                "category": "invoices",
                "phase": "procurement",
                "activity": "materials_purchase",
                "tags": ["invoice", "training_materials", "software_licenses", "procurement"],
                "file_type": "application/pdf",
                "file_size": 892416,  # 872KB
                "file_path": "/uploads/evidence/training_materials_invoice.pdf",
                "thumbnail_path": "/uploads/evidence/thumbnails/training_materials_invoice_thumb.png",
                "metadata": {
                    "location_data": None,
                    "device_info": "Scanner Pro App",
                    "camera_settings": None
                },
                "uploaded_by": user_ids["administrator"],
                "uploaded_at": datetime.now(timezone.utc) - timedelta(days=10),
                "created_at": datetime.now(timezone.utc) - timedelta(days=10),
                "updated_at": datetime.now(timezone.utc) - timedelta(days=8),
                "status": "uploaded",
                "verification_status": "verified",
                "access_level": "project_team"
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Community Training Session Video",
                "description": "Video documentation of digital literacy training session with participants",
                "category": "photos_videos",
                "phase": "training_delivery",
                "activity": "training_session",
                "tags": ["video", "training", "participants", "digital_literacy"],
                "file_type": "video/mp4",
                "file_size": 157286400,  # 150MB
                "file_path": "/uploads/evidence/training_session_video.mp4",
                "thumbnail_path": "/uploads/evidence/thumbnails/training_session_video_thumb.jpg",
                "metadata": {
                    "location_data": {
                        "latitude": 34.0522,
                        "longitude": -118.2437,
                        "accuracy": 3.0,
                        "address": "Community Center, Training Room A"
                    },
                    "device_info": "Canon EOS R5",
                    "camera_settings": {
                        "resolution": "1920x1080",
                        "duration": "45 minutes",
                        "framerate": "30fps"
                    }
                },
                "uploaded_by": user_ids["social_actor"],
                "uploaded_at": datetime.now(timezone.utc) - timedelta(days=3),
                "created_at": datetime.now(timezone.utc) - timedelta(days=3),
                "updated_at": datetime.now(timezone.utc) - timedelta(days=3),
                "status": "uploaded",
                "verification_status": "pending",
                "access_level": "project_team"
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Equipment Installation Permit",
                "description": "Official permit for installing IT equipment at community center",
                "category": "permits",
                "phase": "setup_preparation",
                "activity": "permit_acquisition",
                "tags": ["permit", "installation", "official", "government"],
                "file_type": "application/pdf",
                "file_size": 524288,  # 512KB
                "file_path": "/uploads/evidence/installation_permit.pdf",
                "thumbnail_path": "/uploads/evidence/thumbnails/installation_permit_thumb.png",
                "metadata": {
                    "location_data": None,
                    "device_info": "Government Portal Download",
                    "camera_settings": None
                },
                "uploaded_by": user_ids["administrator"],
                "uploaded_at": datetime.now(timezone.utc) - timedelta(days=15),
                "created_at": datetime.now(timezone.utc) - timedelta(days=15),
                "updated_at": datetime.now(timezone.utc) - timedelta(days=15),
                "status": "uploaded",
                "verification_status": "verified",
                "access_level": "project_team"
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "Participant Completion Certificates",
                "description": "Digital literacy completion certificates for training participants",
                "category": "certificates",
                "phase": "training_completion",
                "activity": "certification",
                "tags": ["certificates", "completion", "participants", "achievement"],
                "file_type": "application/pdf",
                "file_size": 1048576,  # 1MB
                "file_path": "/uploads/evidence/completion_certificates.pdf",
                "thumbnail_path": "/uploads/evidence/thumbnails/completion_certificates_thumb.png",
                "metadata": {
                    "location_data": None,
                    "device_info": "Certificate Generator System",
                    "camera_settings": None
                },
                "uploaded_by": user_ids["social_actor"],
                "uploaded_at": datetime.now(timezone.utc) - timedelta(days=1),
                "created_at": datetime.now(timezone.utc) - timedelta(days=1),
                "updated_at": datetime.now(timezone.utc) - timedelta(days=1),
                "status": "uploaded",
                "verification_status": "pending",
                "access_level": "project_team"
            },
            {
                "id": str(uuid.uuid4()),
                "project_id": project_id,
                "title": "GPS Coordinates of Training Sites",
                "description": "Geospatial data for all training locations and community centers",
                "category": "gps_data",
                "phase": "site_mapping",
                "activity": "location_documentation", 
                "tags": ["gps", "coordinates", "locations", "mapping"],
                "file_type": "application/json",
                "file_size": 8192,  # 8KB
                "file_path": "/uploads/evidence/training_sites_gps.json",
                "thumbnail_path": None,
                "metadata": {
                    "location_data": {
                        "total_sites": 5,
                        "coordinate_system": "WGS84",
                        "accuracy_range": "3-5 meters"
                    },
                    "device_info": "GPS Survey App",
                    "camera_settings": None
                },
                "uploaded_by": user_ids["administrator"],
                "uploaded_at": datetime.now(timezone.utc) - timedelta(days=20),
                "created_at": datetime.now(timezone.utc) - timedelta(days=20),
                "updated_at": datetime.now(timezone.utc) - timedelta(days=20),
                "status": "uploaded",
                "verification_status": "verified",
                "access_level": "project_team"
            }
        ]
        
        for document in sample_document_evidence:
            await db.document_evidence.insert_one(document)
        
        # Sample Financial Instruments & Supporting Materials Data
        sample_instruments = [
            # Financial Instruments
            {
                "id": str(uuid.uuid4()),
                "title": "Social Impact Bonds (SIB) Implementation Guide",
                "description": "Comprehensive guide for structuring and implementing Social Impact Bonds in social investment projects.",
                "detailed_description": "This detailed guide covers the complete lifecycle of Social Impact Bonds, from initial concept development through contract structuring, performance measurement, and outcome evaluation. It includes legal frameworks, contract templates, risk assessment methodologies, and real-world case studies from successful SIB implementations across different sectors. The guide provides step-by-step instructions for investors, service providers, and government commissioners looking to utilize outcome-based financing mechanisms.",
                "category": "financial_instruments",
                "subcategory": "bonds",
                "content_type": "financial_instrument",
                "file_format": "pdf",
                "file_path": "/instruments/sib_implementation_guide.pdf",
                "file_size": 3457600,  # 3.4MB
                "thumbnail_path": "/instruments/thumbnails/sib_guide_thumb.jpg",
                
                # Standardized coding system (Missing feature implementation)
                "standardized_code": "FIN-SIB-001",  # Financial Instrument - Social Impact Bond - 001
                "instrument_classification": {
                    "primary_code": "FIN",  # Financial Instrument
                    "secondary_code": "SIB",  # Social Impact Bond
                    "sequence_number": "001",
                    "version": "2.1"
                },
                "classification_tags": ["outcome-based", "performance-linked", "government-commissioned"],
                
                # Enhanced metadata for modern library features
                "full_text_content": "Social Impact Bonds represent innovative financing mechanisms outcome-based payments performance measurement evaluation...",
                "extracted_text": "This is simulated extracted text from the PDF document for full-text search capabilities...",
                "document_structure": {
                    "total_pages": 85,
                    "chapters": ["Introduction", "SIB Structure", "Implementation", "Measurement", "Case Studies"],
                    "has_appendices": True,
                    "has_glossary": True
                },
                
                "language": "en",
                "is_greek_content": False,
                "tags": ["social_impact_bonds", "outcome_based_financing", "pay_for_success", "investment"],
                "keywords": ["SIB", "impact_bonds", "outcome_payment", "social_finance"],
                "authors": ["Dr. Sarah Mitchell", "Prof. James Chen"],
                "publication_date": "2024-03-15",
                "publisher": "Social Finance Institute",
                "isbn_doi": "978-0-123456-78-9",
                "legal_framework": "UK Social Investment and Finance Act 2012",
                "jurisdiction": "UK, applicable internationally",
                "contract_templates": ["sib_contract_template.docx", "outcome_metrics_framework.xlsx"],
                "nda_required": True,
                "usage_count": 45,
                "downloads": 128,
                "bookmarks": 23,
                "rating": 4.7,
                "view_count": 245,
                "created_by": user_ids["administrator"],
                "created_by_name": "System Administrator",
                "created_at": (datetime.now(timezone.utc) - timedelta(days=30)).isoformat(),
                "updated_at": (datetime.now(timezone.utc) - timedelta(days=5)).isoformat(),
                "status": "active",
                "version": "2.1",
                "metadata": {
                    "target_audience": ["intermediate", "advanced"],
                    "complexity_level": "high",
                    "estimated_reading_time": "45 minutes",
                    "prerequisites": ["basic_finance_knowledge", "social_investment_fundamentals"],
                    "related_instruments": ["development_impact_bonds", "outcome_funds"],
                    "sdg_alignment": [1, 3, 4, 16]  # No Poverty, Health, Education, Strong Institutions
                }
            },
            {
                "id": str(uuid.uuid4()),
                "title": "Blended Finance Mechanisms for Climate Adaptation",
                "description": "Detailed analysis of blended finance structures for climate adaptation projects in developing countries.",
                "detailed_description": "This comprehensive resource explores innovative blended finance mechanisms specifically designed for climate adaptation initiatives. It covers risk mitigation strategies, currency hedging, concessional finance structures, and the role of development finance institutions. The guide includes templates for investment agreements, due diligence checklists, and performance monitoring frameworks tailored for climate resilience projects. Real case studies from Africa, Asia, and Latin America demonstrate successful blended finance applications in water security, agricultural adaptation, and coastal protection projects.",
                "category": "financial_instruments",
                "subcategory": "blended_finance",
                "content_type": "financial_instrument",
                "file_format": "pdf",
                "file_path": "/instruments/blended_finance_climate.pdf",
                "file_size": 2856400,  # 2.8MB
                "thumbnail_path": "/instruments/thumbnails/blended_finance_thumb.jpg",
                "language": "en",
                "is_greek_content": False,
                "tags": ["blended_finance", "climate_adaptation", "development_finance", "risk_mitigation"],
                "keywords": ["climate_finance", "adaptation", "DFI", "concessional_finance"],
                "authors": ["Climate Finance Consortium"],
                "publication_date": "2024-01-20",
                "publisher": "Green Climate Fund",
                "isbn_doi": "10.1234/gcf.2024.bf.001",
                "legal_framework": "Paris Agreement Article 6, Green Climate Fund policies",
                "jurisdiction": "International",
                "contract_templates": ["blended_finance_term_sheet.docx", "climate_adaptation_mou.docx"],
                "nda_required": False,
                "usage_count": 32,
                "downloads": 89,
                "bookmarks": 15,
                "rating": 4.4,
                "view_count": 156,
                "created_by": user_ids["administrator"],
                "created_by_name": "System Administrator",
                "created_at": (datetime.now(timezone.utc) - timedelta(days=45)).isoformat(),
                "updated_at": (datetime.now(timezone.utc) - timedelta(days=10)).isoformat(),
                "status": "active",
                "version": "1.3",
                "metadata": {
                    "target_audience": ["advanced"],
                    "complexity_level": "high",
                    "estimated_reading_time": "60 minutes",
                    "prerequisites": ["climate_finance_basics", "blended_finance_fundamentals"],
                    "related_instruments": ["green_bonds", "climate_funds"],
                    "sdg_alignment": [13, 15, 17]  # Climate Action, Life on Land, Partnerships
                }
            },
            # Greek Bibliography
            {
                "id": str(uuid.uuid4()),
                "title": "Κοινωνικές Επενδύσεις στην Ελλάδα: Θεωρία και Πράξη",
                "description": "Ολοκληρωμένη μελέτη για τις κοινωνικές επενδύσεις στον ελληνικό χώρο και τα χρηματοδοτικά εργαλεία που χρησιμοποιούνται.",
                "detailed_description": "Αυτό το εκτενές βιβλίο εξετάζει το τοπίο των κοινωνικών επενδύσεων στην Ελλάδα, αναλύοντας τα διαθέσιμα χρηματοδοτικά εργαλεία, το νομικό πλαίσιο, και τις βέλτιστες πρακτικές. Περιλαμβάνει μελέτες περίπτωσης από επιτυχημένα έργα, ανάλυση της αγοράς, και προτάσεις για την ανάπτυξη του τομέα. Το βιβλίο απευθύνεται σε επενδυτές, κοινωνικούς επιχειρηματίες, και φορείς χάραξης πολιτικής.",
                "category": "bibliography",
                "subcategory": "greek_books",
                "content_type": "bibliography",
                "file_format": "pdf",
                "file_path": "/bibliography/greek_social_investment_book.pdf",
                "file_size": 4567890,  # 4.5MB
                "thumbnail_path": "/bibliography/thumbnails/greek_book_thumb.jpg",
                "language": "el",
                "is_greek_content": True,
                "tags": ["κοινωνικές_επενδύσεις", "ελληνικός_χώρος", "χρηματοδότηση", "κοινωνική_επιχειρηματικότητα"],
                "keywords": ["social_investment", "greece", "financing", "social_entrepreneurship"],
                "authors": ["Δρ. Μαρία Παπαδοπούλου", "Καθ. Νίκος Αντωνόπουλος"],
                "publication_date": "2023-11-15",
                "publisher": "Εκδόσεις Κοινωνικής Οικονομίας",
                "isbn_doi": "978-960-123-456-7",
                "usage_count": 28,
                "downloads": 67,
                "bookmarks": 12,
                "rating": 4.6,
                "view_count": 134,
                "created_by": user_ids["administrator"],
                "created_by_name": "System Administrator",
                "created_at": (datetime.now(timezone.utc) - timedelta(days=60)).isoformat(),
                "updated_at": (datetime.now(timezone.utc) - timedelta(days=15)).isoformat(),
                "status": "active",
                "version": "1.0",
                "metadata": {
                    "target_audience": ["intermediate", "advanced"],
                    "complexity_level": "medium",
                    "estimated_reading_time": "120 minutes",
                    "prerequisites": ["basic_greek", "social_finance_awareness"],
                    "related_instruments": ["greek_legal_framework", "eu_social_funds"],
                    "sdg_alignment": [8, 10, 17]  # Decent Work, Reduced Inequality, Partnerships
                }
            },
            # Scientific Publications
            {
                "id": str(uuid.uuid4()),
                "title": "The Impact of Microfinance on Women's Empowerment: A Meta-Analysis",
                "description": "Peer-reviewed meta-analysis examining the relationship between microfinance participation and women's empowerment outcomes.",
                "detailed_description": "This rigorous meta-analysis synthesizes findings from 127 peer-reviewed studies conducted between 2010-2023, examining the multifaceted impacts of microfinance on women's empowerment across different geographical regions and cultural contexts. The study employs advanced statistical techniques to analyze effect sizes across various empowerment dimensions including economic autonomy, decision-making power, social capital, and health outcomes. The research identifies key moderating factors and provides evidence-based recommendations for program design and policy implementation.",
                "category": "publications",
                "subcategory": "peer_reviewed",
                "content_type": "bibliography",
                "file_format": "pdf",
                "file_path": "/publications/microfinance_women_empowerment_meta.pdf",
                "file_size": 1245600,  # 1.2MB
                "thumbnail_path": "/publications/thumbnails/meta_analysis_thumb.jpg",
                "language": "en",
                "is_greek_content": False,
                "tags": ["microfinance", "women_empowerment", "meta_analysis", "gender", "financial_inclusion"],
                "keywords": ["microfinance", "empowerment", "women", "systematic_review"],
                "authors": ["Dr. Priya Sharma", "Prof. Lisa Chen", "Dr. Ahmed Hassan"],
                "publication_date": "2024-02-28",
                "publisher": "Journal of Development Economics",
                "journal_name": "Journal of Development Economics",
                "volume_issue": "Vol. 178, Issue 3",
                "isbn_doi": "10.1016/j.jdeveco.2024.103.421",
                "is_peer_reviewed": True,
                "citation_count": 23,
                "usage_count": 67,
                "downloads": 156,
                "bookmarks": 34,
                "rating": 4.8,
                "view_count": 298,
                "created_by": user_ids["administrator"],
                "created_by_name": "System Administrator",
                "created_at": (datetime.now(timezone.utc) - timedelta(days=25)).isoformat(),
                "updated_at": (datetime.now(timezone.utc) - timedelta(days=3)).isoformat(),
                "status": "active",
                "version": "1.0",
                "metadata": {
                    "target_audience": ["advanced"],
                    "complexity_level": "high",
                    "estimated_reading_time": "35 minutes",
                    "prerequisites": ["research_methodology", "statistics", "microfinance_fundamentals"],
                    "related_instruments": ["microfinance_programs", "gender_impact_assessment"],
                    "sdg_alignment": [1, 5, 8, 10]  # No Poverty, Gender Equality, Decent Work, Reduced Inequality
                }
            },
            # Supporting Materials - Legal Framework
            {
                "id": str(uuid.uuid4()),
                "title": "EU Social Investment Package: Legal Framework and Implementation Guidelines",
                "description": "Comprehensive legal framework documentation for EU social investment regulations and implementation procedures.",
                "detailed_description": "This comprehensive legal resource provides detailed analysis of the European Union's Social Investment Package, including all relevant regulations, directives, and implementation guidelines. It covers state aid rules for social services, public procurement procedures for social innovation, and regulatory frameworks for social impact measurement. The document includes practical implementation templates, compliance checklists, and country-specific adaptation guidelines for member states.",
                "category": "supporting_materials",
                "subcategory": "legal_framework",
                "content_type": "supporting_material",
                "file_format": "pdf",
                "file_path": "/supporting/eu_social_investment_legal_framework.pdf",
                "file_size": 5678901,  # 5.6MB
                "thumbnail_path": "/supporting/thumbnails/eu_legal_thumb.jpg",
                "language": "en",
                "is_greek_content": False,
                "tags": ["eu_regulation", "legal_framework", "social_investment", "compliance", "state_aid"],
                "keywords": ["european_union", "regulation", "social_services", "procurement"],
                "authors": ["European Commission DG EMPL"],
                "publication_date": "2024-01-10",
                "publisher": "European Commission",
                "legal_framework": "EU Social Investment Package 2013, updated 2024",
                "jurisdiction": "European Union",
                "contract_templates": ["eu_social_service_contract.docx", "state_aid_application.xlsx"],
                "nda_required": False,
                "usage_count": 89,
                "downloads": 234,
                "bookmarks": 45,
                "rating": 4.5,
                "view_count": 456,
                "created_by": user_ids["administrator"],
                "created_by_name": "System Administrator",
                "created_at": (datetime.now(timezone.utc) - timedelta(days=40)).isoformat(),
                "updated_at": (datetime.now(timezone.utc) - timedelta(days=7)).isoformat(),
                "status": "active",
                "version": "3.2",
                "metadata": {
                    "target_audience": ["intermediate", "advanced"],
                    "complexity_level": "high",
                    "estimated_reading_time": "90 minutes",
                    "prerequisites": ["eu_law_basics", "social_investment_knowledge"],
                    "related_instruments": ["eu_structural_funds", "esif_programs"],
                    "sdg_alignment": [16, 17]  # Strong Institutions, Partnerships
                }
            },
            # Multimedia Content - Video Tutorial
            {
                "id": str(uuid.uuid4()),
                "title": "Impact Measurement in Social Investment Projects - Video Tutorial Series",
                "description": "Comprehensive video tutorial series on impact measurement methodologies for social investment projects.",
                "detailed_description": "This professional video tutorial series consists of 12 modules covering all aspects of impact measurement in social investment projects. Topics include Theory of Change development, indicator selection, data collection methodologies, statistical analysis techniques, and reporting frameworks. Each module includes practical exercises, real-world examples, and downloadable templates. The series features expert interviews with practitioners from leading social investment organizations and academic institutions.",
                "category": "multimedia",
                "subcategory": "video_tutorials",
                "content_type": "supporting_material",
                "file_format": "wmv",
                "file_path": "/multimedia/impact_measurement_tutorial_series.wmv",
                "file_size": 2567890123,  # 2.5GB
                "thumbnail_path": "/multimedia/thumbnails/video_tutorial_thumb.jpg",
                "language": "en",
                "is_greek_content": False,
                "tags": ["impact_measurement", "video_tutorial", "social_investment", "methodology", "evaluation"],
                "keywords": ["impact", "measurement", "evaluation", "methodology"],
                "authors": ["Social Impact Academy"],
                "publication_date": "2024-03-01",
                "publisher": "Social Impact Academy",
                "usage_count": 156,
                "downloads": 89,
                "bookmarks": 67,
                "rating": 4.9,
                "view_count": 789,
                "created_by": user_ids["administrator"],
                "created_by_name": "System Administrator",
                "created_at": (datetime.now(timezone.utc) - timedelta(days=20)).isoformat(),
                "updated_at": (datetime.now(timezone.utc) - timedelta(days=2)).isoformat(),
                "status": "active",
                "version": "1.0",
                "metadata": {
                    "target_audience": ["beginner", "intermediate"],
                    "complexity_level": "medium",
                    "estimated_reading_time": "180 minutes",
                    "prerequisites": ["basic_social_investment_knowledge"],
                    "related_instruments": ["impact_measurement_tools", "evaluation_frameworks"],
                    "sdg_alignment": [17]  # Partnerships for the Goals
                }
            }
        ]
        
        for instrument in sample_instruments:
            await db.template_library.insert_one(instrument)
        
        # Sample Discussion Threads Data (Phase 2)
        sample_discussions = [
            {
                "id": str(uuid.uuid4()),
                "instrument_id": sample_instruments[0]["id"],  # SIB Implementation Guide
                "title": "Implementation challenges in rural communities",
                "title_el": "Προκλήσεις υλοποίησης σε αγροτικές κοινότητες",
                "content": "Has anyone successfully implemented Social Impact Bonds in rural or remote communities? What were the main challenges regarding outcome measurement and payment mechanisms?",
                "content_el": "Έχει κανείς υλοποιήσει επιτυχώς Ομόλογα Κοινωνικού Αντικτύπου σε αγροτικές ή απομακρυσμένες κοινότητες; Ποιες ήταν οι κύριες προκλήσεις όσον αφορά τη μέτρηση αποτελεσμάτων και τους μηχανισμούς πληρωμής;",
                "language": "multilingual",
                "author_id": user_ids["investor"],
                "author_name": "investor_user",
                "author_role": "investor",
                "is_pinned": False,
                "is_locked": False,
                "tags": ["implementation", "rural", "challenges", "outcome_measurement"],
                "replies_count": 3,
                "views_count": 45,
                "likes_count": 8,
                "status": "active",
                "moderation_status": "approved",
                "created_at": (datetime.now(timezone.utc) - timedelta(days=5)).isoformat(),
                "updated_at": (datetime.now(timezone.utc) - timedelta(days=2)).isoformat(),
                "last_activity": (datetime.now(timezone.utc) - timedelta(days=1)).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "instrument_id": sample_instruments[2]["id"],  # Greek book
                "title": "Ελληνική νομοθεσία για κοινωνικές επενδύσεις",
                "title_el": "Ελληνική νομοθεσία για κοινωνικές επενδύσεις",
                "content": "Μπορεί κάποιος να παράσχει ενημέρωση για τις πρόσφατες αλλαγές στο ελληνικό νομικό πλαίσιο για τις κοινωνικές επενδύσεις;",
                "content_el": "Μπορεί κάποιος να παράσχει ενημέρωση για τις πρόσφατες αλλαγές στο ελληνικό νομικό πλαίσιο για τις κοινωνικές επενδύσεις;",
                "language": "el",
                "author_id": user_ids["social_actor"],
                "author_name": "social_actor_user",
                "author_role": "social_actor",
                "is_pinned": True,
                "is_locked": False,
                "tags": ["ελληνική_νομοθεσία", "κοινωνικές_επενδύσεις", "νομικό_πλαίσιο"],
                "replies_count": 7,
                "views_count": 123,
                "likes_count": 15,
                "status": "active",
                "moderation_status": "approved",
                "created_at": (datetime.now(timezone.utc) - timedelta(days=12)).isoformat(),
                "updated_at": (datetime.now(timezone.utc) - timedelta(days=1)).isoformat(),
                "last_activity": (datetime.now(timezone.utc) - timedelta(hours=6)).isoformat()
            }
        ]
        
        for discussion in sample_discussions:
            await db.discussion_threads.insert_one(discussion)
        
        # Sample Discussion Replies
        sample_replies = [
            {
                "id": str(uuid.uuid4()),
                "thread_id": sample_discussions[0]["id"],
                "parent_reply_id": None,
                "content": "I've worked on two rural SIB projects in Scotland. The key challenge is establishing reliable baseline data collection systems. Local capacity building for outcome measurement is crucial.",
                "content_el": "",
                "language": "en",
                "author_id": user_ids["administrator"],
                "author_name": "System Administrator",
                "author_role": "administrator",
                "likes_count": 5,
                "is_solution": True,
                "status": "active",
                "moderation_status": "approved",
                "created_at": (datetime.now(timezone.utc) - timedelta(days=2)).isoformat(),
                "updated_at": (datetime.now(timezone.utc) - timedelta(days=2)).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "thread_id": sample_discussions[1]["id"],
                "parent_reply_id": None,
                "content": "Το νέο νομοσχέδιο 4873/2021 εισάγει σημαντικές αλλαγές στη φορολογική μεταχείριση των κοινωνικών επιχειρήσεων.",
                "content_el": "Το νέο νομοσχέδιο 4873/2021 εισάγει σημαντικές αλλαγές στη φορολογική μεταχείριση των κοινωνικών επιχειρήσεων.",
                "language": "el",
                "author_id": user_ids["administrator"],
                "author_name": "System Administrator",
                "author_role": "administrator",
                "likes_count": 12,
                "is_solution": False,
                "status": "active",
                "moderation_status": "approved",
                "created_at": (datetime.now(timezone.utc) - timedelta(days=1)).isoformat(),
                "updated_at": (datetime.now(timezone.utc) - timedelta(days=1)).isoformat()
            }
        ]
        
        for reply in sample_replies:
            await db.discussion_replies.insert_one(reply)
        
        # Sample User Collections (Phase 3)
        sample_collections = [
            {
                "id": str(uuid.uuid4()),
                "user_id": user_ids["administrator"],
                "name": "Essential SIB Resources",
                "name_el": "Βασικοί Πόροι για SIB",
                "description": "Essential reading materials for Social Impact Bond implementation",
                "description_el": "Βασική βιβλιογραφία για την υλοποίηση Ομολόγων Κοινωνικού Αντικτύπου",
                "instrument_ids": [sample_instruments[0]["id"], sample_instruments[4]["id"]],  # SIB Guide + EU Legal Framework
                "is_public": True,
                "tags": ["sib", "implementation", "legal"],
                "created_at": (datetime.now(timezone.utc) - timedelta(days=20)).isoformat(),
                "updated_at": (datetime.now(timezone.utc) - timedelta(days=5)).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "user_id": user_ids["investor"],
                "name": "My Reading List",
                "name_el": "Η Λίστα Ανάγνωσής Μου",
                "description": "Personal collection of interesting financial instruments and research papers",
                "description_el": "Προσωπική συλλογή ενδιαφερόντων χρηματοδοτικών εργαλείων και ερευνητικών εργασιών",
                "instrument_ids": [sample_instruments[1]["id"], sample_instruments[3]["id"], sample_instruments[5]["id"]],
                "is_public": False,
                "tags": ["personal", "research", "learning"],
                "created_at": (datetime.now(timezone.utc) - timedelta(days=15)).isoformat(),
                "updated_at": (datetime.now(timezone.utc) - timedelta(days=3)).isoformat()
            }
        ]
        
        for collection in sample_collections:
            await db.user_collections.insert_one(collection)
        
        # Sample User Activities (for analytics)
        sample_activities = []
        activity_types = ["view", "download", "bookmark", "search", "discussion_created", "collection_created"]
        
        for i in range(50):  # Generate 50 sample activities
            activity = {
                "id": str(uuid.uuid4()),
                "user_id": random.choice(list(user_ids.values())),
                "activity_type": random.choice(activity_types),
                "metadata": {
                    "instrument_id": random.choice([inst["id"] for inst in sample_instruments]),
                    "timestamp": (datetime.now(timezone.utc) - timedelta(days=random.randint(1, 30))).isoformat()
                },
                "timestamp": (datetime.now(timezone.utc) - timedelta(days=random.randint(1, 30), hours=random.randint(0, 23))).isoformat(),
                "session_id": str(uuid.uuid4())
            }
            sample_activities.append(activity)
        
        for activity in sample_activities:
            await db.user_activities.insert_one(activity)
        
        # Sample Search History
        sample_searches = [
            {
                "id": str(uuid.uuid4()),
                "user_id": user_ids["investor"],
                "query": "social impact bonds implementation",
                "filters": {"category": "financial_instruments", "complexity_level": "high"},
                "results_count": 3,
                "timestamp": (datetime.now(timezone.utc) - timedelta(days=2)).isoformat()
            },
            {
                "id": str(uuid.uuid4()),
                "user_id": user_ids["social_actor"],
                "query": "ελληνική νομοθεσία",
                "filters": {"language": "el", "category": "supporting_materials"},
                "results_count": 2,
                "timestamp": (datetime.now(timezone.utc) - timedelta(days=5)).isoformat()
            }
        ]
        
        for search in sample_searches:
            await db.search_history.insert_one(search)
        
        # Sample SDGs Alignment Data (already included in the API default)
        
        # Sample ESG Indicators Data (already included in the API default)
    
    return {"message": "Enhanced sample data initialized with Video Verification System, Mobile Field Application, Advanced Notification System, Quality Assurance Module, Advanced Analytics & AI, Procurement Management, SROI & Social Impact Tools, Team Management, Digital Checklists, Document Evidence Management, Electronic Library of Financial Instruments & Supporting Material, Discussion Forum System (Phase 2), Advanced Search & Analytics, and User Personalization Features (Phase 3)"}

# Digital Checklists for Deliverables APIs
@api_router.get("/projects/{project_id}/digital-checklists")
async def get_digital_checklists(project_id: str, current_user: User = Depends(get_current_user)):
    """Get all digital checklists for a project"""
    checklists = await db.digital_checklists.find({"project_id": project_id}).to_list(length=None)
    # Convert MongoDB documents to JSON-serializable format
    for checklist in checklists:
        if '_id' in checklist:
            del checklist['_id']
    return checklists

@api_router.post("/projects/{project_id}/digital-checklists")
async def create_digital_checklist(project_id: str, checklist_data: dict, current_user: User = Depends(get_current_user)):
    """Create a new digital checklist"""
    if current_user.role not in [UserRole.ADMINISTRATOR, UserRole.SOCIAL_ACTOR]:
        raise HTTPException(status_code=403, detail="Only administrators and social actors can create checklists")
    
    # Calculate initial completion percentage
    items = checklist_data.get("items", [])
    total_items = len(items)
    completed_items = len([item for item in items if item.get("completed", False)])
    completion_percentage = (completed_items / total_items * 100) if total_items > 0 else 0
    
    checklist = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        "title": checklist_data["title"],
        "description": checklist_data.get("description", ""),
        "template_type": checklist_data.get("template_type", "custom"),
        "deliverable_id": checklist_data.get("deliverable_id"),
        "items": items,
        "status": "active",
        "completion_percentage": completion_percentage,
        "created_by": current_user.id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.digital_checklists.insert_one(checklist)
    
    # Create notification using the correct function signature
    await create_notification(
        user_id=current_user.id,
        title="Digital Checklist Created",
        message=f"Created checklist: {checklist['title']}",
        notification_type=NotificationType.INFO
    )
    
    # Remove MongoDB ObjectId before returning
    if '_id' in checklist:
        del checklist['_id']
    
    return checklist

@api_router.patch("/projects/{project_id}/digital-checklists/{checklist_id}")
async def update_digital_checklist(project_id: str, checklist_id: str, update_data: dict, current_user: User = Depends(get_current_user)):
    """Update a digital checklist"""
    if current_user.role not in [UserRole.ADMINISTRATOR, UserRole.SOCIAL_ACTOR]:
        raise HTTPException(status_code=403, detail="Only administrators and social actors can update checklists")
    
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    # Calculate completion percentage if items are updated
    if "items" in update_data:
        total_items = len(update_data["items"])
        completed_items = len([item for item in update_data["items"] if item.get("completed", False)])
        update_data["completion_percentage"] = (completed_items / total_items * 100) if total_items > 0 else 0
    
    await db.digital_checklists.update_one(
        {"id": checklist_id, "project_id": project_id},
        {"$set": update_data}
    )
    
    updated_checklist = await db.digital_checklists.find_one({"id": checklist_id, "project_id": project_id})
    
    # Create notification for significant progress updates
    if update_data.get("completion_percentage", 0) >= 100:
        await create_notification(
            user_id=current_user.id,
            title="Checklist Completed",
            message=f"Checklist '{updated_checklist['title']}' completed",
            notification_type=NotificationType.SUCCESS
        )
    
    # Remove MongoDB ObjectId before returning
    if updated_checklist and '_id' in updated_checklist:
        del updated_checklist['_id']
    
    return updated_checklist

@api_router.delete("/projects/{project_id}/digital-checklists/{checklist_id}")
async def delete_digital_checklist(project_id: str, checklist_id: str, current_user: User = Depends(get_current_user)):
    """Delete a digital checklist"""
    if current_user.role not in [UserRole.ADMINISTRATOR, UserRole.SOCIAL_ACTOR]:
        raise HTTPException(status_code=403, detail="Only administrators and social actors can delete checklists")
    
    await db.digital_checklists.delete_one({"id": checklist_id, "project_id": project_id})
    return {"message": "Digital checklist deleted successfully"}

@api_router.get("/projects/{project_id}/checklist-templates")
async def get_checklist_templates(project_id: str, current_user: User = Depends(get_current_user)):
    """Get available checklist templates"""
    templates = [
        {
            "id": "equipment_installation",
            "name": "Equipment Installation",
            "description": "Standard checklist for equipment setup and installation",
            "items": [
                {"text": "Verify equipment specifications", "required": True},
                {"text": "Check installation site preparation", "required": True},
                {"text": "Install equipment according to specifications", "required": True},
                {"text": "Test equipment functionality", "required": True},
                {"text": "Document installation completion", "required": True},
                {"text": "Train users on equipment operation", "required": False},
                {"text": "Update inventory records", "required": True}
            ]
        },
        {
            "id": "training_delivery",
            "name": "Training Delivery",
            "description": "Checklist for training session preparation and delivery",
            "items": [
                {"text": "Prepare training materials", "required": True},
                {"text": "Set up training venue", "required": True},
                {"text": "Verify participant attendance", "required": True},
                {"text": "Deliver training content", "required": True},
                {"text": "Conduct practical exercises", "required": False},
                {"text": "Gather participant feedback", "required": True},
                {"text": "Document training completion", "required": True},
                {"text": "Update participant records", "required": True}
            ]
        },
        {
            "id": "quality_assurance",
            "name": "Quality Assurance",
            "description": "General quality assurance checklist for deliverables",
            "items": [
                {"text": "Review deliverable against requirements", "required": True},
                {"text": "Check compliance with quality standards", "required": True},
                {"text": "Verify documentation completeness", "required": True},
                {"text": "Test functionality (if applicable)", "required": False},
                {"text": "Review stakeholder feedback", "required": True},
                {"text": "Document quality assessment", "required": True},
                {"text": "Approve for delivery", "required": True}
            ]
        }
    ]
    return templates

# Enhanced Document Evidence Management APIs
@api_router.get("/projects/{project_id}/document-evidence")
async def get_document_evidence(project_id: str, current_user: User = Depends(get_current_user)):
    """Get all document evidence for a project"""
    documents = await db.document_evidence.find({"project_id": project_id}).to_list(length=None)
    for doc in documents:
        if '_id' in doc:
            del doc['_id']
    return documents

@api_router.post("/projects/{project_id}/document-evidence")
async def upload_document_evidence(
    project_id: str, 
    current_user: User = Depends(get_current_user),
    phase: str = None,
    activity: str = None,
    category: str = "general",
    title: str = None,
    description: str = None,
    tags: list = None
):
    """Upload document evidence with automatic timestamping and categorization"""
    if current_user.role not in [UserRole.ADMINISTRATOR, UserRole.SOCIAL_ACTOR]:
        raise HTTPException(status_code=403, detail="Only administrators and social actors can upload evidence")
    
    document = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        "title": title or "Untitled Document",
        "description": description or "",
        "category": category,
        "phase": phase,
        "activity": activity,
        "tags": tags or [],
        "file_type": "document",  # Will be updated when actual file is processed
        "file_size": 0,  # Will be updated when actual file is processed
        "file_path": None,  # Will be updated when actual file is processed
        "thumbnail_path": None,
        "metadata": {
            "location_data": None,  # For GPS coordinates
            "device_info": None,
            "camera_settings": None
        },
        "uploaded_by": current_user.id,
        "uploaded_at": datetime.now(timezone.utc).isoformat(),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "status": "uploaded",
        "verification_status": "pending",
        "access_level": "project_team"
    }
    
    await db.document_evidence.insert_one(document)
    
    await create_notification(
        user_id=current_user.id,
        title="Document Evidence Uploaded",
        message=f"New evidence uploaded: {document['title']}",
        notification_type=NotificationType.INFO
    )
    
    if '_id' in document:
        del document['_id']
    
    return document

@api_router.patch("/projects/{project_id}/document-evidence/{document_id}")
async def update_document_evidence(
    project_id: str, 
    document_id: str, 
    update_data: dict, 
    current_user: User = Depends(get_current_user)
):
    """Update document evidence metadata"""
    if current_user.role not in [UserRole.ADMINISTRATOR, UserRole.SOCIAL_ACTOR]:
        raise HTTPException(status_code=403, detail="Only administrators and social actors can update evidence")
    
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    await db.document_evidence.update_one(
        {"id": document_id, "project_id": project_id},
        {"$set": update_data}
    )
    
    updated_document = await db.document_evidence.find_one({"id": document_id, "project_id": project_id})
    if updated_document and '_id' in updated_document:
        del updated_document['_id']
    
    return updated_document

@api_router.delete("/projects/{project_id}/document-evidence/{document_id}")
async def delete_document_evidence(
    project_id: str, 
    document_id: str, 
    current_user: User = Depends(get_current_user)
):
    """Delete document evidence"""
    if current_user.role not in [UserRole.ADMINISTRATOR, UserRole.SOCIAL_ACTOR]:
        raise HTTPException(status_code=403, detail="Only administrators and social actors can delete evidence")
    
    await db.document_evidence.delete_one({"id": document_id, "project_id": project_id})
    return {"message": "Document evidence deleted successfully"}

@api_router.get("/projects/{project_id}/document-evidence/categories")
async def get_evidence_categories(project_id: str, current_user: User = Depends(get_current_user)):
    """Get available evidence categories"""
    categories = [
        {
            "id": "photos_videos",
            "name": "Photos & Videos",
            "description": "Visual evidence from intervention sites",
            "icon": "camera",
            "accepted_formats": ["jpg", "jpeg", "png", "webp", "mp4", "mov", "avi"]
        },
        {
            "id": "contracts",
            "name": "Contracts & Agreements",
            "description": "Legal documents and agreements",
            "icon": "file-text",
            "accepted_formats": ["pdf", "doc", "docx"]
        },
        {
            "id": "invoices",
            "name": "Invoices & Receipts",
            "description": "Financial documentation",
            "icon": "receipt",
            "accepted_formats": ["pdf", "jpg", "png", "xlsx", "csv"]
        },
        {
            "id": "permits",
            "name": "Permits & Licenses",
            "description": "Official permits and licenses",
            "icon": "shield-check",
            "accepted_formats": ["pdf", "jpg", "png"]
        },
        {
            "id": "reports",
            "name": "Activity Reports",
            "description": "Progress and activity reports",
            "icon": "file-bar-chart",
            "accepted_formats": ["pdf", "doc", "docx", "xlsx"]
        },
        {
            "id": "certificates",
            "name": "Certificates & Awards",
            "description": "Completion certificates and awards",
            "icon": "award",
            "accepted_formats": ["pdf", "jpg", "png"]
        },
        {
            "id": "gps_data",
            "name": "GPS & Location Data",
            "description": "Geospatial evidence and coordinates",
            "icon": "map-pin",
            "accepted_formats": ["gpx", "kml", "csv", "json"]
        }
    ]
    return categories

@api_router.get("/projects/{project_id}/document-evidence/analytics")
async def get_evidence_analytics(project_id: str, current_user: User = Depends(get_current_user)):
    """Get document evidence analytics"""
    documents = await db.document_evidence.find({"project_id": project_id}).to_list(length=None)
    
    # Calculate analytics
    total_documents = len(documents)
    categories_count = {}
    phases_count = {}
    monthly_uploads = {}
    verification_status_count = {"verified": 0, "pending": 0, "rejected": 0}
    
    for doc in documents:
        # Category distribution
        category = doc.get("category", "general")
        categories_count[category] = categories_count.get(category, 0) + 1
        
        # Phase distribution
        phase = doc.get("phase", "unknown")
        phases_count[phase] = phases_count.get(phase, 0) + 1
        
        # Monthly uploads
        upload_date = doc.get("created_at", "")
        if upload_date:
            month_key = upload_date[:7]  # YYYY-MM format
            monthly_uploads[month_key] = monthly_uploads.get(month_key, 0) + 1
        
        # Verification status
        verification = doc.get("verification_status", "pending")
        if verification in verification_status_count:
            verification_status_count[verification] += 1
    
    return {
        "total_documents": total_documents,
        "categories_distribution": categories_count,
        "phases_distribution": phases_count,
        "monthly_uploads": monthly_uploads,
        "verification_status": verification_status_count,
        "storage_usage": {
            "total_size_mb": sum([doc.get("file_size", 0) for doc in documents]) / (1024 * 1024),
            "average_file_size_mb": (sum([doc.get("file_size", 0) for doc in documents]) / len(documents) / (1024 * 1024)) if documents else 0
        }
    }

# Universal Commenting System APIs
@api_router.get("/projects/{project_id}/comments")
async def get_comments(
    project_id: str, 
    item_type: str = None, 
    item_id: str = None, 
    current_user: User = Depends(get_current_user)
):
    """Get comments with role-based filtering"""
    query = {"project_id": project_id}
    
    if item_type:
        query["item_type"] = item_type
    if item_id:
        query["item_id"] = item_id
    
    comments = await db.comments.find(query).to_list(length=None)
    
    # Filter comments based on user role and approval status
    filtered_comments = []
    for comment in comments:
        # Remove MongoDB ObjectId
        if '_id' in comment:
            del comment['_id']
        
        # Role-based filtering for comment visibility
        if current_user.role == UserRole.INVESTOR:
            # Investors see only their own comments and approved comments from others
            if comment.get("created_by") == current_user.id or comment.get("approval_status") == "approved":
                filtered_comments.append(comment)
        elif current_user.role == UserRole.SOCIAL_ACTOR:
            # Social actors see only approved comments (not pending investor comments)
            if comment.get("approval_status") in ["approved", "auto_approved"] or comment.get("created_by") == current_user.id:
                filtered_comments.append(comment)
        elif current_user.role == UserRole.ADMINISTRATOR:
            # Administrators see all comments regardless of approval status
            filtered_comments.append(comment)
    
    return filtered_comments

@api_router.post("/projects/{project_id}/comments")
async def create_comment(
    project_id: str, 
    comment_data: dict, 
    current_user: User = Depends(get_current_user)
):
    """Create a new comment with approval workflow"""
    
    # Determine approval status based on user role
    approval_status = "auto_approved"  # Default for admin and social actor
    if current_user.role == UserRole.INVESTOR:
        approval_status = "pending_approval"  # Investor comments need admin approval
    
    comment = {
        "id": str(uuid.uuid4()),
        "project_id": project_id,
        "item_type": comment_data.get("item_type", "general"),  # e.g., "deliverable", "kpi", "risk", "tab"
        "item_id": comment_data.get("item_id"),  # ID of the specific item, null for tab-level comments
        "parent_comment_id": comment_data.get("parent_comment_id"),  # For replies/threads
        "content": comment_data["content"],
        "content_type": comment_data.get("content_type", "text"),  # "text", "rich_text", "file"
        "attachments": comment_data.get("attachments", []),
        "mentions": comment_data.get("mentions", []),  # User IDs mentioned with @
        "created_by": current_user.id,
        "created_by_name": current_user.username,
        "created_by_role": current_user.role.value,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "approval_status": approval_status,  # "pending_approval", "approved", "rejected", "auto_approved"
        "approved_by": None,
        "approved_at": None,
        "is_edited": False,
        "edit_history": [],
        "priority": comment_data.get("priority", "normal"),  # "low", "normal", "high", "urgent"
        "tags": comment_data.get("tags", []),
        "visibility": comment_data.get("visibility", "project_team")  # "public", "project_team", "admin_only"
    }
    
    await db.comments.insert_one(comment)
    
    # Create notifications based on comment type and mentions
    if current_user.role == UserRole.INVESTOR:
        # Notify all administrators about new investor comment needing approval
        admin_users = await db.users.find({"role": "administrator"}).to_list(length=None)
        for admin in admin_users:
            await create_notification(
                user_id=admin["id"],
                title="Investor Comment Needs Approval",
                message=f"New comment from {current_user.username} requires your approval",
                notification_type=NotificationType.INFO
            )
    else:
        # Auto-approved comments notify team members
        if comment["item_type"] != "general":
            await create_notification(
                user_id=current_user.id,
                title="Comment Added",
                message=f"New comment on {comment['item_type']}",
                notification_type=NotificationType.INFO
            )
    
    # Handle mentions
    for mentioned_user_id in comment.get("mentions", []):
        await create_notification(
            user_id=mentioned_user_id,
            title="You were mentioned in a comment",
            message=f"{current_user.username} mentioned you in a comment",
            notification_type=NotificationType.INFO
        )
    
    if '_id' in comment:
        del comment['_id']
    
    return comment

@api_router.patch("/projects/{project_id}/comments/{comment_id}")
async def update_comment(
    project_id: str, 
    comment_id: str, 
    update_data: dict, 
    current_user: User = Depends(get_current_user)
):
    """Update a comment (edit content or approve/reject)"""
    
    existing_comment = await db.comments.find_one({"id": comment_id, "project_id": project_id})
    if not existing_comment:
        raise HTTPException(status_code=404, detail="Comment not found")
    
    # Check permissions
    if current_user.role == UserRole.ADMINISTRATOR:
        # Admins can update any comment or approve/reject
        pass
    elif existing_comment["created_by"] == current_user.id:
        # Users can edit their own comments (but not change approval status)
        if "approval_status" in update_data and current_user.role != UserRole.ADMINISTRATOR:
            del update_data["approval_status"]
    else:
        raise HTTPException(status_code=403, detail="Not authorized to update this comment")
    
    # Handle content updates (track edit history)
    if "content" in update_data and update_data["content"] != existing_comment.get("content"):
        edit_history = existing_comment.get("edit_history", [])
        edit_history.append({
            "previous_content": existing_comment.get("content"),
            "edited_by": current_user.id,
            "edited_at": datetime.now(timezone.utc).isoformat()
        })
        update_data["edit_history"] = edit_history
        update_data["is_edited"] = True
    
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    # Handle approval status changes
    if "approval_status" in update_data and current_user.role == UserRole.ADMINISTRATOR:
        if update_data["approval_status"] == "approved":
            update_data["approved_by"] = current_user.id
            update_data["approved_at"] = datetime.now(timezone.utc).isoformat()
            
            # Notify comment creator that their comment was approved
            await create_notification(
                user_id=existing_comment["created_by"],
                title="Comment Approved",
                message="Your comment has been approved by an administrator",
                notification_type=NotificationType.SUCCESS
            )
        elif update_data["approval_status"] == "rejected":
            await create_notification(
                user_id=existing_comment["created_by"],
                title="Comment Not Approved",
                message="Your comment was not approved by an administrator", 
                notification_type=NotificationType.WARNING
            )
    
    await db.comments.update_one(
        {"id": comment_id, "project_id": project_id},
        {"$set": update_data}
    )
    
    updated_comment = await db.comments.find_one({"id": comment_id, "project_id": project_id})
    if updated_comment and '_id' in updated_comment:
        del updated_comment['_id']
    
    return updated_comment

@api_router.delete("/projects/{project_id}/comments/{comment_id}")
async def delete_comment(
    project_id: str, 
    comment_id: str, 
    current_user: User = Depends(get_current_user)
):
    """Delete a comment"""
    
    existing_comment = await db.comments.find_one({"id": comment_id, "project_id": project_id})
    if not existing_comment:
        raise HTTPException(status_code=404, detail="Comment not found")
    
    # Check permissions - users can delete their own comments, admins can delete any
    if current_user.role != UserRole.ADMINISTRATOR and existing_comment["created_by"] != current_user.id:
        raise HTTPException(status_code=403, detail="Not authorized to delete this comment")
    
    await db.comments.delete_one({"id": comment_id, "project_id": project_id})
    return {"message": "Comment deleted successfully"}

@api_router.get("/projects/{project_id}/comments/pending-approval")
async def get_pending_comments(project_id: str, current_user: User = Depends(get_current_user)):
    """Get comments pending approval (admin only)"""
    
    if current_user.role != UserRole.ADMINISTRATOR:
        raise HTTPException(status_code=403, detail="Only administrators can view pending comments")
    
    comments = await db.comments.find({
        "project_id": project_id,
        "approval_status": "pending_approval"
    }).to_list(length=None)
    
    for comment in comments:
        if '_id' in comment:
            del comment['_id']
    
    return comments

@api_router.get("/projects/{project_id}/comments/analytics")
async def get_comment_analytics(project_id: str, current_user: User = Depends(get_current_user)):
    """Get comment analytics for the project"""
    
    comments = await db.comments.find({"project_id": project_id}).to_list(length=None)
    
    # Calculate analytics
    total_comments = len(comments)
    approval_stats = {"pending_approval": 0, "approved": 0, "rejected": 0, "auto_approved": 0}
    user_stats = {}
    item_type_stats = {}
    
    for comment in comments:
        # Approval status distribution
        status = comment.get("approval_status", "auto_approved")
        if status in approval_stats:
            approval_stats[status] += 1
        
        # User activity
        creator = comment.get("created_by_name", "Unknown")
        user_stats[creator] = user_stats.get(creator, 0) + 1
        
        # Item type distribution
        item_type = comment.get("item_type", "general")
        item_type_stats[item_type] = item_type_stats.get(item_type, 0) + 1
    
    return {
        "total_comments": total_comments,
        "approval_statistics": approval_stats,
        "user_activity": user_stats,
        "item_type_distribution": item_type_stats,
        "engagement_rate": total_comments / max(1, len(user_stats))  # Comments per active user
    }

# Contractual Compliance & Accountability Tracking APIs
@api_router.put("/projects/{project_id}/milestones/{milestone_id}")
async def update_milestone(
    project_id: str, 
    milestone_id: str, 
    update_data: dict, 
    current_user: User = Depends(get_current_user)
):
    """Update a milestone"""
    if current_user.role not in [UserRole.ADMINISTRATOR, UserRole.SOCIAL_ACTOR]:
        raise HTTPException(status_code=403, detail="Only administrators and social actors can update milestones")
    
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    if "budget_allocation" in update_data:
        update_data["budget_allocation"] = float(update_data["budget_allocation"])
    
    await db.milestones.update_one(
        {"id": milestone_id, "project_id": project_id},
        {"$set": update_data}
    )
    
    updated_milestone = await db.milestones.find_one({"id": milestone_id, "project_id": project_id})
    if updated_milestone and '_id' in updated_milestone:
        del updated_milestone['_id']
    
    # Notify on status changes
    if "status" in update_data and update_data["status"] == "completed":
        await create_notification(
            user_id=current_user.id,
            title="Milestone Completed",
            message=f"Milestone '{updated_milestone['title']}' has been completed",
            notification_type=NotificationType.SUCCESS
        )
    
    return updated_milestone

@api_router.delete("/projects/{project_id}/milestones/{milestone_id}")
async def delete_milestone(
    project_id: str, 
    milestone_id: str, 
    current_user: User = Depends(get_current_user)
):
    """Delete a milestone"""
    if current_user.role not in [UserRole.ADMINISTRATOR, UserRole.SOCIAL_ACTOR]:
        raise HTTPException(status_code=403, detail="Only administrators and social actors can delete milestones")
    
    await db.milestones.delete_one({"id": milestone_id, "project_id": project_id})
    return {"message": "Milestone deleted successfully"}

@api_router.get("/projects/{project_id}/budget-compliance")
async def get_budget_compliance(project_id: str, current_user: User = Depends(get_current_user)):
    """Get budget compliance information"""
    
    # Get project budget and expenses
    expenses = await db.expenses.find({"project_id": project_id}).to_list(length=None)
    budget_categories = await db.budget_categories.find({"project_id": project_id}).to_list(length=None)
    
    total_budget = sum([cat.get("allocated_amount", 0) for cat in budget_categories])
    total_spent = sum([exp.get("amount", 0) for exp in expenses])
    
    compliance_data = {
        "total_budget": total_budget,
        "total_spent": total_spent,
        "remaining_budget": total_budget - total_spent,
        "budget_utilization": (total_spent / total_budget * 100) if total_budget > 0 else 0,
        "compliance_status": "compliant" if total_spent <= total_budget else "over_budget",
        "category_breakdown": [],
        "spending_trend": [],
        "alerts": []
    }
    
    # Add alerts for budget overruns
    if total_spent > total_budget:
        compliance_data["alerts"].append({
            "type": "budget_overrun",
            "message": f"Project is over budget by ${total_spent - total_budget:,.2f}",
            "severity": "high"
        })
    elif total_spent > total_budget * 0.9:
        compliance_data["alerts"].append({
            "type": "budget_warning",
            "message": f"Project has used {compliance_data['budget_utilization']:.1f}% of budget",
            "severity": "medium"
        })
    
    return compliance_data

# Enhanced Financial Instruments Library APIs with Standardized Coding System
@api_router.get("/template-library")
async def get_financial_instruments(
    category: str = None, 
    content_type: str = None,
    file_format: str = None,
    language: str = None,
    search: str = None,
    instrument_code: str = None,  # New: Standardized coding search
    full_text_search: str = None,  # New: Full-text search within documents
    current_user: User = Depends(get_current_user)
):
    """Get all financial instruments and supporting materials with enhanced search capabilities"""
    query = {"status": "active"}
    
    if category:
        query["category"] = category
    if content_type:
        query["content_type"] = content_type
    if file_format:
        query["file_format"] = file_format
    if language:
        query["language"] = language
    if instrument_code:
        query["standardized_code"] = {"$regex": instrument_code, "$options": "i"}
    
    if search:
        query["$or"] = [
            {"title": {"$regex": search, "$options": "i"}},
            {"description": {"$regex": search, "$options": "i"}},
            {"detailed_description": {"$regex": search, "$options": "i"}},
            {"tags": {"$in": [search]}},
            {"keywords": {"$in": [search]}},
            {"standardized_code": {"$regex": search, "$options": "i"}}
        ]
    
    # Full-text search across document content (simulated - would need actual document indexing)
    if full_text_search:
        query["$or"] = query.get("$or", []) + [
            {"full_text_content": {"$regex": full_text_search, "$options": "i"}},
            {"extracted_text": {"$regex": full_text_search, "$options": "i"}}
        ]
    
    instruments = await db.template_library.find(query).to_list(length=None)
    for instrument in instruments:
        if '_id' in instrument:
            del instrument['_id']
    
    return instruments

@api_router.post("/template-library")
async def create_financial_instrument(
    instrument_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Create a new financial instrument or supporting material (admin only)"""
    if current_user.role != UserRole.ADMINISTRATOR:
        raise HTTPException(status_code=403, detail="Only administrators can create financial instruments")
    
    instrument = {
        "id": str(uuid.uuid4()),
        "title": instrument_data["title"],
        "description": instrument_data.get("description", ""),  # Concise description
        "detailed_description": instrument_data.get("detailed_description", ""),  # Detailed description
        "category": instrument_data["category"],  # Based on new categorization
        "subcategory": instrument_data.get("subcategory", ""),
        
        # Content type based on specifications
        "content_type": instrument_data.get("content_type", "financial_instrument"),  # financial_instrument, bibliography, publication, supporting_material
        
        # Enhanced file format support per specifications
        "file_format": instrument_data.get("file_format", "pdf"),  # pdf, epub, wma, wmv
        "file_path": instrument_data.get("file_path", ""),
        "file_size": instrument_data.get("file_size", 0),
        "thumbnail_path": instrument_data.get("thumbnail_path", ""),
        
        # Language support (Greek/International)
        "language": instrument_data.get("language", "en"),  # en, el (Greek), multilingual
        "is_greek_content": instrument_data.get("language", "en") == "el",
        
        # Enhanced metadata
        "tags": instrument_data.get("tags", []),
        "keywords": instrument_data.get("keywords", []),  # For better search
        "authors": instrument_data.get("authors", []),  # For bibliography
        "publication_date": instrument_data.get("publication_date", ""),
        "publisher": instrument_data.get("publisher", ""),
        "isbn_doi": instrument_data.get("isbn_doi", ""),  # ISBN for books, DOI for papers
        
        # Financial instrument specific fields
        "legal_framework": instrument_data.get("legal_framework", ""),
        "jurisdiction": instrument_data.get("jurisdiction", ""),
        "contract_templates": instrument_data.get("contract_templates", []),  # Related contract templates
        "nda_required": instrument_data.get("nda_required", False),
        
        # Bibliography specific fields
        "journal_name": instrument_data.get("journal_name", ""),
        "volume_issue": instrument_data.get("volume_issue", ""),
        "is_peer_reviewed": instrument_data.get("is_peer_reviewed", False),
        "citation_count": instrument_data.get("citation_count", 0),
        
        # User interaction metrics
        "usage_count": 0,
        "downloads": 0,
        "bookmarks": 0,
        "rating": 0.0,
        "view_count": 0,
        
        # Standard fields
        "created_by": current_user.id,
        "created_by_name": current_user.username,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "status": "active",
        "version": "1.0",
        
        # Enhanced metadata
        "metadata": {
            "target_audience": instrument_data.get("target_audience", []),
            "complexity_level": instrument_data.get("complexity_level", "medium"),  # low, medium, high
            "estimated_reading_time": instrument_data.get("estimated_reading_time", ""),
            "prerequisites": instrument_data.get("prerequisites", []),
            "related_instruments": instrument_data.get("related_instruments", []),
            "sdg_alignment": instrument_data.get("sdg_alignment", [])
        }
    }
    
    await db.template_library.insert_one(instrument)
    
    await create_notification(
        user_id=current_user.id,
        title="Financial Instrument Added",
        message=f"New financial instrument '{instrument['title']}' added to library",
        notification_type=NotificationType.INFO
    )
    
    if '_id' in instrument:
        del instrument['_id']
    
    return instrument

@api_router.put("/template-library/{template_id}")
async def update_template(
    template_id: str,
    update_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Update a template (admin only)"""
    if current_user.role != UserRole.ADMINISTRATOR:
        raise HTTPException(status_code=403, detail="Only administrators can update templates")
    
    update_data["updated_at"] = datetime.now(timezone.utc).isoformat()
    
    await db.template_library.update_one(
        {"id": template_id},
        {"$set": update_data}
    )
    
    updated_template = await db.template_library.find_one({"id": template_id})
    if updated_template and '_id' in updated_template:
        del updated_template['_id']
    
    return updated_template

@api_router.delete("/template-library/{template_id}")
async def delete_template(
    template_id: str,
    current_user: User = Depends(get_current_user)
):
    """Delete a template (admin only)"""
    if current_user.role != UserRole.ADMINISTRATOR:
        raise HTTPException(status_code=403, detail="Only administrators can delete templates")
    
    # Soft delete by setting status to inactive
    await db.template_library.update_one(
        {"id": template_id},
        {"$set": {"status": "inactive", "deleted_at": datetime.now(timezone.utc).isoformat()}}
    )
    
    return {"message": "Template deleted successfully"}

@api_router.post("/template-library/{template_id}/rate")
async def rate_template(
    template_id: str,
    rating_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Rate a template (1-5 stars)"""
    rating = rating_data.get("rating", 0)
    if rating < 1 or rating > 5:
        raise HTTPException(status_code=400, detail="Rating must be between 1 and 5")
    
    # Store individual rating
    rating_record = {
        "id": str(uuid.uuid4()),
        "template_id": template_id,
        "user_id": current_user.id,
        "rating": rating,
        "comment": rating_data.get("comment", ""),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.template_ratings.insert_one(rating_record)
    
    # Update template average rating
    ratings = await db.template_ratings.find({"template_id": template_id}).to_list(length=None)
    avg_rating = sum([r["rating"] for r in ratings]) / len(ratings)
    
    await db.template_library.update_one(
        {"id": template_id},
        {"$set": {"rating": round(avg_rating, 2)}}
    )
    
    return {"message": "Rating submitted successfully", "average_rating": round(avg_rating, 2)}

@api_router.get("/template-library/categories")
async def get_financial_instrument_categories(current_user: User = Depends(get_current_user)):
    """Get available financial instrument and supporting material categories"""
    categories = [
        {
            "id": "financial_instruments",
            "name": "Financial Instruments",
            "name_el": "Χρηματοδοτικά Εργαλεία",
            "description": "Various financial instruments for social investment projects",
            "description_el": "Διάφορα χρηματοδοτικά εργαλεία για έργα κοινωνικής επένδυσης",
            "icon": "banknote",
            "subcategories": [
                {"id": "grants", "name": "Grants", "name_el": "Επιδοτήσεις"},
                {"id": "loans", "name": "Loans", "name_el": "Δάνεια"},
                {"id": "bonds", "name": "Social Impact Bonds", "name_el": "Ομόλογα Κοινωνικού Αντικτύπου"},
                {"id": "equity", "name": "Equity Financing", "name_el": "Χρηματοδότηση Μετοχικού Κεφαλαίου"},
                {"id": "blended_finance", "name": "Blended Finance", "name_el": "Μικτή Χρηματοδότηση"},
                {"id": "microfinance", "name": "Microfinance", "name_el": "Μικροχρηματοδότηση"},
                {"id": "crowdfunding", "name": "Crowdfunding", "name_el": "Ομαδική Χρηματοδότηση"}
            ]
        },
        {
            "id": "bibliography",
            "name": "Bibliography & References",
            "name_el": "Βιβλιογραφία & Αναφορές",
            "description": "International and Greek bibliography on social investment and financial instruments",
            "description_el": "Διεθνής και Ελληνική βιβλιογραφία για κοινωνικές επενδύσεις και χρηματοδοτικά εργαλεία",
            "icon": "book-open",
            "subcategories": [
                {"id": "international_books", "name": "International Books", "name_el": "Διεθνή Βιβλία"},
                {"id": "greek_books", "name": "Greek Books", "name_el": "Ελληνικά Βιβλία"},
                {"id": "academic_papers", "name": "Academic Papers", "name_el": "Ακαδημαϊκές Εργασίες"},
                {"id": "reports", "name": "Research Reports", "name_el": "Ερευνητικές Αναφορές"},
                {"id": "case_studies", "name": "Case Studies", "name_el": "Μελέτες Περίπτωσης"}
            ]
        },
        {
            "id": "publications",
            "name": "Scientific Publications & Journals",
            "name_el": "Επιστημονικές Δημοσιεύσεις & Περιοδικά",
            "description": "Peer-reviewed journals and scientific publications in the field",
            "description_el": "Επιστημονικά περιοδικά και δημοσιεύσεις στον τομέα",
            "icon": "file-text",
            "subcategories": [
                {"id": "peer_reviewed", "name": "Peer-Reviewed Journals", "name_el": "Περιοδικά με Κριτές"},
                {"id": "conference_papers", "name": "Conference Papers", "name_el": "Εργασίες Συνεδρίων"},
                {"id": "policy_papers", "name": "Policy Papers", "name_el": "Πολιτικές Αναφορές"},
                {"id": "white_papers", "name": "White Papers", "name_el": "Λευκές Αναφορές"},
                {"id": "working_papers", "name": "Working Papers", "name_el": "Εργασίες σε Εξέλιξη"}
            ]
        },
        {
            "id": "supporting_materials",
            "name": "Supporting Materials",
            "name_el": "Υποστηρικτικό Υλικό",
            "description": "Legal frameworks, contract templates, agreements, and other supporting materials",
            "description_el": "Θεσμικό πλαίσιο, υποδείγματα συμβάσεων, συμφωνητικά και άλλο υποστηρικτικό υλικό",
            "icon": "folder",
            "subcategories": [
                {"id": "legal_framework", "name": "Legal Framework", "name_el": "Θεσμικό Πλαίσιο"},
                {"id": "contract_templates", "name": "Contract Templates", "name_el": "Υποδείγματα Συμβάσεων"},
                {"id": "agreements", "name": "Agreements & MOUs", "name_el": "Συμφωνητικά & MOU"},
                {"id": "nda_templates", "name": "Non-Disclosure Agreements", "name_el": "Συμφωνίες Εμπιστευτικότητας"},
                {"id": "compliance_docs", "name": "Compliance Documents", "name_el": "Έγγραφα Συμμόρφωσης"},
                {"id": "guidelines", "name": "Guidelines & Best Practices", "name_el": "Οδηγίες & Βέλτιστες Πρακτικές"}
            ]
        },
        {
            "id": "multimedia",
            "name": "Multimedia Content",
            "name_el": "Πολυμεσικό Περιεχόμενο",
            "description": "Audio, video, and interactive content related to financial instruments",
            "description_el": "Ηχητικό, οπτικοακουστικό και διαδραστικό περιεχόμενο σχετικό με χρηματοδοτικά εργαλεία",
            "icon": "play-circle",
            "subcategories": [
                {"id": "video_tutorials", "name": "Video Tutorials", "name_el": "Εκπαιδευτικά Βίντεο"},
                {"id": "webinars", "name": "Webinars & Seminars", "name_el": "Webinars & Σεμινάρια"},
                {"id": "podcasts", "name": "Podcasts & Audio", "name_el": "Podcasts & Ηχητικό"},
                {"id": "presentations", "name": "Presentations", "name_el": "Παρουσιάσεις"},
                {"id": "infographics", "name": "Infographics", "name_el": "Infographics"}
            ]
        }
    ]
    
    return categories

# Phase 2 & 3: Discussion Forum APIs with Greek Support
@api_router.post("/template-library/{instrument_id}/discussions")
async def create_discussion_thread(
    instrument_id: str,
    thread_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Create a new discussion thread for a financial instrument"""
    thread = {
        "id": str(uuid.uuid4()),
        "instrument_id": instrument_id,
        "title": thread_data["title"],
        "title_el": thread_data.get("title_el", ""),  # Greek title support
        "content": thread_data["content"],
        "content_el": thread_data.get("content_el", ""),  # Greek content support
        "language": thread_data.get("language", "en"),  # en, el, or multilingual
        "author_id": current_user.id,
        "author_name": current_user.username,
        "author_role": current_user.role,
        "is_pinned": thread_data.get("is_pinned", False),
        "is_locked": False,
        "tags": thread_data.get("tags", []),
        "replies_count": 0,
        "views_count": 0,
        "likes_count": 0,
        "status": "active",  # active, moderated, deleted
        "moderation_status": "approved" if current_user.role in ["administrator", "social_actor"] else "pending",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "last_activity": datetime.now(timezone.utc).isoformat()
    }
    
    await db.discussion_threads.insert_one(thread)
    
    # Create activity record
    await create_user_activity(current_user.id, "discussion_created", {
        "thread_id": thread["id"],
        "instrument_id": instrument_id,
        "title": thread["title"]
    })
    
    if '_id' in thread:
        del thread['_id']
    
    return thread

@api_router.get("/template-library/{instrument_id}/discussions")
async def get_discussion_threads(
    instrument_id: str,
    language: str = None,
    sort_by: str = "newest",
    current_user: User = Depends(get_current_user)
):
    """Get all discussion threads for a financial instrument"""
    query = {"instrument_id": instrument_id, "status": "active"}
    
    # Filter by moderation status
    if current_user.role != "administrator":
        query["moderation_status"] = "approved"
    
    if language:
        query["language"] = language
    
    threads = await db.discussion_threads.find(query).to_list(length=None)
    
    # Sort threads
    if sort_by == "newest":
        threads.sort(key=lambda x: x["created_at"], reverse=True)
    elif sort_by == "oldest":
        threads.sort(key=lambda x: x["created_at"])
    elif sort_by == "most_active":
        threads.sort(key=lambda x: x["last_activity"], reverse=True)
    elif sort_by == "most_replies":
        threads.sort(key=lambda x: x["replies_count"], reverse=True)
    
    for thread in threads:
        if '_id' in thread:
            del thread['_id']
    
    return threads

@api_router.post("/discussions/{thread_id}/replies")
async def create_thread_reply(
    thread_id: str,
    reply_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Create a reply to a discussion thread"""
    reply = {
        "id": str(uuid.uuid4()),
        "thread_id": thread_id,
        "parent_reply_id": reply_data.get("parent_reply_id"),  # For nested replies
        "content": reply_data["content"],
        "content_el": reply_data.get("content_el", ""),
        "language": reply_data.get("language", "en"),
        "author_id": current_user.id,
        "author_name": current_user.username,
        "author_role": current_user.role,
        "likes_count": 0,
        "is_solution": False,  # Mark as solution to original question
        "status": "active",
        "moderation_status": "approved" if current_user.role in ["administrator", "social_actor"] else "pending",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.discussion_replies.insert_one(reply)
    
    # Update thread reply count and last activity
    await db.discussion_threads.update_one(
        {"id": thread_id},
        {
            "$inc": {"replies_count": 1},
            "$set": {"last_activity": datetime.now(timezone.utc).isoformat()}
        }
    )
    
    if '_id' in reply:
        del reply['_id']
    
    return reply

@api_router.get("/discussions/{thread_id}/replies")
async def get_thread_replies(
    thread_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get all replies for a discussion thread"""
    query = {"thread_id": thread_id, "status": "active"}
    
    if current_user.role != "administrator":
        query["moderation_status"] = "approved"
    
    replies = await db.discussion_replies.find(query).sort("created_at", 1).to_list(length=None)
    
    for reply in replies:
        if '_id' in reply:
            del reply['_id']
    
    return replies

# Advanced Search & Filtering APIs
@api_router.get("/template-library/advanced-search")
async def advanced_search_instruments(
    query: str = None,
    category: str = None,
    content_type: str = None,
    language: str = None,
    author: str = None,
    publisher: str = None,
    date_from: str = None,
    date_to: str = None,
    complexity_level: str = None,
    file_format: str = None,
    min_rating: float = None,
    has_greek_content: bool = None,
    sdg_alignment: str = None,
    tags: str = None,
    sort_by: str = "relevance",
    page: int = 1,
    per_page: int = 20,
    current_user: User = Depends(get_current_user)
):
    """Advanced search with multiple filters and full-text search"""
    search_query = {"status": "active"}
    
    # Full-text search across multiple fields
    if query:
        search_query["$or"] = [
            {"title": {"$regex": query, "$options": "i"}},
            {"description": {"$regex": query, "$options": "i"}},
            {"detailed_description": {"$regex": query, "$options": "i"}},
            {"tags": {"$in": [query]}},
            {"keywords": {"$in": [query]}},
            {"authors": {"$in": [query]}},
            {"publisher": {"$regex": query, "$options": "i"}}
        ]
    
    # Apply filters
    if category:
        search_query["category"] = category
    if content_type:
        search_query["content_type"] = content_type
    if language:
        search_query["language"] = language
    if author:
        search_query["authors"] = {"$in": [author]}
    if publisher:
        search_query["publisher"] = {"$regex": publisher, "$options": "i"}
    if complexity_level:
        search_query["metadata.complexity_level"] = complexity_level
    if file_format:
        search_query["file_format"] = file_format
    if min_rating:
        search_query["rating"] = {"$gte": min_rating}
    if has_greek_content is not None:
        search_query["is_greek_content"] = has_greek_content
    if sdg_alignment:
        sdg_nums = [int(x.strip()) for x in sdg_alignment.split(",") if x.strip().isdigit()]
        if sdg_nums:
            search_query["metadata.sdg_alignment"] = {"$in": sdg_nums}
    if tags:
        tag_list = [t.strip() for t in tags.split(",")]
        search_query["tags"] = {"$in": tag_list}
    
    # Date range filter
    if date_from or date_to:
        date_filter = {}
        if date_from:
            date_filter["$gte"] = date_from
        if date_to:
            date_filter["$lte"] = date_to + "T23:59:59"
        search_query["created_at"] = date_filter
    
    # Get total count for pagination
    total_count = await db.template_library.count_documents(search_query)
    
    # Apply pagination
    skip = (page - 1) * per_page
    
    # Execute search
    cursor = db.template_library.find(search_query)
    
    # Apply sorting
    if sort_by == "newest":
        cursor = cursor.sort("created_at", -1)
    elif sort_by == "oldest":
        cursor = cursor.sort("created_at", 1)
    elif sort_by == "rating":
        cursor = cursor.sort("rating", -1)
    elif sort_by == "downloads":
        cursor = cursor.sort("downloads", -1)
    elif sort_by == "alphabetical":
        cursor = cursor.sort("title", 1)
    elif sort_by == "views":
        cursor = cursor.sort("view_count", -1)
    
    results = await cursor.skip(skip).limit(per_page).to_list(length=per_page)
    
    for result in results:
        if '_id' in result:
            del result['_id']
    
    # Save search history
    await save_search_history(current_user.id, query, search_query, len(results))
    
    return {
        "results": results,
        "total_count": total_count,
        "page": page,
        "per_page": per_page,
        "total_pages": (total_count + per_page - 1) // per_page,
        "has_next": page * per_page < total_count,
        "has_prev": page > 1
    }

# User Activity and Analytics APIs
async def create_user_activity(user_id: str, activity_type: str, metadata: dict):
    """Create user activity record for analytics"""
    activity = {
        "id": str(uuid.uuid4()),
        "user_id": user_id,
        "activity_type": activity_type,  # view, download, bookmark, search, discussion, etc.
        "metadata": metadata,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "session_id": str(uuid.uuid4())  # Could be enhanced with actual session tracking
    }
    await db.user_activities.insert_one(activity)

async def save_search_history(user_id: str, query: str, filters: dict, results_count: int):
    """Save user search history for personalization"""
    search_record = {
        "id": str(uuid.uuid4()),
        "user_id": user_id,
        "query": query,
        "filters": filters,
        "results_count": results_count,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }
    await db.search_history.insert_one(search_record)

@api_router.get("/template-library/search-history")
async def get_user_search_history(current_user: User = Depends(get_current_user)):
    """Get user's search history"""
    history = await db.search_history.find(
        {"user_id": current_user.id}
    ).sort("timestamp", -1).limit(20).to_list(length=20)
    
    for item in history:
        if '_id' in item:
            del item['_id']
    
    return history

@api_router.post("/template-library/saved-searches")
async def save_search_query(
    search_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Save a search query for later use"""
    saved_search = {
        "id": str(uuid.uuid4()),
        "user_id": current_user.id,
        "name": search_data["name"],
        "query": search_data.get("query", ""),
        "filters": search_data.get("filters", {}),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "last_used": datetime.now(timezone.utc).isoformat()
    }
    
    await db.saved_searches.insert_one(saved_search)
    
    if '_id' in saved_search:
        del saved_search['_id']
    
    return saved_search

@api_router.get("/template-library/saved-searches")
async def get_saved_searches(current_user: User = Depends(get_current_user)):
    """Get user's saved search queries"""
    searches = await db.saved_searches.find(
        {"user_id": current_user.id}
    ).sort("last_used", -1).to_list(length=None)
    
    for search in searches:
        if '_id' in search:
            del search['_id']
    
    return searches

# User Collections and Reading Lists
@api_router.post("/template-library/collections")
async def create_collection(
    collection_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Create a personal collection/reading list"""
    collection = {
        "id": str(uuid.uuid4()),
        "user_id": current_user.id,
        "name": collection_data["name"],
        "name_el": collection_data.get("name_el", ""),
        "description": collection_data.get("description", ""),
        "description_el": collection_data.get("description_el", ""),
        "instrument_ids": [],
        "is_public": collection_data.get("is_public", False),
        "tags": collection_data.get("tags", []),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.user_collections.insert_one(collection)
    
    if '_id' in collection:
        del collection['_id']
    
    return collection

@api_router.get("/template-library/collections")
async def get_user_collections(current_user: User = Depends(get_current_user)):
    """Get user's personal collections"""
    collections = await db.user_collections.find(
        {"user_id": current_user.id}
    ).sort("updated_at", -1).to_list(length=None)
    
    # Populate collections with instrument details
    for collection in collections:
        if collection["instrument_ids"]:
            instruments = await db.template_library.find(
                {"id": {"$in": collection["instrument_ids"]}, "status": "active"}
            ).to_list(length=None)
            
            for instrument in instruments:
                if '_id' in instrument:
                    del instrument['_id']
            
            collection["instruments"] = instruments
        else:
            collection["instruments"] = []
        
        if '_id' in collection:
            del collection['_id']
    
    return collections

@api_router.post("/template-library/collections/{collection_id}/instruments/{instrument_id}")
async def add_to_collection(
    collection_id: str,
    instrument_id: str,
    current_user: User = Depends(get_current_user)
):
    """Add an instrument to a collection"""
    await db.user_collections.update_one(
        {"id": collection_id, "user_id": current_user.id},
        {
            "$addToSet": {"instrument_ids": instrument_id},
            "$set": {"updated_at": datetime.now(timezone.utc).isoformat()}
        }
    )
    
    return {"message": "Instrument added to collection successfully"}

@api_router.delete("/template-library/collections/{collection_id}/instruments/{instrument_id}")
async def remove_from_collection(
    collection_id: str,
    instrument_id: str,
    current_user: User = Depends(get_current_user)
):
    """Remove an instrument from a collection"""
    await db.user_collections.update_one(
        {"id": collection_id, "user_id": current_user.id},
        {
            "$pull": {"instrument_ids": instrument_id},
            "$set": {"updated_at": datetime.now(timezone.utc).isoformat()}
        }
    )
    
    return {"message": "Instrument removed from collection successfully"}

# Analytics and Insights APIs
@api_router.get("/template-library/analytics/popular")
async def get_popular_instruments(
    time_period: str = "week",  # week, month, quarter, year, all
    limit: int = 10,
    current_user: User = Depends(get_current_user)
):
    """Get most popular instruments based on various metrics"""
    # Calculate date filter
    now = datetime.now(timezone.utc)
    if time_period == "week":
        date_filter = now - timedelta(weeks=1)
    elif time_period == "month":
        date_filter = now - timedelta(days=30)
    elif time_period == "quarter":
        date_filter = now - timedelta(days=90)
    elif time_period == "year":
        date_filter = now - timedelta(days=365)
    else:
        date_filter = None
    
    # Get activity-based popularity if date filter is specified
    if date_filter:
        activities = await db.user_activities.find({
            "activity_type": {"$in": ["view", "download", "bookmark"]},
            "timestamp": {"$gte": date_filter.isoformat()}
        }).to_list(length=None)
        
        # Count activities per instrument
        instrument_activity = {}
        for activity in activities:
            instrument_id = activity["metadata"].get("instrument_id")
            if instrument_id:
                instrument_activity[instrument_id] = instrument_activity.get(instrument_id, 0) + 1
        
        # Get top instruments
        top_instrument_ids = sorted(instrument_activity.keys(), 
                                  key=lambda x: instrument_activity[x], reverse=True)[:limit]
        
        if top_instrument_ids:
            instruments = await db.template_library.find(
                {"id": {"$in": top_instrument_ids}, "status": "active"}
            ).to_list(length=None)
        else:
            instruments = []
    else:
        # Fall back to overall popularity metrics
        instruments = await db.template_library.find(
            {"status": "active"}
        ).sort([
            ("view_count", -1), 
            ("downloads", -1), 
            ("rating", -1)
        ]).limit(limit).to_list(length=limit)
    
    for instrument in instruments:
        if '_id' in instrument:
            del instrument['_id']
    
    return instruments

@api_router.get("/template-library/analytics/trending")
async def get_trending_instruments(
    limit: int = 10,
    current_user: User = Depends(get_current_user)
):
    """Get trending instruments (increasing in popularity)"""
    # Get instruments with recent activity spike
    week_ago = datetime.now(timezone.utc) - timedelta(weeks=1)
    two_weeks_ago = datetime.now(timezone.utc) - timedelta(weeks=2)
    
    # Get activity counts for recent periods
    recent_activities = await db.user_activities.find({
        "activity_type": {"$in": ["view", "download"]},
        "timestamp": {"$gte": week_ago.isoformat()}
    }).to_list(length=None)
    
    previous_activities = await db.user_activities.find({
        "activity_type": {"$in": ["view", "download"]},
        "timestamp": {"$gte": two_weeks_ago.isoformat(), "$lt": week_ago.isoformat()}
    }).to_list(length=None)
    
    # Calculate trending score (recent activity / previous activity)
    recent_counts = {}
    previous_counts = {}
    
    for activity in recent_activities:
        instrument_id = activity["metadata"].get("instrument_id")
        if instrument_id:
            recent_counts[instrument_id] = recent_counts.get(instrument_id, 0) + 1
    
    for activity in previous_activities:
        instrument_id = activity["metadata"].get("instrument_id")
        if instrument_id:
            previous_counts[instrument_id] = previous_counts.get(instrument_id, 0) + 1
    
    # Calculate trending scores
    trending_scores = {}
    for instrument_id in recent_counts:
        recent = recent_counts[instrument_id]
        previous = previous_counts.get(instrument_id, 1)  # Avoid division by zero
        trending_scores[instrument_id] = recent / previous
    
    # Get top trending instruments
    top_trending_ids = sorted(trending_scores.keys(), 
                            key=lambda x: trending_scores[x], reverse=True)[:limit]
    
    if top_trending_ids:
        instruments = await db.template_library.find(
            {"id": {"$in": top_trending_ids}, "status": "active"}
        ).to_list(length=None)
        
        # Sort by trending score
        instruments.sort(key=lambda x: trending_scores.get(x["id"], 0), reverse=True)
    else:
        instruments = []
    
    for instrument in instruments:
        if '_id' in instrument:
            del instrument['_id']
    
    return instruments

# File Viewing APIs
@api_router.get("/template-library/{instrument_id}/view")
async def get_file_view_url(
    instrument_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get secure URL for viewing file content"""
    instrument = await db.template_library.find_one({"id": instrument_id, "status": "active"})
    
    if not instrument:
        raise HTTPException(status_code=404, detail="Financial instrument not found")
    
    # Record view activity
    await create_user_activity(current_user.id, "view", {
        "instrument_id": instrument_id,
        "instrument_title": instrument["title"],
        "file_format": instrument.get("file_format", "unknown")
    })
    
    # Update view count
    await db.template_library.update_one(
        {"id": instrument_id},
        {"$inc": {"view_count": 1}}
    )
    
    # Generate secure viewing URL (in real implementation, this would be a signed URL)
    file_url = f"/api/template-library/{instrument_id}/file"
    
    return {
        "view_url": file_url,
        "file_format": instrument.get("file_format", "pdf"),
        "file_size": instrument.get("file_size", 0),
        "title": instrument["title"],
        "supports_embed": instrument.get("file_format", "pdf").lower() in ["pdf", "wmv", "wma"],
        "download_url": f"/api/template-library/{instrument_id}/download"
    }

@api_router.get("/template-library/{instrument_id}/file")
async def serve_instrument_file(
    instrument_id: str,
    current_user: User = Depends(get_current_user)
):
    """Serve the actual file content for viewing/download"""
    instrument = await db.template_library.find_one({"id": instrument_id, "status": "active"})
    
    if not instrument:
        raise HTTPException(status_code=404, detail="Financial instrument not found")
    
    # Get file path
    file_path = instrument.get("file_path", "")
    
    # For demo purposes, create sample files if they don't exist
    if not file_path or not os.path.exists(file_path):
        # Create sample file content based on file format
        uploads_dir = Path("/app/uploads/library")
        uploads_dir.mkdir(parents=True, exist_ok=True)
        
        file_format = instrument.get("file_format", "pdf").lower()
        filename = f"{instrument_id}.{file_format}"
        file_path = uploads_dir / filename
        
        # Create sample content based on file type
        if file_format == "pdf":
            # Create a simple PDF-like content (in real app, would serve actual PDF)
            content = f"""Financial Instrument: {instrument['title']}

Description: {instrument.get('description', '')}

Detailed Description: {instrument.get('detailed_description', '')}

Authors: {', '.join(instrument.get('authors', []))}
Publisher: {instrument.get('publisher', 'N/A')}
Publication Date: {instrument.get('publication_date', 'N/A')}

This is a sample document content for demonstration purposes.
In a real implementation, this would be the actual PDF content.

Standardized Code: {instrument.get('standardized_code', 'N/A')}
Category: {instrument.get('category', 'N/A')}
Language: {instrument.get('language', 'en')}

Tags: {', '.join(instrument.get('tags', []))}
Keywords: {', '.join(instrument.get('keywords', []))}
"""
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)
                
        elif file_format == "wmv":
            # Create a placeholder for video file
            content = f"Sample video content for: {instrument['title']}\nThis would be actual WMV video data."
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)
                
        elif file_format == "wma":
            # Create a placeholder for audio file
            content = f"Sample audio content for: {instrument['title']}\nThis would be actual WMA audio data."
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)
                
        else:
            # Default text content
            content = f"Content for: {instrument['title']}\n\n{instrument.get('detailed_description', '')}"
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)
    
    # Determine content type
    content_type_map = {
        "pdf": "application/pdf",
        "wmv": "video/x-ms-wmv", 
        "wma": "audio/x-ms-wma",
        "epub": "application/epub+zip",
        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "txt": "text/plain"
    }
    
    content_type = content_type_map.get(file_format, "application/octet-stream")
    
    # Record view activity
    await create_user_activity(current_user.id, "file_view", {
        "instrument_id": instrument_id,
        "instrument_title": instrument["title"],
        "file_format": file_format
    })
    
    return FileResponse(
        path=str(file_path),
        filename=f"{instrument['title']}.{file_format}",
        media_type=content_type
    )

@api_router.get("/template-library/{instrument_id}/download")
async def download_instrument_file(
    instrument_id: str,
    current_user: User = Depends(get_current_user)
):
    """Download the financial instrument file"""
    instrument = await db.template_library.find_one({"id": instrument_id, "status": "active"})
    
    if not instrument:
        raise HTTPException(status_code=404, detail="Financial instrument not found")
    
    # Get file path (reuse the same logic as file serving)
    file_path = instrument.get("file_path", "")
    
    # Create sample file if it doesn't exist (same as above)
    if not file_path or not os.path.exists(file_path):
        uploads_dir = Path("/app/uploads/library")
        uploads_dir.mkdir(parents=True, exist_ok=True)
        
        file_format = instrument.get("file_format", "pdf").lower()
        filename = f"{instrument_id}.{file_format}"
        file_path = uploads_dir / filename
        
        # Create sample content
        if file_format == "pdf":
            content = f"""Financial Instrument Document: {instrument['title']}

{instrument.get('detailed_description', '')}

Authors: {', '.join(instrument.get('authors', []))}
Publisher: {instrument.get('publisher', 'N/A')}

This document can be cited as:
{', '.join(instrument.get('authors', ['Unknown Author']))} ({instrument.get('publication_date', 'n.d.').split('-')[0] if instrument.get('publication_date') else 'n.d.'}). {instrument['title']}. {instrument.get('publisher', 'Unknown Publisher')}.

Standardized Code: {instrument.get('standardized_code', 'N/A')}
"""
        else:
            content = f"Financial Instrument: {instrument['title']}\n{instrument.get('description', '')}"
            
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)
    
    # Update download count
    await db.template_library.update_one(
        {"id": instrument_id},
        {"$inc": {"downloads": 1, "usage_count": 1}}
    )
    
    # Record download activity
    await create_user_activity(current_user.id, "download", {
        "instrument_id": instrument_id,
        "instrument_title": instrument["title"],
        "file_format": instrument.get("file_format", "unknown")
    })
    
    # Determine content type
    file_format = instrument.get("file_format", "pdf").lower()
    content_type_map = {
        "pdf": "application/pdf",
        "wmv": "video/x-ms-wmv",
        "wma": "audio/x-ms-wma", 
        "epub": "application/epub+zip",
        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    }
    
    content_type = content_type_map.get(file_format, "application/octet-stream")
    
    return FileResponse(
        path=str(file_path),
        filename=f"{instrument['title']}.{file_format}",
        media_type=content_type,
        headers={"Content-Disposition": f"attachment; filename=\"{instrument['title']}.{file_format}\""}
    )

# Citation & Reference Management APIs (Missing Feature Implementation)
@api_router.get("/template-library/{instrument_id}/citation")
async def get_citation_formats(
    instrument_id: str,
    format: str = "apa",  # apa, mla, chicago, harvard, vancouver
    current_user: User = Depends(get_current_user)
):
    """Generate citation in various academic formats"""
    instrument = await db.template_library.find_one({"id": instrument_id, "status": "active"})
    
    if not instrument:
        raise HTTPException(status_code=404, detail="Financial instrument not found")
    
    # Generate citation based on format
    citations = {
        "apa": generate_apa_citation(instrument),
        "mla": generate_mla_citation(instrument),
        "chicago": generate_chicago_citation(instrument),
        "harvard": generate_harvard_citation(instrument),
        "vancouver": generate_vancouver_citation(instrument)
    }
    
    if format in citations:
        return {"format": format, "citation": citations[format], "all_formats": citations}
    else:
        return {"format": "all", "citations": citations}

def generate_apa_citation(instrument):
    """Generate APA format citation"""
    authors = ", ".join(instrument.get("authors", ["Unknown Author"]))
    year = instrument.get("publication_date", "n.d.").split("-")[0] if instrument.get("publication_date") else "n.d."
    title = instrument.get("title", "Untitled")
    publisher = instrument.get("publisher", "Unknown Publisher")
    
    if instrument.get("content_type") == "bibliography":
        return f"{authors} ({year}). {title}. {publisher}."
    elif instrument.get("journal_name"):
        return f"{authors} ({year}). {title}. {instrument.get('journal_name')}, {instrument.get('volume_issue', '')}."
    else:
        return f"{authors} ({year}). {title}. {publisher}."

def generate_mla_citation(instrument):
    """Generate MLA format citation"""
    authors = ", ".join(instrument.get("authors", ["Unknown Author"]))
    title = f'"{instrument.get("title", "Untitled")}"'
    publisher = instrument.get("publisher", "Unknown Publisher")
    year = instrument.get("publication_date", "n.d.").split("-")[0] if instrument.get("publication_date") else "n.d."
    
    return f'{authors}. {title} {publisher}, {year}.'

def generate_chicago_citation(instrument):
    """Generate Chicago format citation"""
    authors = ", ".join(instrument.get("authors", ["Unknown Author"]))
    title = f'"{instrument.get("title", "Untitled")}"'
    publisher = instrument.get("publisher", "Unknown Publisher")
    year = instrument.get("publication_date", "n.d.").split("-")[0] if instrument.get("publication_date") else "n.d."
    
    return f'{authors}. {title} {publisher}, {year}.'

def generate_harvard_citation(instrument):
    """Generate Harvard format citation"""
    authors = ", ".join(instrument.get("authors", ["Unknown Author"]))
    year = instrument.get("publication_date", "n.d.").split("-")[0] if instrument.get("publication_date") else "n.d."
    title = instrument.get("title", "Untitled")
    publisher = instrument.get("publisher", "Unknown Publisher")
    
    return f'{authors} {year}, "{title}", {publisher}.'

def generate_vancouver_citation(instrument):
    """Generate Vancouver format citation"""
    authors = ", ".join(instrument.get("authors", ["Unknown Author"]))
    title = instrument.get("title", "Untitled")
    publisher = instrument.get("publisher", "Unknown Publisher")
    year = instrument.get("publication_date", "n.d.").split("-")[0] if instrument.get("publication_date") else "n.d."
    
    return f'{authors}. {title}. {publisher}; {year}.'

@api_router.post("/template-library/{instrument_id}/annotations")
async def create_annotation(
    instrument_id: str,
    annotation_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Create user annotation for a financial instrument"""
    annotation = {
        "id": str(uuid.uuid4()),
        "instrument_id": instrument_id,
        "user_id": current_user.id,
        "annotation_type": annotation_data.get("type", "note"),  # note, highlight, bookmark
        "content": annotation_data["content"],
        "page_number": annotation_data.get("page_number"),
        "position": annotation_data.get("position", {}),  # x, y coordinates for highlights
        "color": annotation_data.get("color", "yellow"),
        "is_private": annotation_data.get("is_private", True),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.user_annotations.insert_one(annotation)
    
    if '_id' in annotation:
        del annotation['_id']
    
    return annotation

@api_router.get("/template-library/{instrument_id}/annotations")
async def get_user_annotations(
    instrument_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get user's annotations for a financial instrument"""
    annotations = await db.user_annotations.find({
        "instrument_id": instrument_id,
        "user_id": current_user.id
    }).to_list(length=None)
    
    for annotation in annotations:
        if '_id' in annotation:
            del annotation['_id']
    
    return annotations

@api_router.post("/template-library/{instrument_id}/reading-session")
async def create_reading_session(
    instrument_id: str,
    session_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Track reading session for analytics"""
    session = {
        "id": str(uuid.uuid4()),
        "user_id": current_user.id,
        "instrument_id": instrument_id,
        "start_time": session_data.get("start_time", datetime.now(timezone.utc).isoformat()),
        "end_time": session_data.get("end_time"),
        "pages_read": session_data.get("pages_read", 0),
        "reading_time_minutes": session_data.get("reading_time_minutes", 0),
        "completion_percentage": session_data.get("completion_percentage", 0),
        "device_type": session_data.get("device_type", "web"),
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.reading_sessions.insert_one(session)
    
    # Update user reading statistics
    await db.user_reading_stats.update_one(
        {"user_id": current_user.id},
        {
            "$inc": {
                "total_reading_time": session.get("reading_time_minutes", 0),
                "documents_read": 1 if session.get("completion_percentage", 0) > 90 else 0,
                "total_sessions": 1
            },
            "$set": {"last_read_at": datetime.now(timezone.utc).isoformat()}
        },
        upsert=True
    )
    
    if '_id' in session:
        del session['_id']
    
    return session

@api_router.get("/template-library/reading-statistics")
async def get_reading_statistics(current_user: User = Depends(get_current_user)):
    """Get user's reading statistics and achievements"""
    stats = await db.user_reading_stats.find_one({"user_id": current_user.id})
    
    if not stats:
        stats = {
            "user_id": current_user.id,
            "total_reading_time": 0,
            "documents_read": 0,
            "total_sessions": 0,
            "last_read_at": None
        }
    
    # Calculate achievements/badges
    achievements = []
    if stats.get("total_reading_time", 0) > 60:  # 1 hour
        achievements.append({"name": "Dedicated Reader", "icon": "📚", "description": "Read for over 1 hour"})
    if stats.get("documents_read", 0) >= 5:
        achievements.append({"name": "Knowledge Seeker", "icon": "🎓", "description": "Completed 5 documents"})
    if stats.get("total_sessions", 0) >= 10:
        achievements.append({"name": "Regular User", "icon": "⭐", "description": "10+ reading sessions"})
    
    if '_id' in stats:
        del stats['_id']
    
    return {
        "statistics": stats,
        "achievements": achievements,
        "reading_goals": {
            "weekly_target": 300,  # 5 hours
            "monthly_target": 1200,  # 20 hours
            "current_week_progress": min(100, (stats.get("total_reading_time", 0) % 300) / 3),
            "current_month_progress": min(100, (stats.get("total_reading_time", 0) % 1200) / 12)
        }
    }

# Notification System APIs (Missing Feature Implementation)
@api_router.post("/template-library/notifications/subscribe")
async def subscribe_to_notifications(
    subscription_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Subscribe to notifications for specific categories or keywords"""
    subscription = {
        "id": str(uuid.uuid4()),
        "user_id": current_user.id,
        "notification_type": subscription_data["type"],  # new_content, discussions, citations
        "categories": subscription_data.get("categories", []),
        "keywords": subscription_data.get("keywords", []),
        "frequency": subscription_data.get("frequency", "immediate"),  # immediate, daily, weekly
        "is_active": True,
        "created_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.notification_subscriptions.insert_one(subscription)
    
    if '_id' in subscription:
        del subscription['_id']
    
    return subscription

@api_router.get("/template-library/notifications")
async def get_user_notifications(
    current_user: User = Depends(get_current_user),
    unread_only: bool = False
):
    """Get user notifications"""
    query = {"user_id": current_user.id}
    if unread_only:
        query["is_read"] = False
    
    notifications = await db.user_notifications.find(query).sort("created_at", -1).limit(50).to_list(length=50)
    
    for notification in notifications:
        if '_id' in notification:
            del notification['_id']
    
    return notifications

# User Personalization APIs for Financial Instruments Library
@api_router.post("/template-library/{instrument_id}/bookmark")
async def bookmark_instrument(
    instrument_id: str,
    current_user: User = Depends(get_current_user)
):
    """Add/remove bookmark for a financial instrument"""
    # Check if bookmark already exists
    existing_bookmark = await db.user_bookmarks.find_one({
        "user_id": current_user.id,
        "instrument_id": instrument_id
    })
    
    if existing_bookmark:
        # Remove bookmark
        await db.user_bookmarks.delete_one({
            "user_id": current_user.id,
            "instrument_id": instrument_id
        })
        
        # Decrease bookmark count
        await db.template_library.update_one(
            {"id": instrument_id},
            {"$inc": {"bookmarks": -1}}
        )
        
        return {"message": "Bookmark removed", "bookmarked": False}
    else:
        # Add bookmark
        bookmark = {
            "id": str(uuid.uuid4()),
            "user_id": current_user.id,
            "instrument_id": instrument_id,
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        
        await db.user_bookmarks.insert_one(bookmark)
        
        # Increase bookmark count
        await db.template_library.update_one(
            {"id": instrument_id},
            {"$inc": {"bookmarks": 1}}
        )
        
        return {"message": "Bookmark added", "bookmarked": True}

@api_router.get("/template-library/bookmarks")
async def get_user_bookmarks(current_user: User = Depends(get_current_user)):
    """Get user's bookmarked financial instruments"""
    bookmarks = await db.user_bookmarks.find({"user_id": current_user.id}).to_list(length=None)
    instrument_ids = [bookmark["instrument_id"] for bookmark in bookmarks]
    
    if not instrument_ids:
        return []
    
    instruments = await db.template_library.find(
        {"id": {"$in": instrument_ids}, "status": "active"}
    ).to_list(length=None)
    
    for instrument in instruments:
        if '_id' in instrument:
            del instrument['_id']
    
    return instruments

@api_router.post("/template-library/{instrument_id}/reading-progress")
async def update_reading_progress(
    instrument_id: str,
    progress_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Update user's reading progress for an instrument"""
    progress = {
        "user_id": current_user.id,
        "instrument_id": instrument_id,
        "progress_percentage": progress_data.get("progress_percentage", 0),
        "last_position": progress_data.get("last_position", ""),
        "reading_time_minutes": progress_data.get("reading_time_minutes", 0),
        "completed": progress_data.get("completed", False),
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.user_reading_progress.update_one(
        {"user_id": current_user.id, "instrument_id": instrument_id},
        {"$set": progress},
        upsert=True
    )
    
    return {"message": "Reading progress updated"}

@api_router.get("/template-library/reading-progress")
async def get_reading_progress(current_user: User = Depends(get_current_user)):
    """Get user's reading progress for all instruments"""
    progress_list = await db.user_reading_progress.find({"user_id": current_user.id}).to_list(length=None)
    
    for progress in progress_list:
        if '_id' in progress:
            del progress['_id']
    
    return progress_list

@api_router.get("/template-library/personalized-recommendations")
async def get_personalized_recommendations(current_user: User = Depends(get_current_user)):
    """Get personalized recommendations based on user activity"""
    # Get user's bookmarks and reading history
    user_bookmarks = await db.user_bookmarks.find({"user_id": current_user.id}).to_list(length=None)
    user_progress = await db.user_reading_progress.find({"user_id": current_user.id}).to_list(length=None)
    
    # Extract categories and content types from user's interaction history
    interacted_instruments = []
    if user_bookmarks:
        bookmark_ids = [b["instrument_id"] for b in user_bookmarks]
        bookmarked_instruments = await db.template_library.find(
            {"id": {"$in": bookmark_ids}}
        ).to_list(length=None)
        interacted_instruments.extend(bookmarked_instruments)
    
    if user_progress:
        progress_ids = [p["instrument_id"] for p in user_progress]
        read_instruments = await db.template_library.find(
            {"id": {"$in": progress_ids}}
        ).to_list(length=None)
        interacted_instruments.extend(read_instruments)
    
    # Find similar instruments based on categories and content types
    if interacted_instruments:
        user_categories = list(set([inst.get("category") for inst in interacted_instruments if inst.get("category")]))
        user_content_types = list(set([inst.get("content_type") for inst in interacted_instruments if inst.get("content_type")]))
        
        # Get recommendations
        recommendations = await db.template_library.find({
            "status": "active",
            "$or": [
                {"category": {"$in": user_categories}},
                {"content_type": {"$in": user_content_types}}
            ],
            "id": {"$nin": [inst.get("id") for inst in interacted_instruments if inst.get("id")]}
        }).limit(10).to_list(length=None)
    else:
        # For new users, recommend popular instruments
        recommendations = await db.template_library.find(
            {"status": "active"}
        ).sort([("downloads", -1), ("rating", -1)]).limit(10).to_list(length=None)
    
    for rec in recommendations:
        if '_id' in rec:
            del rec['_id']
    
    return recommendations

@api_router.post("/template-library/{instrument_id}/view")
async def record_view(
    instrument_id: str,
    current_user: User = Depends(get_current_user)
):
    """Record a view for analytics"""
    await db.template_library.update_one(
        {"id": instrument_id},
        {"$inc": {"view_count": 1}}
    )
    
    # Record individual user view for analytics
    view_record = {
        "id": str(uuid.uuid4()),
        "user_id": current_user.id,
        "instrument_id": instrument_id,
        "viewed_at": datetime.now(timezone.utc).isoformat()
    }
    
    await db.instrument_views.insert_one(view_record)
    
    return {"message": "View recorded"}

@api_router.get("/template-library/analytics")
async def get_library_analytics(current_user: User = Depends(get_current_user)):
    """Get template library analytics (admin only)"""
    if current_user.role != UserRole.ADMINISTRATOR:
        raise HTTPException(status_code=403, detail="Only administrators can view analytics")
    
    templates = await db.template_library.find({"status": "active"}).to_list(length=None)
    
    total_templates = len(templates)
    total_downloads = sum([t.get("downloads", 0) for t in templates])
    category_distribution = {}
    content_type_distribution = {}
    
    for template in templates:
        # Category distribution
        category = template.get("category", "other")
        category_distribution[category] = category_distribution.get(category, 0) + 1
        
        # Content type distribution
        content_type = template.get("content_type", "document")
        content_type_distribution[content_type] = content_type_distribution.get(content_type, 0) + 1
    
    # Most popular templates
    popular_templates = sorted(templates, key=lambda x: x.get("downloads", 0), reverse=True)[:5]
    
    # Recent uploads
    recent_templates = sorted(templates, key=lambda x: x.get("created_at", ""), reverse=True)[:5]
    
    return {
        "total_templates": total_templates,
        "total_downloads": total_downloads,
        "category_distribution": category_distribution,
        "content_type_distribution": content_type_distribution,
        "popular_templates": popular_templates,
        "recent_templates": recent_templates,
        "average_rating": round(sum([t.get("rating", 0) for t in templates]) / len(templates), 2) if templates else 0
    }

# =============================================================================
# PERSONALIZATION FEATURES - Reading History, Notes, Recommendations, Profile
# =============================================================================

# A) USER READING HISTORY & PROGRESS TRACKING
@api_router.post("/user/reading-history/{instrument_id}")
async def track_reading_progress(
    instrument_id: str, 
    progress_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Track user's reading progress for an instrument"""
    try:
        reading_entry = {
            "id": str(uuid.uuid4()),
            "user_id": current_user.id,
            "instrument_id": instrument_id,
            "progress_percentage": progress_data.get("progress_percentage", 0),
            "time_spent_seconds": progress_data.get("time_spent_seconds", 0),
            "last_position": progress_data.get("last_position", ""),
            "completed": progress_data.get("completed", False),
            "last_accessed": datetime.now(timezone.utc),
            "created_at": datetime.now(timezone.utc)
        }
        
        # Update existing or create new reading history
        existing = await db.user_reading_history.find_one({
            "user_id": current_user.id, 
            "instrument_id": instrument_id
        })
        
        if existing:
            await db.user_reading_history.update_one(
                {"user_id": current_user.id, "instrument_id": instrument_id},
                {"$set": reading_entry}
            )
        else:
            await db.user_reading_history.insert_one(reading_entry)
        
        return {"message": "Reading progress updated", "progress": reading_entry}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/user/reading-history")
async def get_user_reading_history(current_user: User = Depends(get_current_user)):
    """Get user's complete reading history"""
    try:
        history = await db.user_reading_history.find({
            "user_id": current_user.id
        }).sort("last_accessed", -1).to_list(100)
        
        # Clean MongoDB ObjectIds and enrich with instrument details
        for entry in history:
            if '_id' in entry:
                del entry['_id']
            instrument = await db.template_library.find_one({"id": entry["instrument_id"]})
            if instrument:
                entry["instrument_title"] = instrument.get("title", "Unknown")
                entry["instrument_category"] = instrument.get("category", "")
        
        return history
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/user/reading-progress/{instrument_id}")
async def get_reading_progress(
    instrument_id: str, 
    current_user: User = Depends(get_current_user)
):
    """Get user's reading progress for specific instrument"""
    try:
        progress = await db.user_reading_history.find_one({
            "user_id": current_user.id,
            "instrument_id": instrument_id
        })
        if progress and '_id' in progress:
            del progress['_id']
        return progress or {"progress_percentage": 0, "completed": False}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# B) PERSONAL NOTES & ANNOTATIONS
@api_router.post("/user/notes/{instrument_id}")
async def create_user_note(
    instrument_id: str,
    note_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Create a personal note/annotation for an instrument"""
    try:
        note = {
            "id": str(uuid.uuid4()),
            "user_id": current_user.id,
            "instrument_id": instrument_id,
            "content": note_data.get("content", ""),
            "highlight_text": note_data.get("highlight_text", ""),
            "page_number": note_data.get("page_number", 0),
            "position": note_data.get("position", {}),
            "note_type": note_data.get("note_type", "general"),  # general, highlight, bookmark
            "tags": note_data.get("tags", []),
            "is_private": note_data.get("is_private", True),
            "created_at": datetime.now(timezone.utc),
            "updated_at": datetime.now(timezone.utc)
        }
        
        await db.user_notes.insert_one(note)
        # Remove MongoDB ObjectId before returning
        if '_id' in note:
            del note['_id']
        return {"message": "Note created successfully", "note": note}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/user/notes/{instrument_id}")
async def get_user_notes(
    instrument_id: str,
    current_user: User = Depends(get_current_user)
):
    """Get user's notes for specific instrument"""
    try:
        notes = await db.user_notes.find({
            "user_id": current_user.id,
            "instrument_id": instrument_id
        }).sort("created_at", -1).to_list(100)
        # Clean MongoDB ObjectIds
        for note in notes:
            if '_id' in note:
                del note['_id']
        return notes
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/user/notes")
async def get_all_user_notes(current_user: User = Depends(get_current_user)):
    """Get all user's notes across all instruments"""
    try:
        notes = await db.user_notes.find({
            "user_id": current_user.id
        }).sort("created_at", -1).to_list(200)
        
        # Clean MongoDB ObjectIds and enrich with instrument details
        for note in notes:
            if '_id' in note:
                del note['_id']
            instrument = await db.template_library.find_one({"id": note["instrument_id"]})
            if instrument:
                note["instrument_title"] = instrument.get("title", "Unknown")
        
        return notes
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.put("/user/notes/{note_id}")
async def update_user_note(
    note_id: str,
    note_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Update user's note"""
    try:
        update_data = {
            "content": note_data.get("content"),
            "tags": note_data.get("tags", []),
            "updated_at": datetime.now(timezone.utc)
        }
        
        result = await db.user_notes.update_one(
            {"id": note_id, "user_id": current_user.id},
            {"$set": update_data}
        )
        
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="Note not found")
        
        return {"message": "Note updated successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.delete("/user/notes/{note_id}")
async def delete_user_note(
    note_id: str,
    current_user: User = Depends(get_current_user)
):
    """Delete user's note"""
    try:
        result = await db.user_notes.delete_one({
            "id": note_id, 
            "user_id": current_user.id
        })
        
        if result.deleted_count == 0:
            raise HTTPException(status_code=404, detail="Note not found")
        
        return {"message": "Note deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# C) PERSONALIZED RECOMMENDATIONS
@api_router.get("/user/recommendations")
async def get_personalized_recommendations(current_user: User = Depends(get_current_user)):
    """Get personalized instrument recommendations based on user behavior"""
    try:
        # Get user's reading history and bookmarks
        reading_history = await db.user_reading_history.find({
            "user_id": current_user.id
        }).to_list(50)
        
        bookmarks = await db.user_bookmarks.find({
            "user_id": current_user.id
        }).to_list(50)
        
        # Get user's preferred categories from history
        read_instruments = [entry["instrument_id"] for entry in reading_history]
        bookmarked_instruments = [bookmark["instrument_id"] for bookmark in bookmarks]
        
        interested_instruments = list(set(read_instruments + bookmarked_instruments))
        
        recommendations = []
        
        if interested_instruments:
            # Get categories of instruments user has interacted with
            user_instruments = await db.template_library.find({
                "id": {"$in": interested_instruments}
            }).to_list(100)
            
            # Clean MongoDB ObjectIds
            for inst in user_instruments:
                if '_id' in inst:
                    del inst['_id']
            
            user_categories = list(set([inst.get("category") for inst in user_instruments if inst.get("category")]))
            user_content_types = list(set([inst.get("content_type") for inst in user_instruments if inst.get("content_type")]))
            
            # Find similar instruments user hasn't seen
            similar_instruments = await db.template_library.find({
                "$and": [
                    {"id": {"$nin": interested_instruments}},
                    {"$or": [
                        {"category": {"$in": user_categories}},
                        {"content_type": {"$in": user_content_types}},
                        {"tags": {"$in": [tag for inst in user_instruments for tag in inst.get("tags", [])]}},
                    ]}
                ]
            }).sort("rating", -1).limit(10).to_list(10)
            
            # Clean MongoDB ObjectIds
            for inst in similar_instruments:
                if '_id' in inst:
                    del inst['_id']
            
            recommendations.extend(similar_instruments)
        
        # Add role-based recommendations
        role_recommendations = []
        if current_user.role == "investor":
            role_recommendations = await db.template_library.find({
                "$or": [
                    {"category": {"$in": ["economic_development", "impact_investment"]}},
                    {"tags": {"$in": ["roi", "investment", "returns", "financial"]}},
                    {"content_type": "financial_instrument"}
                ]
            }).sort("downloads", -1).limit(5).to_list(5)
        elif current_user.role == "social_actor":
            role_recommendations = await db.template_library.find({
                "$or": [
                    {"category": {"$in": ["education", "healthcare", "social_services"]}},
                    {"tags": {"$in": ["community", "social_impact", "beneficiaries"]}},
                    {"complexity_level": {"$in": ["beginner", "medium"]}}
                ]
            }).sort("rating", -1).limit(5).to_list(5)
        
        # Clean MongoDB ObjectIds from role recommendations
        for rec in role_recommendations:
            if '_id' in rec:
                del rec['_id']
        
        # Combine and deduplicate recommendations
        all_recommendations = recommendations + role_recommendations
        seen_ids = set()
        unique_recommendations = []
        for rec in all_recommendations:
            if rec["id"] not in seen_ids:
                seen_ids.add(rec["id"])
                unique_recommendations.append(rec)
        
        # Add trending items if we don't have enough recommendations
        if len(unique_recommendations) < 8:
            trending = await db.template_library.find({
                "id": {"$nin": list(seen_ids)}
            }).sort("view_count", -1).limit(8 - len(unique_recommendations)).to_list(10)
            # Clean MongoDB ObjectIds from trending
            for trend in trending:
                if '_id' in trend:
                    del trend['_id']
            unique_recommendations.extend(trending)
        
        return {
            "recommendations": unique_recommendations[:8],
            "recommendation_reason": {
                "based_on_reading": len(read_instruments),
                "based_on_bookmarks": len(bookmarked_instruments),
                "role_based": current_user.role,
                "categories_of_interest": user_categories if 'user_categories' in locals() else []
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# D) ENHANCED USER PROFILE & PREFERENCES
@api_router.get("/user/profile")
async def get_user_profile(current_user: User = Depends(get_current_user)):
    """Get enhanced user profile with statistics and preferences"""
    try:
        # Get reading statistics
        reading_stats = await db.user_reading_history.aggregate([
            {"$match": {"user_id": current_user.id}},
            {"$group": {
                "_id": None,
                "total_instruments_read": {"$sum": 1},
                "completed_instruments": {"$sum": {"$cond": [{"$eq": ["$completed", True]}, 1, 0]}},
                "total_reading_time": {"$sum": "$time_spent_seconds"},
                "avg_progress": {"$avg": "$progress_percentage"}
            }}
        ]).to_list(1)
        
        # Get bookmark count
        bookmark_count = await db.user_bookmarks.count_documents({"user_id": current_user.id})
        
        # Get notes count
        notes_count = await db.user_notes.count_documents({"user_id": current_user.id})
        
        # Get user preferences
        preferences = await db.user_preferences.find_one({"user_id": current_user.id})
        if preferences and '_id' in preferences:
            del preferences['_id']
        
        # Get favorite categories from reading history
        category_stats = await db.user_reading_history.aggregate([
            {"$match": {"user_id": current_user.id}},
            {"$lookup": {
                "from": "template_library",
                "localField": "instrument_id", 
                "foreignField": "id",
                "as": "instrument"
            }},
            {"$unwind": "$instrument"},
            {"$group": {
                "_id": "$instrument.category",
                "count": {"$sum": 1},
                "avg_progress": {"$avg": "$progress_percentage"}
            }},
            {"$sort": {"count": -1}},
            {"$limit": 5}
        ]).to_list(5)
        
        # Clean MongoDB ObjectIds from category stats
        for stat in category_stats:
            if '_id' in stat:
                del stat['_id']
        
        stats = reading_stats[0] if reading_stats else {}
        
        profile = {
            "user_info": {
                "id": current_user.id,
                "username": current_user.username,
                "email": current_user.email,
                "role": current_user.role,
                "organization": current_user.organization_name,
                "joined_date": current_user.created_at
            },
            "reading_statistics": {
                "total_instruments_accessed": stats.get("total_instruments_read", 0),
                "completed_instruments": stats.get("completed_instruments", 0),
                "total_reading_time_hours": round((stats.get("total_reading_time", 0) / 3600), 2),
                "average_completion_rate": round(stats.get("avg_progress", 0), 1),
                "bookmarks_count": bookmark_count,
                "notes_count": notes_count
            },
            "favorite_categories": category_stats,
            "preferences": preferences or {
                "preferred_languages": ["en"],
                "preferred_categories": [],
                "notification_settings": {
                    "new_instruments": True,
                    "recommendations": True,
                    "discussion_replies": True
                },
                "display_preferences": {
                    "items_per_page": 12,
                    "view_mode": "grid",
                    "sort_default": "newest"
                }
            }
        }
        
        return profile
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.put("/user/preferences")
async def update_user_preferences(
    preferences_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Update user preferences"""
    try:
        preferences = {
            "user_id": current_user.id,
            "preferred_languages": preferences_data.get("preferred_languages", ["en"]),
            "preferred_categories": preferences_data.get("preferred_categories", []),
            "notification_settings": preferences_data.get("notification_settings", {}),
            "display_preferences": preferences_data.get("display_preferences", {}),
            "updated_at": datetime.now(timezone.utc)
        }
        
        # Update existing or create new preferences
        await db.user_preferences.update_one(
            {"user_id": current_user.id},
            {"$set": preferences},
            upsert=True
        )
        
        return {"message": "Preferences updated successfully", "preferences": preferences}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/user/dashboard")
async def get_personalized_dashboard(current_user: User = Depends(get_current_user)):
    """Get personalized dashboard data"""
    try:
        # Recently read instruments
        recent_reading = await db.user_reading_history.find({
            "user_id": current_user.id
        }).sort("last_accessed", -1).limit(5).to_list(5)
        
        # Continue reading (incomplete items)
        continue_reading = await db.user_reading_history.find({
            "user_id": current_user.id,
            "completed": False,
            "progress_percentage": {"$gt": 0}
        }).sort("last_accessed", -1).limit(3).to_list(3)
        
        # Recent notes
        recent_notes = await db.user_notes.find({
            "user_id": current_user.id
        }).sort("created_at", -1).limit(3).to_list(3)
        
        # Clean MongoDB ObjectIds and enrich with instrument details
        for item in recent_reading + continue_reading + recent_notes:
            if '_id' in item:
                del item['_id']
            if "instrument_id" in item:
                instrument = await db.template_library.find_one({"id": item["instrument_id"]})
                if instrument:
                    item["instrument_title"] = instrument.get("title", "Unknown")
                    item["instrument_category"] = instrument.get("category", "")
        
        return {
            "recent_reading": recent_reading,
            "continue_reading": continue_reading,
            "recent_notes": recent_notes,
            "quick_stats": {
                "instruments_this_week": await db.user_reading_history.count_documents({
                    "user_id": current_user.id,
                    "last_accessed": {"$gte": datetime.now(timezone.utc) - timedelta(days=7)}
                }),
                "total_bookmarks": await db.user_bookmarks.count_documents({"user_id": current_user.id}),
                "total_notes": await db.user_notes.count_documents({"user_id": current_user.id})
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# USER GUIDES & DOCUMENTATION ENDPOINTS
# =============================================================================

@api_router.get("/user-guides")
async def get_user_guides():
    """Get list of available user guides"""
    try:
        guides = [
            {
                "id": "admin",
                "title": "Administrator User Guide",
                "description": "Complete guide for platform administrators with content management and system administration",
                "filename": "USER_GUIDE_ADMINISTRATOR.md",
                "role": "administrator",
                "pages": "15+ pages",
                "updated": "2025-10-03"
            },
            {
                "id": "investor", 
                "title": "Investor User Guide",
                "description": "Investment-focused guide with portfolio management, ROI tracking, and due diligence tools",
                "filename": "USER_GUIDE_INVESTOR.md", 
                "role": "investor",
                "pages": "12+ pages",
                "updated": "2025-10-03"
            },
            {
                "id": "social_actor",
                "title": "Social Actor User Guide", 
                "description": "Community-focused guide with beneficiary tracking, impact measurement, and program management",
                "filename": "USER_GUIDE_SOCIAL_ACTOR.md",
                "role": "social_actor", 
                "pages": "14+ pages",
                "updated": "2025-10-03"
            },
            {
                "id": "master",
                "title": "Platform Master Guide",
                "description": "Comprehensive overview comparing all roles with platform-wide features",
                "filename": "PLATFORM_USER_GUIDES_MASTER.md",
                "role": "all",
                "pages": "20+ pages", 
                "updated": "2025-10-03"
            },
            {
                "id": "quick_reference",
                "title": "Quick Reference Card",
                "description": "Fast access credentials, key features summary, and troubleshooting guide",
                "filename": "QUICK_REFERENCE_CARD.md",
                "role": "all",
                "pages": "4 pages",
                "updated": "2025-10-03"
            }
        ]
        return guides
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/user-guides/{guide_id}")
async def get_user_guide_content(guide_id: str):
    """Get user guide content"""
    try:
        guide_files = {
            "admin": "USER_GUIDE_ADMINISTRATOR.md",
            "investor": "USER_GUIDE_INVESTOR.md", 
            "social_actor": "USER_GUIDE_SOCIAL_ACTOR.md",
            "master": "PLATFORM_USER_GUIDES_MASTER.md",
            "quick_reference": "QUICK_REFERENCE_CARD.md"
        }
        
        if guide_id not in guide_files:
            raise HTTPException(status_code=404, detail="Guide not found")
            
        file_path = f"/app/{guide_files[guide_id]}"
        
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
                
            return {
                "id": guide_id,
                "filename": guide_files[guide_id],
                "content": content,
                "format": "markdown"
            }
        except FileNotFoundError:
            raise HTTPException(status_code=404, detail="Guide file not found")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/user-guides/{guide_id}/download")
async def download_user_guide(guide_id: str, format: str = "markdown"):
    """Download user guide in specified format"""
    try:
        guide_files = {
            "admin": "USER_GUIDE_ADMINISTRATOR.md",
            "investor": "USER_GUIDE_INVESTOR.md",
            "social_actor": "USER_GUIDE_SOCIAL_ACTOR.md", 
            "master": "PLATFORM_USER_GUIDES_MASTER.md",
            "quick_reference": "QUICK_REFERENCE_CARD.md"
        }
        
        if guide_id not in guide_files:
            raise HTTPException(status_code=404, detail="Guide not found")
            
        file_path = f"/app/{guide_files[guide_id]}"
        
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
        except FileNotFoundError:
            raise HTTPException(status_code=404, detail="Guide file not found")
        
        # Return content for download
        filename = guide_files[guide_id]
        
        if format == "txt":
            # Convert markdown to plain text (remove markdown syntax)
            import re
            # Remove markdown headers
            plain_text = re.sub(r'^#{1,6}\s*', '', content, flags=re.MULTILINE)
            # Remove bold and italic
            plain_text = re.sub(r'\*\*(.*?)\*\*', r'\1', plain_text)
            plain_text = re.sub(r'\*(.*?)\*', r'\1', plain_text)
            # Remove code blocks
            plain_text = re.sub(r'`(.*?)`', r'\1', plain_text)
            # Remove links
            plain_text = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', plain_text)
            # Clean up extra whitespace
            plain_text = re.sub(r'\n\s*\n', '\n\n', plain_text)
            # Remove remaining markdown characters
            plain_text = re.sub(r'[>-]', '', plain_text)
            
            return Response(
                content=plain_text,
                media_type="text/plain",
                headers={"Content-Disposition": f"attachment; filename={filename.replace('.md', '.txt')}"}
            )
        elif format == "html":
            # Convert markdown to HTML for better Word compatibility
            import re
            html_content = content
            # Convert headers
            html_content = re.sub(r'^# (.*$)', r'<h1>\1</h1>', html_content, flags=re.MULTILINE)
            html_content = re.sub(r'^## (.*$)', r'<h2>\1</h2>', html_content, flags=re.MULTILINE)  
            html_content = re.sub(r'^### (.*$)', r'<h3>\1</h3>', html_content, flags=re.MULTILINE)
            # Convert bold and italic
            html_content = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', html_content)
            html_content = re.sub(r'\*(.*?)\*', r'<em>\1</em>', html_content)
            # Convert code
            html_content = re.sub(r'`(.*?)`', r'<code>\1</code>', html_content)
            # Convert links
            html_content = re.sub(r'\[([^\]]+)\]\(([^\)]+)\)', r'<a href="\2">\1</a>', html_content)
            # Convert line breaks
            html_content = html_content.replace('\n', '<br>\n')
            
            # Wrap in basic HTML structure
            full_html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{filename.replace('.md', '')}</title>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; margin: 40px; }}
        h1 {{ color: #2563eb; }}
        h2 {{ color: #1e40af; margin-top: 30px; }}
        h3 {{ color: #1e3a8a; }}
        code {{ background-color: #f3f4f6; padding: 2px 4px; border-radius: 3px; }}
    </style>
</head>
<body>
{html_content}
</body>
</html>"""
            
            return Response(
                content=full_html,
                media_type="text/html",
                headers={"Content-Disposition": f"attachment; filename={filename.replace('.md', '.html')}"}
            )
        else:
            # Return as markdown
            return Response(
                content=content,
                media_type="text/markdown", 
                headers={"Content-Disposition": f"attachment; filename={filename}"}
            )
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# ADMIN USER MANAGEMENT & PLATFORM REPORTS
# =============================================================================

# USER MANAGEMENT ENDPOINTS (Admin Only)
@api_router.get("/admin/users")
async def get_all_users(current_user: User = Depends(get_current_user)):
    """Get all platform users (Admin only)"""
    if current_user.role != 'administrator':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        users = await db.users.find({}).to_list(1000)
        
        # Clean and enrich user data
        user_list = []
        for user in users:
            if '_id' in user:
                del user['_id']
            
            # Get user statistics
            user_stats = await db.user_reading_history.aggregate([
                {"$match": {"user_id": user["id"]}},
                {"$group": {
                    "_id": None,
                    "total_reads": {"$sum": 1},
                    "total_time": {"$sum": "$time_spent_seconds"},
                    "last_activity": {"$max": "$last_accessed"}
                }}
            ]).to_list(1)
            
            bookmark_count = await db.user_bookmarks.count_documents({"user_id": user["id"]})
            notes_count = await db.user_notes.count_documents({"user_id": user["id"]})
            
            stats = user_stats[0] if user_stats else {}
            
            user_data = {
                **user,
                "statistics": {
                    "total_reads": stats.get("total_reads", 0),
                    "total_time_hours": round((stats.get("total_time", 0) / 3600), 2),
                    "bookmarks_count": bookmark_count,
                    "notes_count": notes_count,
                    "last_activity": stats.get("last_activity")
                }
            }
            
            # Remove password hash
            if 'hashed_password' in user_data:
                del user_data['hashed_password']
                
            user_list.append(user_data)
        
        return {
            "total_users": len(user_list),
            "users": user_list
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.put("/admin/users/{user_id}")
async def update_user(
    user_id: str, 
    user_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Update user information (Admin only)"""
    if current_user.role != 'administrator':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        update_fields = {
            "username": user_data.get("username"),
            "email": user_data.get("email"),
            "role": user_data.get("role"),
            "organization_name": user_data.get("organization_name"),
            "is_active": user_data.get("is_active", True),
            "updated_at": datetime.now(timezone.utc)
        }
        
        # Remove None values
        update_fields = {k: v for k, v in update_fields.items() if v is not None}
        
        result = await db.users.update_one(
            {"id": user_id},
            {"$set": update_fields}
        )
        
        if result.matched_count == 0:
            raise HTTPException(status_code=404, detail="User not found")
        
        return {"message": "User updated successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.delete("/admin/users/{user_id}")
async def delete_user(
    user_id: str,
    current_user: User = Depends(get_current_user)
):
    """Delete user (Admin only)"""
    if current_user.role != 'administrator':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    if user_id == current_user.id:
        raise HTTPException(status_code=400, detail="Cannot delete your own account")
    
    try:
        # Delete user and all associated data
        await db.users.delete_one({"id": user_id})
        await db.user_reading_history.delete_many({"user_id": user_id})
        await db.user_bookmarks.delete_many({"user_id": user_id})
        await db.user_notes.delete_many({"user_id": user_id})
        await db.user_preferences.delete_many({"user_id": user_id})
        
        return {"message": "User and associated data deleted successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/admin/users")
async def create_user(
    user_data: dict,
    current_user: User = Depends(get_current_user)
):
    """Create new user (Admin only)"""
    if current_user.role != 'administrator':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        # Check if username or email already exists
        existing_user = await db.users.find_one({
            "$or": [
                {"username": user_data["username"]},
                {"email": user_data["email"]}
            ]
        })
        
        if existing_user:
            raise HTTPException(status_code=400, detail="Username or email already exists")
        
        # Create user
        hashed_password = pwd_context.hash(user_data["password"])
        
        new_user = {
            "id": str(uuid.uuid4()),
            "username": user_data["username"],
            "email": user_data["email"],
            "hashed_password": hashed_password,
            "role": user_data["role"],
            "organization_name": user_data.get("organization_name", ""),
            "is_active": user_data.get("is_active", True),
            "created_at": datetime.now(timezone.utc),
            "updated_at": datetime.now(timezone.utc)
        }
        
        await db.users.insert_one(new_user)
        
        # Remove password hash before returning
        del new_user['hashed_password']
        if '_id' in new_user:
            del new_user['_id']
        
        return {"message": "User created successfully", "user": new_user}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# PLATFORM REPORTS ENDPOINTS (Admin Only)
@api_router.get("/admin/reports/overview")
async def get_platform_overview_report(current_user: User = Depends(get_current_user)):
    """Get comprehensive platform overview report (Admin only)"""
    if current_user.role != 'administrator':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        # User statistics
        total_users = await db.users.count_documents({})
        active_users_week = await db.user_reading_history.distinct("user_id", {
            "last_accessed": {"$gte": datetime.now(timezone.utc) - timedelta(days=7)}
        })
        
        users_by_role = await db.users.aggregate([
            {"$group": {"_id": "$role", "count": {"$sum": 1}}}
        ]).to_list(10)
        
        # Content statistics
        total_instruments = await db.template_library.count_documents({})
        
        instruments_by_category = await db.template_library.aggregate([
            {"$group": {"_id": "$category", "count": {"$sum": 1}}}
        ]).to_list(20)
        
        # Activity statistics
        total_reads = await db.user_reading_history.count_documents({})
        total_downloads = await db.template_library.aggregate([
            {"$group": {"_id": None, "total": {"$sum": "$downloads"}}}
        ]).to_list(1)
        
        total_bookmarks = await db.user_bookmarks.count_documents({})
        total_notes = await db.user_notes.count_documents({})
        
        # Top content
        popular_instruments = await db.template_library.find({}).sort("view_count", -1).limit(5).to_list(5)
        for instrument in popular_instruments:
            if '_id' in instrument:
                del instrument['_id']
        
        # Recent activity (last 30 days)
        recent_activity = await db.user_reading_history.aggregate([
            {"$match": {"last_accessed": {"$gte": datetime.now(timezone.utc) - timedelta(days=30)}}},
            {"$group": {
                "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$last_accessed"}},
                "reads": {"$sum": 1},
                "unique_users": {"$addToSet": "$user_id"}
            }},
            {"$project": {
                "date": "$_id",
                "reads": 1,
                "unique_users": {"$size": "$unique_users"},
                "_id": 0
            }},
            {"$sort": {"date": 1}}
        ]).to_list(30)
        
        return {
            "generated_at": datetime.now(timezone.utc),
            "user_statistics": {
                "total_users": total_users,
                "active_users_this_week": len(active_users_week),
                "users_by_role": users_by_role
            },
            "content_statistics": {
                "total_instruments": total_instruments,
                "instruments_by_category": instruments_by_category
            },
            "activity_statistics": {
                "total_reads": total_reads,
                "total_downloads": total_downloads[0]["total"] if total_downloads else 0,
                "total_bookmarks": total_bookmarks,
                "total_notes": total_notes
            },
            "popular_content": popular_instruments,
            "activity_trend": recent_activity
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/admin/reports/users")
async def get_user_activity_report(current_user: User = Depends(get_current_user)):
    """Get detailed user activity report (Admin only)"""
    if current_user.role != 'administrator':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        # User engagement metrics
        user_engagement = await db.user_reading_history.aggregate([
            {"$group": {
                "_id": "$user_id",
                "total_reads": {"$sum": 1},
                "total_time": {"$sum": "$time_spent_seconds"},
                "avg_progress": {"$avg": "$progress_percentage"},
                "completed_reads": {"$sum": {"$cond": [{"$eq": ["$completed", True]}, 1, 0]}},
                "last_activity": {"$max": "$last_accessed"}
            }},
            {"$lookup": {
                "from": "users",
                "localField": "_id",
                "foreignField": "id",
                "as": "user"
            }},
            {"$unwind": "$user"},
            {"$project": {
                "user_id": "$_id",
                "username": "$user.username",
                "role": "$user.role",
                "total_reads": 1,
                "total_time_hours": {"$round": [{"$divide": ["$total_time", 3600]}, 2]},
                "avg_progress": {"$round": ["$avg_progress", 1]},
                "completion_rate": {"$round": [{"$multiply": [{"$divide": ["$completed_reads", "$total_reads"]}, 100]}, 1]},
                "last_activity": 1,
                "_id": 0
            }},
            {"$sort": {"total_reads": -1}}
        ]).to_list(100)
        
        # User registration trends
        registration_trend = await db.users.aggregate([
            {"$group": {
                "_id": {"$dateToString": {"format": "%Y-%m", "date": "$created_at"}},
                "new_users": {"$sum": 1}
            }},
            {"$sort": {"_id": 1}}
        ]).to_list(12)
        
        return {
            "generated_at": datetime.now(timezone.utc),
            "user_engagement": user_engagement,
            "registration_trend": registration_trend
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/admin/reports/content")
async def get_content_performance_report(current_user: User = Depends(get_current_user)):
    """Get content performance report (Admin only)"""
    if current_user.role != 'administrator':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        # Content performance metrics (simplified to avoid aggregation issues)
        content_performance = await db.template_library.find({}).sort("view_count", -1).limit(50).to_list(50)
        
        # Clean and format the data
        formatted_content = []
        for content in content_performance:
            if '_id' in content:
                del content['_id']
            formatted_content.append({
                "title": content.get("title", ""),
                "category": content.get("category", "Uncategorized"),
                "created_by_name": content.get("created_by_name", "Unknown"),
                "view_count": content.get("view_count", 0),
                "downloads": content.get("downloads", 0),
                "rating": content.get("rating", 0),
                "created_at": content.get("created_at"),
                "file_size_mb": round((content.get("file_size", 0) / 1048576), 2) if content.get("file_size") else 0
            })
        
        content_performance = formatted_content
        
        # Category performance
        category_performance = await db.template_library.aggregate([
            {"$group": {
                "_id": "$category",
                "total_instruments": {"$sum": 1},
                "total_views": {"$sum": {"$ifNull": ["$view_count", 0]}},
                "total_downloads": {"$sum": {"$ifNull": ["$downloads", 0]}},
                "avg_rating": {"$avg": {"$ifNull": ["$rating", 0]}}
            }},
            {"$sort": {"total_views": -1}}
        ]).to_list(20)
        
        # Clean category performance data
        for category in category_performance:
            if category["_id"] is None:
                category["_id"] = "Uncategorized"
        
        return {
            "generated_at": datetime.now(timezone.utc),
            "content_performance": content_performance,
            "category_performance": category_performance
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ADD SAMPLE DATA FOR TESTING REPORTS
@api_router.post("/admin/add-sample-data")
async def add_sample_data(current_user: User = Depends(get_current_user)):
    """Add sample data to make reports more meaningful"""
    if current_user.role != 'administrator':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        # Add sample reading history
        sample_readings = []
        user_ids = [current_user.id]  # Use current admin user
        
        # Get existing instruments
        instruments = await db.template_library.find({}).limit(5).to_list(5)
        
        for i in range(20):  # Create 20 sample reading records
            reading = {
                "id": str(uuid.uuid4()),
                "user_id": current_user.id,
                "instrument_id": instruments[i % len(instruments)]["id"] if instruments else str(uuid.uuid4()),
                "progress_percentage": random.randint(10, 100),
                "time_spent_seconds": random.randint(300, 3600),
                "completed": random.choice([True, False]),
                "last_accessed": datetime.now(timezone.utc) - timedelta(days=random.randint(0, 30)),
                "created_at": datetime.now(timezone.utc) - timedelta(days=random.randint(0, 30))
            }
            sample_readings.append(reading)
        
        await db.user_reading_history.insert_many(sample_readings)
        
        # Update instrument view counts
        if instruments:
            for instrument in instruments:
                await db.template_library.update_one(
                    {"id": instrument["id"]},
                    {"$set": {
                        "view_count": random.randint(50, 500),
                        "downloads": random.randint(10, 100),
                        "rating": round(random.uniform(3.0, 5.0), 1)
                    }}
                )
        
        return {"message": "Sample data added successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# PDF EXPORT FUNCTIONALITY
@api_router.get("/admin/reports/{report_type}/export-pdf")
async def export_report_pdf(
    report_type: str,
    current_user: User = Depends(get_current_user)
):
    """Export report as PDF"""
    if current_user.role != 'administrator':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        # Get report data
        if report_type == "overview":
            report_data = await get_platform_overview_report(current_user)
        elif report_type == "users":
            report_data = await get_user_activity_report(current_user)
        elif report_type == "content":
            report_data = await get_content_performance_report(current_user)
        else:
            raise HTTPException(status_code=404, detail="Report type not found")
        
        # Generate PDF content
        from reportlab.lib.pagesizes import letter, A4
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import inch
        from reportlab.lib import colors
        from io import BytesIO
        import json
        
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=18)
        
        # Get styles
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle('CustomTitle', parent=styles['Heading1'], fontSize=24, spaceAfter=30, alignment=1)
        heading_style = ParagraphStyle('CustomHeading', parent=styles['Heading2'], fontSize=16, spaceAfter=12)
        
        # Build PDF content
        story = []
        
        # Title
        report_titles = {
            "overview": "Platform Overview Report",
            "users": "User Activity Report", 
            "content": "Content Performance Report"
        }
        
        story.append(Paragraph(report_titles[report_type], title_style))
        story.append(Paragraph(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal']))
        story.append(Spacer(1, 20))
        
        if report_type == "overview":
            # User Statistics
            story.append(Paragraph("User Statistics", heading_style))
            user_data = [
                ["Metric", "Value"],
                ["Total Users", str(report_data.user_statistics.total_users)],
                ["Active This Week", str(report_data.user_statistics.active_users_this_week)]
            ]
            
            # Add users by role
            for role in report_data.user_statistics.users_by_role:
                user_data.append([f"{role['_id']} Users", str(role['count'])])
            
            user_table = Table(user_data)
            user_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            story.append(user_table)
            story.append(Spacer(1, 20))
            
            # Content Statistics
            story.append(Paragraph("Content Statistics", heading_style))
            content_data = [
                ["Metric", "Value"],
                ["Total Instruments", str(report_data.content_statistics.total_instruments)],
                ["Total Reads", str(report_data.activity_statistics.total_reads)],
                ["Total Downloads", str(report_data.activity_statistics.total_downloads)],
                ["Total Bookmarks", str(report_data.activity_statistics.total_bookmarks)],
                ["Total Notes", str(report_data.activity_statistics.total_notes)]
            ]
            
            content_table = Table(content_data)
            content_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            story.append(content_table)
            
        elif report_type == "users":
            # Top Users
            story.append(Paragraph("Top Active Users", heading_style))
            if report_data.user_engagement:
                user_data = [["Username", "Role", "Total Reads", "Hours", "Completion %"]]
                for user in report_data.user_engagement[:10]:
                    user_data.append([
                        user['username'],
                        user['role'].replace('_', ' ').title(),
                        str(user['total_reads']),
                        str(user['total_time_hours']),
                        str(user['completion_rate']) + "%"
                    ])
                
                users_table = Table(user_data)
                users_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 10),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                story.append(users_table)
            else:
                story.append(Paragraph("No user engagement data available", styles['Normal']))
                
        elif report_type == "content":
            # Content Performance
            story.append(Paragraph("Top Performing Content", heading_style))
            if report_data.content_performance:
                content_data = [["Title", "Category", "Views", "Downloads", "Rating"]]
                for content in report_data.content_performance[:10]:
                    content_data.append([
                        content['title'][:30] + "..." if len(content['title']) > 30 else content['title'],
                        content['category'] or "N/A",
                        str(content['view_count']),
                        str(content['downloads']),
                        str(round(content['rating'], 1))
                    ])
                
                content_table = Table(content_data)
                content_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 9),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                story.append(content_table)
            else:
                story.append(Paragraph("No content performance data available", styles['Normal']))
        
        # Build PDF
        doc.build(story)
        buffer.seek(0)
        
        return Response(
            content=buffer.getvalue(),
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={report_type}_report_{datetime.now().strftime('%Y%m%d')}.pdf"}
        )
        
    except ImportError:
        # If reportlab is not installed, fall back to JSON
        raise HTTPException(status_code=500, detail="PDF generation not available. Please install reportlab.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# =============================================================================
# SOURCE CODE DOCUMENTATION EXPORT
# =============================================================================

@api_router.get("/admin/source-code-documentation")
async def get_source_code_documentation(current_user: User = Depends(get_current_user)):
    """Get complete source code documentation"""
    if current_user.role != 'administrator':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        file_path = "/app/COMPLETE_SOURCE_CODE_DOCUMENTATION.md"
        
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
            
        return {
            "filename": "COMPLETE_SOURCE_CODE_DOCUMENTATION.md",
            "content": content,
            "generated_at": datetime.now(timezone.utc),
            "total_lines": len(content.split('\n')),
            "file_size_kb": round(len(content.encode('utf-8')) / 1024, 2)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.get("/admin/source-code-documentation/download")
async def download_source_code_documentation(
    format: str = "html",
    current_user: User = Depends(get_current_user)
):
    """Download complete source code documentation in Word-compatible format"""
    if current_user.role != 'administrator':
        raise HTTPException(status_code=403, detail="Admin access required")
    
    try:
        file_path = "/app/COMPLETE_SOURCE_CODE_DOCUMENTATION.md"
        
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
        
        if format == "html":
            # Convert markdown to HTML for Word compatibility
            import re
            html_content = content
            
            # Convert headers
            html_content = re.sub(r'^# (.*$)', r'<h1 style="color: #2563eb; font-size: 24px; margin-top: 30px;">\1</h1>', html_content, flags=re.MULTILINE)
            html_content = re.sub(r'^## (.*$)', r'<h2 style="color: #1e40af; font-size: 20px; margin-top: 25px;">\1</h2>', html_content, flags=re.MULTILINE)  
            html_content = re.sub(r'^### (.*$)', r'<h3 style="color: #1e3a8a; font-size: 18px; margin-top: 20px;">\1</h3>', html_content, flags=re.MULTILINE)
            
            # Convert bold and italic
            html_content = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', html_content)
            html_content = re.sub(r'\*(.*?)\*', r'<em>\1</em>', html_content)
            
            # Convert code blocks
            html_content = re.sub(r'```(\w+)?\n(.*?)\n```', r'<pre style="background-color: #f3f4f6; padding: 15px; border-radius: 5px; font-family: monospace; overflow-x: auto; white-space: pre;"><code>\2</code></pre>', html_content, flags=re.DOTALL)
            html_content = re.sub(r'`(.*?)`', r'<code style="background-color: #f3f4f6; padding: 2px 4px; border-radius: 3px; font-family: monospace;">\1</code>', html_content)
            
            # Convert links
            html_content = re.sub(r'\[([^\]]+)\]\(([^\)]+)\)', r'<a href="\2" style="color: #2563eb;">\1</a>', html_content)
            
            # Convert bullet points
            html_content = re.sub(r'^\- (.*$)', r'<li>\1</li>', html_content, flags=re.MULTILINE)
            html_content = re.sub(r'(<li>.*</li>)', r'<ul style="margin: 10px 0; padding-left: 20px;">\1</ul>', html_content, flags=re.DOTALL)
            
            # Convert line breaks
            html_content = html_content.replace('\n\n', '</p><p style="margin: 10px 0;">')
            html_content = html_content.replace('\n', '<br>')
            
            # Wrap in complete HTML document
            full_html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Complete Source Code Documentation - Social Impact Platform</title>
    <style>
        body {{ 
            font-family: Arial, sans-serif; 
            line-height: 1.6; 
            margin: 40px; 
            background-color: white;
            color: #333;
        }}
        h1 {{ 
            color: #2563eb; 
            border-bottom: 3px solid #2563eb; 
            padding-bottom: 10px; 
        }}
        h2 {{ 
            color: #1e40af; 
            border-bottom: 2px solid #e5e7eb; 
            padding-bottom: 5px; 
            margin-top: 30px; 
        }}
        h3 {{ 
            color: #1e3a8a; 
            margin-top: 25px; 
        }}
        pre {{
            background-color: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 20px;
            overflow-x: auto;
            font-size: 12px;
            line-height: 1.4;
        }}
        code {{ 
            background-color: #f1f5f9; 
            padding: 2px 6px; 
            border-radius: 4px; 
            font-family: 'Courier New', monospace;
            font-size: 13px;
        }}
        .toc {{
            background-color: #f8fafc;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            padding: 20px;
            margin: 30px 0;
        }}
        .feature-highlight {{
            background-color: #ecfdf5;
            border-left: 4px solid #10b981;
            padding: 15px;
            margin: 20px 0;
        }}
    </style>
</head>
<body>
<div style="text-align: center; margin-bottom: 50px;">
    <h1 style="font-size: 28px; margin-bottom: 10px;">Social Impact Project Management Platform</h1>
    <h2 style="font-size: 20px; color: #6b7280; border: none;">Complete Source Code Documentation</h2>
    <p style="color: #6b7280;">Generated on {datetime.now().strftime('%B %d, %Y at %I:%M %p')}</p>
</div>

<p style="margin: 10px 0;">{html_content}</p>
</body>
</html>"""
            
            return Response(
                content=full_html,
                media_type="text/html",
                headers={"Content-Disposition": "attachment; filename=Complete_Source_Code_Documentation.html"}
            )
        else:
            # Return as markdown
            return Response(
                content=content,
                media_type="text/markdown",
                headers={"Content-Disposition": "attachment; filename=Complete_Source_Code_Documentation.md"}
            )
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()